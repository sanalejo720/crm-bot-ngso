import { ConfigService } from '@nestjs/config';
export declare class EmailService {
    private configService;
    private readonly logger;
    private transporter;
    constructor(configService: ConfigService);
    private verifyConnection;
    sendBackupPasswordEmail(backupId: string, masterPassword: string, createdBy: string, backupName: string, recipients?: string[]): Promise<void>;
    send(options: {
        to: string;
        subject: string;
        html: string;
        from?: string;
    }): Promise<void>;
}
