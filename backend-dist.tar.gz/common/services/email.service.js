"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var EmailService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const nodemailer = __importStar(require("nodemailer"));
let EmailService = EmailService_1 = class EmailService {
    constructor(configService) {
        this.configService = configService;
        this.logger = new common_1.Logger(EmailService_1.name);
        this.transporter = nodemailer.createTransport({
            host: this.configService.get('SMTP_HOST'),
            port: this.configService.get('SMTP_PORT'),
            secure: this.configService.get('SMTP_SECURE') === 'true',
            auth: {
                user: this.configService.get('SMTP_USER'),
                pass: this.configService.get('SMTP_PASSWORD'),
            },
        });
        this.verifyConnection();
    }
    async verifyConnection() {
        try {
            await this.transporter.verify();
            this.logger.log('✅ Conexión SMTP verificada correctamente');
        }
        catch (error) {
            this.logger.error('❌ Error al verificar conexión SMTP:', error.message);
        }
    }
    async sendBackupPasswordEmail(backupId, masterPassword, createdBy, backupName, recipients) {
        try {
            const toAddresses = recipients && recipients.length > 0
                ? recipients.join(', ')
                : this.configService.get('BACKUP_EMAIL_RECIPIENT');
            const from = this.configService.get('SMTP_FROM');
            const mailOptions = {
                from,
                to: toAddresses,
                subject: `🔒 Contraseña de Backup del Sistema - ${backupName}`,
                html: `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <style>
              body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
              }
              .header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 20px;
                border-radius: 8px 8px 0 0;
                text-align: center;
              }
              .content {
                background: #f9f9f9;
                padding: 30px;
                border: 1px solid #ddd;
                border-top: none;
              }
              .password-box {
                background: #fff;
                border: 2px solid #667eea;
                border-radius: 8px;
                padding: 20px;
                margin: 20px 0;
                text-align: center;
              }
              .password {
                font-size: 20px;
                font-weight: bold;
                color: #667eea;
                font-family: 'Courier New', monospace;
                letter-spacing: 2px;
                word-break: break-all;
              }
              .info-table {
                width: 100%;
                margin: 20px 0;
                border-collapse: collapse;
              }
              .info-table td {
                padding: 10px;
                border-bottom: 1px solid #ddd;
              }
              .info-table td:first-child {
                font-weight: bold;
                color: #667eea;
                width: 40%;
              }
              .warning {
                background: #fff3cd;
                border-left: 4px solid #ffc107;
                padding: 15px;
                margin: 20px 0;
                border-radius: 4px;
              }
              .footer {
                text-align: center;
                color: #666;
                font-size: 12px;
                margin-top: 30px;
                padding-top: 20px;
                border-top: 1px solid #ddd;
              }
            </style>
          </head>
          <body>
            <div class="header">
              <h1>🔒 Contraseña de Backup del Sistema</h1>
            </div>
            <div class="content">
              <p>Estimado equipo de Gerencia,</p>
              
              <p>Se ha creado un nuevo backup del sistema CRM NGS&O WhatsApp. A continuación encontrará la contraseña maestra necesaria para descargar y descifrar el backup:</p>
              
              <div class="password-box">
                <p style="margin: 0 0 10px 0; color: #666;">Contraseña Maestra:</p>
                <div class="password">${masterPassword}</div>
              </div>

              <table class="info-table">
                <tr>
                  <td>📦 Nombre del Backup:</td>
                  <td>${backupName}</td>
                </tr>
                <tr>
                  <td>🆔 ID del Backup:</td>
                  <td>${backupId}</td>
                </tr>
                <tr>
                  <td>👤 Creado por:</td>
                  <td>${createdBy}</td>
                </tr>
                <tr>
                  <td>📅 Fecha:</td>
                  <td>${new Date().toLocaleString('es-CO', { timeZone: 'America/Bogota' })}</td>
                </tr>
              </table>

              <div class="warning">
                <strong>⚠️ INFORMACIÓN DE SEGURIDAD IMPORTANTE:</strong>
                <ul style="margin: 10px 0 0 0; padding-left: 20px;">
                  <li>Esta contraseña es única y no se puede recuperar</li>
                  <li>Guarde esta contraseña en un lugar seguro</li>
                  <li>NO comparta esta contraseña con personal no autorizado</li>
                  <li>El backup está cifrado con AES-256-CBC</li>
                  <li>Solo el personal de gerencia puede acceder a esta información</li>
                </ul>
              </div>

              <p><strong>Para descargar el backup:</strong></p>
              <ol>
                <li>Acceda al módulo "Backups IT" en el sistema</li>
                <li>Localice el backup con ID: <code>${backupId}</code></li>
                <li>Haga clic en "Descargar"</li>
                <li>Ingrese la contraseña maestra proporcionada arriba</li>
                <li>El archivo ZIP descargado contendrá el backup completo de la base de datos</li>
              </ol>

              <p>Si tiene alguna pregunta o necesita asistencia, por favor contacte al equipo de IT.</p>

              <div class="footer">
                <p>Este es un correo automático del Sistema CRM NGS&O WhatsApp</p>
                <p>Por favor no responda a este correo</p>
                <p>&copy; ${new Date().getFullYear()} NGS&O - Todos los derechos reservados</p>
              </div>
            </div>
          </body>
          </html>
        `,
                text: `
CONTRASEÑA DE BACKUP DEL SISTEMA CRM NGS&O

Contraseña Maestra: ${masterPassword}

Información del Backup:
- Nombre: ${backupName}
- ID: ${backupId}
- Creado por: ${createdBy}
- Fecha: ${new Date().toLocaleString('es-CO', { timeZone: 'America/Bogota' })}

INFORMACIÓN DE SEGURIDAD:
- Esta contraseña es única y no se puede recuperar
- Guarde esta contraseña en un lugar seguro
- NO comparta esta contraseña con personal no autorizado
- El backup está cifrado con AES-256-CBC

Para descargar el backup, acceda al módulo "Backups IT" en el sistema e ingrese la contraseña proporcionada.

---
Este es un correo automático del Sistema CRM NGS&O WhatsApp
        `,
            };
            const info = await this.transporter.sendMail(mailOptions);
            this.logger.log(`✅ Email de contraseña enviado exitosamente a ${toAddresses} - MessageID: ${info.messageId}`);
        }
        catch (error) {
            this.logger.error(`❌ Error al enviar email de contraseña:`, error.message);
            throw error;
        }
    }
    async send(options) {
        try {
            const from = options.from || this.configService.get('SMTP_FROM');
            const mailOptions = {
                from,
                to: options.to,
                subject: options.subject,
                html: options.html,
            };
            const info = await this.transporter.sendMail(mailOptions);
            this.logger.log(`✅ Email enviado exitosamente a ${options.to} - MessageID: ${info.messageId}`);
        }
        catch (error) {
            this.logger.error(`❌ Error al enviar email a ${options.to}:`, error.message);
            throw error;
        }
    }
};
exports.EmailService = EmailService;
exports.EmailService = EmailService = EmailService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], EmailService);
//# sourceMappingURL=email.service.js.map