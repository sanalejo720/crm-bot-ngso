import { Repository } from 'typeorm';
import { Client, LeadStatus } from './entities/client.entity';
import { CreateClientDto } from './dto/create-client.dto';
import { UpdateClientDto } from './dto/update-client.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { PazYSalvoService } from './paz-y-salvo.service';
import { PaymentRecord } from '../metrics/entities/payment-record.entity';
export declare class ClientsService {
    private clientRepository;
    private paymentRecordRepository;
    private eventEmitter;
    private pazYSalvoService;
    private readonly logger;
    constructor(clientRepository: Repository<Client>, paymentRecordRepository: Repository<PaymentRecord>, eventEmitter: EventEmitter2, pazYSalvoService: PazYSalvoService);
    create(createClientDto: CreateClientDto, createdBy?: string): Promise<Client>;
    findAll(filters?: {
        search?: string;
        leadStatus?: LeadStatus;
        campaignId?: string;
        tags?: string[];
        assignedTo?: string;
    }): Promise<Client[]>;
    findOne(id: string): Promise<Client>;
    findByPhone(phone: string): Promise<Client | null>;
    findByEmail(email: string): Promise<Client | null>;
    update(id: string, updateClientDto: UpdateClientDto): Promise<Client>;
    updateLeadStatus(id: string, leadStatus: LeadStatus): Promise<Client>;
    addNote(id: string, note: string, addedBy: string): Promise<Client>;
    addTags(id: string, tags: string[]): Promise<Client>;
    removeTags(id: string, tags: string[]): Promise<Client>;
    assignTo(id: string, userId: string): Promise<Client>;
    remove(id: string): Promise<void>;
    getStats(campaignId?: string): Promise<{
        total: number;
        byStatus: any;
    }>;
    findDuplicates(): Promise<any[]>;
    bulkImport(clients: CreateClientDto[], createdBy: string): Promise<{
        success: number;
        failed: number;
    }>;
}
