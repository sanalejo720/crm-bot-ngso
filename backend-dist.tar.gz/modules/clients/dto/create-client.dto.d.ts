import { LeadStatus } from '../entities/client.entity';
import { CollectionStatus } from '../enums/collection-status.enum';
export declare class CreateClientDto {
    phone: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    company?: string;
    jobTitle?: string;
    leadStatus?: LeadStatus;
    campaignId?: string;
    tags?: string[];
    metadata?: Record<string, any>;
    assignedTo?: string;
    debtAmount?: number;
    daysOverdue?: number;
    documentNumber?: string;
    collectionStatus?: CollectionStatus;
    customFields?: Record<string, any>;
}
