"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const chats_service_1 = require("./chats.service");
const chats_export_service_1 = require("./chats-export.service");
const assignment_service_1 = require("./services/assignment.service");
const return_to_bot_service_1 = require("./services/return-to-bot.service");
const transfer_service_1 = require("./services/transfer.service");
const chat_resolution_service_1 = require("./services/chat-resolution.service");
const create_chat_dto_1 = require("./dto/create-chat.dto");
const update_chat_dto_1 = require("./dto/update-chat.dto");
const assign_chat_dto_1 = require("./dto/assign-chat.dto");
const return_to_bot_dto_1 = require("./dto/return-to-bot.dto");
const resolve_chat_dto_1 = require("./dto/resolve-chat.dto");
const create_manual_chat_dto_1 = require("./dto/create-manual-chat.dto");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const chat_entity_1 = require("./entities/chat.entity");
let ChatsController = class ChatsController {
    constructor(chatsService, chatsExportService, assignmentService, returnToBotService, transferService, chatResolutionService) {
        this.chatsService = chatsService;
        this.chatsExportService = chatsExportService;
        this.assignmentService = assignmentService;
        this.returnToBotService = returnToBotService;
        this.transferService = transferService;
        this.chatResolutionService = chatResolutionService;
    }
    create(createChatDto) {
        return this.chatsService.create(createChatDto);
    }
    findAll(status, campaignId, assignedAgentId, whatsappNumberId, search, page, limit) {
        return this.chatsService.findAll({
            status,
            campaignId,
            assignedAgentId,
            whatsappNumberId,
            search,
            page: page ? parseInt(page, 10) : undefined,
            limit: limit ? parseInt(limit, 10) : undefined,
        });
    }
    getMyChats(userId, userRole) {
        if (userRole.name === 'Supervisor' || userRole.name === 'Super Admin') {
            return this.chatsService.findAll({});
        }
        return this.chatsService.findAll({ assignedAgentId: userId });
    }
    getWaitingChats(campaignId) {
        return this.chatsService.getWaitingChats(campaignId);
    }
    findOne(id) {
        return this.chatsService.findOne(id);
    }
    update(id, updateChatDto) {
        return this.chatsService.update(id, updateChatDto);
    }
    async getWaitingQueue(campaignId) {
        const chats = await this.assignmentService.getWaitingQueue(campaignId);
        return {
            success: true,
            data: chats,
            total: chats.length,
        };
    }
    async assign(id, assignDto, userId) {
        const chat = await this.assignmentService.assignChatToAgent(id, assignDto.agentId, userId);
        return {
            success: true,
            data: chat,
            message: 'Chat asignado exitosamente',
        };
    }
    reassign(id, assignDto) {
        return this.chatsService.assign(id, assignDto.agentId, assignDto.reason);
    }
    updateStatus(id, body, userId) {
        if (body.status === chat_entity_1.ChatStatus.CLOSED) {
            return this.chatsService.close(id, userId);
        }
        if (body.status === chat_entity_1.ChatStatus.RESOLVED) {
            return this.chatsService.resolve(id, userId);
        }
        return this.chatsService.update(id, { status: body.status });
    }
    async returnToBot(id, returnDto, userId) {
        const chat = await this.returnToBotService.returnChatToBot(id, returnDto.reason, userId, returnDto.notes);
        return {
            success: true,
            data: chat,
            message: 'Chat retornado al bot exitosamente',
        };
    }
    async transfer(id, currentUserId, transferDto) {
        const chat = await this.transferService.transferChat(id, transferDto.newAgentId, currentUserId, transferDto.reason);
        return {
            success: true,
            data: chat,
            message: 'Chat transferido exitosamente',
        };
    }
    async getTransferHistory(id) {
        const history = await this.transferService.getTransferHistory(id);
        return {
            success: true,
            data: history,
        };
    }
    async transferToCampaign(id, body, userId) {
        const chat = await this.chatsService.transferToCampaign(id, body.campaignId, userId);
        return {
            success: true,
            data: chat,
            message: 'Chat transferido a otra campaña exitosamente',
        };
    }
    close(id, userId) {
        return this.chatsService.close(id, userId);
    }
    async resolve(id, resolveDto, userId) {
        const chat = await this.chatResolutionService.resolveChat(id, resolveDto, userId);
        return {
            success: true,
            data: chat,
            message: 'Chat resuelto exitosamente',
        };
    }
    async getResolutionStats(agentId, startDate, endDate) {
        const stats = await this.chatResolutionService.getResolutionStatsByAgent(agentId, startDate ? new Date(startDate) : undefined, endDate ? new Date(endDate) : undefined);
        return {
            success: true,
            data: stats,
        };
    }
    async getGlobalResolutionStats(startDate, endDate, campaignId) {
        const stats = await this.chatResolutionService.getGlobalResolutionStats(startDate ? new Date(startDate) : undefined, endDate ? new Date(endDate) : undefined, campaignId);
        return {
            success: true,
            data: stats,
        };
    }
    getAgentStats(agentId) {
        return this.chatsService.getAgentStats(agentId);
    }
    async exportChatToPDF(id, body, agentId) {
        const result = await this.chatsExportService.exportChatToPDF(id, body.closureType, agentId);
        return {
            success: true,
            message: 'Cierre de negociación enviado exitosamente a supervisores',
            data: {
                fileName: result.fileName,
                ticketNumber: result.ticketNumber,
            },
        };
    }
    async updateContactInfo(id, body) {
        return this.chatsService.updateContactInfo(id, body);
    }
    async createManualChat(createManualChatDto, agentId, userRole) {
        const roleMap = {
            'Super Admin': 'superadmin',
            'Administrador': 'admin',
            'Supervisor': 'supervisor',
            'Agente': 'agent',
        };
        const creatorRole = roleMap[userRole.name] || 'agent';
        const result = await this.chatsService.createManualChat(createManualChatDto.phone, agentId, createManualChatDto.contactName, createManualChatDto.campaignId, createManualChatDto.assignToAgentId, creatorRole, createManualChatDto.templateSid, createManualChatDto.templateVariables);
        return {
            success: true,
            message: result.templateSent
                ? 'Chat creado y plantilla enviada exitosamente.'
                : result.isNew
                    ? 'Chat creado exitosamente. Puede enviar un mensaje inicial.'
                    : 'Chat existente recuperado.',
            data: {
                chat: result.chat,
                isNew: result.isNew,
                canSendMessage: result.canSendMessage,
                waitingResponse: result.waitingResponse,
                previousAgent: result.previousAgent,
                ticketHistory: result.ticketHistory,
                templateSent: result.templateSent,
                info: result.waitingResponse
                    ? 'Límite: 1 mensaje por día hasta que el cliente responda.'
                    : undefined,
            },
        };
    }
    async getClientHistory(phone, campaignId) {
        const history = await this.chatsService.getClientHistory(phone, campaignId);
        return {
            success: true,
            data: history,
        };
    }
    async canSendMessage(id) {
        const result = await this.chatsService.canSendManualMessage(id);
        return {
            success: true,
            data: result,
        };
    }
};
exports.ChatsController = ChatsController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Crear nuevo chat' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_chat_dto_1.CreateChatDto]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener todos los chats (solo supervisores)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'manage' }),
    __param(0, (0, common_1.Query)('status')),
    __param(1, (0, common_1.Query)('campaignId')),
    __param(2, (0, common_1.Query)('assignedAgentId')),
    __param(3, (0, common_1.Query)('whatsappNumberId')),
    __param(4, (0, common_1.Query)('search')),
    __param(5, (0, common_1.Query)('page')),
    __param(6, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('my-chats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener mis chats asignados (agentes) o todos (supervisores)' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('role')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "getMyChats", null);
__decorate([
    (0, common_1.Get)('waiting/:campaignId'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener chats en cola' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Param)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "getWaitingChats", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener chat por ID' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Actualizar chat' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_chat_dto_1.UpdateChatDto]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "update", null);
__decorate([
    (0, common_1.Get)('waiting-queue'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener cola de chats en espera de asignación' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Query)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "getWaitingQueue", null);
__decorate([
    (0, common_1.Post)(':id/assign'),
    (0, swagger_1.ApiOperation)({ summary: 'Asignar chat a un agente desde cola de espera' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'assign' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, assign_chat_dto_1.AssignChatDto, String]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "assign", null);
__decorate([
    (0, common_1.Patch)(':id/assign'),
    (0, swagger_1.ApiOperation)({ summary: 'Asignar/Reasignar chat a un agente (para supervisores)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'assign' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, assign_chat_dto_1.AssignChatDto]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "reassign", null);
__decorate([
    (0, common_1.Patch)(':id/status'),
    (0, swagger_1.ApiOperation)({ summary: 'Cambiar estado del chat' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Post)(':id/return-to-bot'),
    (0, swagger_1.ApiOperation)({ summary: 'Retornar chat al bot' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, return_to_bot_dto_1.ReturnToBotDto, String]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "returnToBot", null);
__decorate([
    (0, common_1.Post)(':id/transfer'),
    (0, swagger_1.ApiOperation)({ summary: 'Transferir chat a otro agente' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'transfer' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, assign_chat_dto_1.TransferChatDto]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "transfer", null);
__decorate([
    (0, common_1.Get)(':id/transfer-history'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener historial de transferencias de un chat' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "getTransferHistory", null);
__decorate([
    (0, common_1.Patch)(':id/transfer-campaign'),
    (0, swagger_1.ApiOperation)({ summary: 'Transferir chat a otra campaña' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "transferToCampaign", null);
__decorate([
    (0, common_1.Post)(':id/close'),
    (0, swagger_1.ApiOperation)({ summary: 'Cerrar chat' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "close", null);
__decorate([
    (0, common_1.Post)(':id/resolve'),
    (0, swagger_1.ApiOperation)({ summary: 'Resolver chat con resultado de gestión' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, resolve_chat_dto_1.ResolveChatDto, String]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "resolve", null);
__decorate([
    (0, common_1.Get)(':id/resolution-stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas de resolución de un agente' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "getResolutionStats", null);
__decorate([
    (0, common_1.Get)('resolution-stats/global'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas de resolución global' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "getGlobalResolutionStats", null);
__decorate([
    (0, common_1.Get)(':id/stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas de un agente' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "getAgentStats", null);
__decorate([
    (0, common_1.Post)(':id/export-pdf'),
    (0, swagger_1.ApiOperation)({ summary: 'Enviar cierre de negociación (PDF cifrado a supervisores)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "exportChatToPDF", null);
__decorate([
    (0, common_1.Patch)(':id/contact'),
    (0, swagger_1.ApiOperation)({ summary: 'Actualizar información del contacto del chat' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "updateContactInfo", null);
__decorate([
    (0, common_1.Post)('manual'),
    (0, swagger_1.ApiOperation)({ summary: 'Crear chat manual (agente inicia conversación con un número)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, current_user_decorator_1.CurrentUser)('role')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_manual_chat_dto_1.CreateManualChatDto, String, Object]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "createManualChat", null);
__decorate([
    (0, common_1.Get)('client-history/:phone'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener historial de un cliente por teléfono' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Param)('phone')),
    __param(1, (0, common_1.Query)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "getClientHistory", null);
__decorate([
    (0, common_1.Get)(':id/can-send'),
    (0, swagger_1.ApiOperation)({ summary: 'Verificar si se puede enviar mensaje en chat manual' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "canSendMessage", null);
exports.ChatsController = ChatsController = __decorate([
    (0, swagger_1.ApiTags)('chats'),
    (0, common_1.Controller)('chats'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [chats_service_1.ChatsService,
        chats_export_service_1.ChatsExportService,
        assignment_service_1.AssignmentService,
        return_to_bot_service_1.ReturnToBotService,
        transfer_service_1.TransferService,
        chat_resolution_service_1.ChatResolutionService])
], ChatsController);
//# sourceMappingURL=chats.controller.js.map