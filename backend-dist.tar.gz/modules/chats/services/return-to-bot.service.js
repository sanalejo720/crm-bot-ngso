"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ReturnToBotService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReturnToBotService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const chat_entity_1 = require("../entities/chat.entity");
const chat_state_service_1 = require("./chat-state.service");
const whatsapp_service_1 = require("../../whatsapp/whatsapp.service");
const chats_export_service_1 = require("../chats-export.service");
const message_entity_1 = require("../../messages/entities/message.entity");
let ReturnToBotService = ReturnToBotService_1 = class ReturnToBotService {
    constructor(chatRepository, chatStateService, whatsappService, chatsExportService) {
        this.chatRepository = chatRepository;
        this.chatStateService = chatStateService;
        this.whatsappService = whatsappService;
        this.chatsExportService = chatsExportService;
        this.logger = new common_1.Logger(ReturnToBotService_1.name);
    }
    async returnChatToBot(chatId, reason, agentId, notes) {
        const chat = await this.chatRepository.findOne({
            where: { id: chatId },
            relations: ['assignedAgent', 'campaign', 'whatsappNumber', 'debtor'],
        });
        if (!chat) {
            throw new common_1.NotFoundException(`Chat ${chatId} no encontrado`);
        }
        const validStatuses = ['waiting', 'active', 'pending'];
        if (!validStatuses.includes(chat.status)) {
            throw new common_1.BadRequestException(`No se puede retornar al bot un chat en estado ${chat.status}. Estados válidos: ${validStatuses.join(', ')}`);
        }
        this.logger.log(`🔄 Iniciando retorno al bot para chat ${chatId}. Motivo: ${reason}`);
        try {
            this.logger.log(`📄 Generando PDF del chat ${chatId}...`);
            await this.chatsExportService.exportChatToPDF(chatId, 'promise', agentId);
            this.logger.log(`✅ PDF generado exitosamente`);
            const farewellMessage = this.generateFarewellMessage(reason);
            if (chat.whatsappNumber?.id) {
                await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, farewellMessage, message_entity_1.MessageType.TEXT);
                this.logger.log(`💬 Mensaje de despedida enviado al cliente`);
            }
            await this.chatStateService.transition(chatId, 'bot', 'bot_active', {
                reason: `Retornado al bot: ${reason}${notes ? ' - ' + notes : ''}`,
                triggeredBy: 'agent',
                agentId,
            });
            if (chat.assignedAgentId) {
                await this.chatRepository.update(chatId, {
                    assignedAgentId: null,
                });
                await this.chatRepository.manager.query(`UPDATE users SET "currentChatsCount" = GREATEST("currentChatsCount" - 1, 0) WHERE id = $1`, [chat.assignedAgentId]);
            }
            await this.chatRepository.update(chatId, {
                transferCount: 0,
                botRestartCount: () => '"botRestartCount" + 1',
            });
            this.logger.log(`✅ Chat ${chatId} retornado al bot exitosamente`);
            return this.chatRepository.findOne({
                where: { id: chatId },
                relations: ['assignedAgent', 'campaign', 'debtor'],
            });
        }
        catch (error) {
            this.logger.error(`❌ Error retornando chat ${chatId} al bot: ${error.message}`, error.stack);
            throw error;
        }
    }
    generateFarewellMessage(reason) {
        const greeting = 'Hola';
        const messages = {
            'cliente_no_responde': `${greeting}, hemos intentado comunicarnos contigo pero no hemos recibido respuesta. Si necesitas ayuda, puedes escribirnos nuevamente y con gusto te atenderemos. ¡Que tengas un excelente día! 😊`,
            'solicitud_completada': `${greeting}, hemos completado tu solicitud exitosamente. Si necesitas algo más, no dudes en escribirnos. ¡Gracias por comunicarte con nosotros! 🙌`,
            'informacion_enviada': `${greeting}, te hemos enviado toda la información solicitada. Si tienes alguna duda adicional, puedes escribirnos cuando lo necesites. ¡Estamos para ayudarte! 📋`,
            'derivado_otro_canal': `${greeting}, tu consulta será gestionada por otro canal. En breve nos comunicaremos contigo. ¡Gracias por tu paciencia! 📞`,
            'fuera_horario': `${greeting}, te contactamos fuera del horario de atención. Puedes escribirnos en nuestro horario de atención y con gusto te ayudaremos. ¡Hasta pronto! 🕐`,
            default: `${greeting}, gracias por comunicarte con nosotros. Si necesitas ayuda en el futuro, estaremos disponibles para atenderte. ¡Que tengas un excelente día! 😊`,
        };
        return messages[reason] || messages.default;
    }
    async getReturnStats(agentId, startDate, endDate) {
        const query = this.chatRepository
            .createQueryBuilder('chat')
            .select('COUNT(*)', 'total')
            .addSelect('chat.status', 'current_status')
            .where('chat.botRestartCount > 0');
        if (agentId) {
            query.andWhere('EXISTS (SELECT 1 FROM chat_state_transitions WHERE "chatId" = chat.id AND "agentId" = :agentId AND reason LIKE :pattern)', { agentId, pattern: 'Retornado al bot:%' });
        }
        if (startDate && endDate) {
            query.andWhere('chat.updatedAt BETWEEN :startDate AND :endDate', {
                startDate,
                endDate,
            });
        }
        query.groupBy('chat.status');
        return query.getRawMany();
    }
};
exports.ReturnToBotService = ReturnToBotService;
exports.ReturnToBotService = ReturnToBotService = ReturnToBotService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        chat_state_service_1.ChatStateService,
        whatsapp_service_1.WhatsappService,
        chats_export_service_1.ChatsExportService])
], ReturnToBotService);
//# sourceMappingURL=return-to-bot.service.js.map