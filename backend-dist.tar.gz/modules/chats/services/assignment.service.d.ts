import { Repository } from 'typeorm';
import { Chat } from '../entities/chat.entity';
import { User } from '../../users/entities/user.entity';
import { ChatStateService } from './chat-state.service';
export declare class AssignmentService {
    private chatRepository;
    private userRepository;
    private chatStateService;
    private readonly logger;
    constructor(chatRepository: Repository<Chat>, userRepository: Repository<User>, chatStateService: ChatStateService);
    assignChatToAgent(chatId: string, agentId: string, assignedBy: string): Promise<Chat>;
    getWaitingQueue(campaignId?: string): Promise<Chat[]>;
    findAvailableAgent(campaignId?: string): Promise<User | null>;
    calculatePriority(chat: Chat): number;
    updateQueuePriorities(): Promise<void>;
}
