"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var TransferService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransferService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const chat_entity_1 = require("../entities/chat.entity");
const user_entity_1 = require("../../users/entities/user.entity");
const chat_state_service_1 = require("./chat-state.service");
const whatsapp_service_1 = require("../../whatsapp/whatsapp.service");
const event_emitter_1 = require("@nestjs/event-emitter");
const message_entity_1 = require("../../messages/entities/message.entity");
let TransferService = TransferService_1 = class TransferService {
    constructor(chatRepository, userRepository, chatStateService, whatsappService, eventEmitter) {
        this.chatRepository = chatRepository;
        this.userRepository = userRepository;
        this.chatStateService = chatStateService;
        this.whatsappService = whatsappService;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(TransferService_1.name);
    }
    async transferChat(chatId, newAgentId, currentAgentId, reason, notes) {
        const chat = await this.chatRepository.findOne({
            where: { id: chatId },
            relations: ['assignedAgent', 'campaign', 'whatsappNumber', 'debtor'],
        });
        if (!chat) {
            throw new common_1.NotFoundException(`Chat ${chatId} no encontrado`);
        }
        if (chat.assignedAgentId !== currentAgentId) {
            throw new common_1.BadRequestException('Solo puedes transferir chats asignados a ti');
        }
        const validStatuses = ['waiting', 'active', 'pending'];
        if (!validStatuses.includes(chat.status)) {
            throw new common_1.BadRequestException(`No se puede transferir un chat en estado ${chat.status}`);
        }
        const newAgent = await this.userRepository.findOne({
            where: { id: newAgentId, isAgent: true, status: 'active' },
        });
        if (!newAgent) {
            throw new common_1.NotFoundException('Agente destino no encontrado o no disponible');
        }
        if (newAgent.currentChatsCount >= newAgent.maxConcurrentChats) {
            throw new common_1.BadRequestException(`El agente ${newAgent.fullName} ha alcanzado su capacidad máxima (${newAgent.maxConcurrentChats} chats)`);
        }
        this.logger.log(`🔄 Iniciando transferencia del chat ${chatId} de ${chat.assignedAgent?.fullName} a ${newAgent.fullName}`);
        try {
            await this.chatStateService.transition(chatId, 'active', 'transferring', {
                reason: `Transferencia: ${reason}${notes ? ' - ' + notes : ''}`,
                triggeredBy: 'agent',
                agentId: currentAgentId,
            });
            this.eventEmitter.emit('chat.transfer.initiated', {
                chatId,
                fromAgentId: currentAgentId,
                toAgentId: newAgentId,
                reason,
            });
            if (chat.whatsappNumber?.id) {
                const clientMessage = `Tu conversación está siendo transferida a ${newAgent.fullName}. En un momento te atenderá. ⏳`;
                await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, clientMessage, message_entity_1.MessageType.TEXT);
            }
            await this.chatRepository.update(chatId, {
                assignedAgentId: newAgentId,
            });
            await this.userRepository.decrement({ id: currentAgentId }, 'currentChatsCount', 1);
            await this.userRepository.increment({ id: newAgentId }, 'currentChatsCount', 1);
            await this.chatRepository.increment({ id: chatId }, 'transferCount', 1);
            await this.chatStateService.transition(chatId, 'active', 'active_conversation', {
                reason: `Chat transferido exitosamente a ${newAgent.fullName}`,
                triggeredBy: 'system',
                agentId: newAgentId,
            });
            this.eventEmitter.emit('chat.transfer.completed', {
                chatId,
                fromAgentId: currentAgentId,
                toAgentId: newAgentId,
                reason,
                chat,
            });
            this.logger.log(`✅ Chat ${chatId} transferido exitosamente de ${chat.assignedAgent?.fullName} a ${newAgent.fullName}`);
            return this.chatRepository.findOne({
                where: { id: chatId },
                relations: ['assignedAgent', 'campaign', 'debtor'],
            });
        }
        catch (error) {
            this.logger.error(`❌ Error transfiriendo chat ${chatId}: ${error.message}`, error.stack);
            try {
                await this.chatStateService.transition(chatId, 'active', 'active_conversation', {
                    reason: 'Transferencia fallida, revertida a estado activo',
                    triggeredBy: 'system',
                    agentId: currentAgentId,
                });
            }
            catch (revertError) {
                this.logger.error('Error revirtiendo estado después de fallo', revertError);
            }
            throw error;
        }
    }
    async getTransferHistory(chatId) {
        const transitions = await this.chatRepository.manager.query(`SELECT 
        cst.*,
        u."fullName" as "agentName"
      FROM chat_state_transitions cst
      LEFT JOIN users u ON u.id = cst."agentId"
      WHERE cst."chatId" = $1 
        AND cst."toSubStatus" = 'transferring'
      ORDER BY cst."createdAt" DESC`, [chatId]);
        return transitions;
    }
    async getTransferStats(agentId, startDate, endDate) {
        let query = `
      SELECT 
        COUNT(*) as "totalTransfers",
        COUNT(DISTINCT "chatId") as "uniqueChats",
        AVG(c."transferCount") as "avgTransfersPerChat"
      FROM chat_state_transitions cst
      JOIN chats c ON c.id = cst."chatId"
      WHERE cst."toSubStatus" = 'transferring'
    `;
        const params = [];
        let paramIndex = 1;
        if (agentId) {
            query += ` AND cst."agentId" = $${paramIndex}`;
            params.push(agentId);
            paramIndex++;
        }
        if (startDate && endDate) {
            query += ` AND cst."createdAt" BETWEEN $${paramIndex} AND $${paramIndex + 1}`;
            params.push(startDate, endDate);
        }
        const result = await this.chatRepository.manager.query(query, params);
        return result[0];
    }
};
exports.TransferService = TransferService;
exports.TransferService = TransferService = TransferService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        chat_state_service_1.ChatStateService,
        whatsapp_service_1.WhatsappService,
        event_emitter_1.EventEmitter2])
], TransferService);
//# sourceMappingURL=transfer.service.js.map