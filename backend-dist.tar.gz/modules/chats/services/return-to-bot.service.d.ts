import { Repository } from 'typeorm';
import { Chat } from '../entities/chat.entity';
import { ChatStateService } from './chat-state.service';
import { WhatsappService } from '../../whatsapp/whatsapp.service';
import { ChatsExportService } from '../chats-export.service';
export declare class ReturnToBotService {
    private chatRepository;
    private chatStateService;
    private whatsappService;
    private chatsExportService;
    private readonly logger;
    constructor(chatRepository: Repository<Chat>, chatStateService: ChatStateService, whatsappService: WhatsappService, chatsExportService: ChatsExportService);
    returnChatToBot(chatId: string, reason: string, agentId: string, notes?: string): Promise<Chat>;
    private generateFarewellMessage;
    getReturnStats(agentId?: string, startDate?: Date, endDate?: Date): Promise<any[]>;
}
