import { Repository } from 'typeorm';
import { Chat } from '../entities/chat.entity';
import { User } from '../../users/entities/user.entity';
import { ChatStateService } from './chat-state.service';
import { WhatsappService } from '../../whatsapp/whatsapp.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
export declare class TransferService {
    private chatRepository;
    private userRepository;
    private chatStateService;
    private whatsappService;
    private eventEmitter;
    private readonly logger;
    constructor(chatRepository: Repository<Chat>, userRepository: Repository<User>, chatStateService: ChatStateService, whatsappService: WhatsappService, eventEmitter: EventEmitter2);
    transferChat(chatId: string, newAgentId: string, currentAgentId: string, reason: string, notes?: string): Promise<Chat>;
    getTransferHistory(chatId: string): Promise<any>;
    getTransferStats(agentId?: string, startDate?: Date, endDate?: Date): Promise<any>;
}
