export declare enum ResolutionType {
    PAID = "paid",
    PROMISE = "promise",
    NO_AGREEMENT = "no_agreement",
    CALLBACK = "callback"
}
export declare class ResolveChatDto {
    resolutionType: ResolutionType;
    paymentMethod?: string;
    paymentAmount?: number;
    promiseDate?: string;
    promiseAmount?: number;
    promisePaymentMethod?: string;
    noAgreementReason?: string;
    callbackDate?: string;
    callbackNotes?: string;
    notes?: string;
    sendClosingMessage?: boolean;
}
