export declare class CreateChatDto {
    externalId: string;
    contactPhone: string;
    contactName?: string;
    campaignId: string;
    whatsappNumberId: string;
    tags?: string[];
    priority?: number;
    assignedToUserId?: string;
    metadata?: Record<string, any>;
}
