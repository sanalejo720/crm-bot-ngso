export declare class ReturnToBotDto {
    reason: string;
    notes?: string;
}
