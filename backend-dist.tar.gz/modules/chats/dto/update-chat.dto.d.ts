import { ChatStatus } from '../entities/chat.entity';
import { CreateChatDto } from './create-chat.dto';
declare const UpdateChatDto_base: import("@nestjs/common").Type<Partial<CreateChatDto>>;
export declare class UpdateChatDto extends UpdateChatDto_base {
    status?: ChatStatus;
    subStatus?: string;
    assignedAgentId?: string;
    assignedAt?: Date;
    clientId?: string;
    botContext?: {
        sessionId?: string;
        flowId?: string;
        currentNodeId?: string;
        variables?: Record<string, any>;
        transferredToAgent?: boolean;
        autoAssigned?: boolean;
        assignedAgentName?: string;
        closureType?: 'paid' | 'promise';
    };
    closedAt?: Date;
}
export {};
