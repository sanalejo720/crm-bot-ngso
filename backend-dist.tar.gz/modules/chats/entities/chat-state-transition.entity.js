"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatStateTransition = void 0;
const typeorm_1 = require("typeorm");
const chat_entity_1 = require("./chat.entity");
const user_entity_1 = require("../../users/entities/user.entity");
let ChatStateTransition = class ChatStateTransition {
};
exports.ChatStateTransition = ChatStateTransition;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], ChatStateTransition.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'chat_id' }),
    __metadata("design:type", String)
], ChatStateTransition.prototype, "chatId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => chat_entity_1.Chat),
    (0, typeorm_1.JoinColumn)({ name: 'chat_id' }),
    __metadata("design:type", chat_entity_1.Chat)
], ChatStateTransition.prototype, "chat", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'from_status' }),
    __metadata("design:type", String)
], ChatStateTransition.prototype, "fromStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'to_status' }),
    __metadata("design:type", String)
], ChatStateTransition.prototype, "toStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'from_sub_status', nullable: true }),
    __metadata("design:type", String)
], ChatStateTransition.prototype, "fromSubStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'to_sub_status', nullable: true }),
    __metadata("design:type", String)
], ChatStateTransition.prototype, "toSubStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ChatStateTransition.prototype, "reason", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'triggered_by' }),
    __metadata("design:type", String)
], ChatStateTransition.prototype, "triggeredBy", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'agent_id', nullable: true }),
    __metadata("design:type", String)
], ChatStateTransition.prototype, "agentId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.User, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'agent_id' }),
    __metadata("design:type", user_entity_1.User)
], ChatStateTransition.prototype, "agent", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', default: {} }),
    __metadata("design:type", Object)
], ChatStateTransition.prototype, "metadata", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], ChatStateTransition.prototype, "createdAt", void 0);
exports.ChatStateTransition = ChatStateTransition = __decorate([
    (0, typeorm_1.Entity)('chat_state_transitions')
], ChatStateTransition);
//# sourceMappingURL=chat-state-transition.entity.js.map