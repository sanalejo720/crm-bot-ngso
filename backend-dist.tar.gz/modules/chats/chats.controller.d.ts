import { ChatsService } from './chats.service';
import { ChatsExportService } from './chats-export.service';
import { AssignmentService } from './services/assignment.service';
import { ReturnToBotService } from './services/return-to-bot.service';
import { TransferService } from './services/transfer.service';
import { ChatResolutionService } from './services/chat-resolution.service';
import { CreateChatDto } from './dto/create-chat.dto';
import { UpdateChatDto } from './dto/update-chat.dto';
import { AssignChatDto, TransferChatDto } from './dto/assign-chat.dto';
import { ReturnToBotDto } from './dto/return-to-bot.dto';
import { ResolveChatDto } from './dto/resolve-chat.dto';
import { CreateManualChatDto } from './dto/create-manual-chat.dto';
import { ChatStatus } from './entities/chat.entity';
export declare class ChatsController {
    private readonly chatsService;
    private readonly chatsExportService;
    private readonly assignmentService;
    private readonly returnToBotService;
    private readonly transferService;
    private readonly chatResolutionService;
    constructor(chatsService: ChatsService, chatsExportService: ChatsExportService, assignmentService: AssignmentService, returnToBotService: ReturnToBotService, transferService: TransferService, chatResolutionService: ChatResolutionService);
    create(createChatDto: CreateChatDto): Promise<import("./entities/chat.entity").Chat>;
    findAll(status?: ChatStatus, campaignId?: string, assignedAgentId?: string, whatsappNumberId?: string, search?: string, page?: string, limit?: string): Promise<{
        data: import("./entities/chat.entity").Chat[];
        pagination?: {
            page: number;
            limit: number;
            total: number;
            totalPages: number;
        };
    }>;
    getMyChats(userId: string, userRole: {
        name: string;
    }): Promise<{
        data: import("./entities/chat.entity").Chat[];
        pagination?: {
            page: number;
            limit: number;
            total: number;
            totalPages: number;
        };
    }>;
    getWaitingChats(campaignId: string): Promise<import("./entities/chat.entity").Chat[]>;
    findOne(id: string): Promise<import("./entities/chat.entity").Chat>;
    update(id: string, updateChatDto: UpdateChatDto): Promise<import("./entities/chat.entity").Chat>;
    getWaitingQueue(campaignId?: string): Promise<{
        success: boolean;
        data: import("./entities/chat.entity").Chat[];
        total: number;
    }>;
    assign(id: string, assignDto: AssignChatDto, userId: string): Promise<{
        success: boolean;
        data: import("./entities/chat.entity").Chat;
        message: string;
    }>;
    reassign(id: string, assignDto: AssignChatDto): Promise<import("./entities/chat.entity").Chat>;
    updateStatus(id: string, body: {
        status: ChatStatus;
    }, userId: string): Promise<import("./entities/chat.entity").Chat>;
    returnToBot(id: string, returnDto: ReturnToBotDto, userId: string): Promise<{
        success: boolean;
        data: import("./entities/chat.entity").Chat;
        message: string;
    }>;
    transfer(id: string, currentUserId: string, transferDto: TransferChatDto): Promise<{
        success: boolean;
        data: import("./entities/chat.entity").Chat;
        message: string;
    }>;
    getTransferHistory(id: string): Promise<{
        success: boolean;
        data: any;
    }>;
    transferToCampaign(id: string, body: {
        campaignId: string;
    }, userId: string): Promise<{
        success: boolean;
        data: import("./entities/chat.entity").Chat;
        message: string;
    }>;
    close(id: string, userId: string): Promise<import("./entities/chat.entity").Chat>;
    resolve(id: string, resolveDto: ResolveChatDto, userId: string): Promise<{
        success: boolean;
        data: import("./entities/chat.entity").Chat;
        message: string;
    }>;
    getResolutionStats(agentId: string, startDate?: string, endDate?: string): Promise<{
        success: boolean;
        data: any;
    }>;
    getGlobalResolutionStats(startDate?: string, endDate?: string, campaignId?: string): Promise<{
        success: boolean;
        data: any;
    }>;
    getAgentStats(agentId: string): Promise<{
        active: number;
        resolved: number;
        total: number;
    }>;
    exportChatToPDF(id: string, body: {
        closureType: 'paid' | 'promise';
    }, agentId: string): Promise<{
        success: boolean;
        message: string;
        data: {
            fileName: string;
            ticketNumber: string;
        };
    }>;
    updateContactInfo(id: string, body: {
        contactName?: string;
        contactPhone?: string;
    }): Promise<import("./entities/chat.entity").Chat>;
    createManualChat(createManualChatDto: CreateManualChatDto, agentId: string, userRole: {
        name: string;
    }): Promise<{
        success: boolean;
        message: string;
        data: {
            chat: import("./entities/chat.entity").Chat;
            isNew: boolean;
            canSendMessage: boolean;
            waitingResponse: boolean;
            previousAgent: {
                id: string;
                name: string;
                email: string;
            };
            ticketHistory: {
                ticketNumber: string;
                closedAt: Date;
                typification: string;
                typificationCategory: string;
                agentName: string;
                campaignName: string;
            }[];
            templateSent: boolean;
            info: string;
        };
    }>;
    getClientHistory(phone: string, campaignId?: string): Promise<{
        success: boolean;
        data: {
            previousAgent: {
                id: string;
                name: string;
                email: string;
            } | null;
            ticketHistory: Array<{
                ticketNumber: string;
                closedAt: Date;
                typification: string;
                typificationCategory: string;
                agentName: string;
                campaignName: string;
            }>;
            totalChats: number;
            uniqueClient: boolean;
        };
    }>;
    canSendMessage(id: string): Promise<{
        success: boolean;
        data: {
            canSend: boolean;
            reason?: string;
        };
    }>;
}
