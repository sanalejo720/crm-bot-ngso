"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AuditService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const audit_log_entity_1 = require("./entities/audit-log.entity");
const event_emitter_1 = require("@nestjs/event-emitter");
let AuditService = AuditService_1 = class AuditService {
    constructor(auditLogRepository, eventEmitter) {
        this.auditLogRepository = auditLogRepository;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(AuditService_1.name);
    }
    async log(data) {
        const auditLog = this.auditLogRepository.create(data);
        const saved = await this.auditLogRepository.save(auditLog);
        return Array.isArray(saved) ? saved[0] : saved;
    }
    async findAll(filters) {
        const query = this.auditLogRepository.createQueryBuilder('audit');
        if (filters?.userId) {
            query.andWhere('audit.userId = :userId', { userId: filters.userId });
        }
        if (filters?.module) {
            query.andWhere('audit.module = :module', { module: filters.module });
        }
        if (filters?.action) {
            query.andWhere('audit.action = :action', { action: filters.action });
        }
        if (filters?.entityType) {
            query.andWhere('audit.entityType = :entityType', { entityType: filters.entityType });
        }
        if (filters?.startDate && filters?.endDate) {
            query.andWhere('audit.createdAt BETWEEN :startDate AND :endDate', {
                startDate: filters.startDate,
                endDate: filters.endDate,
            });
        }
        query.orderBy('audit.createdAt', 'DESC');
        if (filters?.limit) {
            query.take(filters.limit);
        }
        return query.getMany();
    }
    async findByEntity(entityType, entityId) {
        return this.auditLogRepository.find({
            where: { entityType, entityId },
            order: { createdAt: 'DESC' },
        });
    }
    async findByUser(userId, limit = 100) {
        return this.auditLogRepository.find({
            where: { userId },
            order: { createdAt: 'DESC' },
            take: limit,
        });
    }
    async getStats(startDate, endDate) {
        const query = this.auditLogRepository.createQueryBuilder('audit');
        if (startDate && endDate) {
            query.where('audit.createdAt BETWEEN :startDate AND :endDate', { startDate, endDate });
        }
        const total = await query.getCount();
        const byModule = await query
            .clone()
            .select('audit.module', 'module')
            .addSelect('COUNT(*)', 'count')
            .groupBy('audit.module')
            .getRawMany();
        const byAction = await query
            .clone()
            .select('audit.action', 'action')
            .addSelect('COUNT(*)', 'count')
            .groupBy('audit.action')
            .getRawMany();
        const byUser = await query
            .clone()
            .select('audit.userId', 'userId')
            .addSelect('audit.userName', 'userName')
            .addSelect('COUNT(*)', 'count')
            .groupBy('audit.userId, audit.userName')
            .orderBy('COUNT(*)', 'DESC')
            .limit(10)
            .getRawMany();
        return {
            total,
            byModule: byModule.reduce((acc, item) => {
                acc[item.module] = parseInt(item.count);
                return acc;
            }, {}),
            byAction: byAction.reduce((acc, item) => {
                acc[item.action] = parseInt(item.count);
                return acc;
            }, {}),
            topUsers: byUser.map((item) => ({
                userId: item.userId,
                userName: item.userName,
                count: parseInt(item.count),
            })),
        };
    }
    handleUserCreated(data) {
        this.log({
            userId: data.createdBy,
            action: 'create',
            module: 'users',
            entityId: data.id,
            entityType: 'User',
            newValues: { email: data.email, fullName: data.fullName },
        });
    }
    handleUserUpdated(data) {
        this.log({
            userId: data.updatedBy,
            action: 'update',
            module: 'users',
            entityId: data.id,
            entityType: 'User',
        });
    }
    handleUserDeleted(data) {
        this.log({
            action: 'delete',
            module: 'users',
            entityId: data.userId,
            entityType: 'User',
        });
    }
    handleChatAssigned(data) {
        this.log({
            userId: data.agentId,
            userName: data.agentName,
            action: 'assign',
            module: 'chats',
            entityId: data.chat.id,
            entityType: 'Chat',
            metadata: { agentId: data.agentId, agentName: data.agentName },
        });
    }
    handleChatTransferred(data) {
        this.log({
            userId: data.toAgentId,
            action: 'transfer',
            module: 'chats',
            entityId: data.chat.id,
            entityType: 'Chat',
            metadata: {
                fromAgentId: data.fromAgentId,
                toAgentId: data.toAgentId,
                fromAgentName: data.fromAgentName,
                toAgentName: data.toAgentName,
            },
        });
    }
    handleCampaignCreated(data) {
        this.log({
            userId: data.createdBy,
            action: 'create',
            module: 'campaigns',
            entityId: data.id,
            entityType: 'Campaign',
            newValues: { name: data.name },
        });
    }
    handleCampaignStatusChanged(data) {
        this.log({
            action: 'update_status',
            module: 'campaigns',
            entityId: data.campaign.id,
            entityType: 'Campaign',
            oldValues: { status: data.oldStatus },
            newValues: { status: data.newStatus },
        });
    }
    handleRoleCreated(data) {
        this.log({
            action: 'create',
            module: 'roles',
            entityId: data.id,
            entityType: 'Role',
            newValues: { name: data.name },
        });
    }
    handleClientLeadStatusChanged(data) {
        this.log({
            action: 'update_lead_status',
            module: 'clients',
            entityId: data.client.id,
            entityType: 'Client',
            oldValues: { leadStatus: data.oldStatus },
            newValues: { leadStatus: data.newStatus },
        });
    }
    handleTaskStatusChanged(data) {
        this.log({
            action: 'update_status',
            module: 'tasks',
            entityId: data.task.id,
            entityType: 'Task',
            oldValues: { status: data.oldStatus },
            newValues: { status: data.newStatus },
        });
    }
    handleMessageCreated(event) {
        const { message } = event;
        this.log({
            action: 'create',
            module: 'messages',
            entityId: message.id,
            entityType: 'Message',
            metadata: {
                chatId: message.chatId,
                type: message.type,
                direction: message.direction,
            },
        });
    }
};
exports.AuditService = AuditService;
__decorate([
    (0, event_emitter_1.OnEvent)('user.created'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuditService.prototype, "handleUserCreated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('user.updated'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuditService.prototype, "handleUserUpdated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('user.deleted'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuditService.prototype, "handleUserDeleted", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.assigned'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuditService.prototype, "handleChatAssigned", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.transferred'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuditService.prototype, "handleChatTransferred", null);
__decorate([
    (0, event_emitter_1.OnEvent)('campaign.created'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuditService.prototype, "handleCampaignCreated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('campaign.status-changed'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuditService.prototype, "handleCampaignStatusChanged", null);
__decorate([
    (0, event_emitter_1.OnEvent)('role.created'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuditService.prototype, "handleRoleCreated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('client.lead-status-changed'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuditService.prototype, "handleClientLeadStatusChanged", null);
__decorate([
    (0, event_emitter_1.OnEvent)('task.status-changed'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuditService.prototype, "handleTaskStatusChanged", null);
__decorate([
    (0, event_emitter_1.OnEvent)('message.created'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuditService.prototype, "handleMessageCreated", null);
exports.AuditService = AuditService = AuditService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(audit_log_entity_1.AuditLog)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        event_emitter_1.EventEmitter2])
], AuditService);
//# sourceMappingURL=audit.service.js.map