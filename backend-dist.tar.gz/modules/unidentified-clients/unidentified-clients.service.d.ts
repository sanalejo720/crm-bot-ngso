import { Repository } from 'typeorm';
import { UnidentifiedClient } from './entities/unidentified-client.entity';
import { CreateUnidentifiedClientDto, UpdateUnidentifiedClientDto, UpdateStatusDto } from './dto/unidentified-client.dto';
import { Chat } from '../chats/entities/chat.entity';
import { User } from '../users/entities/user.entity';
export declare class UnidentifiedClientsService {
    private readonly unidentifiedClientRepository;
    private readonly chatRepository;
    private readonly userRepository;
    constructor(unidentifiedClientRepository: Repository<UnidentifiedClient>, chatRepository: Repository<Chat>, userRepository: Repository<User>);
    create(createDto: CreateUnidentifiedClientDto): Promise<UnidentifiedClient>;
    findAll(page?: number, limit?: number, status?: string, assignedTo?: string, search?: string): Promise<{
        data: UnidentifiedClient[];
        total: number;
        page: number;
        lastPage: number;
    }>;
    findOne(id: string): Promise<UnidentifiedClient>;
    findByPhone(phone: string): Promise<UnidentifiedClient | null>;
    update(id: string, updateDto: UpdateUnidentifiedClientDto): Promise<UnidentifiedClient>;
    updateStatus(id: string, statusDto: UpdateStatusDto): Promise<UnidentifiedClient>;
    assignTo(id: string, userId: string): Promise<UnidentifiedClient>;
    remove(id: string): Promise<void>;
    getStats(): Promise<any>;
}
