"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const users_service_1 = require("./users.service");
const agent_sessions_service_1 = require("./services/agent-sessions.service");
const user_campaigns_service_1 = require("./services/user-campaigns.service");
const create_user_dto_1 = require("./dto/create-user.dto");
const update_user_dto_1 = require("./dto/update-user.dto");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const user_entity_1 = require("./entities/user.entity");
let UsersController = class UsersController {
    constructor(usersService, agentSessionsService, userCampaignsService) {
        this.usersService = usersService;
        this.agentSessionsService = agentSessionsService;
        this.userCampaignsService = userCampaignsService;
    }
    create(createUserDto) {
        return this.usersService.create(createUserDto);
    }
    async updateMe(userId, body) {
        const updateData = {};
        if (body.fullName)
            updateData.fullName = body.fullName;
        if (body.phone)
            updateData.phone = body.phone;
        const updated = await this.usersService.update(userId, updateData);
        return {
            success: true,
            data: updated,
            message: 'Perfil actualizado correctamente',
        };
    }
    findAll(status, roleId, campaignId, isAgent) {
        const isAgentBool = isAgent === 'true';
        return this.usersService.findAll({ status, roleId, campaignId, isAgent: isAgentBool });
    }
    findOne(id) {
        return this.usersService.findOne(id);
    }
    update(id, updateUserDto) {
        return this.usersService.update(id, updateUserDto);
    }
    remove(id) {
        return this.usersService.remove(id);
    }
    getAvailableAgents(campaignId) {
        return this.usersService.getAvailableAgents(campaignId);
    }
    async assignCampaigns(id, body) {
        const assignments = await this.userCampaignsService.assignUserToCampaigns(id, body.campaignIds, body.primaryCampaignId);
        return {
            success: true,
            data: assignments,
            message: `Usuario asignado a ${body.campaignIds.length} campaña(s)`,
        };
    }
    async getUserCampaigns(id) {
        const campaigns = await this.userCampaignsService.getUserCampaigns(id);
        return {
            success: true,
            data: campaigns,
        };
    }
    changeStatus(id, body) {
        return this.usersService.update(id, { status: body.status });
    }
    async getAgentSessionHistory(id, startDate, endDate) {
        const start = startDate ? new Date(startDate) : undefined;
        const end = endDate ? new Date(endDate) : undefined;
        const history = await this.agentSessionsService.getAgentHistory(id, start, end);
        return {
            success: true,
            data: history,
        };
    }
    async getAgentAttendanceStats(id, startDate, endDate) {
        const stats = await this.agentSessionsService.getAttendanceStats(id, new Date(startDate), new Date(endDate));
        return {
            success: true,
            data: stats,
        };
    }
    async getAllActiveSessions() {
        const sessions = await this.agentSessionsService.getAllActiveSessions();
        return {
            success: true,
            data: sessions,
            count: sessions.length,
        };
    }
};
exports.UsersController = UsersController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Crear nuevo usuario' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'users', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_user_dto_1.CreateUserDto]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "create", null);
__decorate([
    (0, common_1.Patch)('me'),
    (0, swagger_1.ApiOperation)({ summary: 'Actualizar perfil propio' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "updateMe", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener todos los usuarios' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'users', action: 'read' }),
    __param(0, (0, common_1.Query)('status')),
    __param(1, (0, common_1.Query)('roleId')),
    __param(2, (0, common_1.Query)('campaignId')),
    __param(3, (0, common_1.Query)('isAgent')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener usuario por ID' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'users', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Actualizar usuario' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'users', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_user_dto_1.UpdateUserDto]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Desactivar usuario' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'users', action: 'delete' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "remove", null);
__decorate([
    (0, common_1.Get)('campaign/:campaignId/available'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener agentes disponibles de una campaña' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'users', action: 'read' }),
    __param(0, (0, common_1.Param)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "getAvailableAgents", null);
__decorate([
    (0, common_1.Put)(':id/campaigns'),
    (0, swagger_1.ApiOperation)({ summary: 'Asignar campañas a un usuario' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'users', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "assignCampaigns", null);
__decorate([
    (0, common_1.Get)(':id/campaigns'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener campañas asignadas a un usuario' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'users', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getUserCampaigns", null);
__decorate([
    (0, common_1.Patch)(':id/status'),
    (0, swagger_1.ApiOperation)({ summary: 'Cambiar estado del usuario' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'users', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], UsersController.prototype, "changeStatus", null);
__decorate([
    (0, common_1.Get)(':id/sessions/history'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener historial de sesiones de un agente' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, type: String }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'users', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getAgentSessionHistory", null);
__decorate([
    (0, common_1.Get)(':id/sessions/attendance-stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas de asistencia de un agente' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: true, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: true, type: String }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'users', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getAgentAttendanceStats", null);
__decorate([
    (0, common_1.Get)('sessions/active'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener todas las sesiones activas de agentes' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'users', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "getAllActiveSessions", null);
exports.UsersController = UsersController = __decorate([
    (0, swagger_1.ApiTags)('users'),
    (0, common_1.Controller)('users'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [users_service_1.UsersService,
        agent_sessions_service_1.AgentSessionsService,
        user_campaigns_service_1.UserCampaignsService])
], UsersController);
//# sourceMappingURL=users.controller.js.map