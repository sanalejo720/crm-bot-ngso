import { Repository } from 'typeorm';
import { AgentSession, AgentSessionStatus } from '../entities/agent-session.entity';
import { User } from '../entities/user.entity';
export declare class AgentSessionsService {
    private agentSessionRepository;
    private userRepository;
    private readonly logger;
    constructor(agentSessionRepository: Repository<AgentSession>, userRepository: Repository<User>);
    startSession(userId: string, status: AgentSessionStatus, ipAddress?: string, userAgent?: string): Promise<AgentSession>;
    endSession(sessionId: string): Promise<AgentSession>;
    changeSessionStatus(userId: string, newStatus: AgentSessionStatus, reason?: string): Promise<AgentSession>;
    getActiveSession(userId: string): Promise<AgentSession | null>;
    getAgentHistory(userId: string, startDate?: Date, endDate?: Date): Promise<AgentSession[]>;
    getAttendanceStats(userId: string, startDate: Date, endDate: Date): Promise<any>;
    getAllActiveSessions(): Promise<AgentSession[]>;
    endAllActiveSessions(): Promise<number>;
    cleanOrphanSessions(): Promise<number>;
}
