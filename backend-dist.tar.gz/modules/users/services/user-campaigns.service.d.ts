import { Repository } from 'typeorm';
import { UserCampaign } from '../entities/user-campaign.entity';
export declare class UserCampaignsService {
    private readonly userCampaignRepository;
    private readonly logger;
    constructor(userCampaignRepository: Repository<UserCampaign>);
    assignUserToCampaigns(userId: string, campaignIds: string[], primaryCampaignId?: string): Promise<UserCampaign[]>;
    getUserCampaigns(userId: string): Promise<UserCampaign[]>;
    getUserCampaignIds(userId: string): Promise<string[]>;
    getCampaignAgents(campaignId: string): Promise<UserCampaign[]>;
    getCampaignAgentIds(campaignId: string): Promise<string[]>;
    isUserInCampaign(userId: string, campaignId: string): Promise<boolean>;
    getPrimaryCampaign(userId: string): Promise<UserCampaign | null>;
    removeUserFromCampaign(userId: string, campaignId: string): Promise<void>;
    removeUserFromAllCampaigns(userId: string): Promise<void>;
}
