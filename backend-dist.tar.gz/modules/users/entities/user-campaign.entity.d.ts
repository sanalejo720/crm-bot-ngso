import { User } from './user.entity';
import { Campaign } from '../../campaigns/entities/campaign.entity';
export declare class UserCampaign {
    id: string;
    user: User;
    userId: string;
    campaign: Campaign;
    campaignId: string;
    isActive: boolean;
    isPrimary: boolean;
    assignedAt: Date;
    createdAt: Date;
    updatedAt: Date;
}
