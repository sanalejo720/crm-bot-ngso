"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DebtorRowDto = exports.UploadErrorDto = exports.UploadResultDto = void 0;
class UploadResultDto {
}
exports.UploadResultDto = UploadResultDto;
class UploadErrorDto {
}
exports.UploadErrorDto = UploadErrorDto;
class DebtorRowDto {
}
exports.DebtorRowDto = DebtorRowDto;
//# sourceMappingURL=upload-result.dto.js.map