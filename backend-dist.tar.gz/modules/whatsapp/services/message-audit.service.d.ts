import { Repository } from 'typeorm';
import { Message } from '../../messages/entities/message.entity';
import { EventEmitter2 } from '@nestjs/event-emitter';
export interface MessageAuditLog {
    messageId: string;
    chatId: string;
    whatsappNumberId: string;
    direction: 'inbound' | 'outbound';
    status: string;
    twilioSid?: string;
    twilioStatus?: string;
    errorCode?: number;
    errorMessage?: string;
    timestamp: Date;
    latencyMs?: number;
}
export declare class MessageAuditService {
    private messageRepository;
    private eventEmitter;
    private readonly logger;
    private pendingMessages;
    private readonly DELIVERY_TIMEOUT_MS;
    constructor(messageRepository: Repository<Message>, eventEmitter: EventEmitter2);
    recordSendAttempt(messageId: string, chatId: string, whatsappNumberId: string): Promise<void>;
    recordSendSuccess(messageId: string, twilioSid?: string, twilioStatus?: string): Promise<void>;
    recordSendFailure(messageId: string, errorCode?: number, errorMessage?: string): Promise<void>;
    private handleDeliveryTimeout;
    updateFromTwilioWebhook(twilioSid: string, status: string, errorCode?: number, errorMessage?: string): Promise<void>;
    getDeliveryStats(whatsappNumberId: string, startDate: Date, endDate: Date): Promise<{
        total: number;
        sent: number;
        delivered: number;
        read: number;
        failed: number;
        pending: number;
        deliveryRate: number;
        readRate: number;
    }>;
    getFailedMessages(whatsappNumberId?: string, limit?: number): Promise<Message[]>;
}
