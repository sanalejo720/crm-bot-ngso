"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var MessageAuditService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageAuditService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const message_entity_1 = require("../../messages/entities/message.entity");
const event_emitter_1 = require("@nestjs/event-emitter");
let MessageAuditService = MessageAuditService_1 = class MessageAuditService {
    constructor(messageRepository, eventEmitter) {
        this.messageRepository = messageRepository;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(MessageAuditService_1.name);
        this.pendingMessages = new Map();
        this.DELIVERY_TIMEOUT_MS = 30000;
    }
    async recordSendAttempt(messageId, chatId, whatsappNumberId) {
        const sentAt = new Date();
        const timeout = setTimeout(() => {
            this.handleDeliveryTimeout(messageId);
        }, this.DELIVERY_TIMEOUT_MS);
        this.pendingMessages.set(messageId, {
            messageId,
            sentAt,
            timeout,
        });
        this.logger.log(`📤 Mensaje ${messageId} enviado, esperando confirmación...`);
    }
    async recordSendSuccess(messageId, twilioSid, twilioStatus) {
        const pending = this.pendingMessages.get(messageId);
        if (pending) {
            clearTimeout(pending.timeout);
            this.pendingMessages.delete(messageId);
            const latencyMs = Date.now() - pending.sentAt.getTime();
            await this.messageRepository.update(messageId, {
                status: message_entity_1.MessageStatus.SENT,
                externalId: twilioSid,
                sentAt: new Date(),
            });
            this.logger.log(`✅ Mensaje ${messageId} confirmado (SID: ${twilioSid}, Latencia: ${latencyMs}ms)`);
            this.eventEmitter.emit('message.delivery.success', {
                messageId,
                twilioSid,
                latencyMs,
            });
        }
        else {
            this.logger.warn(`⚠️ Confirmación para mensaje ${messageId} no encontrado en pendientes`);
        }
    }
    async recordSendFailure(messageId, errorCode, errorMessage) {
        const pending = this.pendingMessages.get(messageId);
        if (pending) {
            clearTimeout(pending.timeout);
            this.pendingMessages.delete(messageId);
        }
        await this.messageRepository.update(messageId, {
            status: message_entity_1.MessageStatus.FAILED,
            errorMessage: JSON.stringify({ errorCode, errorMessage }),
        });
        this.logger.error(`❌ Mensaje ${messageId} falló (Código: ${errorCode}, Error: ${errorMessage})`);
        this.eventEmitter.emit('message.delivery.failed', {
            messageId,
            errorCode,
            errorMessage,
        });
    }
    async handleDeliveryTimeout(messageId) {
        this.pendingMessages.delete(messageId);
        const message = await this.messageRepository.findOne({
            where: { id: messageId },
        });
        if (message && message.status === message_entity_1.MessageStatus.PENDING) {
            await this.messageRepository.update(messageId, {
                status: message_entity_1.MessageStatus.FAILED,
                errorMessage: JSON.stringify({
                    error: 'DELIVERY_TIMEOUT',
                    message: 'No se recibió confirmación de entrega en 30 segundos'
                }),
            });
            this.logger.warn(`⏰ Timeout de entrega para mensaje ${messageId}`);
            this.eventEmitter.emit('message.delivery.timeout', {
                messageId,
                chatId: message.chatId,
            });
        }
    }
    async updateFromTwilioWebhook(twilioSid, status, errorCode, errorMessage) {
        const message = await this.messageRepository.findOne({
            where: { externalId: twilioSid },
        });
        if (!message) {
            this.logger.warn(`Webhook para SID ${twilioSid} no encontró mensaje`);
            return;
        }
        const statusMap = {
            'queued': message_entity_1.MessageStatus.PENDING,
            'sending': message_entity_1.MessageStatus.PENDING,
            'sent': message_entity_1.MessageStatus.SENT,
            'delivered': message_entity_1.MessageStatus.DELIVERED,
            'read': message_entity_1.MessageStatus.READ,
            'failed': message_entity_1.MessageStatus.FAILED,
            'undelivered': message_entity_1.MessageStatus.FAILED,
        };
        const newStatus = statusMap[status] || message.status;
        await this.messageRepository.update(message.id, {
            status: newStatus,
            deliveredAt: status === 'delivered' ? new Date() : message.deliveredAt,
            readAt: status === 'read' ? new Date() : message.readAt,
            errorMessage: errorCode
                ? JSON.stringify({ errorCode, errorMessage: errorMessage, twilioStatus: status })
                : message.errorMessage,
        });
        this.logger.log(`📬 Webhook Twilio: Mensaje ${message.id} -> ${status} (${newStatus})`);
        if (status === 'delivered') {
            this.eventEmitter.emit('message.delivered', { messageId: message.id });
        }
        else if (status === 'read') {
            this.eventEmitter.emit('message.read', { messageId: message.id });
        }
        else if (status === 'failed' || status === 'undelivered') {
            this.eventEmitter.emit('message.delivery.failed', {
                messageId: message.id,
                errorCode,
                errorMessage,
            });
        }
    }
    async getDeliveryStats(whatsappNumberId, startDate, endDate) {
        const messages = await this.messageRepository
            .createQueryBuilder('message')
            .where('message.whatsappNumberId = :whatsappNumberId', { whatsappNumberId })
            .andWhere('message.direction = :direction', { direction: 'outbound' })
            .andWhere('message.createdAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .getMany();
        const total = messages.length;
        const sent = messages.filter(m => m.status === message_entity_1.MessageStatus.SENT).length;
        const delivered = messages.filter(m => m.status === message_entity_1.MessageStatus.DELIVERED).length;
        const read = messages.filter(m => m.status === message_entity_1.MessageStatus.READ).length;
        const failed = messages.filter(m => m.status === message_entity_1.MessageStatus.FAILED).length;
        const pending = messages.filter(m => m.status === message_entity_1.MessageStatus.PENDING).length;
        const successfulDeliveries = delivered + read;
        const deliveryRate = total > 0 ? (successfulDeliveries / total) * 100 : 0;
        const readRate = successfulDeliveries > 0 ? (read / successfulDeliveries) * 100 : 0;
        return {
            total,
            sent,
            delivered,
            read,
            failed,
            pending,
            deliveryRate: Math.round(deliveryRate * 100) / 100,
            readRate: Math.round(readRate * 100) / 100,
        };
    }
    async getFailedMessages(whatsappNumberId, limit = 50) {
        const query = this.messageRepository
            .createQueryBuilder('message')
            .where('message.status = :status', { status: message_entity_1.MessageStatus.FAILED })
            .andWhere('message.direction = :direction', { direction: 'outbound' })
            .orderBy('message.createdAt', 'DESC')
            .take(limit);
        if (whatsappNumberId) {
            query.andWhere('message.whatsappNumberId = :whatsappNumberId', {
                whatsappNumberId,
            });
        }
        return query.getMany();
    }
};
exports.MessageAuditService = MessageAuditService;
exports.MessageAuditService = MessageAuditService = MessageAuditService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(message_entity_1.Message)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        event_emitter_1.EventEmitter2])
], MessageAuditService);
//# sourceMappingURL=message-audit.service.js.map