import { RoutingStrategy } from './routing-strategy.interface';
import { User } from '../../users/entities/user.entity';
import { Chat } from '../../chats/entities/chat.entity';
export declare class LeastBusyStrategy implements RoutingStrategy {
    private readonly logger;
    selectAgent(availableAgents: User[], chat: Chat): User | null;
    getName(): string;
}
