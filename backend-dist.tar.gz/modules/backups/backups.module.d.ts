import { OnModuleInit } from '@nestjs/common';
import { BackupEmailRecipientsService } from './backup-email-recipients.service';
export declare class BackupsModule implements OnModuleInit {
    private recipientsService;
    constructor(recipientsService: BackupEmailRecipientsService);
    onModuleInit(): Promise<void>;
}
