import { Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { BackupEmailRecipient } from './entities/backup-email-recipient.entity';
import { CreateBackupEmailRecipientDto, UpdateBackupEmailRecipientDto } from './dto/backup-email-recipient.dto';
export declare class BackupEmailRecipientsService {
    private recipientRepo;
    private configService;
    private readonly logger;
    constructor(recipientRepo: Repository<BackupEmailRecipient>, configService: ConfigService);
    findAll(): Promise<BackupEmailRecipient[]>;
    findActive(): Promise<BackupEmailRecipient[]>;
    getActiveEmails(): Promise<string[]>;
    create(dto: CreateBackupEmailRecipientDto, userId?: string): Promise<BackupEmailRecipient>;
    update(id: string, dto: UpdateBackupEmailRecipientDto): Promise<BackupEmailRecipient>;
    remove(id: string): Promise<void>;
    initializeDefaultRecipient(): Promise<void>;
}
