"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BackupsModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const backups_service_1 = require("./backups.service");
const backups_controller_1 = require("./backups.controller");
const backup_email_recipients_controller_1 = require("./backup-email-recipients.controller");
const backup_email_recipients_service_1 = require("./backup-email-recipients.service");
const email_service_1 = require("../../common/services/email.service");
const backup_entity_1 = require("./entities/backup.entity");
const backup_email_recipient_entity_1 = require("./entities/backup-email-recipient.entity");
const user_entity_1 = require("../users/entities/user.entity");
let BackupsModule = class BackupsModule {
    constructor(recipientsService) {
        this.recipientsService = recipientsService;
    }
    async onModuleInit() {
        await this.recipientsService.initializeDefaultRecipient();
    }
};
exports.BackupsModule = BackupsModule;
exports.BackupsModule = BackupsModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([backup_entity_1.Backup, backup_email_recipient_entity_1.BackupEmailRecipient, user_entity_1.User])],
        controllers: [backup_email_recipients_controller_1.BackupEmailRecipientsController, backups_controller_1.BackupsController],
        providers: [backups_service_1.BackupsService, backup_email_recipients_service_1.BackupEmailRecipientsService, email_service_1.EmailService],
        exports: [backups_service_1.BackupsService, backup_email_recipients_service_1.BackupEmailRecipientsService],
    }),
    __metadata("design:paramtypes", [backup_email_recipients_service_1.BackupEmailRecipientsService])
], BackupsModule);
//# sourceMappingURL=backups.module.js.map