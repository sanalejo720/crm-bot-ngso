import { BackupEmailRecipientsService } from './backup-email-recipients.service';
import { CreateBackupEmailRecipientDto, UpdateBackupEmailRecipientDto } from './dto/backup-email-recipient.dto';
export declare class BackupEmailRecipientsController {
    private readonly recipientsService;
    constructor(recipientsService: BackupEmailRecipientsService);
    findAll(): Promise<{
        success: boolean;
        data: {
            id: string;
            email: string;
            name: string;
            isActive: boolean;
            createdAt: Date;
            addedBy: {
                id: string;
                name: string;
            };
        }[];
    }>;
    create(dto: CreateBackupEmailRecipientDto, user: any): Promise<{
        success: boolean;
        message: string;
        data: {
            id: string;
            email: string;
            name: string;
            isActive: boolean;
            createdAt: Date;
        };
    }>;
    update(id: string, dto: UpdateBackupEmailRecipientDto): Promise<{
        success: boolean;
        message: string;
        data: {
            id: string;
            email: string;
            name: string;
            isActive: boolean;
            updatedAt: Date;
        };
    }>;
    remove(id: string): Promise<{
        success: boolean;
        message: string;
    }>;
}
