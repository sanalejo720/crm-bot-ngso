"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var BackupEmailRecipientsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BackupEmailRecipientsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const config_1 = require("@nestjs/config");
const backup_email_recipient_entity_1 = require("./entities/backup-email-recipient.entity");
let BackupEmailRecipientsService = BackupEmailRecipientsService_1 = class BackupEmailRecipientsService {
    constructor(recipientRepo, configService) {
        this.recipientRepo = recipientRepo;
        this.configService = configService;
        this.logger = new common_1.Logger(BackupEmailRecipientsService_1.name);
    }
    async findAll() {
        return this.recipientRepo.find({
            relations: ['addedBy'],
            order: { createdAt: 'DESC' },
        });
    }
    async findActive() {
        return this.recipientRepo.find({
            where: { isActive: true },
            order: { createdAt: 'DESC' },
        });
    }
    async getActiveEmails() {
        const recipients = await this.findActive();
        if (recipients.length === 0) {
            const defaultEmail = this.configService.get('BACKUP_EMAIL_RECIPIENT');
            if (defaultEmail) {
                return [defaultEmail];
            }
            return [];
        }
        return recipients.map(r => r.email);
    }
    async create(dto, userId) {
        const existing = await this.recipientRepo.findOne({
            where: { email: dto.email.toLowerCase() },
        });
        if (existing) {
            throw new common_1.ConflictException(`El correo ${dto.email} ya está registrado`);
        }
        const recipient = this.recipientRepo.create({
            email: dto.email.toLowerCase(),
            name: dto.name,
            isActive: true,
            addedById: userId,
        });
        const saved = await this.recipientRepo.save(recipient);
        this.logger.log(`✅ Nuevo destinatario de backup agregado: ${dto.email}`);
        return saved;
    }
    async update(id, dto) {
        const recipient = await this.recipientRepo.findOne({ where: { id } });
        if (!recipient) {
            throw new common_1.NotFoundException('Destinatario no encontrado');
        }
        if (dto.email && dto.email.toLowerCase() !== recipient.email) {
            const existing = await this.recipientRepo.findOne({
                where: { email: dto.email.toLowerCase() },
            });
            if (existing) {
                throw new common_1.ConflictException(`El correo ${dto.email} ya está registrado`);
            }
            recipient.email = dto.email.toLowerCase();
        }
        if (dto.name !== undefined) {
            recipient.name = dto.name;
        }
        if (dto.isActive !== undefined) {
            recipient.isActive = dto.isActive;
        }
        const saved = await this.recipientRepo.save(recipient);
        this.logger.log(`✅ Destinatario de backup actualizado: ${saved.email}`);
        return saved;
    }
    async remove(id) {
        const recipient = await this.recipientRepo.findOne({ where: { id } });
        if (!recipient) {
            throw new common_1.NotFoundException('Destinatario no encontrado');
        }
        await this.recipientRepo.remove(recipient);
        this.logger.log(`🗑️ Destinatario de backup eliminado: ${recipient.email}`);
    }
    async initializeDefaultRecipient() {
        const count = await this.recipientRepo.count();
        if (count === 0) {
            const defaultEmail = this.configService.get('BACKUP_EMAIL_RECIPIENT');
            if (defaultEmail) {
                await this.recipientRepo.save({
                    email: defaultEmail.toLowerCase(),
                    name: 'Gerencia (Configuración inicial)',
                    isActive: true,
                });
                this.logger.log(`✅ Destinatario por defecto inicializado: ${defaultEmail}`);
            }
        }
    }
};
exports.BackupEmailRecipientsService = BackupEmailRecipientsService;
exports.BackupEmailRecipientsService = BackupEmailRecipientsService = BackupEmailRecipientsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(backup_email_recipient_entity_1.BackupEmailRecipient)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        config_1.ConfigService])
], BackupEmailRecipientsService);
//# sourceMappingURL=backup-email-recipients.service.js.map