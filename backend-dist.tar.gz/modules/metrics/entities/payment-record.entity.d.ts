import { Client } from '../../clients/entities/client.entity';
import { User } from '../../users/entities/user.entity';
import { Campaign } from '../../campaigns/entities/campaign.entity';
export declare enum PaymentSource {
    EVIDENCE = "evidence",
    MANUAL = "manual",
    BOT_PROMISE = "bot_promise",
    INTEGRATION = "integration"
}
export declare enum PaymentStatus {
    CONFIRMED = "confirmed",
    PENDING = "pending",
    REJECTED = "rejected"
}
export declare class PaymentRecord {
    id: string;
    clientId: string;
    client: Client;
    agentId: string;
    agent: User;
    campaignId: string;
    campaign: Campaign;
    amount: number;
    originalDebt: number;
    remainingDebt: number;
    recoveryPercentage: number;
    paymentDate: Date;
    source: PaymentSource;
    status: PaymentStatus;
    referenceId: string;
    notes: string;
    metadata: Record<string, any>;
    createdAt: Date;
}
