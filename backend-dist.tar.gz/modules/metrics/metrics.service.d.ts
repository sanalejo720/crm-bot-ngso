import { Repository } from 'typeorm';
import { Chat } from '../chats/entities/chat.entity';
import { Message } from '../messages/entities/message.entity';
import { User } from '../users/entities/user.entity';
import { AgentSession } from '../users/entities/agent-session.entity';
import { Campaign } from '../campaigns/entities/campaign.entity';
import { Client } from '../clients/entities/client.entity';
import { PaymentRecord, PaymentSource, PaymentStatus } from './entities/payment-record.entity';
export declare class MetricsService {
    private chatRepository;
    private messageRepository;
    private userRepository;
    private sessionRepository;
    private campaignRepository;
    private clientRepository;
    private paymentRecordRepository;
    private readonly logger;
    constructor(chatRepository: Repository<Chat>, messageRepository: Repository<Message>, userRepository: Repository<User>, sessionRepository: Repository<AgentSession>, campaignRepository: Repository<Campaign>, clientRepository: Repository<Client>, paymentRecordRepository: Repository<PaymentRecord>);
    getAgentTMO(agentId: string, startDate: Date, endDate: Date): Promise<{
        tmoMinutes: number;
        totalChats: number;
    }>;
    getAgentFRT(agentId: string, startDate: Date, endDate: Date): Promise<{
        frtSeconds: number;
        totalChats: number;
    }>;
    getAgentMetrics(agentId: string, startDate: Date, endDate: Date): Promise<{
        agentId: string;
        agentName: string;
        period: {
            start: Date;
            end: Date;
        };
        chats: {
            total: number;
            active: number;
            closed: number;
            resolved: number;
        };
        messages: {
            sent: number;
            received: number;
        };
        performance: {
            tmoMinutes: number;
            frtSeconds: number;
            avgMessagesPerChat: number;
            closureRate: number;
        };
        session: {
            totalTimeHours: number;
            avgSessionDuration: number;
            totalSessions: number;
        };
    }>;
    getCampaignMetrics(campaignId: string, startDate: Date, endDate: Date): Promise<{
        campaignId: string;
        campaignName: string;
        period: {
            start: Date;
            end: Date;
        };
        chats: {
            total: number;
            attended: number;
            unattended: number;
            botOnly: number;
            transferred: number;
        };
        queue: {
            avgWaitTimeSeconds: number;
            maxWaitTimeSeconds: number;
            currentInQueue: number;
        };
        agents: {
            total: number;
            available: number;
            loadDistribution: Array<{
                agentId: string;
                agentName: string;
                chatCount: number;
            }>;
        };
    }>;
    getBotMetrics(campaignId: string | null, startDate: Date, endDate: Date): Promise<{
        period: {
            start: Date;
            end: Date;
        };
        resolution: {
            totalChats: number;
            resolvedByBot: number;
            transferredToAgent: number;
            resolutionRate: number;
        };
        dropRate: {
            totalStarted: number;
            abandoned: number;
            dropRate: number;
        };
        performance: {
            avgBotInteractions: number;
            avgTimeInBotSeconds: number;
        };
    }>;
    getSupervisorDashboard(campaignId: string | null, startDate: Date, endDate: Date): Promise<any>;
    recordPayment(dto: {
        clientId: string;
        agentId?: string;
        campaignId?: string;
        amount: number;
        paymentDate: string;
        source?: PaymentSource;
        status?: PaymentStatus;
        referenceId?: string;
        notes?: string;
    }, recordedBy?: string): Promise<PaymentRecord>;
    getCollectionMetrics(filters: {
        startDate?: string;
        endDate?: string;
        agentId?: string;
        campaignId?: string;
    }): Promise<{
        totalCollected: number;
        totalDebtAssigned: number;
        recoveryPercentage: number;
        paymentsCount: number;
        averagePayment: number;
    }>;
    getAgentCollectionMetrics(filters: {
        startDate?: string;
        endDate?: string;
        campaignId?: string;
    }): Promise<Array<{
        agentId: string;
        agentName: string;
        totalCollected: number;
        totalAssigned: number;
        recoveryPercentage: number;
        paymentsCount: number;
        ranking: number;
    }>>;
    getCollectionTimeSeries(filters: {
        startDate?: string;
        endDate?: string;
        agentId?: string;
        campaignId?: string;
        groupBy?: 'day' | 'week' | 'month';
    }): Promise<Array<{
        date: string;
        totalCollected: number;
        paymentsCount: number;
        recoveryPercentage: number;
    }>>;
    getPortfolioSummary(campaignId?: string): Promise<{
        totalPortfolio: number;
        totalCollected: number;
        totalPending: number;
        recoveryPercentage: number;
        clientsCount: number;
        paidClients: number;
        pendingClients: number;
    }>;
}
