"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimeSeriesMetricsDto = exports.AgentMetricsDto = exports.CollectionMetricsDto = exports.MetricsFilterDto = exports.CreatePaymentRecordDto = void 0;
const class_validator_1 = require("class-validator");
const payment_record_entity_1 = require("../entities/payment-record.entity");
const class_transformer_1 = require("class-transformer");
class CreatePaymentRecordDto {
}
exports.CreatePaymentRecordDto = CreatePaymentRecordDto;
__decorate([
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CreatePaymentRecordDto.prototype, "clientId", void 0);
__decorate([
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreatePaymentRecordDto.prototype, "agentId", void 0);
__decorate([
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreatePaymentRecordDto.prototype, "campaignId", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], CreatePaymentRecordDto.prototype, "amount", void 0);
__decorate([
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], CreatePaymentRecordDto.prototype, "paymentDate", void 0);
__decorate([
    (0, class_validator_1.IsEnum)(payment_record_entity_1.PaymentSource),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreatePaymentRecordDto.prototype, "source", void 0);
__decorate([
    (0, class_validator_1.IsEnum)(payment_record_entity_1.PaymentStatus),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreatePaymentRecordDto.prototype, "status", void 0);
__decorate([
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreatePaymentRecordDto.prototype, "referenceId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreatePaymentRecordDto.prototype, "notes", void 0);
class MetricsFilterDto {
}
exports.MetricsFilterDto = MetricsFilterDto;
__decorate([
    (0, class_validator_1.IsDateString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], MetricsFilterDto.prototype, "startDate", void 0);
__decorate([
    (0, class_validator_1.IsDateString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], MetricsFilterDto.prototype, "endDate", void 0);
__decorate([
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], MetricsFilterDto.prototype, "agentId", void 0);
__decorate([
    (0, class_validator_1.IsUUID)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], MetricsFilterDto.prototype, "campaignId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], MetricsFilterDto.prototype, "groupBy", void 0);
class CollectionMetricsDto {
}
exports.CollectionMetricsDto = CollectionMetricsDto;
class AgentMetricsDto {
}
exports.AgentMetricsDto = AgentMetricsDto;
class TimeSeriesMetricsDto {
}
exports.TimeSeriesMetricsDto = TimeSeriesMetricsDto;
//# sourceMappingURL=metrics.dto.js.map