import { PaymentSource, PaymentStatus } from '../entities/payment-record.entity';
export declare class CreatePaymentRecordDto {
    clientId: string;
    agentId?: string;
    campaignId?: string;
    amount: number;
    paymentDate: string;
    source?: PaymentSource;
    status?: PaymentStatus;
    referenceId?: string;
    notes?: string;
}
export declare class MetricsFilterDto {
    startDate?: string;
    endDate?: string;
    agentId?: string;
    campaignId?: string;
    groupBy?: 'day' | 'week' | 'month';
}
export declare class CollectionMetricsDto {
    totalCollected: number;
    totalDebtAssigned: number;
    recoveryPercentage: number;
    paymentsCount: number;
    averagePayment: number;
}
export declare class AgentMetricsDto {
    agentId: string;
    agentName: string;
    totalCollected: number;
    totalAssigned: number;
    recoveryPercentage: number;
    paymentsCount: number;
    ranking: number;
}
export declare class TimeSeriesMetricsDto {
    date: string;
    totalCollected: number;
    paymentsCount: number;
    recoveryPercentage: number;
}
