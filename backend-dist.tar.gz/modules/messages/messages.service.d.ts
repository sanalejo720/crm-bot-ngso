import { Repository } from 'typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Message, MessageType, MessageStatus } from './entities/message.entity';
import { CreateMessageDto } from './dto/create-message.dto';
import { ChatsService } from '../chats/chats.service';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { ClientsService } from '../clients/clients.service';
import { DebtorsService } from '../debtors/debtors.service';
import { CampaignsService } from '../campaigns/campaigns.service';
import { WhatsappNumber } from '../whatsapp/entities/whatsapp-number.entity';
import { Client } from '../clients/entities/client.entity';
export declare class MessagesService {
    private messageRepository;
    private whatsappNumberRepository;
    private clientRepository;
    private chatsService;
    private whatsappService;
    private clientsService;
    private debtorsService;
    private campaignsService;
    private eventEmitter;
    private readonly logger;
    constructor(messageRepository: Repository<Message>, whatsappNumberRepository: Repository<WhatsappNumber>, clientRepository: Repository<Client>, chatsService: ChatsService, whatsappService: WhatsappService, clientsService: ClientsService, debtorsService: DebtorsService, campaignsService: CampaignsService, eventEmitter: EventEmitter2);
    create(createMessageDto: CreateMessageDto): Promise<Message>;
    findByChatId(chatId: string, options?: {
        limit?: number;
        offset?: number;
    }): Promise<Message[]>;
    findOne(id: string): Promise<Message>;
    findByExternalId(externalId: string): Promise<Message | null>;
    sendTextMessage(chatId: string, senderId: string, content: string): Promise<Message>;
    sendMediaMessage(chatId: string, senderId: string, mediaUrl: string, mediaType: MessageType, caption?: string): Promise<Message>;
    processIncomingMessage(data: {
        externalId: string;
        whatsappNumberId: string;
        contactPhone: string;
        contactName?: string;
        type: MessageType;
        content?: string;
        mediaUrl?: string;
        mediaFileName?: string;
        mediaMimeType?: string;
        timestamp: number;
    }): Promise<Message>;
    updateStatus(id: string, status: MessageStatus, errorMessage?: string): Promise<void>;
    markAsRead(chatId: string): Promise<void>;
    getStats(chatId: string): Promise<{
        total: number;
        sent: number;
        delivered: number;
        read: number;
        failed: number;
    }>;
    handleIncomingWhatsAppMessage(data: {
        provider: string;
        from: string;
        content: string;
        type: string;
        messageId: string;
        timestamp: Date;
        sessionName: string;
        mediaUrl?: string;
        fileName?: string;
        mimeType?: string;
        isMedia?: boolean;
    }): Promise<void>;
    private associateDebtorToClient;
}
