import { Role } from './role.entity';
export declare class Permission {
    id: string;
    module: string;
    action: string;
    description: string;
    name: string;
    setName(): void;
    roles: Role[];
    createdAt: Date;
}
