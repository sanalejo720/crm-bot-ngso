"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var TimeoutMonitorWorker_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimeoutMonitorWorker = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const chat_entity_1 = require("../chats/entities/chat.entity");
const chat_state_service_1 = require("../chats/services/chat-state.service");
const event_emitter_1 = require("@nestjs/event-emitter");
let TimeoutMonitorWorker = TimeoutMonitorWorker_1 = class TimeoutMonitorWorker {
    constructor(chatRepository, chatStateService, eventEmitter) {
        this.chatRepository = chatRepository;
        this.chatStateService = chatStateService;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(TimeoutMonitorWorker_1.name);
        this.AGENT_WARNING_TIME = 30;
        this.AGENT_TIMEOUT_TIME = 60 * 24;
        this.CLIENT_WARNING_TIME = 60;
        this.CLIENT_TIMEOUT_TIME = 60 * 24;
        this.CLIENT_TIMEOUT_ENABLED = false;
    }
    async checkTimeouts() {
        this.logger.log('⏰ Iniciando verificación de timeouts...');
        try {
            await Promise.all([
                this.checkAgentTimeouts(),
                this.checkClientTimeouts(),
            ]);
        }
        catch (error) {
            this.logger.error(`Error en verificación de timeouts: ${error.message}`, error.stack);
        }
    }
    async checkAgentTimeouts() {
        const now = new Date();
        const warningThreshold = new Date(now.getTime() - this.AGENT_WARNING_TIME * 60000);
        const timeoutThreshold = new Date(now.getTime() - this.AGENT_TIMEOUT_TIME * 60000);
        const chatsNeedingWarning = await this.chatRepository
            .createQueryBuilder('chat')
            .where('chat.status = :status', { status: 'active' })
            .andWhere('chat.lastClientMessageAt IS NOT NULL')
            .andWhere('chat.lastClientMessageAt < :warningThreshold', { warningThreshold })
            .andWhere('(chat.lastAgentMessageAt IS NULL OR chat.lastAgentMessageAt < chat.lastClientMessageAt)')
            .andWhere('chat.agentWarningSent = :sent', { sent: false })
            .andWhere('chat.assignedAgentId IS NOT NULL')
            .getMany();
        for (const chat of chatsNeedingWarning) {
            await this.sendAgentWarning(chat);
        }
        this.logger.log(`⚠️ Warnings enviados: ${chatsNeedingWarning.length} chats`);
        const chatsToTimeout = await this.chatRepository
            .createQueryBuilder('chat')
            .where('chat.status = :status', { status: 'active' })
            .andWhere('chat.lastClientMessageAt IS NOT NULL')
            .andWhere('chat.lastClientMessageAt < :timeoutThreshold', { timeoutThreshold })
            .andWhere('(chat.lastAgentMessageAt IS NULL OR chat.lastAgentMessageAt < chat.lastClientMessageAt)')
            .andWhere('chat.agentWarningSent = :sent', { sent: true })
            .andWhere('chat.assignedAgentId IS NOT NULL')
            .getMany();
        for (const chat of chatsToTimeout) {
            await this.closeByAgentTimeout(chat);
        }
        this.logger.log(`⏰ Chats cerrados por timeout de agente: ${chatsToTimeout.length}`);
    }
    async checkClientTimeouts() {
        if (!this.CLIENT_TIMEOUT_ENABLED) {
            const now = new Date();
            const warningThreshold = new Date(now.getTime() - this.CLIENT_WARNING_TIME * 60000);
            const chatsNeedingWarning = await this.chatRepository
                .createQueryBuilder('chat')
                .where('chat.status = :status', { status: 'active' })
                .andWhere('chat.lastAgentMessageAt IS NOT NULL')
                .andWhere('chat.lastAgentMessageAt < :warningThreshold', { warningThreshold })
                .andWhere('(chat.lastClientMessageAt IS NULL OR chat.lastClientMessageAt < chat.lastAgentMessageAt)')
                .andWhere('chat.clientWarningSent = :sent', { sent: false })
                .andWhere('chat.assignedAgentId IS NOT NULL')
                .getMany();
            for (const chat of chatsNeedingWarning) {
                await this.sendClientWarning(chat);
            }
            this.logger.log(`ℹ️ Warnings informativos de cliente enviados: ${chatsNeedingWarning.length} chats (sin cierre automático)`);
            return;
        }
        this.logger.log(`ℹ️ Timeout de cliente deshabilitado según configuración`);
    }
    async sendAgentWarning(chat) {
        try {
            await this.chatRepository.update(chat.id, {
                agentWarningSent: true,
            });
            this.eventEmitter.emit('chat.agent.timeout.warning', {
                chatId: chat.id,
                agentId: chat.assignedAgentId,
                minutesSinceLastMessage: this.AGENT_WARNING_TIME,
            });
            this.logger.log(`⚠️ Warning enviado al agente para chat ${chat.id}`);
        }
        catch (error) {
            this.logger.error(`Error enviando warning de agente: ${error.message}`);
        }
    }
    async sendClientWarning(chat) {
        try {
            await this.chatRepository.update(chat.id, {
                clientWarningSent: true,
            });
            this.eventEmitter.emit('chat.client.timeout.warning', {
                chatId: chat.id,
                agentId: chat.assignedAgentId,
                minutesSinceLastMessage: this.CLIENT_WARNING_TIME,
            });
            this.logger.log(`⚠️ Warning de cliente enviado para chat ${chat.id}`);
        }
        catch (error) {
            this.logger.error(`Error enviando warning de cliente: ${error.message}`);
        }
    }
    async closeByAgentTimeout(chat) {
        try {
            await this.chatStateService.transition(chat.id, 'closed', 'closed_agent_timeout', {
                reason: `Chat cerrado automáticamente: agente no respondió en ${this.AGENT_TIMEOUT_TIME} minutos`,
                triggeredBy: 'system',
                agentId: chat.assignedAgentId,
            });
            this.eventEmitter.emit('chat.closed.agent.timeout', {
                chatId: chat.id,
                agentId: chat.assignedAgentId,
            });
            this.logger.log(`🚫 Chat ${chat.id} cerrado por timeout de agente`);
        }
        catch (error) {
            this.logger.error(`Error cerrando chat por timeout de agente: ${error.message}`);
        }
    }
    async closeByClientTimeout(chat) {
        try {
            await this.chatStateService.transition(chat.id, 'closed', 'closed_client_inactive', {
                reason: `Chat cerrado automáticamente: cliente no respondió en ${this.CLIENT_TIMEOUT_TIME} minutos`,
                triggeredBy: 'system',
                agentId: chat.assignedAgentId,
            });
            this.eventEmitter.emit('chat.closed.client.timeout', {
                chatId: chat.id,
                agentId: chat.assignedAgentId,
            });
            this.logger.log(`🚫 Chat ${chat.id} cerrado por inactividad del cliente`);
        }
        catch (error) {
            this.logger.error(`Error cerrando chat por timeout de cliente: ${error.message}`);
        }
    }
    async getTimeoutStats(startDate, endDate) {
        const agentTimeouts = await this.chatRepository
            .createQueryBuilder('chat')
            .where('chat.subStatus = :status', { status: 'closed_agent_timeout' })
            .andWhere('chat.closedAt BETWEEN :startDate AND :endDate', { startDate, endDate })
            .getCount();
        const clientTimeouts = await this.chatRepository
            .createQueryBuilder('chat')
            .where('chat.subStatus = :status', { status: 'closed_client_inactive' })
            .andWhere('chat.closedAt BETWEEN :startDate AND :endDate', { startDate, endDate })
            .getCount();
        return {
            agentTimeouts,
            clientTimeouts,
            total: agentTimeouts + clientTimeouts,
        };
    }
};
exports.TimeoutMonitorWorker = TimeoutMonitorWorker;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_MINUTE),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TimeoutMonitorWorker.prototype, "checkTimeouts", null);
exports.TimeoutMonitorWorker = TimeoutMonitorWorker = TimeoutMonitorWorker_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        chat_state_service_1.ChatStateService,
        event_emitter_1.EventEmitter2])
], TimeoutMonitorWorker);
//# sourceMappingURL=timeout-monitor.worker.js.map