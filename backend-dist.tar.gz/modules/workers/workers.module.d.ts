export declare class WorkersModule {
}
