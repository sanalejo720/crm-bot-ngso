import { OnGatewayConnection, OnGatewayDisconnect } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
import { Repository } from 'typeorm';
import { Chat } from '../chats/entities/chat.entity';
import { Message } from '../messages/entities/message.entity';
import { User, AgentState } from '../users/entities/user.entity';
interface AuthenticatedSocket extends Socket {
    userId?: string;
    user?: User;
}
export declare class EventsGateway implements OnGatewayConnection, OnGatewayDisconnect {
    private jwtService;
    private userRepository;
    server: Server;
    private readonly logger;
    private connectedUsers;
    constructor(jwtService: JwtService, userRepository: Repository<User>);
    handleConnection(client: AuthenticatedSocket): Promise<void>;
    handleDisconnect(client: AuthenticatedSocket): Promise<void>;
    handleSubscribeChat(client: AuthenticatedSocket, data: {
        chatId: string;
    }): {
        success: boolean;
    };
    handleUnsubscribeChat(client: AuthenticatedSocket, data: {
        chatId: string;
    }): {
        success: boolean;
    };
    handleAgentJoin(client: AuthenticatedSocket, data: {
        agentId: string;
    }): {
        success: boolean;
        room: string;
    };
    handleTyping(client: AuthenticatedSocket, data: {
        chatId: string;
        isTyping: boolean;
    }): void;
    handleAgentStateChange(client: AuthenticatedSocket, data: {
        state: AgentState;
    }): {
        success: boolean;
    };
    handleChatCreated(chat: Chat): void;
    handleChatAssigned(data: {
        chat: Chat;
        agentId: string;
        agentName: string;
    }): void;
    handleChatTransferred(data: {
        chat: Chat;
        fromAgentId: string;
        toAgentId: string;
        fromAgentName: string;
        toAgentName: string;
    }): void;
    handleDebtorLinked(data: {
        chatId: string;
        debtorId: string;
        debtorInfo: {
            id: string;
            fullName: string;
            documentNumber: string;
            phone: string;
            email: string;
            debtAmount: number;
            status: string;
            campaignName: string;
        };
    }): void;
    handleChatUnassigned(data: {
        chat: Chat;
        previousAgentId: string;
        reason: string;
    }): void;
    handleChatClosed(chat: Chat): void;
    handleMessageCreated(event: {
        message: Message;
        chat: any;
    }): void;
    handleMessageStatusUpdated(data: {
        messageId: string;
        chatId: string;
        status: string;
    }): void;
    handleAgentStateChanged(data: {
        userId: string;
        userName: string;
        state: AgentState;
    }): void;
    handleWhatsAppQRGenerated(data: {
        numberId: string;
        qrCode: string;
        sessionName?: string;
    }): void;
    handleWhatsAppSessionStatus(data: {
        sessionName: string;
        status: string;
    }): void;
    handleWhatsAppSessionDisconnected(data: {
        numberId: string;
    }): void;
    handleWhatsAppMessageReceived(data: any): void;
    handleAgentTimeoutWarning(data: {
        chatId: number;
        agentId: number;
        minutesSinceLastMessage: number;
    }): void;
    handleClientTimeoutWarning(data: {
        chatId: number;
        agentId: number;
        minutesSinceLastMessage: number;
    }): void;
    handleChatClosedByAgentTimeout(data: {
        chatId: number;
        agentId: number;
    }): void;
    handleChatClosedByClientTimeout(data: {
        chatId: number;
        agentId: number;
    }): void;
    handleChatAutoClosed(data: {
        chatId: number;
        agentId?: number;
        inactiveHours: number;
        lastActivity: Date;
    }): void;
    emitToUser(userId: string, event: string, data: any): void;
    emitToChat(chatId: string, event: string, data: any): void;
    emitToAgents(event: string, data: any): void;
    emitToSupervisors(event: string, data: any): void;
    isUserConnected(userId: string): boolean;
    getConnectedUsers(): string[];
    notifyAgentTimeout(agentId: number, chatId: number, minutesSinceLastMessage: number): void;
    notifyClientTimeout(agentId: number, chatId: number, minutesSinceLastMessage: number): void;
    playSoundNotification(userId: string, soundType: 'success' | 'warning' | 'error' | 'notification' | 'alert'): void;
    sendBrowserNotification(userId: string, title: string, options: {
        body?: string;
        icon?: string;
        badge?: string;
        sound?: string;
        vibrate?: number[];
        tag?: string;
        requireInteraction?: boolean;
    }): void;
    notifyUpcomingAutoClose(agentId: number, chatId: number, hoursRemaining: number): void;
    notifyAgentChatClosed(agentId: number, chatId: number, reason: string, message: string): void;
    notifySupervisorsTimeoutStats(stats: {
        agentTimeouts: number;
        clientTimeouts: number;
        autoClosures: number;
        period: string;
    }): void;
    notifyWaitingQueueUpdate(queueCount: number, chatId?: number): void;
}
export {};
