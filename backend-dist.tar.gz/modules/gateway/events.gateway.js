"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var EventsGateway_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventsGateway = void 0;
const websockets_1 = require("@nestjs/websockets");
const socket_io_1 = require("socket.io");
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const event_emitter_1 = require("@nestjs/event-emitter");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const chat_entity_1 = require("../chats/entities/chat.entity");
const user_entity_1 = require("../users/entities/user.entity");
let EventsGateway = EventsGateway_1 = class EventsGateway {
    constructor(jwtService, userRepository) {
        this.jwtService = jwtService;
        this.userRepository = userRepository;
        this.logger = new common_1.Logger(EventsGateway_1.name);
        this.connectedUsers = new Map();
    }
    async handleConnection(client) {
        try {
            const token = client.handshake.auth?.token || client.handshake.headers?.authorization?.replace('Bearer ', '');
            if (!token) {
                this.logger.warn(`❌ Cliente sin token rechazado: ${client.id}`);
                client.disconnect();
                return;
            }
            this.logger.log(`🔍 Validando token para cliente: ${client.id}`);
            const payload = await this.jwtService.verifyAsync(token);
            client.userId = payload.sub;
            client.user = payload;
            this.connectedUsers.set(payload.sub, client.id);
            client.join(`user:${payload.sub}`);
            const user = await this.userRepository.findOne({ where: { id: payload.sub } });
            if (user?.isAgent) {
                client.join('agents');
                if (user.agentState === user_entity_1.AgentState.OFFLINE) {
                    await this.userRepository.update(payload.sub, {
                        agentState: user_entity_1.AgentState.AVAILABLE,
                        lastActivityAt: new Date(),
                    });
                    this.logger.log(`✅ Agente ${payload.email} puesto en estado AVAILABLE (WebSocket)`);
                }
            }
            if (payload.role?.name === 'Supervisor' || payload.role?.name === 'Super Admin' || payload.role?.name === 'Administrador') {
                client.join('supervisors');
            }
            this.logger.log(`✅ Cliente conectado exitosamente: ${payload.email} (${client.id})`);
            this.server.to('supervisors').emit('agent:online', {
                userId: payload.sub,
                userName: payload.fullName,
                timestamp: new Date(),
            });
        }
        catch (error) {
            this.logger.error(`❌ Error en autenticación WebSocket (${client.id}): ${error.message}`);
            client.disconnect();
        }
    }
    async handleDisconnect(client) {
        if (client.userId) {
            this.connectedUsers.delete(client.userId);
            const user = await this.userRepository.findOne({ where: { id: client.userId } });
            if (user?.isAgent) {
                await this.userRepository.update(client.userId, {
                    agentState: user_entity_1.AgentState.OFFLINE,
                    lastActivityAt: new Date(),
                });
                this.logger.log(`✅ Agente ${client.userId} puesto en estado OFFLINE (desconexión WebSocket)`);
            }
            this.logger.log(`Cliente desconectado: ${client.userId} (${client.id})`);
            this.server.to('supervisors').emit('agent:offline', {
                userId: client.userId,
                timestamp: new Date(),
            });
        }
    }
    handleSubscribeChat(client, data) {
        client.join(`chat:${data.chatId}`);
        this.logger.log(`Usuario ${client.userId} suscrito a chat ${data.chatId}`);
        return { success: true };
    }
    handleUnsubscribeChat(client, data) {
        client.leave(`chat:${data.chatId}`);
        this.logger.log(`Usuario ${client.userId} desuscrito de chat ${data.chatId}`);
        return { success: true };
    }
    handleAgentJoin(client, data) {
        const roomName = `user:${data.agentId}`;
        client.join(roomName);
        this.logger.log(`✅ Agente ${data.agentId} unido a sala ${roomName} (Socket: ${client.id})`);
        return { success: true, room: roomName };
    }
    handleTyping(client, data) {
        this.server.to(`chat:${data.chatId}`).emit('chat:typing', {
            chatId: data.chatId,
            userId: client.userId,
            userName: client.user?.fullName,
            isTyping: data.isTyping,
            timestamp: new Date(),
        });
    }
    handleAgentStateChange(client, data) {
        this.server.to('supervisors').emit('agent:state-changed', {
            userId: client.userId,
            userName: client.user?.fullName,
            state: data.state,
            timestamp: new Date(),
        });
        return { success: true };
    }
    handleChatCreated(chat) {
        this.logger.log(`Evento chat.created: ${chat.id}`);
        this.server.to('agents').emit('chat:new', {
            chatId: chat.id,
            campaignId: chat.campaignId,
            contactPhone: chat.contactPhone,
            contactName: chat.contactName,
            lastMessage: chat.lastMessage,
            timestamp: new Date(),
        });
        this.server.to('supervisors').emit('chat:created', {
            chatId: chat.id,
            campaignId: chat.campaignId,
            status: chat.status,
            timestamp: new Date(),
        });
    }
    handleChatAssigned(data) {
        this.logger.log(`📨 Evento chat.assigned recibido: Chat ${data.chat.id} -> Agente ${data.agentName} (${data.agentId})`);
        const roomName = `user:${data.agentId}`;
        const socketId = this.connectedUsers.get(data.agentId);
        this.logger.log(`🎯 Emitiendo a sala: ${roomName} (Socket: ${socketId || 'no conectado'})`);
        this.server.to(roomName).emit('chat:assigned', {
            chatId: data.chat.id,
            campaignId: data.chat.campaignId,
            contactPhone: data.chat.contactPhone,
            contactName: data.chat.contactName,
            lastMessage: data.chat.lastMessage,
            timestamp: new Date(),
        });
        this.server.to('supervisors').emit('chat:assignment', {
            chatId: data.chat.id,
            agentId: data.agentId,
            agentName: data.agentName,
            timestamp: new Date(),
        });
        this.logger.log(`✅ Evento chat:assigned emitido correctamente`);
    }
    handleChatTransferred(data) {
        this.logger.log(`Evento chat.transferred: ${data.chat.id} -> ${data.toAgentName}`);
        this.server.to(`user:${data.fromAgentId}`).emit('chat:transferred-out', {
            chatId: data.chat.id,
            toAgentName: data.toAgentName,
            timestamp: new Date(),
        });
        this.server.to(`user:${data.toAgentId}`).emit('chat:transferred-in', {
            chatId: data.chat.id,
            campaignId: data.chat.campaignId,
            contactPhone: data.chat.contactPhone,
            contactName: data.chat.contactName,
            fromAgentName: data.fromAgentName,
            timestamp: new Date(),
        });
        this.server.to('supervisors').emit('chat:transfer', {
            chatId: data.chat.id,
            fromAgentId: data.fromAgentId,
            toAgentId: data.toAgentId,
            timestamp: new Date(),
        });
    }
    handleDebtorLinked(data) {
        this.logger.log(`📋 Evento chat.debtor.linked: Chat ${data.chatId} vinculado a deudor ${data.debtorInfo.fullName}`);
        this.server.to(`chat:${data.chatId}`).emit('chat:debtor:linked', {
            chatId: data.chatId,
            debtorId: data.debtorId,
            debtor: data.debtorInfo,
            timestamp: new Date(),
        });
        this.server.to('supervisors').emit('chat:debtor:linked', {
            chatId: data.chatId,
            debtorId: data.debtorId,
            debtor: data.debtorInfo,
            timestamp: new Date(),
        });
        this.logger.log(`✅ Evento chat:debtor:linked emitido para chat ${data.chatId}`);
    }
    handleChatUnassigned(data) {
        this.logger.log(`Evento chat.unassigned: ${data.chat.id} desasignado del agente ${data.previousAgentId}`);
        this.server.to(`user:${data.previousAgentId}`).emit('chat:unassigned', {
            chatId: data.chat.id,
            reason: data.reason,
            timestamp: new Date(),
        });
        this.server.to('supervisors').emit('chat:unassigned', {
            chatId: data.chat.id,
            previousAgentId: data.previousAgentId,
            reason: data.reason,
            timestamp: new Date(),
        });
    }
    handleChatClosed(chat) {
        this.logger.log(`Evento chat.closed: ${chat.id}`);
        this.server.to(`chat:${chat.id}`).emit('chat:closed', {
            chatId: chat.id,
            status: chat.status,
            timestamp: new Date(),
        });
        if (chat.assignedAgentId) {
            this.server.to(`user:${chat.assignedAgentId}`).emit('chat:closed', {
                chatId: chat.id,
                timestamp: new Date(),
            });
        }
        this.server.to('supervisors').emit('chat:status-changed', {
            chatId: chat.id,
            status: chat.status,
            timestamp: new Date(),
        });
    }
    handleMessageCreated(event) {
        const { message, chat } = event;
        this.logger.log(`Evento message.created: ${message.id} en chat ${message.chatId}`);
        this.server.to(`chat:${message.chatId}`).emit('message:new', {
            messageId: message.id,
            chatId: message.chatId,
            type: message.type,
            direction: message.direction,
            senderType: message.senderType,
            content: message.content,
            mediaUrl: message.mediaUrl,
            status: message.status,
            timestamp: message.createdAt,
        });
        if (chat?.assignedAgentId) {
            this.server.to(`user:${chat.assignedAgentId}`).emit('message:new', {
                messageId: message.id,
                chatId: message.chatId,
                type: message.type,
                direction: message.direction,
                senderType: message.senderType,
                content: message.content,
                mediaUrl: message.mediaUrl,
                status: message.status,
                timestamp: message.createdAt,
            });
        }
    }
    handleMessageStatusUpdated(data) {
        this.logger.log(`Evento message.status-updated: ${data.messageId} -> ${data.status}`);
        this.server.to(`chat:${data.chatId}`).emit('message:status', {
            messageId: data.messageId,
            status: data.status,
            timestamp: new Date(),
        });
    }
    handleAgentStateChanged(data) {
        this.logger.log(`Evento user.agent-state-changed: ${data.userName} -> ${data.state}`);
        this.server.to('supervisors').emit('agent:state-changed', {
            userId: data.userId,
            userName: data.userName,
            state: data.state,
            timestamp: new Date(),
        });
    }
    handleWhatsAppQRGenerated(data) {
        this.logger.log(`Evento whatsapp.qrcode.generated: ${data.numberId || data.sessionName}`);
        this.server.emit('whatsapp.qrcode.generated', {
            numberId: data.numberId,
            sessionName: data.sessionName,
            qrCode: data.qrCode,
            timestamp: new Date(),
        });
    }
    handleWhatsAppSessionStatus(data) {
        this.logger.log(`Evento whatsapp.session.status: ${data.sessionName} -> ${data.status}`);
        this.server.emit('whatsapp.session.status', {
            sessionName: data.sessionName,
            status: data.status,
            timestamp: new Date(),
        });
        if (data.status === 'isLogged' || data.status === 'qrReadSuccess') {
            this.server.emit('whatsapp.session.connected', {
                sessionName: data.sessionName,
                timestamp: new Date(),
            });
        }
    }
    handleWhatsAppSessionDisconnected(data) {
        this.logger.log(`Evento whatsapp.session.disconnected: ${data.numberId}`);
        this.server.emit('whatsapp.session.disconnected', {
            numberId: data.numberId,
            timestamp: new Date(),
        });
    }
    handleWhatsAppMessageReceived(data) {
        this.logger.log(`Evento whatsapp.message.received: ${data.from}`);
        this.server.to('agents').emit('whatsapp.message.incoming', {
            from: data.from,
            content: data.content,
            timestamp: data.timestamp,
        });
    }
    handleAgentTimeoutWarning(data) {
        this.logger.log(`⚠️ Warning de timeout de agente: Chat ${data.chatId}, Agente ${data.agentId}`);
        this.server.to(`user:${data.agentId}`).emit('chat:agent:timeout:warning', {
            chatId: data.chatId,
            minutesSinceLastMessage: data.minutesSinceLastMessage,
            message: `⚠️ El cliente está esperando tu respuesta hace ${data.minutesSinceLastMessage} minutos`,
            timestamp: new Date(),
            sound: 'warning',
            priority: 'high',
        });
        this.server.to('supervisors').emit('chat:agent:timeout:warning', {
            chatId: data.chatId,
            agentId: data.agentId,
            minutesSinceLastMessage: data.minutesSinceLastMessage,
            timestamp: new Date(),
        });
    }
    handleClientTimeoutWarning(data) {
        this.logger.log(`⚠️ Warning de timeout de cliente: Chat ${data.chatId}`);
        this.server.to(`user:${data.agentId}`).emit('chat:client:timeout:warning', {
            chatId: data.chatId,
            minutesSinceLastMessage: data.minutesSinceLastMessage,
            message: `⏰ El cliente no responde hace ${data.minutesSinceLastMessage} minutos. El chat se cerrará pronto.`,
            timestamp: new Date(),
            sound: 'notification',
            priority: 'medium',
        });
    }
    handleChatClosedByAgentTimeout(data) {
        this.logger.log(`🚫 Chat ${data.chatId} cerrado por timeout de agente ${data.agentId}`);
        this.server.to(`user:${data.agentId}`).emit('chat:closed:agent:timeout', {
            chatId: data.chatId,
            message: '🚫 Chat cerrado automáticamente por no responder a tiempo',
            timestamp: new Date(),
            sound: 'alert',
            priority: 'critical',
        });
        this.server.to('supervisors').emit('chat:closed:agent:timeout', {
            chatId: data.chatId,
            agentId: data.agentId,
            timestamp: new Date(),
        });
        this.server.to(`chat:${data.chatId}`).emit('chat:closed', {
            chatId: data.chatId,
            reason: 'agent_timeout',
            timestamp: new Date(),
        });
    }
    handleChatClosedByClientTimeout(data) {
        this.logger.log(`🚫 Chat ${data.chatId} cerrado por inactividad del cliente`);
        this.server.to(`user:${data.agentId}`).emit('chat:closed:client:timeout', {
            chatId: data.chatId,
            message: '✅ Chat cerrado automáticamente por inactividad del cliente',
            timestamp: new Date(),
            sound: 'success',
            priority: 'low',
        });
        this.server.to('supervisors').emit('chat:closed:client:timeout', {
            chatId: data.chatId,
            agentId: data.agentId,
            timestamp: new Date(),
        });
        this.server.to(`chat:${data.chatId}`).emit('chat:closed', {
            chatId: data.chatId,
            reason: 'client_timeout',
            timestamp: new Date(),
        });
    }
    handleChatAutoClosed(data) {
        this.logger.log(`🔒 Chat ${data.chatId} cerrado automáticamente por ${data.inactiveHours}h de inactividad`);
        if (data.agentId) {
            this.server.to(`user:${data.agentId}`).emit('chat:auto:closed', {
                chatId: data.chatId,
                inactiveHours: data.inactiveHours,
                lastActivity: data.lastActivity,
                message: `🔒 Chat cerrado automáticamente por ${data.inactiveHours} horas de inactividad`,
                timestamp: new Date(),
                sound: 'notification',
                priority: 'low',
            });
        }
        this.server.to('supervisors').emit('chat:auto:closed', {
            chatId: data.chatId,
            agentId: data.agentId,
            inactiveHours: data.inactiveHours,
            lastActivity: data.lastActivity,
            timestamp: new Date(),
        });
        this.server.to(`chat:${data.chatId}`).emit('chat:closed', {
            chatId: data.chatId,
            reason: 'auto_close',
            inactiveHours: data.inactiveHours,
            timestamp: new Date(),
        });
    }
    emitToUser(userId, event, data) {
        this.server.to(`user:${userId}`).emit(event, data);
    }
    emitToChat(chatId, event, data) {
        this.server.to(`chat:${chatId}`).emit(event, data);
    }
    emitToAgents(event, data) {
        this.server.to('agents').emit(event, data);
    }
    emitToSupervisors(event, data) {
        this.server.to('supervisors').emit(event, data);
    }
    isUserConnected(userId) {
        return this.connectedUsers.has(userId);
    }
    getConnectedUsers() {
        return Array.from(this.connectedUsers.keys());
    }
    notifyAgentTimeout(agentId, chatId, minutesSinceLastMessage) {
        this.logger.log(`🔔 Notificando timeout de agente: ${agentId} - Chat ${chatId}`);
        this.server.to(`user:${agentId}`).emit('notification:agent:timeout', {
            type: 'agent_timeout',
            chatId,
            minutesSinceLastMessage,
            title: '⚠️ Cliente esperando respuesta',
            message: `El cliente del chat #${chatId} está esperando hace ${minutesSinceLastMessage} minutos`,
            sound: 'warning',
            vibrate: [200, 100, 200],
            priority: 'high',
            timestamp: new Date(),
            actions: [
                { action: 'view', title: 'Ver chat' },
                { action: 'dismiss', title: 'Ignorar' },
            ],
        });
    }
    notifyClientTimeout(agentId, chatId, minutesSinceLastMessage) {
        this.logger.log(`🔔 Notificando timeout de cliente: Chat ${chatId}`);
        this.server.to(`user:${agentId}`).emit('notification:client:timeout', {
            type: 'client_timeout',
            chatId,
            minutesSinceLastMessage,
            title: '⏰ Cliente inactivo',
            message: `El cliente del chat #${chatId} no responde hace ${minutesSinceLastMessage} minutos`,
            sound: 'notification',
            priority: 'medium',
            timestamp: new Date(),
        });
    }
    playSoundNotification(userId, soundType) {
        this.server.to(`user:${userId}`).emit('sound:play', {
            type: soundType,
            timestamp: new Date(),
        });
    }
    sendBrowserNotification(userId, title, options) {
        this.server.to(`user:${userId}`).emit('browser:notification', {
            title,
            options,
            timestamp: new Date(),
        });
    }
    notifyUpcomingAutoClose(agentId, chatId, hoursRemaining) {
        this.logger.log(`📅 Notificando auto-cierre próximo: Chat ${chatId} - ${hoursRemaining}h restantes`);
        this.server.to(`user:${agentId}`).emit('notification:upcoming:close', {
            type: 'upcoming_close',
            chatId,
            hoursRemaining,
            title: '📅 Chat próximo a cerrarse',
            message: `El chat #${chatId} se cerrará automáticamente en ${hoursRemaining} horas por inactividad`,
            sound: 'notification',
            priority: 'low',
            timestamp: new Date(),
        });
    }
    notifyAgentChatClosed(agentId, chatId, reason, message) {
        this.logger.log(`🚫 Notificando cierre de chat: ${chatId} - Razón: ${reason}`);
        const soundMap = {
            agent_timeout: 'alert',
            client_timeout: 'success',
            auto_close: 'notification',
            manual: 'success',
        };
        const priorityMap = {
            agent_timeout: 'critical',
            client_timeout: 'low',
            auto_close: 'low',
            manual: 'medium',
        };
        this.server.to(`user:${agentId}`).emit('notification:chat:closed', {
            type: 'chat_closed',
            chatId,
            reason,
            message,
            sound: soundMap[reason] || 'notification',
            priority: priorityMap[reason] || 'medium',
            timestamp: new Date(),
        });
    }
    notifySupervisorsTimeoutStats(stats) {
        this.logger.log(`📊 Enviando estadísticas de timeouts a supervisores`);
        this.server.to('supervisors').emit('stats:timeouts', {
            ...stats,
            timestamp: new Date(),
        });
    }
    notifyWaitingQueueUpdate(queueCount, chatId) {
        this.logger.log(`📋 Actualizando cola de espera: ${queueCount} chats`);
        this.server.to('supervisors').emit('queue:waiting:update', {
            queueCount,
            chatId,
            timestamp: new Date(),
        });
        if (chatId) {
            this.server.to('supervisors').emit('sound:play', {
                type: 'notification',
                reason: 'new_waiting_chat',
                chatId,
            });
        }
    }
};
exports.EventsGateway = EventsGateway;
__decorate([
    (0, websockets_1.WebSocketServer)(),
    __metadata("design:type", socket_io_1.Server)
], EventsGateway.prototype, "server", void 0);
__decorate([
    (0, websockets_1.SubscribeMessage)('chat:subscribe'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleSubscribeChat", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('chat:unsubscribe'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleUnsubscribeChat", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('agent:join'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleAgentJoin", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('chat:typing'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleTyping", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('agent:state'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleAgentStateChange", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.created'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [chat_entity_1.Chat]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatCreated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.assigned'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatAssigned", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.transferred'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatTransferred", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.debtor.linked'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleDebtorLinked", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.unassigned'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatUnassigned", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.closed'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [chat_entity_1.Chat]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatClosed", null);
__decorate([
    (0, event_emitter_1.OnEvent)('message.created'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleMessageCreated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('message.status-updated'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleMessageStatusUpdated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('user.agent-state-changed'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleAgentStateChanged", null);
__decorate([
    (0, event_emitter_1.OnEvent)('whatsapp.qrcode.generated'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleWhatsAppQRGenerated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('whatsapp.session.status'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleWhatsAppSessionStatus", null);
__decorate([
    (0, event_emitter_1.OnEvent)('whatsapp.session.disconnected'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleWhatsAppSessionDisconnected", null);
__decorate([
    (0, event_emitter_1.OnEvent)('whatsapp.message.received'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleWhatsAppMessageReceived", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.agent.timeout.warning'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleAgentTimeoutWarning", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.client.timeout.warning'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleClientTimeoutWarning", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.closed.agent.timeout'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatClosedByAgentTimeout", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.closed.client.timeout'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatClosedByClientTimeout", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.auto.closed'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatAutoClosed", null);
exports.EventsGateway = EventsGateway = EventsGateway_1 = __decorate([
    (0, websockets_1.WebSocketGateway)({
        cors: {
            origin: [
                process.env.FRONTEND_URL || 'http://localhost:5173',
                'http://localhost:5174',
            ],
            credentials: true,
        },
        namespace: '/events',
    }),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [jwt_1.JwtService,
        typeorm_2.Repository])
], EventsGateway);
//# sourceMappingURL=events.gateway.js.map