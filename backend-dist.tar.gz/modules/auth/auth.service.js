"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AuthService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const config_1 = require("@nestjs/config");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const bcrypt = __importStar(require("bcrypt"));
const speakeasy = __importStar(require("speakeasy"));
const user_entity_1 = require("../users/entities/user.entity");
const agent_sessions_service_1 = require("../users/services/agent-sessions.service");
const agent_session_entity_1 = require("../users/entities/agent-session.entity");
let AuthService = AuthService_1 = class AuthService {
    constructor(userRepository, jwtService, configService, agentSessionsService) {
        this.userRepository = userRepository;
        this.jwtService = jwtService;
        this.configService = configService;
        this.agentSessionsService = agentSessionsService;
        this.logger = new common_1.Logger(AuthService_1.name);
    }
    async validateUser(email, password) {
        const user = await this.userRepository.findOne({
            where: { email },
            relations: ['role', 'role.permissions'],
        });
        if (!user) {
            return null;
        }
        if (user.status !== user_entity_1.UserStatus.ACTIVE) {
            throw new common_1.UnauthorizedException('Usuario inactivo o suspendido');
        }
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return null;
        }
        const { password: _, ...result } = user;
        return result;
    }
    async login(loginDto) {
        const user = await this.validateUser(loginDto.email, loginDto.password);
        if (!user) {
            throw new common_1.UnauthorizedException('Credenciales inválidas');
        }
        if (user.twoFactorEnabled) {
            if (!loginDto.twoFactorCode) {
                throw new common_1.UnauthorizedException('Código 2FA requerido');
            }
            const isValid = speakeasy.totp.verify({
                secret: user.twoFactorSecret,
                encoding: 'base32',
                token: loginDto.twoFactorCode,
            });
            if (!isValid) {
                throw new common_1.UnauthorizedException('Código 2FA inválido');
            }
        }
        const tokens = await this.generateTokens(user);
        const updateData = {
            refreshToken: await bcrypt.hash(tokens.refreshToken, 10),
            lastLoginAt: new Date(),
        };
        if (user.isAgent) {
            updateData.agentState = user_entity_1.AgentState.AVAILABLE;
            await this.agentSessionsService.startSession(user.id, agent_session_entity_1.AgentSessionStatus.AVAILABLE, loginDto.ipAddress, loginDto.userAgent);
            this.logger.log(`✅ Agente ${user.email} puesto en estado AVAILABLE y sesión iniciada`);
        }
        await this.userRepository.update(user.id, updateData);
        this.logger.log(`Usuario ${user.email} inició sesión`);
        return {
            ...tokens,
            user: {
                id: user.id,
                fullName: user.fullName,
                email: user.email,
                role: {
                    id: user.role.id,
                    name: user.role.name,
                    permissions: user.role.permissions.map((p) => ({
                        id: p.id,
                        name: `${p.module}:${p.action}`,
                        module: p.module,
                        action: p.action,
                        description: p.description,
                    })),
                },
            },
        };
    }
    async register(registerDto) {
        const existingUser = await this.userRepository.findOne({
            where: { email: registerDto.email },
        });
        if (existingUser) {
            throw new common_1.ConflictException('El email ya está registrado');
        }
        const hashedPassword = await bcrypt.hash(registerDto.password, 10);
        const user = this.userRepository.create({
            ...registerDto,
            password: hashedPassword,
            status: user_entity_1.UserStatus.ACTIVE,
        });
        return this.userRepository.save(user);
    }
    async generateTokens(user) {
        const payload = {
            sub: user.id,
            email: user.email,
            roleId: user.role.id,
        };
        const accessToken = this.jwtService.sign(payload, {
            secret: this.configService.get('JWT_SECRET'),
            expiresIn: this.configService.get('JWT_EXPIRATION', '1h'),
        });
        const refreshToken = this.jwtService.sign(payload, {
            secret: this.configService.get('JWT_REFRESH_SECRET'),
            expiresIn: this.configService.get('JWT_REFRESH_EXPIRATION', '7d'),
        });
        return { accessToken, refreshToken };
    }
    async refreshToken(userId, refreshToken) {
        const user = await this.userRepository.findOne({
            where: { id: userId },
            relations: ['role', 'role.permissions'],
        });
        if (!user || !user.refreshToken) {
            throw new common_1.UnauthorizedException('Token inválido');
        }
        const isValid = await bcrypt.compare(refreshToken, user.refreshToken);
        if (!isValid) {
            throw new common_1.UnauthorizedException('Token inválido');
        }
        return this.generateTokens(user);
    }
    async logout(userId) {
        const user = await this.userRepository.findOne({ where: { id: userId } });
        const updateData = {
            refreshToken: null,
        };
        if (user?.isAgent) {
            updateData.agentState = user_entity_1.AgentState.OFFLINE;
            const activeSession = await this.agentSessionsService.getActiveSession(userId);
            if (activeSession) {
                await this.agentSessionsService.endSession(activeSession.id);
            }
            this.logger.log(`✅ Agente ${userId} puesto en estado OFFLINE y sesión finalizada`);
        }
        await this.userRepository.update(userId, updateData);
        this.logger.log(`Usuario ${userId} cerró sesión`);
    }
    generate2FASecret(email) {
        const secret = speakeasy.generateSecret({
            name: `CRM WhatsApp (${email})`,
            length: 32,
        });
        return {
            secret: secret.base32,
            qrCode: secret.otpauth_url,
        };
    }
    async enable2FA(userId, secret, token) {
        const isValid = speakeasy.totp.verify({
            secret,
            encoding: 'base32',
            token,
        });
        if (!isValid) {
            throw new common_1.UnauthorizedException('Código 2FA inválido');
        }
        await this.userRepository.update(userId, {
            twoFactorSecret: secret,
            twoFactorEnabled: true,
        });
        this.logger.log(`2FA habilitado para usuario ${userId}`);
    }
    async disable2FA(userId) {
        await this.userRepository.update(userId, {
            twoFactorSecret: null,
            twoFactorEnabled: false,
        });
        this.logger.log(`2FA deshabilitado para usuario ${userId}`);
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = AuthService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __param(3, (0, common_1.Inject)((0, common_1.forwardRef)(() => agent_sessions_service_1.AgentSessionsService))),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        jwt_1.JwtService,
        config_1.ConfigService,
        agent_sessions_service_1.AgentSessionsService])
], AuthService);
//# sourceMappingURL=auth.service.js.map