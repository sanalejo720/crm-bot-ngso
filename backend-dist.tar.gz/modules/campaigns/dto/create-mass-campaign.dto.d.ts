declare class RecipientDto {
    phone: string;
    variables?: Record<string, string>;
    agentEmail?: string;
}
export declare class CreateMassCampaignDto {
    name: string;
    templateSid: string;
    recipients: RecipientDto[];
    description?: string;
    messageDelay?: number;
    batchSize?: number;
}
export {};
