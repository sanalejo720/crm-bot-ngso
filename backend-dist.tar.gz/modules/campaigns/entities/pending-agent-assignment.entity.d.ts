import { Campaign } from './campaign.entity';
export declare class PendingAgentAssignment {
    id: number;
    phone: string;
    agentEmail: string;
    campaignId: string;
    campaign: Campaign;
    templateSid: string;
    expiresAt: Date;
    assigned: boolean;
    assignedAt: Date;
    createdAt: Date;
    updatedAt: Date;
}
