"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var CampaignsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampaignsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const campaign_entity_1 = require("./entities/campaign.entity");
const pending_agent_assignment_entity_1 = require("./entities/pending-agent-assignment.entity");
const event_emitter_1 = require("@nestjs/event-emitter");
const user_campaign_entity_1 = require("../users/entities/user-campaign.entity");
const whatsapp_service_1 = require("../whatsapp/whatsapp.service");
let CampaignsService = CampaignsService_1 = class CampaignsService {
    constructor(campaignRepository, userCampaignRepository, pendingAssignmentRepository, eventEmitter, whatsappService) {
        this.campaignRepository = campaignRepository;
        this.userCampaignRepository = userCampaignRepository;
        this.pendingAssignmentRepository = pendingAssignmentRepository;
        this.eventEmitter = eventEmitter;
        this.whatsappService = whatsappService;
        this.logger = new common_1.Logger(CampaignsService_1.name);
    }
    async create(createCampaignDto, createdBy) {
        this.logger.log(`Creando campaña: ${createCampaignDto.name}`);
        const campaign = this.campaignRepository.create({
            ...createCampaignDto,
            createdBy,
        });
        const saved = await this.campaignRepository.save(campaign);
        const savedCampaign = Array.isArray(saved) ? saved[0] : saved;
        this.eventEmitter.emit('campaign.created', savedCampaign);
        return savedCampaign;
    }
    async findAll(filters) {
        const query = this.campaignRepository.createQueryBuilder('campaign');
        if (filters?.status) {
            query.andWhere('campaign.status = :status', { status: filters.status });
        }
        if (filters?.search) {
            query.andWhere('(campaign.name LIKE :search OR campaign.description LIKE :search)', { search: `%${filters.search}%` });
        }
        query
            .leftJoinAndSelect('campaign.whatsappNumbers', 'whatsappNumbers')
            .orderBy('campaign.createdAt', 'DESC');
        return query.getMany();
    }
    async findActive() {
        return this.campaignRepository.find({
            where: { status: campaign_entity_1.CampaignStatus.ACTIVE },
            relations: ['whatsappNumbers'],
        });
    }
    async findOne(id) {
        const campaign = await this.campaignRepository.findOne({
            where: { id },
            relations: ['whatsappNumbers', 'chats', 'debtors'],
        });
        if (!campaign) {
            throw new common_1.NotFoundException(`Campaña ${id} no encontrada`);
        }
        return campaign;
    }
    async update(id, updateCampaignDto) {
        const campaign = await this.findOne(id);
        Object.assign(campaign, updateCampaignDto);
        const updatedCampaign = await this.campaignRepository.save(campaign);
        this.eventEmitter.emit('campaign.updated', updatedCampaign);
        return updatedCampaign;
    }
    async updateStatus(id, status) {
        const campaign = await this.findOne(id);
        const oldStatus = campaign.status;
        campaign.status = status;
        const updatedCampaign = await this.campaignRepository.save(campaign);
        this.eventEmitter.emit('campaign.status-changed', {
            campaign: updatedCampaign,
            oldStatus,
            newStatus: status,
        });
        return updatedCampaign;
    }
    async updateSettings(id, settings) {
        const campaign = await this.findOne(id);
        campaign.settings = {
            ...campaign.settings,
            ...settings,
        };
        return this.campaignRepository.save(campaign);
    }
    async activate(id) {
        return this.updateStatus(id, campaign_entity_1.CampaignStatus.ACTIVE);
    }
    async pause(id) {
        return this.updateStatus(id, campaign_entity_1.CampaignStatus.PAUSED);
    }
    async remove(id) {
        const campaign = await this.findOne(id);
        await this.campaignRepository.softRemove(campaign);
        this.eventEmitter.emit('campaign.deleted', { campaignId: id });
        this.logger.log(`Campaña ${id} eliminada`);
    }
    async getStats(id) {
        const campaign = await this.findOne(id);
        const totalChats = await this.campaignRepository
            .createQueryBuilder('campaign')
            .leftJoin('campaign.chats', 'chat')
            .where('campaign.id = :id', { id })
            .getCount();
        const chatsByStatus = await this.campaignRepository
            .createQueryBuilder('campaign')
            .leftJoin('campaign.chats', 'chat')
            .select('chat.status', 'status')
            .addSelect('COUNT(*)', 'count')
            .where('campaign.id = :id', { id })
            .groupBy('chat.status')
            .getRawMany();
        const totalDebtors = await this.campaignRepository
            .createQueryBuilder('campaign')
            .leftJoin('campaign.debtors', 'debtor')
            .where('campaign.id = :id', { id })
            .getCount();
        const debtorsByStatus = await this.campaignRepository
            .createQueryBuilder('campaign')
            .leftJoin('campaign.debtors', 'debtor')
            .select('debtor.status', 'status')
            .addSelect('COUNT(*)', 'count')
            .where('campaign.id = :id', { id })
            .groupBy('debtor.status')
            .getRawMany();
        return {
            id: campaign.id,
            name: campaign.name,
            status: campaign.status,
            totalChats,
            chatsByStatus: chatsByStatus.reduce((acc, item) => {
                acc[item.status] = parseInt(item.count);
                return acc;
            }, {}),
            totalDebtors,
            debtorsByStatus: debtorsByStatus.reduce((acc, item) => {
                acc[item.status] = parseInt(item.count);
                return acc;
            }, {}),
        };
    }
    async getWhatsappNumbers(id) {
        const campaign = await this.campaignRepository.findOne({
            where: { id },
            relations: ['whatsappNumbers'],
        });
        if (!campaign) {
            throw new common_1.NotFoundException(`Campaña ${id} no encontrada`);
        }
        return campaign.whatsappNumbers;
    }
    async duplicate(id, newName, createdBy) {
        const original = await this.findOne(id);
        const duplicated = this.campaignRepository.create({
            name: newName,
            description: original.description ? `${original.description} (Copia)` : undefined,
            status: campaign_entity_1.CampaignStatus.DRAFT,
            settings: { ...original.settings },
            createdBy,
        });
        const saved = await this.campaignRepository.save(duplicated);
        const savedCampaign = Array.isArray(saved) ? saved[0] : saved;
        this.logger.log(`Campaña ${id} duplicada como ${savedCampaign.id}`);
        return savedCampaign;
    }
    async getUserCampaigns(userId) {
        const userCampaigns = await this.userCampaignRepository.find({
            where: { userId, isActive: true },
            relations: ['campaign', 'campaign.whatsappNumbers'],
        });
        if (userCampaigns.length > 0) {
            return userCampaigns
                .filter(uc => uc.campaign && uc.campaign.status === campaign_entity_1.CampaignStatus.ACTIVE)
                .map(uc => uc.campaign);
        }
        return this.findActive();
    }
    async sendMassCampaign(dto, userId) {
        const batchSize = dto.batchSize || 10;
        const messageDelay = dto.messageDelay || 1000;
        this.logger.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        this.logger.log(`📤 INICIANDO CAMPAÑA MASIVA: ${dto.name}`);
        this.logger.log(`   Total destinatarios: ${dto.recipients.length}`);
        this.logger.log(`   Mensajes por lote: ${batchSize}`);
        this.logger.log(`   Delay entre lotes: ${messageDelay}ms`);
        this.logger.log(`   Plantilla: ${dto.templateSid}`);
        this.logger.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        const activeNumbers = await this.whatsappService.findAllActive();
        if (!activeNumbers || activeNumbers.length === 0) {
            throw new Error('No hay números de WhatsApp activos disponibles');
        }
        const whatsappNumber = activeNumbers[0];
        this.logger.log(`📞 Usando número WhatsApp: ${whatsappNumber.phoneNumber}`);
        const results = {
            total: dto.recipients.length,
            sent: 0,
            failed: 0,
            errors: [],
        };
        const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
        const totalBatches = Math.ceil(dto.recipients.length / batchSize);
        for (let i = 0; i < dto.recipients.length; i += batchSize) {
            const batch = dto.recipients.slice(i, i + batchSize);
            const batchNumber = Math.floor(i / batchSize) + 1;
            this.logger.log(`\n📦 Lote ${batchNumber}/${totalBatches} (${batch.length} mensajes)`);
            await Promise.all(batch.map(async (recipient, idx) => {
                try {
                    const phone = recipient.phone.replace(/\D/g, '');
                    if (phone.length < 10 || phone.length > 15) {
                        throw new Error('Formato de teléfono inválido');
                    }
                    const sendResult = await this.whatsappService.sendContentTemplate(whatsappNumber.id, `+${phone}`, dto.templateSid, recipient.variables || {});
                    if (recipient.agentEmail) {
                        const expiresAt = new Date();
                        expiresAt.setDate(expiresAt.getDate() + 7);
                        await this.pendingAssignmentRepository.save({
                            phone: `+${phone}`,
                            agentEmail: recipient.agentEmail,
                            templateSid: dto.templateSid,
                            expiresAt,
                            assigned: false,
                        });
                        this.logger.log(`   🎯 Asignación pendiente creada: ${phone} → ${recipient.agentEmail} (expira: ${expiresAt.toLocaleDateString()})`);
                    }
                    results.sent++;
                    const msgNum = i + idx + 1;
                    this.logger.log(`   ✅ [${msgNum}/${dto.recipients.length}] ${phone} - OK ${sendResult?.messageId ? `(ID: ${sendResult.messageId.substring(0, 15)}...)` : ''}`);
                }
                catch (error) {
                    results.failed++;
                    const msgNum = i + idx + 1;
                    const errorMsg = error.response?.data?.message || error.message || 'Error desconocido';
                    results.errors.push({
                        phone: recipient.phone,
                        error: errorMsg,
                    });
                    this.logger.error(`   ❌ [${msgNum}/${dto.recipients.length}] ${recipient.phone} - FAILED: ${errorMsg}`);
                }
            }));
            if (i + batchSize < dto.recipients.length) {
                this.logger.log(`   ⏱️  Esperando ${messageDelay}ms antes del siguiente lote...`);
                await delay(messageDelay);
            }
        }
        const successRate = ((results.sent / results.total) * 100).toFixed(2);
        this.logger.log(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
        this.logger.log(`✅ CAMPAÑA COMPLETADA: ${dto.name}`);
        this.logger.log(`   📊 Resultados:`);
        this.logger.log(`      Total: ${results.total}`);
        this.logger.log(`      ✅ Enviados: ${results.sent}`);
        this.logger.log(`      ❌ Fallidos: ${results.failed}`);
        this.logger.log(`      📈 Tasa de éxito: ${successRate}%`);
        this.logger.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`);
        return {
            campaignName: dto.name,
            templateSid: dto.templateSid,
            success: results.failed === 0,
            ...results,
            startedBy: userId,
            completedAt: new Date(),
        };
    }
    async validateCsvData(csvData) {
        const errors = [];
        const recipients = [];
        this.logger.log(`📋 Validando CSV: ${csvData.length} filas detectadas`);
        if (!csvData || csvData.length === 0) {
            return { valid: false, errors: ['El archivo CSV está vacío'], recipients: [] };
        }
        csvData.forEach((row, index) => {
            const rowNum = index + 1;
            const hasAnyValue = Object.values(row).some(val => val && val.toString().trim() !== '');
            if (!hasAnyValue) {
                this.logger.log(`⏭️  Fila ${rowNum} vacía, ignorando...`);
                return;
            }
            if (!row.phone && !row.telefono && !row.numero) {
                errors.push(`Fila ${rowNum}: No se encontró columna de teléfono (phone/telefono/numero)`);
                this.logger.error(`❌ Fila ${rowNum}: Sin columna de teléfono`);
                return;
            }
            const phone = (row.phone || row.telefono || row.numero).toString().replace(/\D/g, '');
            if (phone.length < 10 || phone.length > 15) {
                errors.push(`Fila ${rowNum}: Teléfono inválido (${phone})`);
                this.logger.error(`❌ Fila ${rowNum}: Teléfono inválido (${phone})`);
                return;
            }
            const variables = {};
            let agentEmail;
            Object.keys(row).forEach((key) => {
                const lowerKey = key.toLowerCase();
                if (lowerKey === 'agentemail' || lowerKey === 'agent_email' || lowerKey === 'correo_agente' || lowerKey === 'email_agente') {
                    agentEmail = row[key]?.toString().trim();
                }
                else if (!['phone', 'telefono', 'numero'].includes(lowerKey)) {
                    const match = key.match(/var(\d+)|variable(\d+)|(\d+)/i);
                    if (match) {
                        const varNum = match[1] || match[2] || match[3];
                        variables[varNum] = row[key]?.toString() || '';
                    }
                    else {
                        const colIndex = Object.keys(row).filter(k => !['phone', 'telefono', 'numero', 'agentemail', 'agent_email', 'correo_agente', 'email_agente'].includes(k.toLowerCase())).indexOf(key) + 1;
                        variables[colIndex.toString()] = row[key]?.toString() || '';
                    }
                }
            });
            const recipient = { phone, variables };
            if (agentEmail) {
                recipient.agentEmail = agentEmail;
            }
            recipients.push(recipient);
            this.logger.log(`✅ Fila ${rowNum}: ${phone} con ${Object.keys(variables).length} variables${agentEmail ? ` [Agente: ${agentEmail}]` : ''}`);
        });
        this.logger.log(`\n📊 Resumen validación: ${recipients.length} destinatarios válidos, ${errors.length} errores`);
        return {
            valid: errors.length === 0 && recipients.length > 0,
            errors,
            recipients,
        };
    }
    async findPendingAssignment(phone) {
        try {
            const assignment = await this.pendingAssignmentRepository.findOne({
                where: {
                    phone,
                    assigned: false,
                },
                order: {
                    createdAt: 'DESC',
                },
            });
            if (!assignment) {
                return null;
            }
            const now = new Date();
            if (assignment.expiresAt < now) {
                this.logger.log(`⏰ Asignación pendiente para ${phone} ha expirado (${assignment.expiresAt.toISOString()})`);
                return null;
            }
            this.logger.log(`🎯 Asignación pendiente encontrada: ${phone} → ${assignment.agentEmail}`);
            return assignment.agentEmail;
        }
        catch (error) {
            this.logger.error(`Error buscando asignación pendiente para ${phone}:`, error);
            return null;
        }
    }
    async markAssignmentAsCompleted(phone, agentEmail) {
        try {
            await this.pendingAssignmentRepository.update({
                phone,
                agentEmail,
                assigned: false,
            }, {
                assigned: true,
                assignedAt: new Date(),
            });
            this.logger.log(`✅ Asignación marcada como completada: ${phone} → ${agentEmail}`);
        }
        catch (error) {
            this.logger.error(`Error marcando asignación como completada:`, error);
        }
    }
};
exports.CampaignsService = CampaignsService;
exports.CampaignsService = CampaignsService = CampaignsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(campaign_entity_1.Campaign)),
    __param(1, (0, typeorm_1.InjectRepository)(user_campaign_entity_1.UserCampaign)),
    __param(2, (0, typeorm_1.InjectRepository)(pending_agent_assignment_entity_1.PendingAgentAssignment)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        event_emitter_1.EventEmitter2,
        whatsapp_service_1.WhatsappService])
], CampaignsService);
//# sourceMappingURL=campaigns.service.js.map