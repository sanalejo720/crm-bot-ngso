// Test de login
const axios = require('axios');

async function testLogin() {
  console.log('🔐 Probando login...\n');
  
  try {
    const response = await axios.post('http://localhost:3000/api/v1/auth/login', {
      email: 'san.alejo0720@gmail.com',
      password: 'admin123'
    });
    
    console.log('✅ Login exitoso!');
    console.log('Token:', response.data.access_token?.substring(0, 50) + '...');
    console.log('Usuario:', response.data.user?.fullName);
    console.log('Role:', response.data.user?.role?.name);
    
  } catch (error) {
    console.error('❌ Error en login:');
    console.error('Status:', error.response?.status);
    console.error('Message:', error.response?.data?.message);
    console.error('Data:', error.response?.data);
  }
}

testLogin();
