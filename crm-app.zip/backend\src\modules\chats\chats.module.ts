import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ChatsService } from './chats.service';
import { ChatsExportService } from './chats-export.service';
import { ChatsController } from './chats.controller';
import { Chat } from './entities/chat.entity';
import { Message } from '../messages/entities/message.entity';
import { User } from '../users/entities/user.entity';
import { UsersModule } from '../users/users.module';
import { WhatsappModule } from '../whatsapp/whatsapp.module';
import { EvidencesModule } from '../evidences/evidences.module';
import { EmailService } from '../../common/services/email.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([Chat, Message, User]),
    UsersModule,
    forwardRef(() => WhatsappModule),
    EvidencesModule,
  ],
  controllers: [ChatsController],
  providers: [ChatsService, ChatsExportService, EmailService],
  exports: [ChatsService],
})
export class ChatsModule {}
