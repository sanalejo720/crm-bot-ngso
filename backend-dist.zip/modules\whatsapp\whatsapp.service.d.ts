import { Repository } from 'typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { WhatsappNumber, ConnectionStatus } from './entities/whatsapp-number.entity';
import { WhatsappNumberCampaign } from './entities/whatsapp-number-campaign.entity';
import { MetaCloudService } from './providers/meta-cloud.service';
import { WppConnectService } from './providers/wppconnect.service';
import { TwilioService } from './providers/twilio.service';
import { MessageType } from '../messages/entities/message.entity';
export declare class WhatsappService {
    private whatsappNumberRepository;
    private whatsappNumberCampaignRepository;
    private metaCloudService;
    private wppConnectService;
    private twilioService;
    private eventEmitter;
    private readonly logger;
    constructor(whatsappNumberRepository: Repository<WhatsappNumber>, whatsappNumberCampaignRepository: Repository<WhatsappNumberCampaign>, metaCloudService: MetaCloudService, wppConnectService: WppConnectService, twilioService: TwilioService, eventEmitter: EventEmitter2);
    findOne(id: string): Promise<WhatsappNumber>;
    sendMessage(whatsappNumberId: string, to: string, content: string, type: MessageType, mediaUrl?: string): Promise<{
        messageId: string;
        metadata?: any;
    }>;
    processMetaWebhook(payload: any): Promise<void>;
    processTwilioWebhook(payload: any): Promise<void>;
    private sendViaMeta;
    private sendViaWppConnect;
    private sendViaTwilio;
    startWppConnectSession(whatsappNumberId: string): Promise<{
        success: boolean;
        message: string;
        sessionName: string;
        qrCode: string;
        status: string;
    }>;
    getWppConnectStatus(whatsappNumberId: string): Promise<{
        connected: boolean;
        phone?: string;
    }>;
    updateConnectionStatus(whatsappNumberId: string, status: ConnectionStatus): Promise<void>;
    findAllActive(): Promise<WhatsappNumber[]>;
    findByCampaign(campaignId: string): Promise<WhatsappNumber[]>;
    getDebugSessions(): Promise<{
        wppConnectSessions: string[];
        databaseNumbers: {
            id: string;
            phone: string;
            sessionName: string;
            status: ConnectionStatus;
        }[];
    }>;
    sendButtonsMessage(whatsappNumberId: string, to: string, title: string, description: string, buttons: Array<{
        id: string;
        text: string;
    }>): Promise<{
        messageId: string;
        metadata?: any;
    }>;
    sendListMessage(whatsappNumberId: string, to: string, title: string, description: string, buttonText: string, sections: Array<{
        title: string;
        rows: Array<{
            id: string;
            title: string;
            description?: string;
        }>;
    }>): Promise<{
        messageId: string;
        metadata?: any;
    }>;
    sendContentTemplate(whatsappNumberId: string, to: string, contentSid: string, contentVariables?: Record<string, string>): Promise<{
        messageId: string;
        metadata?: any;
    }>;
    getWhatsappNumberByCampaign(campaignId: string): Promise<WhatsappNumber | null>;
}
