import { ReportsService } from './reports.service';
export declare class ReportsController {
    private readonly reportsService;
    constructor(reportsService: ReportsService);
    getSystemMetrics(): Promise<import("./reports.service").SystemMetrics>;
    getDashboard(): Promise<{
        success: boolean;
        data: {
            totalAgents: number;
            activeAgents: number;
            totalChats: number;
            activeChats: number;
            totalDebt: number;
            recoveredToday: number;
            pendingTasks: number;
        };
    }>;
    getDailyReport(date?: string): Promise<{
        success: boolean;
        data: any[];
    }>;
    getChatStatistics(campaignId?: string): Promise<{
        success: boolean;
        data: any;
    }>;
    getSystemStats(): Promise<{
        totalAgents: number;
        activeAgents: number;
        totalChats: number;
        activeChats: number;
        totalDebt: number;
        recoveredToday: number;
        pendingTasks: number;
    }>;
    getMyStats(userId: string): Promise<{
        activeChats: number;
        totalChatsToday: number;
        maxConcurrentChats: number;
        messagesCount: number;
        promisesObtained: number;
        recoveredAmount: number;
        averageResponseTime: number;
        completionRate: number;
    }>;
    getMyActivity(userId: string): Promise<any[]>;
    getAgentsPerformance(): Promise<any[]>;
    getAgentMetrics(agentId: string, startDate?: string, endDate?: string): Promise<import("./reports.service").AgentMetrics>;
    getAllAgentsMetrics(startDate?: string, endDate?: string): Promise<import("./reports.service").AgentMetrics[]>;
    getAgentRanking(metric: 'totalChats' | 'resolvedChats' | 'averageResponseTime' | 'sentMessagesPerHour', startDate?: string, endDate?: string, limit?: string): Promise<import("./reports.service").AgentMetrics[]>;
    getCampaignMetrics(campaignId: string, startDate?: string, endDate?: string): Promise<import("./reports.service").CampaignMetrics>;
    getChatsTrend(startDate: string, endDate: string, campaignId?: string): Promise<any[]>;
    getChatsDistribution(campaignId?: string): Promise<any>;
}
