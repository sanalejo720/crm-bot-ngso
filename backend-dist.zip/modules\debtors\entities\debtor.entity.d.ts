import { Campaign } from '../../campaigns/entities/campaign.entity';
import { WhatsappNumber } from '../../whatsapp/entities/whatsapp-number.entity';
import { User } from '../../users/entities/user.entity';
export declare enum DocumentType {
    CC = "CC",
    CE = "CE",
    NIT = "NIT",
    TI = "TI",
    PASSPORT = "PASSPORT"
}
export declare class Debtor {
    id: string;
    fullName: string;
    documentType: DocumentType;
    documentNumber: string;
    phone: string;
    email: string;
    address: string;
    debtAmount: number;
    initialDebtAmount: number;
    daysOverdue: number;
    lastPaymentDate: Date;
    promiseDate: Date;
    status: string;
    notes: string;
    metadata: {
        producto?: string;
        numeroCredito?: string;
        fechaVencimiento?: string;
        [key: string]: any;
    };
    campaign: Campaign;
    campaignId: string;
    whatsappNumber: WhatsappNumber;
    whatsappNumberId: string;
    assignedAgent: User;
    assignedAgentId: string;
    contactType: string;
    createdAt: Date;
    updatedAt: Date;
    lastContactedAt: Date;
}
