"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AgentSessionsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentSessionsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const agent_session_entity_1 = require("../entities/agent-session.entity");
const user_entity_1 = require("../entities/user.entity");
let AgentSessionsService = AgentSessionsService_1 = class AgentSessionsService {
    constructor(agentSessionRepository, userRepository) {
        this.agentSessionRepository = agentSessionRepository;
        this.userRepository = userRepository;
        this.logger = new common_1.Logger(AgentSessionsService_1.name);
    }
    async startSession(userId, status, ipAddress, userAgent) {
        const user = await this.userRepository.findOne({
            where: { id: userId },
            relations: ['campaign'],
        });
        const session = this.agentSessionRepository.create({
            userId,
            status,
            startedAt: new Date(),
            ipAddress,
            userAgent,
            campaignId: user?.campaignId,
        });
        const saved = await this.agentSessionRepository.save(session);
        this.logger.log(`✅ Sesión iniciada para agente ${userId} con estado ${status}`);
        return saved;
    }
    async endSession(sessionId) {
        const session = await this.agentSessionRepository.findOne({
            where: { id: sessionId },
        });
        if (!session) {
            this.logger.warn(`⚠️ Sesión ${sessionId} no encontrada`);
            return null;
        }
        const endedAt = new Date();
        const durationSeconds = Math.floor((endedAt.getTime() - session.startedAt.getTime()) / 1000);
        session.endedAt = endedAt;
        session.durationSeconds = durationSeconds;
        await this.agentSessionRepository.save(session);
        this.logger.log(`✅ Sesión ${sessionId} finalizada. Duración: ${durationSeconds}s`);
        return session;
    }
    async changeSessionStatus(userId, newStatus, reason) {
        const activeSession = await this.getActiveSession(userId);
        if (activeSession) {
            await this.endSession(activeSession.id);
        }
        const session = this.agentSessionRepository.create({
            userId,
            status: newStatus,
            startedAt: new Date(),
            reason,
        });
        const saved = await this.agentSessionRepository.save(session);
        this.logger.log(`✅ Cambio de estado para ${userId}: ${newStatus}`);
        return saved;
    }
    async getActiveSession(userId) {
        return await this.agentSessionRepository.findOne({
            where: {
                userId,
                endedAt: null,
            },
            order: {
                startedAt: 'DESC',
            },
        });
    }
    async getAgentHistory(userId, startDate, endDate) {
        const query = this.agentSessionRepository
            .createQueryBuilder('session')
            .where('session.userId = :userId', { userId })
            .leftJoinAndSelect('session.campaign', 'campaign')
            .orderBy('session.startedAt', 'DESC');
        if (startDate && endDate) {
            query.andWhere('session.startedAt BETWEEN :startDate AND :endDate', {
                startDate,
                endDate,
            });
        }
        return await query.getMany();
    }
    async getAttendanceStats(userId, startDate, endDate) {
        const sessions = await this.getAgentHistory(userId, startDate, endDate);
        const stats = {
            totalSessions: sessions.length,
            totalTimeSeconds: 0,
            timeByStatus: {
                available: 0,
                busy: 0,
                break: 0,
                offline: 0,
            },
            averageSessionDuration: 0,
            firstLogin: null,
            lastLogout: null,
        };
        sessions.forEach((session) => {
            if (session.durationSeconds) {
                stats.totalTimeSeconds += session.durationSeconds;
                stats.timeByStatus[session.status] += session.durationSeconds;
            }
            if (!stats.firstLogin || session.startedAt < stats.firstLogin) {
                stats.firstLogin = session.startedAt;
            }
            if (session.endedAt && (!stats.lastLogout || session.endedAt > stats.lastLogout)) {
                stats.lastLogout = session.endedAt;
            }
        });
        if (sessions.length > 0) {
            stats.averageSessionDuration = Math.floor(stats.totalTimeSeconds / sessions.length);
        }
        return stats;
    }
    async getAllActiveSessions() {
        return await this.agentSessionRepository.find({
            where: {
                endedAt: null,
            },
            relations: ['user', 'campaign'],
            order: {
                startedAt: 'DESC',
            },
        });
    }
    async endAllActiveSessions() {
        const activeSessions = await this.getAllActiveSessions();
        for (const session of activeSessions) {
            await this.endSession(session.id);
        }
        this.logger.log(`✅ Finalizadas ${activeSessions.length} sesiones activas`);
        return activeSessions.length;
    }
    async cleanOrphanSessions() {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const orphanSessions = await this.agentSessionRepository.find({
            where: {
                endedAt: null,
                startedAt: (0, typeorm_2.Between)(new Date(0), yesterday),
            },
        });
        for (const session of orphanSessions) {
            await this.endSession(session.id);
        }
        this.logger.log(`🧹 Limpiadas ${orphanSessions.length} sesiones huérfanas`);
        return orphanSessions.length;
    }
};
exports.AgentSessionsService = AgentSessionsService;
exports.AgentSessionsService = AgentSessionsService = AgentSessionsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(agent_session_entity_1.AgentSession)),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], AgentSessionsService);
//# sourceMappingURL=agent-sessions.service.js.map