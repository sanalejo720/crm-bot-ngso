import { Chat } from '../../chats/entities/chat.entity';
import { User } from '../../users/entities/user.entity';
export declare enum MessageType {
    TEXT = "text",
    IMAGE = "image",
    AUDIO = "audio",
    VIDEO = "video",
    DOCUMENT = "document",
    LOCATION = "location",
    CONTACT = "contact",
    STICKER = "sticker",
    TEMPLATE = "template"
}
export declare enum MessageDirection {
    INBOUND = "inbound",
    OUTBOUND = "outbound"
}
export declare enum MessageStatus {
    PENDING = "pending",
    SENT = "sent",
    DELIVERED = "delivered",
    READ = "read",
    FAILED = "failed"
}
export declare enum MessageSenderType {
    CONTACT = "contact",
    AGENT = "agent",
    BOT = "bot",
    SYSTEM = "system"
}
export declare class Message {
    id: string;
    externalId: string;
    type: MessageType;
    direction: MessageDirection;
    senderType: MessageSenderType;
    content: string;
    mediaUrl: string;
    mediaFileName: string;
    mediaMimeType: string;
    mediaSize: number;
    status: MessageStatus;
    sentAt: Date;
    deliveredAt: Date;
    readAt: Date;
    errorMessage: string;
    metadata: Record<string, any>;
    isInternal: boolean;
    chat: Chat;
    chatId: string;
    sender: User;
    senderId: string;
    createdAt: Date;
}
