"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const app_module_1 = require("./app.module");
const compression_1 = __importDefault(require("compression"));
const helmet_1 = __importDefault(require("helmet"));
const path_1 = require("path");
async function bootstrap() {
    const logger = new common_1.Logger('Bootstrap');
    const app = await core_1.NestFactory.create(app_module_1.AppModule, {
        logger: ['error', 'warn', 'log', 'debug', 'verbose'],
    });
    app.useStaticAssets((0, path_1.join)(__dirname, '..', 'uploads'), {
        prefix: '/uploads/',
    });
    app.setGlobalPrefix('api/v1');
    app.enableCors({
        origin: [
            process.env.FRONTEND_URL || 'http://localhost:5173',
            'http://localhost:5174',
            'http://172.203.16.202',
            'https://172.203.16.202',
            'http://ngso-chat.assoftware.xyz',
            'https://ngso-chat.assoftware.xyz',
        ],
        credentials: true,
        methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    });
    app.use((0, helmet_1.default)({
        contentSecurityPolicy: false,
    }));
    app.use((0, compression_1.default)());
    app.useGlobalPipes(new common_1.ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
        transformOptions: {
            enableImplicitConversion: true,
        },
    }));
    if (process.env.NODE_ENV !== 'production') {
        const config = new swagger_1.DocumentBuilder()
            .setTitle('NGS&O CRM Gestión API')
            .setDescription('Sistema de Gestión de Cobranzas con WhatsApp - Desarrollado por AS Software')
            .setVersion('1.0.0')
            .setContact('AS Software', 'https://as-software.com', 'contacto@as-software.com')
            .addBearerAuth()
            .addTag('auth', 'Autenticación y autorización')
            .addTag('users', 'Gestión de usuarios y gestores')
            .addTag('roles', 'Gestión de roles y permisos')
            .addTag('campaigns', 'Gestión de campañas de cobranza')
            .addTag('whatsapp', 'Integración con WhatsApp')
            .addTag('chats', 'Gestión de conversaciones')
            .addTag('messages', 'Gestión de mensajes')
            .addTag('bot', 'Bot de cobranza automatizado')
            .addTag('clients', 'Gestión de clientes deudores')
            .addTag('tasks', 'Gestión de tareas de cobranza')
            .addTag('reports', 'Reportes y analytics de gestión')
            .addTag('audit', 'Auditoría y trazabilidad')
            .build();
        const document = swagger_1.SwaggerModule.createDocument(app, config);
        swagger_1.SwaggerModule.setup('api/docs', app, document, {
            swaggerOptions: {
                persistAuthorization: true,
            },
        });
        logger.log(`Swagger documentation available at http://localhost:${process.env.PORT}/api/docs`);
    }
    const port = process.env.PORT || 3000;
    await app.listen(port);
    logger.log(`╔════════════════════════════════════════════════════════╗`);
    logger.log(`║   NGS&O CRM Gestión - Sistema de Cobranzas           ║`);
    logger.log(`║   Desarrollado por: AS Software                       ║`);
    logger.log(`╚════════════════════════════════════════════════════════╝`);
    logger.log(`🚀 Application is running on: http://localhost:${port}/api/v1`);
    logger.log(`📚 API Documentation: http://localhost:${port}/api/docs`);
    logger.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
}
bootstrap();
//# sourceMappingURL=main.js.map