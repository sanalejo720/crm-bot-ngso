"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnidentifiedClientsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const unidentified_client_entity_1 = require("./entities/unidentified-client.entity");
const chat_entity_1 = require("../chats/entities/chat.entity");
const user_entity_1 = require("../users/entities/user.entity");
let UnidentifiedClientsService = class UnidentifiedClientsService {
    constructor(unidentifiedClientRepository, chatRepository, userRepository) {
        this.unidentifiedClientRepository = unidentifiedClientRepository;
        this.chatRepository = chatRepository;
        this.userRepository = userRepository;
    }
    async create(createDto) {
        const existing = await this.unidentifiedClientRepository.findOne({
            where: { phone: createDto.phone },
        });
        if (existing) {
            throw new common_1.ConflictException(`Ya existe un registro para el teléfono ${createDto.phone}`);
        }
        if (createDto.chatId) {
            const chat = await this.chatRepository.findOne({ where: { id: createDto.chatId } });
            if (!chat) {
                throw new common_1.NotFoundException(`Chat con ID ${createDto.chatId} no encontrado`);
            }
        }
        if (createDto.assignedToId) {
            const user = await this.userRepository.findOne({ where: { id: createDto.assignedToId } });
            if (!user) {
                throw new common_1.NotFoundException(`Usuario con ID ${createDto.assignedToId} no encontrado`);
            }
        }
        const client = this.unidentifiedClientRepository.create(createDto);
        return await this.unidentifiedClientRepository.save(client);
    }
    async findAll(page = 1, limit = 10, status, assignedTo, search) {
        const query = this.unidentifiedClientRepository
            .createQueryBuilder('client')
            .leftJoinAndSelect('client.chat', 'chat')
            .leftJoinAndSelect('client.assignedTo', 'assignedTo');
        if (status) {
            query.andWhere('client.status = :status', { status });
        }
        if (assignedTo) {
            query.andWhere('client.assignedToId = :assignedTo', { assignedTo });
        }
        if (search) {
            query.andWhere('(client.phone LIKE :search OR client.name LIKE :search OR client.documentNumber LIKE :search)', { search: `%${search}%` });
        }
        query.orderBy('client.createdAt', 'DESC');
        query.skip((page - 1) * limit).take(limit);
        const [data, total] = await query.getManyAndCount();
        return { data, total, page, lastPage: Math.ceil(total / limit) };
    }
    async findOne(id) {
        const client = await this.unidentifiedClientRepository.findOne({
            where: { id },
            relations: ['chat', 'assignedTo'],
        });
        if (!client) {
            throw new common_1.NotFoundException(`Cliente no identificado con ID ${id} no encontrado`);
        }
        return client;
    }
    async findByPhone(phone) {
        return await this.unidentifiedClientRepository.findOne({
            where: { phone },
            relations: ['chat', 'assignedTo'],
        });
    }
    async update(id, updateDto) {
        const client = await this.findOne(id);
        if (updateDto.chatId) {
            const chat = await this.chatRepository.findOne({ where: { id: updateDto.chatId } });
            if (!chat) {
                throw new common_1.NotFoundException(`Chat con ID ${updateDto.chatId} no encontrado`);
            }
        }
        if (updateDto.assignedToId) {
            const user = await this.userRepository.findOne({ where: { id: updateDto.assignedToId } });
            if (!user) {
                throw new common_1.NotFoundException(`Usuario con ID ${updateDto.assignedToId} no encontrado`);
            }
        }
        Object.assign(client, updateDto);
        return await this.unidentifiedClientRepository.save(client);
    }
    async updateStatus(id, statusDto) {
        const client = await this.findOne(id);
        client.status = statusDto.status;
        if (statusDto.notes) {
            const timestamp = new Date().toISOString();
            const newNote = `[${timestamp}] ${statusDto.notes}`;
            client.notes = client.notes ? `${client.notes}\n${newNote}` : newNote;
        }
        return await this.unidentifiedClientRepository.save(client);
    }
    async assignTo(id, userId) {
        const client = await this.findOne(id);
        const user = await this.userRepository.findOne({ where: { id: userId } });
        if (!user) {
            throw new common_1.NotFoundException(`Usuario con ID ${userId} no encontrado`);
        }
        client.assignedToId = userId;
        return await this.unidentifiedClientRepository.save(client);
    }
    async remove(id) {
        const client = await this.findOne(id);
        await this.unidentifiedClientRepository.remove(client);
    }
    async getStats() {
        const stats = await this.unidentifiedClientRepository
            .createQueryBuilder('client')
            .select('client.status', 'status')
            .addSelect('COUNT(*)', 'count')
            .groupBy('client.status')
            .getRawMany();
        return stats.reduce((acc, stat) => {
            acc[stat.status] = parseInt(stat.count);
            return acc;
        }, {});
    }
};
exports.UnidentifiedClientsService = UnidentifiedClientsService;
exports.UnidentifiedClientsService = UnidentifiedClientsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(unidentified_client_entity_1.UnidentifiedClient)),
    __param(1, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __param(2, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], UnidentifiedClientsService);
//# sourceMappingURL=unidentified-clients.service.js.map