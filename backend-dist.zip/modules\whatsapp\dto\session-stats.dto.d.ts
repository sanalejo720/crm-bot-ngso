export interface SessionStatsDto {
    numberId: string;
    phoneNumber: string;
    displayName: string;
    status: string;
    isConnected: boolean;
    messagesSent: number;
    messagesReceived: number;
    totalMessages: number;
    lastMessageAt?: Date;
    connectedSince?: Date;
    uptime?: number;
    alertCount?: number;
    offensiveWordsDetected?: number;
}
export interface ActiveSessionsDto {
    totalSessions: number;
    activeSessions: number;
    maxSessions: number;
    sessions: SessionStatsDto[];
    uptimeAverage: number;
}
