"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueryEvidencesDto = exports.ReviewEvidenceDto = exports.CreateEvidenceDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
class CreateEvidenceDto {
}
exports.CreateEvidenceDto = CreateEvidenceDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'ID del cliente asociado al pago' }),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CreateEvidenceDto.prototype, "clientId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Monto del pago', example: 50000 }),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], CreateEvidenceDto.prototype, "paymentAmount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Fecha del pago', example: '2025-11-24' }),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], CreateEvidenceDto.prototype, "paymentDate", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Notas adicionales sobre el pago' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(500),
    __metadata("design:type", String)
], CreateEvidenceDto.prototype, "notes", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'ID de campaña asociada' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CreateEvidenceDto.prototype, "campaignId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Número de referencia del pago' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], CreateEvidenceDto.prototype, "referenceNumber", void 0);
class ReviewEvidenceDto {
}
exports.ReviewEvidenceDto = ReviewEvidenceDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Estado de revisión', enum: ['approved', 'rejected'] }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], ReviewEvidenceDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Notas de la revisión' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(500),
    __metadata("design:type", String)
], ReviewEvidenceDto.prototype, "reviewNotes", void 0);
class QueryEvidencesDto {
}
exports.QueryEvidencesDto = QueryEvidencesDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'ID del cliente' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], QueryEvidencesDto.prototype, "clientId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Estado', enum: ['pending', 'approved', 'rejected'] }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], QueryEvidencesDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Fecha inicio' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], QueryEvidencesDto.prototype, "startDate", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Fecha fin' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], QueryEvidencesDto.prototype, "endDate", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'ID del agente que subió la evidencia' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], QueryEvidencesDto.prototype, "uploadedBy", void 0);
//# sourceMappingURL=evidence.dto.js.map