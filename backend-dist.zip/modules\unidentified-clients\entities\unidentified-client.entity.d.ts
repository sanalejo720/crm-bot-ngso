import { Chat } from '../../chats/entities/chat.entity';
import { User } from '../../users/entities/user.entity';
export declare enum UnidentifiedClientStatus {
    PENDING = "pending",
    CONTACTED = "contacted",
    RESOLVED = "resolved",
    TRANSFERRED = "transferred"
}
export declare class UnidentifiedClient {
    id: string;
    phone: string;
    name: string;
    documentType: string;
    documentNumber: string;
    notes: string;
    status: UnidentifiedClientStatus;
    metadata: any;
    chat: Chat;
    chatId: string;
    assignedTo: User;
    assignedToId: string;
    createdAt: Date;
    updatedAt: Date;
}
