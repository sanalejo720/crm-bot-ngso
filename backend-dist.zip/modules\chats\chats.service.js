"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ChatsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const event_emitter_1 = require("@nestjs/event-emitter");
const chat_entity_1 = require("./entities/chat.entity");
const users_service_1 = require("../users/users.service");
const user_entity_1 = require("../users/entities/user.entity");
const user_campaign_entity_1 = require("../users/entities/user-campaign.entity");
const debtor_entity_1 = require("../debtors/entities/debtor.entity");
const whatsapp_service_1 = require("../whatsapp/whatsapp.service");
let ChatsService = ChatsService_1 = class ChatsService {
    constructor(chatRepository, debtorRepository, userCampaignRepository, usersService, eventEmitter, whatsappService) {
        this.chatRepository = chatRepository;
        this.debtorRepository = debtorRepository;
        this.userCampaignRepository = userCampaignRepository;
        this.usersService = usersService;
        this.eventEmitter = eventEmitter;
        this.whatsappService = whatsappService;
        this.logger = new common_1.Logger(ChatsService_1.name);
    }
    async create(createChatDto) {
        const existing = await this.chatRepository.findOne({
            where: { externalId: createChatDto.externalId },
        });
        if (existing) {
            this.logger.warn(`Chat con externalId ${createChatDto.externalId} ya existe`);
            return existing;
        }
        const chat = this.chatRepository.create({
            ...createChatDto,
            status: chat_entity_1.ChatStatus.WAITING,
        });
        const savedChat = await this.chatRepository.save(chat);
        this.logger.log(`Chat creado: ${savedChat.id} - ${savedChat.contactPhone}`);
        const chatWithCampaign = await this.chatRepository.findOne({
            where: { id: savedChat.id },
            relations: ['campaign'],
        });
        this.eventEmitter.emit('chat.created', chatWithCampaign);
        return savedChat;
    }
    async findAll(filters) {
        const query = this.chatRepository
            .createQueryBuilder('chat')
            .leftJoinAndSelect('chat.campaign', 'campaign')
            .leftJoinAndSelect('chat.whatsappNumber', 'whatsappNumber')
            .leftJoinAndSelect('chat.assignedAgent', 'assignedAgent')
            .leftJoinAndSelect('chat.client', 'client')
            .orderBy('chat.lastMessageAt', 'DESC');
        if (filters?.status) {
            query.andWhere('chat.status = :status', { status: filters.status });
        }
        if (filters?.campaignId) {
            query.andWhere('chat.campaignId = :campaignId', { campaignId: filters.campaignId });
        }
        if (filters?.assignedAgentId) {
            query.andWhere('chat.assignedAgentId = :assignedAgentId', {
                assignedAgentId: filters.assignedAgentId,
            });
        }
        if (filters?.whatsappNumberId) {
            query.andWhere('chat.whatsappNumberId = :whatsappNumberId', {
                whatsappNumberId: filters.whatsappNumberId,
            });
        }
        if (filters?.search) {
            const searchTerm = `%${filters.search.toLowerCase()}%`;
            query.andWhere(`(LOWER(chat.contactName) LIKE :searchTerm 
         OR chat.contactPhone LIKE :searchTerm 
         OR chat.externalId LIKE :searchTerm
         OR LOWER(client.fullName) LIKE :searchTerm
         OR client.documentNumber LIKE :searchTerm
         OR client.phone LIKE :searchTerm)`, { searchTerm });
        }
        if (filters?.page && filters?.limit) {
            const skip = (filters.page - 1) * filters.limit;
            const [chats, total] = await query.skip(skip).take(filters.limit).getManyAndCount();
            for (const chat of chats) {
                if (chat.debtorId) {
                    const debtor = await this.debtorRepository.findOne({
                        where: { id: chat.debtorId },
                    });
                    if (debtor) {
                        chat.debtor = debtor;
                    }
                }
            }
            return {
                data: chats,
                pagination: {
                    page: filters.page,
                    limit: filters.limit,
                    total,
                    totalPages: Math.ceil(total / filters.limit),
                },
            };
        }
        const chats = await query.getMany();
        for (const chat of chats) {
            if (chat.debtorId) {
                const debtor = await this.debtorRepository.findOne({
                    where: { id: chat.debtorId },
                });
                if (debtor) {
                    chat.debtor = debtor;
                }
            }
        }
        return { data: chats };
    }
    async findOne(id) {
        const chat = await this.chatRepository.findOne({
            where: { id },
            relations: ['campaign', 'whatsappNumber', 'assignedAgent', 'client', 'messages'],
        });
        if (!chat) {
            throw new common_1.NotFoundException(`Chat con ID ${id} no encontrado`);
        }
        if (chat.debtorId) {
            const debtor = await this.debtorRepository.findOne({
                where: { id: chat.debtorId },
            });
            if (debtor) {
                chat.debtor = debtor;
            }
        }
        return chat;
    }
    async findByExternalId(externalId) {
        const chat = await this.chatRepository.findOne({
            where: { externalId },
            relations: ['campaign', 'whatsappNumber', 'assignedAgent'],
        });
        if (chat?.debtorId) {
            const debtor = await this.debtorRepository.findOne({
                where: { id: chat.debtorId },
            });
            if (debtor) {
                chat.debtor = debtor;
            }
        }
        return chat;
    }
    async update(id, updateChatDto) {
        const chat = await this.findOne(id);
        Object.assign(chat, updateChatDto);
        const updatedChat = await this.chatRepository.save(chat);
        this.logger.log(`Chat actualizado: ${updatedChat.id}`);
        this.eventEmitter.emit('chat.updated', updatedChat);
        return updatedChat;
    }
    async assign(chatId, agentId, reason) {
        this.logger.log(`🎯 MÉTODO ASSIGN LLAMADO - Chat: ${chatId}, AgentId: ${agentId}, Reason: ${reason}`);
        const chat = await this.findOne(chatId);
        const previousAgentId = chat.assignedAgentId;
        this.logger.log(`📋 Chat encontrado. Estado actual: assignedAgentId=${previousAgentId}`);
        if (!agentId) {
            this.logger.log(`🤖 Transfiriendo chat ${chatId} al bot - CERRANDO CONVERSACIÓN`);
            if (previousAgentId) {
                await this.usersService.decrementChatCount(previousAgentId);
                this.logger.log(`📉 Contador de chats decrementado para agente ${previousAgentId}`);
            }
            chat.assignedAgentId = null;
            chat.status = chat_entity_1.ChatStatus.CLOSED;
            chat.closedAt = new Date();
            chat.assignedAt = null;
            await this.chatRepository.save(chat);
            this.logger.log(`✅ Chat ${chatId} cerrado y desasignado del agente ${previousAgentId}`);
            this.eventEmitter.emit('chat.closed', chat);
            if (previousAgentId) {
                this.logger.log(`🔥 EMITIENDO EVENTO chat.unassigned para agente ${previousAgentId}`);
                this.eventEmitter.emit('chat.unassigned', {
                    chat: await this.findOne(chatId),
                    previousAgentId,
                    reason: reason || 'Transferido al bot y cerrado',
                });
            }
            return this.findOne(chatId);
        }
        const agent = await this.usersService.findOne(agentId);
        this.logger.log(`👤 Agente encontrado: ${agent.fullName} - Estado: ${agent.agentState} - Chats: ${agent.currentChatsCount}/${agent.maxConcurrentChats}`);
        if (agent.agentState !== user_entity_1.AgentState.AVAILABLE) {
            this.logger.error(`❌ VALIDACIÓN FALLIDA: Agente ${agent.fullName} NO está disponible (estado: ${agent.agentState})`);
            throw new common_1.BadRequestException('El agente no está disponible');
        }
        if (agent.currentChatsCount >= agent.maxConcurrentChats) {
            this.logger.error(`❌ VALIDACIÓN FALLIDA: Agente ${agent.fullName} alcanzó límite ${agent.currentChatsCount}/${agent.maxConcurrentChats}`);
            throw new common_1.BadRequestException('El agente alcanzó su límite de chats concurrentes');
        }
        if (previousAgentId && previousAgentId !== agentId) {
            await this.usersService.decrementChatCount(previousAgentId);
        }
        chat.assignedAgentId = agentId;
        chat.status = chat_entity_1.ChatStatus.ACTIVE;
        chat.assignedAt = new Date();
        await this.chatRepository.save(chat);
        if (previousAgentId !== agentId) {
            await this.usersService.incrementChatCount(agentId);
        }
        this.logger.log(`Chat ${chatId} asignado al agente ${agentId}`);
        this.logger.log(`🔥 EMITIENDO EVENTO chat.assigned para agente ${agent.fullName} (${agent.id})`);
        this.eventEmitter.emit('chat.assigned', {
            chat: await this.findOne(chatId),
            agentId: agent.id,
            agentName: agent.fullName,
        });
        this.logger.log(`🔥 EVENTO EMITIDO correctamente`);
        return this.findOne(chatId);
    }
    async transfer(chatId, currentAgentId, newAgentId, reason) {
        const chat = await this.findOne(chatId);
        const newAgent = await this.usersService.findOne(newAgentId);
        if (chat.assignedAgentId !== currentAgentId) {
            throw new common_1.BadRequestException('No tienes permiso para transferir este chat');
        }
        if (newAgent.currentChatsCount >= newAgent.maxConcurrentChats) {
            throw new common_1.BadRequestException('El nuevo agente alcanzó su límite de chats');
        }
        await this.usersService.decrementChatCount(currentAgentId);
        chat.assignedAgentId = newAgentId;
        chat.metadata = {
            ...chat.metadata,
            transferHistory: [
                ...(chat.metadata?.transferHistory || []),
                {
                    from: currentAgentId,
                    to: newAgentId,
                    reason,
                    timestamp: new Date(),
                },
            ],
        };
        await this.chatRepository.save(chat);
        await this.usersService.incrementChatCount(newAgentId);
        this.logger.log(`Chat ${chatId} transferido de ${currentAgentId} a ${newAgentId}`);
        this.eventEmitter.emit('chat.transferred', {
            chat,
            fromAgent: currentAgentId,
            toAgent: newAgentId,
            reason,
        });
        return this.findOne(chatId);
    }
    async close(chatId, userId) {
        const chat = await this.findOne(chatId);
        const previousAgentId = chat.assignedAgentId;
        if (chat.assignedAgentId) {
            await this.usersService.decrementChatCount(chat.assignedAgentId);
        }
        chat.status = chat_entity_1.ChatStatus.CLOSED;
        chat.closedAt = new Date();
        await this.chatRepository.save(chat);
        this.logger.log(`Chat ${chatId} cerrado por usuario ${userId}`);
        this.eventEmitter.emit('chat.closed', chat);
        if (previousAgentId) {
            this.eventEmitter.emit('chat.unassigned', {
                chat: await this.findOne(chatId),
                previousAgentId,
                reason: 'Chat cerrado manualmente',
            });
            this.logger.log(`🎧 Evento chat.unassigned emitido para generar PDF de cierre`);
        }
        return chat;
    }
    async resolve(chatId, userId) {
        const chat = await this.findOne(chatId);
        chat.status = chat_entity_1.ChatStatus.RESOLVED;
        chat.resolvedAt = new Date();
        await this.chatRepository.save(chat);
        this.logger.log(`Chat ${chatId} resuelto por usuario ${userId}`);
        this.eventEmitter.emit('chat.resolved', chat);
        return chat;
    }
    async getWaitingChats(campaignId) {
        return this.chatRepository.find({
            where: {
                campaignId,
                status: chat_entity_1.ChatStatus.WAITING,
            },
            order: {
                priority: 'DESC',
                createdAt: 'ASC',
            },
        });
    }
    async updateLastActivity(chatId, messageText) {
        await this.chatRepository.update(chatId, {
            lastMessageText: messageText.substring(0, 255),
            lastMessageAt: new Date(),
        });
    }
    async incrementUnreadCount(chatId) {
        await this.chatRepository.increment({ id: chatId }, 'unreadCount', 1);
    }
    async resetUnreadCount(chatId) {
        await this.chatRepository.update(chatId, { unreadCount: 0 });
    }
    async getAgentStats(agentId) {
        const [active, resolved, total] = await Promise.all([
            this.chatRepository.count({
                where: { assignedAgentId: agentId, status: chat_entity_1.ChatStatus.ACTIVE },
            }),
            this.chatRepository.count({
                where: { assignedAgentId: agentId, status: chat_entity_1.ChatStatus.RESOLVED },
            }),
            this.chatRepository.count({ where: { assignedAgentId: agentId } }),
        ]);
        return { active, resolved, total };
    }
    async updateContactInfo(chatId, data) {
        const chat = await this.findOne(chatId);
        if (data.contactName) {
            chat.contactName = data.contactName;
        }
        if (data.contactPhone) {
            chat.contactPhone = data.contactPhone;
        }
        await this.chatRepository.save(chat);
        this.logger.log(`Chat ${chatId} - Información de contacto actualizada: ${JSON.stringify(data)}`);
        if (chat.clientId) {
            try {
                const clientRepo = this.chatRepository.manager.getRepository('Client');
                const updateData = {};
                if (data.contactName) {
                    updateData.fullName = data.contactName;
                }
                if (data.contactPhone) {
                    updateData.phone = data.contactPhone;
                }
                if (Object.keys(updateData).length > 0) {
                    await clientRepo.update(chat.clientId, updateData);
                    this.logger.log(`Cliente ${chat.clientId} actualizado con: ${JSON.stringify(updateData)}`);
                }
            }
            catch (error) {
                this.logger.warn(`No se pudo actualizar el cliente asociado: ${error.message}`);
            }
        }
        this.eventEmitter.emit('chat.updated', { chat });
        return chat;
    }
    async transferToCampaign(chatId, newCampaignId, userId) {
        const chat = await this.findOne(chatId);
        const previousCampaignId = chat.campaignId;
        const previousAgentId = chat.assignedAgentId;
        const campaignRepo = this.chatRepository.manager.getRepository('Campaign');
        const newCampaign = await campaignRepo.findOne({ where: { id: newCampaignId } });
        if (!newCampaign) {
            throw new common_1.NotFoundException(`Campaña ${newCampaignId} no encontrada`);
        }
        if (previousAgentId) {
            await this.usersService.decrementChatCount(previousAgentId);
        }
        chat.campaignId = newCampaignId;
        chat.assignedAgentId = null;
        chat.assignedAt = null;
        chat.status = chat_entity_1.ChatStatus.WAITING;
        chat.subStatus = 'waiting_for_agent';
        const transferNote = {
            type: 'campaign_transfer',
            from: previousCampaignId,
            to: newCampaignId,
            by: userId,
            previousAgent: previousAgentId,
            timestamp: new Date().toISOString(),
        };
        chat.metadata = {
            ...chat.metadata,
            campaignTransfers: [...(chat.metadata?.campaignTransfers || []), transferNote],
        };
        await this.chatRepository.save(chat);
        this.logger.log(`✅ Chat ${chatId} transferido de campaña ${previousCampaignId} a ${newCampaignId} por usuario ${userId}`);
        if (previousAgentId) {
            this.eventEmitter.emit('chat.unassigned', {
                chat,
                previousAgentId,
                reason: `Transferido a campaña: ${newCampaign.name}`,
            });
        }
        this.eventEmitter.emit('chat.campaign_transferred', {
            chat,
            previousCampaignId,
            newCampaignId,
            userId,
        });
        return chat;
    }
    async getClientHistory(phone, campaignId) {
        const normalizedPhone = phone.replace(/[\s\-\(\)\+]/g, '');
        const whereCondition = {
            contactPhone: normalizedPhone,
            status: chat_entity_1.ChatStatus.CLOSED,
            closedAt: (0, typeorm_2.Not)((0, typeorm_2.IsNull)()),
        };
        if (campaignId) {
            whereCondition.campaignId = campaignId;
        }
        const previousChats = await this.chatRepository.find({
            where: whereCondition,
            relations: ['assignedAgent', 'campaign'],
            order: { closedAt: 'DESC' },
        });
        let previousAgent = null;
        if (previousChats.length > 0 && previousChats[0].assignedAgent) {
            const agent = previousChats[0].assignedAgent;
            previousAgent = {
                id: agent.id,
                name: agent.fullName,
                email: agent.email,
            };
        }
        const chatIds = previousChats.map(c => c.id);
        let evidences = [];
        if (chatIds.length > 0) {
            evidences = await this.chatRepository.manager.getRepository('evidences').find({
                where: { chatId: (0, typeorm_2.In)(chatIds) },
                relations: ['agent', 'chat'],
                order: { createdAt: 'DESC' },
            });
        }
        const ticketHistory = evidences.map(evidence => {
            const chat = previousChats.find(c => c.id === evidence.chatId);
            return {
                ticketNumber: evidence.ticketNumber,
                closedAt: chat?.closedAt || evidence.createdAt,
                typification: evidence.closureType === 'paid' ? 'Pagado' :
                    evidence.closureType === 'promise' ? 'Promesa de pago' :
                        evidence.closureType || 'Sin tipificación',
                typificationCategory: chat?.resolutionType || 'Sin categoría',
                agentName: evidence.agent?.fullName || chat?.assignedAgent?.fullName || 'Sin asignar',
                campaignName: chat?.campaign?.name || 'Sin campaña',
            };
        });
        const uniqueClient = previousChats.length <= 1;
        return {
            previousAgent,
            ticketHistory,
            totalChats: previousChats.length,
            uniqueClient,
        };
    }
    async createManualChat(phone, agentId, contactName, campaignId, assignToAgentId, creatorRole, templateSid, templateVariables) {
        this.logger.log(`📱 Creando chat manual - Teléfono: ${phone}, Agente: ${agentId}, AssignTo: ${assignToAgentId || 'auto'}, Template: ${templateSid || 'ninguno'}`);
        const normalizedPhone = phone.replace(/[\s\-\(\)\+]/g, '');
        let resolvedCampaignId = campaignId;
        if (!resolvedCampaignId) {
            const userCampaign = await this.userCampaignRepository.findOne({
                where: { userId: agentId, isActive: true },
                order: { isPrimary: 'DESC', assignedAt: 'ASC' },
            });
            if (!userCampaign) {
                throw new common_1.BadRequestException('No tiene una campaña asignada. Contacte al administrador.');
            }
            resolvedCampaignId = userCampaign.campaignId;
            this.logger.log(`📋 Campaña obtenida del agente: ${resolvedCampaignId}`);
        }
        const clientHistory = await this.getClientHistory(normalizedPhone, resolvedCampaignId);
        this.logger.log(`📊 Historial del cliente: ${clientHistory.totalChats} chats anteriores`);
        let targetAgentId = agentId;
        const canAssignToOther = ['superadmin', 'admin', 'supervisor'].includes(creatorRole || '');
        if (assignToAgentId && canAssignToOther) {
            targetAgentId = assignToAgentId;
            this.logger.log(`👤 Asignando a agente específico: ${assignToAgentId}`);
        }
        else if (clientHistory.previousAgent && !assignToAgentId) {
            targetAgentId = clientHistory.previousAgent.id;
            this.logger.log(`🔄 Cliente recurrente, asignando al agente anterior: ${clientHistory.previousAgent.name}`);
        }
        const whatsappNumber = await this.whatsappService.getWhatsappNumberByCampaign(resolvedCampaignId);
        if (!whatsappNumber) {
            throw new common_1.BadRequestException('La campaña no tiene un número de WhatsApp asignado');
        }
        const externalId = `manual_${normalizedPhone}_${resolvedCampaignId}_${Date.now()}`;
        const existingChat = await this.chatRepository.findOne({
            where: {
                contactPhone: normalizedPhone,
                campaignId: resolvedCampaignId,
                status: (0, typeorm_2.In)([chat_entity_1.ChatStatus.WAITING, chat_entity_1.ChatStatus.BOT, chat_entity_1.ChatStatus.ACTIVE, chat_entity_1.ChatStatus.PENDING]),
            },
            relations: ['campaign', 'whatsappNumber', 'assignedAgent'],
        });
        if (existingChat) {
            this.logger.log(`📋 Chat existente encontrado: ${existingChat.id}`);
            if (existingChat.assignedAgentId && existingChat.assignedAgentId !== targetAgentId) {
                if (canAssignToOther && assignToAgentId) {
                    await this.usersService.decrementChatCount(existingChat.assignedAgentId);
                    existingChat.assignedAgentId = targetAgentId;
                    existingChat.assignedAt = new Date();
                    existingChat.metadata = {
                        ...existingChat.metadata,
                        reassignedBy: agentId,
                        reassignedAt: new Date().toISOString(),
                    };
                    await this.chatRepository.save(existingChat);
                    await this.usersService.incrementChatCount(targetAgentId);
                    this.logger.log(`🔄 Chat reasignado por ${creatorRole} a: ${targetAgentId}`);
                }
                else {
                    throw new common_1.BadRequestException('Este contacto ya tiene un chat activo asignado a otro agente');
                }
            }
            if (!existingChat.assignedAgentId) {
                existingChat.assignedAgentId = targetAgentId;
                existingChat.assignedAt = new Date();
                existingChat.status = chat_entity_1.ChatStatus.ACTIVE;
                await this.chatRepository.save(existingChat);
                await this.usersService.incrementChatCount(targetAgentId);
            }
            let templateSent = false;
            if (templateSid) {
                try {
                    this.logger.log(`📤 Enviando template ${templateSid} a chat existente ${existingChat.id}`);
                    await this.whatsappService.sendContentTemplate(existingChat.whatsappNumberId, normalizedPhone, templateSid, templateVariables);
                    templateSent = true;
                    existingChat.metadata = {
                        ...existingChat.metadata,
                        templateSent: true,
                        templateSid,
                        templateSentAt: new Date().toISOString(),
                    };
                    await this.chatRepository.save(existingChat);
                    this.logger.log(`✅ Template enviado a chat existente`);
                }
                catch (templateError) {
                    this.logger.error(`❌ Error enviando template a chat existente: ${templateError.message}`);
                }
            }
            return {
                chat: existingChat,
                isNew: false,
                canSendMessage: true,
                waitingResponse: existingChat.metadata?.waitingClientResponse || false,
                templateSent,
                previousAgent: clientHistory.previousAgent,
                ticketHistory: clientHistory.ticketHistory,
            };
        }
        const chat = this.chatRepository.create({
            externalId,
            contactPhone: normalizedPhone,
            contactName: contactName || `+${normalizedPhone}`,
            campaignId: resolvedCampaignId,
            whatsappNumberId: whatsappNumber.id,
            assignedAgentId: targetAgentId,
            assignedAt: new Date(),
            status: chat_entity_1.ChatStatus.ACTIVE,
            metadata: {
                createdManually: true,
                createdBy: agentId,
                createdAt: new Date().toISOString(),
                waitingClientResponse: true,
                messagesWithoutResponse: 0,
                isReturningClient: clientHistory.totalChats > 0,
                previousChatsCount: clientHistory.totalChats,
                assignedByRole: creatorRole,
            },
        });
        const savedChat = await this.chatRepository.save(chat);
        await this.usersService.incrementChatCount(targetAgentId);
        const fullChat = await this.chatRepository.findOne({
            where: { id: savedChat.id },
            relations: ['campaign', 'whatsappNumber', 'assignedAgent'],
        });
        this.logger.log(`✅ Chat manual creado: ${savedChat.id}, asignado a: ${targetAgentId}`);
        this.eventEmitter.emit('chat.created', fullChat);
        let templateSent = false;
        if (templateSid && fullChat) {
            try {
                this.logger.log(`📤 Enviando template ${templateSid} a ${normalizedPhone}`);
                await this.whatsappService.sendContentTemplate(whatsappNumber.id, normalizedPhone, templateSid, templateVariables);
                templateSent = true;
                this.logger.log(`✅ Template enviado exitosamente a ${normalizedPhone}`);
                fullChat.metadata = {
                    ...fullChat.metadata,
                    templateSent: true,
                    templateSid,
                    templateSentAt: new Date().toISOString(),
                };
                await this.chatRepository.save(fullChat);
            }
            catch (templateError) {
                this.logger.error(`❌ Error enviando template: ${templateError.message}`);
            }
        }
        return {
            chat: fullChat,
            isNew: true,
            canSendMessage: true,
            waitingResponse: true,
            templateSent,
            previousAgent: clientHistory.previousAgent,
            ticketHistory: clientHistory.ticketHistory,
        };
    }
    async recordManualMessageSent(chatId) {
        const chat = await this.findOne(chatId);
        const messagesWithoutResponse = (chat.metadata?.messagesWithoutResponse || 0) + 1;
        const maxMessagesWithoutResponse = 1;
        chat.metadata = {
            ...chat.metadata,
            messagesWithoutResponse,
            lastMessageSentAt: new Date().toISOString(),
            waitingClientResponse: true,
        };
        await this.chatRepository.save(chat);
        return {
            canSendMore: messagesWithoutResponse < maxMessagesWithoutResponse,
            messagesCount: messagesWithoutResponse,
        };
    }
    async activateOnClientResponse(chatId) {
        const chat = await this.findOne(chatId);
        if (chat.metadata?.createdManually && chat.metadata?.waitingClientResponse) {
            chat.metadata = {
                ...chat.metadata,
                waitingClientResponse: false,
                messagesWithoutResponse: 0,
                clientRespondedAt: new Date().toISOString(),
            };
            chat.status = chat_entity_1.ChatStatus.ACTIVE;
            await this.chatRepository.save(chat);
            this.logger.log(`✅ Chat ${chatId} activado por respuesta del cliente`);
        }
        return chat;
    }
    async canSendManualMessage(chatId) {
        const chat = await this.findOne(chatId);
        if (!chat.metadata?.createdManually) {
            return { canSend: true };
        }
        if (!chat.metadata?.waitingClientResponse) {
            return { canSend: true };
        }
        const messagesWithoutResponse = chat.metadata?.messagesWithoutResponse || 0;
        if (messagesWithoutResponse >= 1) {
            return {
                canSend: false,
                reason: 'Ya se envió un mensaje y el cliente aún no ha respondido. Debe esperar la respuesta del cliente para continuar.',
            };
        }
        return { canSend: true };
    }
};
exports.ChatsService = ChatsService;
exports.ChatsService = ChatsService = ChatsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __param(1, (0, typeorm_1.InjectRepository)(debtor_entity_1.Debtor)),
    __param(2, (0, typeorm_1.InjectRepository)(user_campaign_entity_1.UserCampaign)),
    __param(5, (0, common_1.Inject)((0, common_1.forwardRef)(() => whatsapp_service_1.WhatsappService))),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        users_service_1.UsersService,
        event_emitter_1.EventEmitter2,
        whatsapp_service_1.WhatsappService])
], ChatsService);
//# sourceMappingURL=chats.service.js.map