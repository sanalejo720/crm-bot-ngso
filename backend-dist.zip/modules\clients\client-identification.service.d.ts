import { Repository } from 'typeorm';
import { Client } from './entities/client.entity';
import { ClientPhoneNumber } from './entities/client-phone-number.entity';
import { Chat } from '../chats/entities/chat.entity';
export declare class ClientIdentificationService {
    private clientRepository;
    private phoneRepository;
    private chatRepository;
    private readonly logger;
    constructor(clientRepository: Repository<Client>, phoneRepository: Repository<ClientPhoneNumber>, chatRepository: Repository<Chat>);
    identifyClientByDocument(documentNumber: string, phoneNumber: string): Promise<{
        client: Client;
        isNewPhone: boolean;
    }>;
    getClientPhoneNumbers(clientId: string): Promise<ClientPhoneNumber[]>;
    findClientByPhone(phoneNumber: string): Promise<Client | null>;
    calculateBusinessDays(startDate: Date, daysToAdd: number): Date;
}
