"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FinancialController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const financial_stats_service_1 = require("./financial-stats.service");
let FinancialController = class FinancialController {
    constructor(financialStatsService) {
        this.financialStatsService = financialStatsService;
    }
    async getFinancialSummary(period = 'daily', startDate, endDate) {
        let start;
        let end;
        if (period === 'custom') {
            if (!startDate || !endDate) {
                throw new common_1.BadRequestException('Se requieren startDate y endDate para período custom');
            }
            start = new Date(startDate);
            end = new Date(endDate);
        }
        const data = await this.financialStatsService.getFinancialSummary(period, start, end);
        return {
            success: true,
            data,
        };
    }
    async getCampaignFinancials(campaignId, startDate, endDate) {
        const start = startDate ? new Date(startDate) : new Date();
        const end = endDate ? new Date(endDate) : new Date();
        const data = await this.financialStatsService.getCampaignFinancials(campaignId, start, end);
        return {
            success: true,
            data,
        };
    }
    async getAgentRecaudo(agentId, startDate, endDate) {
        const start = startDate ? new Date(startDate) : new Date();
        const end = endDate ? new Date(endDate) : new Date();
        const data = await this.financialStatsService.getAgentRecaudo(agentId, start, end);
        return {
            success: true,
            data,
        };
    }
    async getDailyFinancials(date) {
        const targetDate = date ? new Date(date) : new Date();
        const data = await this.financialStatsService.getDailyFinancials(targetDate);
        return {
            success: true,
            data,
        };
    }
    async getFinancialTrend(startDate, endDate) {
        if (!startDate || !endDate) {
            throw new common_1.BadRequestException('Se requieren startDate y endDate');
        }
        const start = new Date(startDate);
        const end = new Date(endDate);
        const data = await this.financialStatsService.getFinancialTrend(start, end);
        return {
            success: true,
            data,
        };
    }
    async getAgentsRanking(period = 'monthly', startDate, endDate) {
        let start;
        let end;
        if (period === 'custom') {
            if (!startDate || !endDate) {
                throw new common_1.BadRequestException('Se requieren startDate y endDate para período custom');
            }
            start = new Date(startDate);
            end = new Date(endDate);
        }
        const summary = await this.financialStatsService.getFinancialSummary(period, start, end);
        return {
            success: true,
            data: summary.topAgents,
        };
    }
};
exports.FinancialController = FinancialController;
__decorate([
    (0, common_1.Get)('summary'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiOperation)({ summary: 'Resumen financiero global con filtros de período' }),
    (0, swagger_1.ApiQuery)({
        name: 'period',
        enum: ['daily', 'weekly', 'monthly', 'custom'],
        required: false,
    }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, type: String }),
    __param(0, (0, common_1.Query)('period')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], FinancialController.prototype, "getFinancialSummary", null);
__decorate([
    (0, common_1.Get)('campaigns/:id/stats'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiOperation)({ summary: 'Estadísticas financieras de una campaña específica' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, type: String }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], FinancialController.prototype, "getCampaignFinancials", null);
__decorate([
    (0, common_1.Get)('agents/:id/recaudo'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiOperation)({ summary: 'Recaudo de un agente específico' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, type: String }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], FinancialController.prototype, "getAgentRecaudo", null);
__decorate([
    (0, common_1.Get)('daily'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiOperation)({ summary: 'Estadísticas financieras del día' }),
    (0, swagger_1.ApiQuery)({ name: 'date', required: false, type: String }),
    __param(0, (0, common_1.Query)('date')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], FinancialController.prototype, "getDailyFinancials", null);
__decorate([
    (0, common_1.Get)('trend'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiOperation)({ summary: 'Tendencia financiera en un rango de fechas' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: true, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: true, type: String }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], FinancialController.prototype, "getFinancialTrend", null);
__decorate([
    (0, common_1.Get)('ranking/agents'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiOperation)({ summary: 'Ranking de agentes por recaudo' }),
    (0, swagger_1.ApiQuery)({
        name: 'period',
        enum: ['daily', 'weekly', 'monthly', 'custom'],
        required: false,
    }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, type: String }),
    __param(0, (0, common_1.Query)('period')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], FinancialController.prototype, "getAgentsRanking", null);
exports.FinancialController = FinancialController = __decorate([
    (0, swagger_1.ApiTags)('financial'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, common_1.Controller)('financial'),
    __metadata("design:paramtypes", [financial_stats_service_1.FinancialStatsService])
], FinancialController);
//# sourceMappingURL=financial.controller.js.map