import { Repository } from 'typeorm';
import { Task, TaskStatus, TaskPriority } from './entities/task.entity';
import { CreateTaskDto } from './dto/create-task.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
export declare class TasksService {
    private taskRepository;
    private eventEmitter;
    private readonly logger;
    constructor(taskRepository: Repository<Task>, eventEmitter: EventEmitter2);
    create(createTaskDto: CreateTaskDto, createdBy: string): Promise<Task>;
    findAll(filters?: {
        assignedTo?: string;
        createdBy?: string;
        status?: TaskStatus;
        priority?: TaskPriority;
        clientId?: string;
        campaignId?: string;
        chatId?: string;
    }): Promise<Task[]>;
    findPendingByUser(userId: string): Promise<Task[]>;
    findOverdueByUser(userId: string): Promise<Task[]>;
    findOne(id: string): Promise<Task>;
    update(id: string, updateTaskDto: UpdateTaskDto): Promise<Task>;
    updateStatus(id: string, status: TaskStatus, completedBy?: string): Promise<Task>;
    assignTo(id: string, userId: string): Promise<Task>;
    complete(id: string, completedBy: string): Promise<Task>;
    remove(id: string): Promise<void>;
    getStats(userId?: string): Promise<{
        total: number;
        pending: number;
        completed: number;
        overdue: number;
        completionRate: string | number;
        byPriority: any;
    }>;
    notifyOverdueTasks(): Promise<void>;
    notifyUpcomingTasks(): Promise<void>;
}
