import { Repository } from 'typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { BotFlow } from './entities/bot-flow.entity';
import { BotNode } from './entities/bot-node.entity';
import { Chat } from '../chats/entities/chat.entity';
import { Campaign } from '../campaigns/entities/campaign.entity';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { MessagesService } from '../messages/messages.service';
interface BotSession {
    chatId: string;
    flowId: string;
    currentNodeId: string;
    variables: Record<string, any>;
    startedAt: Date;
    waitingForInput?: boolean;
}
export declare class BotExecutorService {
    private botFlowRepository;
    private botNodeRepository;
    private chatRepository;
    private campaignRepository;
    private whatsappService;
    private messagesService;
    private eventEmitter;
    private readonly logger;
    private botSessions;
    constructor(botFlowRepository: Repository<BotFlow>, botNodeRepository: Repository<BotNode>, chatRepository: Repository<Chat>, campaignRepository: Repository<Campaign>, whatsappService: WhatsappService, messagesService: MessagesService, eventEmitter: EventEmitter2);
    handleMessageCreated(payload: any): Promise<void>;
    handleChatClosed(chat: any): Promise<void>;
    processIncomingMessage(chatId: string, message: string): Promise<{
        shouldRespond: boolean;
        response?: string;
        shouldTransferToAgent?: boolean;
    }>;
    private executeCurrentNode;
    private handleMessageNode;
    private handleMenuNode;
    private handleInputNode;
    private handleTransferNode;
    private replaceVariables;
    resetBotSession(chatId: string): Promise<void>;
    getBotSession(chatId: string): BotSession | undefined;
    private sendBotMessage;
}
export {};
