import { PaymentPromisesService } from './payment-promises.service';
export declare class PaymentPromisesController {
    private readonly paymentPromisesService;
    constructor(paymentPromisesService: PaymentPromisesService);
    getUpcomingPromises(days?: number): Promise<{
        success: boolean;
        data: import("./payment-promises.service").PaymentPromise[];
        total: number;
    }>;
    getPromisesDueToday(): Promise<{
        success: boolean;
        data: import("./payment-promises.service").PaymentPromise[];
        total: number;
    }>;
    getOverduePromises(): Promise<{
        success: boolean;
        data: import("./payment-promises.service").PaymentPromise[];
        total: number;
    }>;
    sendReminder(clientId: string, reminderType: 'upcoming' | 'today' | 'overdue'): Promise<{
        success: boolean;
        message: string;
    }>;
    markPromiseAsPaid(clientId: string, actualPaymentAmount?: number): Promise<{
        success: boolean;
        data: import("./entities/client.entity").Client;
        message: string;
    }>;
    triggerDailyReminders(): Promise<{
        success: boolean;
        message: string;
    }>;
}
