"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResolveChatDto = exports.ResolutionType = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
var ResolutionType;
(function (ResolutionType) {
    ResolutionType["PAID"] = "paid";
    ResolutionType["PROMISE"] = "promise";
    ResolutionType["NO_AGREEMENT"] = "no_agreement";
    ResolutionType["CALLBACK"] = "callback";
})(ResolutionType || (exports.ResolutionType = ResolutionType = {}));
class ResolveChatDto {
}
exports.ResolveChatDto = ResolveChatDto;
__decorate([
    (0, swagger_1.ApiProperty)({ enum: ResolutionType, description: 'Tipo de resolución' }),
    (0, class_validator_1.IsEnum)(ResolutionType),
    __metadata("design:type", String)
], ResolveChatDto.prototype, "resolutionType", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Método de pago' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ResolveChatDto.prototype, "paymentMethod", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Monto del pago' }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ResolveChatDto.prototype, "paymentAmount", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Fecha de promesa de pago' }),
    (0, class_validator_1.IsDateString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ResolveChatDto.prototype, "promiseDate", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Monto prometido' }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], ResolveChatDto.prototype, "promiseAmount", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Método de pago para la promesa' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ResolveChatDto.prototype, "promisePaymentMethod", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Razón de no acuerdo' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ResolveChatDto.prototype, "noAgreementReason", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Fecha de callback' }),
    (0, class_validator_1.IsDateString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ResolveChatDto.prototype, "callbackDate", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Notas del callback' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ResolveChatDto.prototype, "callbackNotes", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Notas adicionales' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], ResolveChatDto.prototype, "notes", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Enviar mensaje de cierre' }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], ResolveChatDto.prototype, "sendClosingMessage", void 0);
//# sourceMappingURL=resolve-chat.dto.js.map