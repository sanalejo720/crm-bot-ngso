"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateManualChatDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
class CreateManualChatDto {
}
exports.CreateManualChatDto = CreateManualChatDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: '573011234567',
        description: 'Número de teléfono del contacto (formato internacional sin +)'
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(10),
    (0, class_validator_1.MaxLength)(15),
    (0, class_validator_1.Matches)(/^[0-9]+$/, { message: 'El teléfono debe contener solo números' }),
    __metadata("design:type", String)
], CreateManualChatDto.prototype, "phone", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'Juan Pérez',
        description: 'Nombre del contacto (opcional)'
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], CreateManualChatDto.prototype, "contactName", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'uuid-campaign-id',
        description: 'ID de la campaña (opcional, se usa la campaña del agente si no se especifica)'
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CreateManualChatDto.prototype, "campaignId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'uuid-agent-id',
        description: 'ID del agente a asignar (solo admin/supervisor, opcional)'
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], CreateManualChatDto.prototype, "assignToAgentId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'Hola, me comunico desde NGS&O para...',
        description: 'Mensaje inicial a enviar (opcional)'
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(4096),
    __metadata("design:type", String)
], CreateManualChatDto.prototype, "initialMessage", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'HX87f380266edfc0d2c150932e7c716d16',
        description: 'Content SID de la plantilla de Twilio a enviar'
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateManualChatDto.prototype, "templateSid", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: { '1': 'Juan', '2': '500000', '3': '15 días' },
        description: 'Variables para la plantilla ({{1}}, {{2}}, etc.)'
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsObject)(),
    __metadata("design:type", Object)
], CreateManualChatDto.prototype, "templateVariables", void 0);
//# sourceMappingURL=create-manual-chat.dto.js.map