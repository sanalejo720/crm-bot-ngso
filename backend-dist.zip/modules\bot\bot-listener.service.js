"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var BotListenerService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotListenerService = void 0;
const common_1 = require("@nestjs/common");
const event_emitter_1 = require("@nestjs/event-emitter");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const bot_engine_service_1 = require("./bot-engine.service");
const chats_service_1 = require("../chats/chats.service");
const debtors_service_1 = require("../debtors/debtors.service");
const chat_entity_1 = require("../chats/entities/chat.entity");
const message_entity_1 = require("../messages/entities/message.entity");
const messages_service_1 = require("../messages/messages.service");
const whatsapp_service_1 = require("../whatsapp/whatsapp.service");
const campaign_entity_1 = require("../campaigns/entities/campaign.entity");
const debtor_entity_1 = require("../debtors/entities/debtor.entity");
let BotListenerService = BotListenerService_1 = class BotListenerService {
    constructor(botEngineService, chatsService, debtorsService, messagesService, whatsappService, campaignRepository) {
        this.botEngineService = botEngineService;
        this.chatsService = chatsService;
        this.debtorsService = debtorsService;
        this.messagesService = messagesService;
        this.whatsappService = whatsappService;
        this.campaignRepository = campaignRepository;
        this.logger = new common_1.Logger(BotListenerService_1.name);
    }
    isBusinessHours() {
        const now = new Date();
        const colombiaTime = new Date(now.toLocaleString('en-US', { timeZone: 'America/Bogota' }));
        const hour = colombiaTime.getHours();
        return hour >= 7 && hour < 19;
    }
    async handleMessageCreated(event) {
        const { message, chat } = event;
        if (message.direction !== message_entity_1.MessageDirection.INBOUND) {
            return;
        }
        if (!this.isBusinessHours()) {
            this.logger.log(`⏰ Mensaje recibido fuera de horario laboral en chat ${chat.id}`);
            await this.sendOutOfHoursMessage(chat);
            return;
        }
        this.logger.log(`🤖 Evaluando activación de bot para chat ${chat.id}`);
        if (chat.assignedAgentId) {
            this.logger.log(`⏭️ Chat ${chat.id} ya tiene agente asignado, bot no se activa`);
            return;
        }
        if (chat.status === chat_entity_1.ChatStatus.BOT) {
            this.logger.log(`🔄 Chat ${chat.id} ya está en modo bot, verificando sesión...`);
            const hasSession = this.botEngineService.hasActiveSession(chat.id);
            if (hasSession) {
                this.logger.log(`✅ Sesión activa encontrada, procesando input`);
                await this.botEngineService.processUserInput(chat.id, message.content);
                return;
            }
            else {
                this.logger.log(`⚠️ No hay sesión activa, reiniciando flujo desde el inicio`);
            }
        }
        let botFlowId = null;
        let botEnabled = false;
        if (chat.whatsappNumberId) {
            try {
                const whatsappNumber = await this.whatsappService.findOne(chat.whatsappNumberId);
                if (whatsappNumber?.botFlowId) {
                    botFlowId = whatsappNumber.botFlowId;
                    botEnabled = true;
                    this.logger.log(`📱 Usando flujo de bot del número de WhatsApp: ${botFlowId}`);
                }
            }
            catch (error) {
                this.logger.warn(`⚠️ No se pudo obtener el número de WhatsApp: ${error.message}`);
            }
        }
        if (!botFlowId && chat.campaignId) {
            const campaign = await this.campaignRepository.findOne({
                where: { id: chat.campaignId },
            });
            if (campaign) {
                botEnabled = campaign.settings?.botEnabled || false;
                botFlowId = campaign.settings?.botFlowId;
                if (botFlowId) {
                    this.logger.log(`📊 Usando flujo de bot de la campaña: ${botFlowId}`);
                }
            }
            else {
                this.logger.warn(`❌ Campaña ${chat.campaignId} no encontrada`);
            }
        }
        if (!botEnabled || !botFlowId) {
            this.logger.log(`⏭️ Bot no habilitado o sin flujo configurado`);
            return;
        }
        this.logger.log(`🚀 Activando bot para chat ${chat.id} con flujo ${botFlowId}`);
        try {
            const botVariables = {
                clientName: chat.contactName || 'Cliente',
                clientPhone: chat.contactPhone,
                debtorFound: false,
            };
            this.logger.log(`📝 Variables iniciales: Cliente ${chat.contactName}, Tel: ${chat.contactPhone}`);
            await this.botEngineService.startFlow(chat.id, botFlowId);
            this.logger.log(`✅ Bot activado exitosamente para chat ${chat.id}`);
        }
        catch (error) {
            this.logger.error(`❌ Error activando bot: ${error.message}`, error.stack);
        }
    }
    async searchDebtorByDocument(documentType, documentNumber) {
        try {
            const validType = documentType.toUpperCase();
            if (!Object.values(debtor_entity_1.DocumentType).includes(validType)) {
                return {
                    found: false,
                    error: 'Tipo de documento inválido. Use: CC, CE, NIT, TI o PASSPORT',
                };
            }
            const debtor = await this.debtorsService.findByDocument(validType, documentNumber);
            if (!debtor) {
                return {
                    found: false,
                    message: 'No encontramos información asociada a este documento.',
                };
            }
            await this.debtorsService.updateLastContacted(debtor.id);
            return {
                found: true,
                debtor: {
                    fullName: debtor.fullName,
                    documentType: debtor.documentType,
                    documentNumber: debtor.documentNumber,
                    phone: debtor.phone,
                    email: debtor.email,
                    debtAmount: debtor.debtAmount,
                    initialDebtAmount: debtor.initialDebtAmount,
                    daysOverdue: debtor.daysOverdue,
                    status: debtor.status,
                    lastPaymentDate: debtor.lastPaymentDate,
                    promiseDate: debtor.promiseDate,
                    metadata: debtor.metadata,
                },
            };
        }
        catch (error) {
            this.logger.error(`Error buscando deudor: ${error.message}`, error.stack);
            return {
                found: false,
                error: 'Error buscando información. Intente nuevamente.',
            };
        }
    }
    async sendOutOfHoursMessage(chat) {
        try {
            const mensaje = `🕐 *Horario de Atención*\n\n` +
                `Gracias por comunicarte con nosotros.\n\n` +
                `Nuestro horario de atención es:\n` +
                `📅 *Lunes a Viernes*\n` +
                `🕖 *7:00 AM - 7:00 PM*\n\n` +
                `En este momento nos encontramos fuera del horario laboral. ` +
                `Un asesor te contactará durante nuestro próximo horario de atención.\n\n` +
                `¡Gracias por tu comprensión! 😊`;
            const result = await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, mensaje, message_entity_1.MessageType.TEXT);
            const savedMessage = await this.messagesService.create({
                chatId: chat.id,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
                content: mensaje,
                externalId: result.messageId,
            });
            await this.messagesService.updateStatus(savedMessage.id, message_entity_1.MessageStatus.SENT);
            this.logger.log(`✅ Mensaje de horario enviado a ${chat.contactPhone}`);
        }
        catch (error) {
            this.logger.error(`Error enviando mensaje de horario: ${error.message}`);
        }
    }
    async handleChatAssigned(event) {
        const { chat, agentName } = event;
        this.logger.log(`👤 Chat ${chat.id} asignado a asesor: ${agentName}`);
        try {
            const mensaje = `✅ *¡Has sido conectado con un asesor!*\n\n` +
                `👤 Asesor asignado: *${agentName}*\n` +
                `🎫 Número de ticket: *${chat.id.substring(0, 8).toUpperCase()}*\n\n` +
                `Nuestro asesor te atenderá en breve. Por favor, describe tu consulta.`;
            const result = await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, mensaje, message_entity_1.MessageType.TEXT);
            const savedMessage = await this.messagesService.create({
                chatId: chat.id,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
                content: mensaje,
                externalId: result.messageId,
            });
            await this.messagesService.updateStatus(savedMessage.id, message_entity_1.MessageStatus.SENT);
            this.logger.log(`✅ Mensaje de asignación enviado a ${chat.contactPhone}`);
        }
        catch (error) {
            this.logger.error(`Error enviando mensaje de asignación: ${error.message}`);
        }
    }
};
exports.BotListenerService = BotListenerService;
__decorate([
    (0, event_emitter_1.OnEvent)('message.created'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], BotListenerService.prototype, "handleMessageCreated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.assigned'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], BotListenerService.prototype, "handleChatAssigned", null);
exports.BotListenerService = BotListenerService = BotListenerService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(5, (0, typeorm_1.InjectRepository)(campaign_entity_1.Campaign)),
    __metadata("design:paramtypes", [bot_engine_service_1.BotEngineService,
        chats_service_1.ChatsService,
        debtors_service_1.DebtorsService,
        messages_service_1.MessagesService,
        whatsapp_service_1.WhatsappService,
        typeorm_2.Repository])
], BotListenerService);
//# sourceMappingURL=bot-listener.service.js.map