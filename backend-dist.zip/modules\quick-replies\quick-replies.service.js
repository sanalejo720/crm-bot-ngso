"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuickRepliesService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const quick_reply_entity_1 = require("./entities/quick-reply.entity");
let QuickRepliesService = class QuickRepliesService {
    constructor(quickReplyRepository) {
        this.quickReplyRepository = quickReplyRepository;
    }
    async create(userId, createDto) {
        const existing = await this.quickReplyRepository.findOne({
            where: {
                shortcut: createDto.shortcut,
                userId,
                campaignId: createDto.campaignId || null,
            },
        });
        if (existing) {
            throw new common_1.BadRequestException('Ya existe una plantilla con ese shortcut');
        }
        const quickReply = this.quickReplyRepository.create({
            ...createDto,
            userId,
        });
        return await this.quickReplyRepository.save(quickReply);
    }
    async findAll(userId, campaignId, category) {
        const query = this.quickReplyRepository.createQueryBuilder('qr');
        query.where('(qr.userId IS NULL OR qr.userId = :userId)', { userId });
        if (campaignId) {
            query.andWhere('(qr.campaignId IS NULL OR qr.campaignId = :campaignId)', { campaignId });
        }
        if (category) {
            query.andWhere('qr.category = :category', { category });
        }
        query.andWhere('qr.isActive = true');
        query.orderBy('qr.usageCount', 'DESC').addOrderBy('qr.createdAt', 'DESC');
        return await query.getMany();
    }
    async findOne(id) {
        const quickReply = await this.quickReplyRepository.findOne({ where: { id } });
        if (!quickReply) {
            throw new common_1.NotFoundException('Plantilla no encontrada');
        }
        return quickReply;
    }
    async update(id, userId, updateDto) {
        const quickReply = await this.findOne(id);
        if (quickReply.userId && quickReply.userId !== userId) {
            throw new common_1.BadRequestException('No tienes permiso para editar esta plantilla');
        }
        if (updateDto.shortcut && updateDto.shortcut !== quickReply.shortcut) {
            const existing = await this.quickReplyRepository.findOne({
                where: {
                    shortcut: updateDto.shortcut,
                    userId: quickReply.userId,
                    campaignId: quickReply.campaignId,
                },
            });
            if (existing) {
                throw new common_1.BadRequestException('Ya existe una plantilla con ese shortcut');
            }
        }
        Object.assign(quickReply, updateDto);
        return await this.quickReplyRepository.save(quickReply);
    }
    async remove(id, userId) {
        const quickReply = await this.findOne(id);
        if (quickReply.userId && quickReply.userId !== userId) {
            throw new common_1.BadRequestException('No tienes permiso para eliminar esta plantilla');
        }
        await this.quickReplyRepository.remove(quickReply);
    }
    replaceVariables(content, variables) {
        let result = content;
        for (const [key, value] of Object.entries(variables)) {
            const regex = new RegExp(`{{${key}}}`, 'g');
            result = result.replace(regex, String(value || ''));
        }
        return result;
    }
    async applyTemplate(id, variables) {
        const quickReply = await this.findOne(id);
        quickReply.usageCount += 1;
        await this.quickReplyRepository.save(quickReply);
        return this.replaceVariables(quickReply.content, variables);
    }
    async findByShortcut(shortcut, userId, campaignId) {
        const query = this.quickReplyRepository.createQueryBuilder('qr');
        query.where('qr.shortcut = :shortcut', { shortcut });
        query.andWhere('(qr.userId IS NULL OR qr.userId = :userId)', { userId });
        if (campaignId) {
            query.andWhere('(qr.campaignId IS NULL OR qr.campaignId = :campaignId)', { campaignId });
        }
        query.andWhere('qr.isActive = true');
        query.orderBy('qr.userId', 'DESC');
        return await query.getOne();
    }
    async getStats(userId) {
        const templates = await this.quickReplyRepository.find({
            where: { userId },
            order: { usageCount: 'DESC' },
        });
        const totalUsage = templates.reduce((sum, t) => sum + t.usageCount, 0);
        const byCategory = templates.reduce((acc, t) => {
            const cat = t.category || 'Sin categoría';
            acc[cat] = (acc[cat] || 0) + t.usageCount;
            return acc;
        }, {});
        return {
            totalTemplates: templates.length,
            totalUsage,
            topTemplates: templates.slice(0, 5).map(t => ({
                id: t.id,
                title: t.title,
                shortcut: t.shortcut,
                usageCount: t.usageCount,
            })),
            byCategory,
        };
    }
};
exports.QuickRepliesService = QuickRepliesService;
exports.QuickRepliesService = QuickRepliesService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(quick_reply_entity_1.QuickReply)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], QuickRepliesService);
//# sourceMappingURL=quick-replies.service.js.map