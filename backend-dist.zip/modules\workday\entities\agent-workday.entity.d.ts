import { User } from '../../users/entities/user.entity';
import { AgentPause } from './agent-pause.entity';
import { AgentWorkdayEvent } from './agent-workday-event.entity';
export declare enum WorkdayStatus {
    OFFLINE = "offline",
    WORKING = "working",
    ON_PAUSE = "on_pause"
}
export declare class AgentWorkday {
    id: string;
    agentId: string;
    agent: User;
    workDate: Date;
    clockInTime: Date;
    clockOutTime: Date;
    totalWorkMinutes: number;
    totalPauseMinutes: number;
    totalProductiveMinutes: number;
    currentStatus: WorkdayStatus;
    chatsHandled: number;
    messagesSent: number;
    avgResponseTimeSeconds: number;
    notes: string;
    pauses: AgentPause[];
    events: AgentWorkdayEvent[];
    createdAt: Date;
    updatedAt: Date;
}
