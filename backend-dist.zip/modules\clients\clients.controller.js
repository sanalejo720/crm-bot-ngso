"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const clients_service_1 = require("./clients.service");
const create_client_dto_1 = require("./dto/create-client.dto");
const update_client_dto_1 = require("./dto/update-client.dto");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const client_entity_1 = require("./entities/client.entity");
let ClientsController = class ClientsController {
    constructor(clientsService) {
        this.clientsService = clientsService;
    }
    create(createClientDto, user) {
        return this.clientsService.create(createClientDto, user.sub);
    }
    findAll(search, leadStatus, campaignId, tags, assignedTo) {
        return this.clientsService.findAll({
            search,
            leadStatus,
            campaignId,
            tags: tags ? tags.split(',') : undefined,
            assignedTo,
        });
    }
    getStats(campaignId) {
        return this.clientsService.getStats(campaignId);
    }
    findDuplicates() {
        return this.clientsService.findDuplicates();
    }
    findOne(id) {
        return this.clientsService.findOne(id);
    }
    update(id, updateClientDto) {
        return this.clientsService.update(id, updateClientDto);
    }
    updateLeadStatus(id, body) {
        return this.clientsService.updateLeadStatus(id, body.leadStatus);
    }
    addNote(id, body, user) {
        return this.clientsService.addNote(id, body.note, user.sub);
    }
    addTags(id, body) {
        return this.clientsService.addTags(id, body.tags);
    }
    removeTags(id, body) {
        return this.clientsService.removeTags(id, body.tags);
    }
    assignTo(id, body) {
        return this.clientsService.assignTo(id, body.userId);
    }
    bulkImport(body, user) {
        return this.clientsService.bulkImport(body.clients, user.sub);
    }
    remove(id) {
        return this.clientsService.remove(id);
    }
};
exports.ClientsController = ClientsController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Crear nuevo cliente' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_client_dto_1.CreateClientDto, Object]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener todos los clientes con filtros' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'read' }),
    __param(0, (0, common_1.Query)('search')),
    __param(1, (0, common_1.Query)('leadStatus')),
    __param(2, (0, common_1.Query)('campaignId')),
    __param(3, (0, common_1.Query)('tags')),
    __param(4, (0, common_1.Query)('assignedTo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas de clientes' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'read' }),
    __param(0, (0, common_1.Query)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)('duplicates'),
    (0, swagger_1.ApiOperation)({ summary: 'Buscar clientes duplicados' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "findDuplicates", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener cliente por ID' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Actualizar cliente' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_client_dto_1.UpdateClientDto]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "update", null);
__decorate([
    (0, common_1.Patch)(':id/lead-status'),
    (0, swagger_1.ApiOperation)({ summary: 'Cambiar estado del lead' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "updateLeadStatus", null);
__decorate([
    (0, common_1.Post)(':id/notes'),
    (0, swagger_1.ApiOperation)({ summary: 'Agregar nota interna' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "addNote", null);
__decorate([
    (0, common_1.Post)(':id/tags'),
    (0, swagger_1.ApiOperation)({ summary: 'Agregar tags al cliente' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "addTags", null);
__decorate([
    (0, common_1.Delete)(':id/tags'),
    (0, swagger_1.ApiOperation)({ summary: 'Remover tags del cliente' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "removeTags", null);
__decorate([
    (0, common_1.Patch)(':id/assign'),
    (0, swagger_1.ApiOperation)({ summary: 'Asignar cliente a usuario' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "assignTo", null);
__decorate([
    (0, common_1.Post)('bulk-import'),
    (0, swagger_1.ApiOperation)({ summary: 'Importar clientes en lote' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "bulkImport", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Eliminar cliente (soft delete)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'delete' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ClientsController.prototype, "remove", null);
exports.ClientsController = ClientsController = __decorate([
    (0, swagger_1.ApiTags)('clients'),
    (0, common_1.Controller)('clients'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [clients_service_1.ClientsService])
], ClientsController);
//# sourceMappingURL=clients.controller.js.map