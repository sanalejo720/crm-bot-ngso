"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const typeorm_1 = require("@nestjs/typeorm");
const bull_1 = require("@nestjs/bull");
const event_emitter_1 = require("@nestjs/event-emitter");
const schedule_1 = require("@nestjs/schedule");
const http_exception_filter_1 = require("./common/filters/http-exception.filter");
const transform_interceptor_1 = require("./common/interceptors/transform.interceptor");
const auth_module_1 = require("./modules/auth/auth.module");
const users_module_1 = require("./modules/users/users.module");
const roles_module_1 = require("./modules/roles/roles.module");
const campaigns_module_1 = require("./modules/campaigns/campaigns.module");
const whatsapp_module_1 = require("./modules/whatsapp/whatsapp.module");
const chats_module_1 = require("./modules/chats/chats.module");
const messages_module_1 = require("./modules/messages/messages.module");
const queue_module_1 = require("./modules/queues/queue.module");
const bot_module_1 = require("./modules/bot/bot.module");
const gateway_module_1 = require("./modules/gateway/gateway.module");
const clients_module_1 = require("./modules/clients/clients.module");
const tasks_module_1 = require("./modules/tasks/tasks.module");
const reports_module_1 = require("./modules/reports/reports.module");
const audit_module_1 = require("./modules/audit/audit.module");
const quick_replies_module_1 = require("./modules/quick-replies/quick-replies.module");
const monitoring_module_1 = require("./modules/monitoring/monitoring.module");
const debtors_module_1 = require("./modules/debtors/debtors.module");
const payment_evidences_module_1 = require("./modules/payment-evidences/payment-evidences.module");
const backups_module_1 = require("./modules/backups/backups.module");
const unidentified_clients_module_1 = require("./modules/unidentified-clients/unidentified-clients.module");
const evidences_module_1 = require("./modules/evidences/evidences.module");
const workday_module_1 = require("./modules/workday/workday.module");
const workers_module_1 = require("./modules/workers/workers.module");
const metrics_module_1 = require("./modules/metrics/metrics.module");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({
                isGlobal: true,
                envFilePath: '.env',
            }),
            typeorm_1.TypeOrmModule.forRootAsync({
                imports: [config_1.ConfigModule],
                inject: [config_1.ConfigService],
                useFactory: (configService) => ({
                    type: 'postgres',
                    host: configService.get('DB_HOST'),
                    port: configService.get('DB_PORT'),
                    username: configService.get('DB_USERNAME'),
                    password: configService.get('DB_PASSWORD'),
                    database: configService.get('DB_NAME'),
                    entities: [__dirname + '/**/*.entity{.ts,.js}'],
                    synchronize: configService.get('NODE_ENV') !== 'production',
                    logging: configService.get('NODE_ENV') === 'development',
                    ssl: configService.get('DB_SSL') === 'true' ? { rejectUnauthorized: false } : false,
                    timezone: 'America/Bogota',
                }),
            }),
            bull_1.BullModule.forRootAsync({
                imports: [config_1.ConfigModule],
                inject: [config_1.ConfigService],
                useFactory: (configService) => ({
                    redis: {
                        host: configService.get('REDIS_HOST', 'localhost'),
                        port: configService.get('REDIS_PORT', 6379),
                        password: configService.get('REDIS_PASSWORD'),
                    },
                }),
            }),
            event_emitter_1.EventEmitterModule.forRoot({
                wildcard: true,
                delimiter: '.',
                maxListeners: 20,
                verboseMemoryLeak: true,
            }),
            schedule_1.ScheduleModule.forRoot(),
            auth_module_1.AuthModule,
            users_module_1.UsersModule,
            roles_module_1.RolesModule,
            campaigns_module_1.CampaignsModule,
            whatsapp_module_1.WhatsappModule,
            chats_module_1.ChatsModule,
            messages_module_1.MessagesModule,
            queue_module_1.QueueModule,
            bot_module_1.BotModule,
            gateway_module_1.GatewayModule,
            clients_module_1.ClientsModule,
            tasks_module_1.TasksModule,
            reports_module_1.ReportsModule,
            audit_module_1.AuditModule,
            quick_replies_module_1.QuickRepliesModule,
            monitoring_module_1.MonitoringModule,
            debtors_module_1.DebtorsModule,
            payment_evidences_module_1.PaymentEvidencesModule,
            backups_module_1.BackupsModule,
            unidentified_clients_module_1.UnidentifiedClientsModule,
            evidences_module_1.EvidencesModule,
            workday_module_1.WorkdayModule,
            workers_module_1.WorkersModule,
            metrics_module_1.MetricsModule,
        ],
        providers: [
            {
                provide: 'APP_FILTER',
                useClass: http_exception_filter_1.HttpExceptionFilter,
            },
            {
                provide: 'APP_INTERCEPTOR',
                useClass: transform_interceptor_1.TransformInterceptor,
            },
        ],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map