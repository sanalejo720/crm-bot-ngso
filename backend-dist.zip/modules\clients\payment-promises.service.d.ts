import { Repository } from 'typeorm';
import { Client } from '../clients/entities/client.entity';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { Chat } from '../chats/entities/chat.entity';
export interface PaymentPromise {
    id: string;
    clientId: string;
    clientName: string;
    phone: string;
    promiseAmount: number;
    promiseDate: Date;
    debtAmount: number;
    daysUntilDue: number;
    chatId?: string;
    whatsappNumberId?: string;
    status: 'upcoming' | 'due-today' | 'overdue';
}
export declare class PaymentPromisesService {
    private clientRepository;
    private chatRepository;
    private whatsappService;
    private readonly logger;
    constructor(clientRepository: Repository<Client>, chatRepository: Repository<Chat>, whatsappService: WhatsappService);
    getUpcomingPromises(daysAhead?: number): Promise<PaymentPromise[]>;
    getPromisesDueToday(): Promise<PaymentPromise[]>;
    getOverduePromises(): Promise<PaymentPromise[]>;
    markPromiseAsPaid(clientId: string, actualPaymentAmount?: number): Promise<Client>;
    sendPaymentReminder(clientId: string, reminderType: 'upcoming' | 'today' | 'overdue'): Promise<boolean>;
    private generateReminderMessage;
    private mapClientsToPromises;
    sendDailyReminders(): Promise<void>;
}
