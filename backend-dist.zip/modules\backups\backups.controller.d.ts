import { Response } from 'express';
import { BackupsService } from './backups.service';
import { CreateBackupDto, DownloadBackupDto } from './dto/backup.dto';
export declare class BackupsController {
    private readonly backupsService;
    constructor(backupsService: BackupsService);
    create(createBackupDto: CreateBackupDto, user: any): Promise<{
        success: boolean;
        message: string;
        data: {
            id: string;
            fileName: string;
            status: import("./entities/backup.entity").BackupStatus;
            masterPassword: any;
            createdAt: Date;
        };
    }>;
    findAll(): Promise<{
        success: boolean;
        data: {
            id: string;
            fileName: string;
            fileSize: number;
            status: import("./entities/backup.entity").BackupStatus;
            type: import("./entities/backup.entity").BackupType;
            isEncrypted: boolean;
            createdAt: Date;
            completedAt: Date;
            createdBy: {
                id: string;
                name: string;
            };
            metadata: {
                databaseSize?: number;
                filesSize?: number;
                totalRecords?: number;
                tablesIncluded?: string[];
                compressionRatio?: number;
            };
        }[];
    }>;
    findOne(id: string): Promise<{
        success: boolean;
        data: {
            id: string;
            fileName: string;
            fileSize: number;
            status: import("./entities/backup.entity").BackupStatus;
            type: import("./entities/backup.entity").BackupType;
            isEncrypted: boolean;
            createdAt: Date;
            completedAt: Date;
            errorMessage: string;
            createdBy: {
                id: string;
                name: string;
                email: string;
            };
            metadata: {
                databaseSize?: number;
                filesSize?: number;
                totalRecords?: number;
                tablesIncluded?: string[];
                compressionRatio?: number;
            };
        };
    }>;
    download(id: string, downloadDto: DownloadBackupDto, res: Response): Promise<void>;
    remove(id: string): Promise<{
        success: boolean;
        message: string;
    }>;
}
