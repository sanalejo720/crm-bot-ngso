import { DebtorsService } from './debtors.service';
import { CreateDebtorDto } from './dto/create-debtor.dto';
import { DocumentType } from './entities/debtor.entity';
export declare class DebtorsController {
    private readonly debtorsService;
    private readonly logger;
    constructor(debtorsService: DebtorsService);
    create(createDebtorDto: CreateDebtorDto): Promise<{
        message: string;
        data: import("./entities/debtor.entity").Debtor;
    }>;
    findAll(page?: number, limit?: number): Promise<{
        message: string;
        data: import("./entities/debtor.entity").Debtor[];
        meta: {
            page: number;
            limit: number;
            total: number;
            totalPages: number;
        };
    }>;
    findByDocument(documentType: DocumentType, documentNumber: string): Promise<{
        message: string;
        data: import("./entities/debtor.entity").Debtor;
    }>;
    findByPhone(phone: string): Promise<{
        message: string;
        data: import("./entities/debtor.entity").Debtor;
    }>;
    uploadFile(file: Express.Multer.File): Promise<{
        success: boolean;
        message: string;
        data?: undefined;
    } | {
        success: boolean;
        message: string;
        data: import("./dto/upload-result.dto").UploadResultDto;
    }>;
    uploadCsv(file: any): Promise<{
        success: boolean;
        message: string;
        data?: undefined;
    } | {
        message: string;
        data: {
            created: number;
            updated: number;
            errorsCount: number;
            errors: string[];
        };
        success?: undefined;
    }>;
}
