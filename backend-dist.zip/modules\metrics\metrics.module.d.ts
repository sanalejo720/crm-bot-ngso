export declare class MetricsModule {
}
