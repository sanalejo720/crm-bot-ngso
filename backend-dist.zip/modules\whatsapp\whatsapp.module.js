"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WhatsappModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const whatsapp_service_1 = require("./whatsapp.service");
const whatsapp_controller_1 = require("./whatsapp.controller");
const whatsapp_numbers_controller_1 = require("./whatsapp-numbers.controller");
const whatsapp_numbers_service_1 = require("./whatsapp-numbers.service");
const webhook_controller_1 = require("./webhook.controller");
const whatsapp_number_entity_1 = require("./entities/whatsapp-number.entity");
const whatsapp_number_campaign_entity_1 = require("./entities/whatsapp-number-campaign.entity");
const meta_cloud_service_1 = require("./providers/meta-cloud.service");
const meta_service_1 = require("./providers/meta.service");
const wppconnect_service_1 = require("./providers/wppconnect.service");
const twilio_service_1 = require("./providers/twilio.service");
const twilio_spam_detector_service_1 = require("./services/twilio-spam-detector.service");
const message_audit_service_1 = require("./services/message-audit.service");
const message_entity_1 = require("../messages/entities/message.entity");
const chat_entity_1 = require("../chats/entities/chat.entity");
let WhatsappModule = class WhatsappModule {
};
exports.WhatsappModule = WhatsappModule;
exports.WhatsappModule = WhatsappModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([whatsapp_number_entity_1.WhatsappNumber, whatsapp_number_campaign_entity_1.WhatsappNumberCampaign, message_entity_1.Message, chat_entity_1.Chat])],
        controllers: [whatsapp_controller_1.WhatsappController, whatsapp_numbers_controller_1.WhatsappNumbersController, webhook_controller_1.WebhookController],
        providers: [
            whatsapp_service_1.WhatsappService,
            whatsapp_numbers_service_1.WhatsappNumbersService,
            meta_cloud_service_1.MetaCloudService,
            meta_service_1.MetaService,
            wppconnect_service_1.WppConnectService,
            twilio_service_1.TwilioService,
            twilio_spam_detector_service_1.TwilioSpamDetectorService,
            message_audit_service_1.MessageAuditService,
        ],
        exports: [
            whatsapp_service_1.WhatsappService,
            whatsapp_numbers_service_1.WhatsappNumbersService,
            twilio_spam_detector_service_1.TwilioSpamDetectorService,
            message_audit_service_1.MessageAuditService,
        ],
    })
], WhatsappModule);
//# sourceMappingURL=whatsapp.module.js.map