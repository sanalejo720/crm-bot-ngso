"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AutoCloseWorker_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoCloseWorker = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const chat_entity_1 = require("../chats/entities/chat.entity");
const chat_state_service_1 = require("../chats/services/chat-state.service");
const chats_export_service_1 = require("../chats/chats-export.service");
const event_emitter_1 = require("@nestjs/event-emitter");
let AutoCloseWorker = AutoCloseWorker_1 = class AutoCloseWorker {
    constructor(chatRepository, chatStateService, chatsExportService, eventEmitter) {
        this.chatRepository = chatRepository;
        this.chatStateService = chatStateService;
        this.chatsExportService = chatsExportService;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(AutoCloseWorker_1.name);
        this.AUTO_CLOSE_HOURS = 24;
        this.BATCH_SIZE = 50;
    }
    async processAutoClose() {
        this.logger.log('🔄 Iniciando verificación de chats antiguos...');
        try {
            const chatsToClose = await this.findChatsToAutoClose();
            if (chatsToClose.length === 0) {
                this.logger.log('✅ No hay chats pendientes de auto-cierre');
                return;
            }
            this.logger.log(`📋 Encontrados ${chatsToClose.length} chats para auto-cierre`);
            let successCount = 0;
            let errorCount = 0;
            for (const chat of chatsToClose) {
                try {
                    await this.autoCloseChat(chat);
                    successCount++;
                }
                catch (error) {
                    errorCount++;
                    this.logger.error(`Error cerrando chat ${chat.id}: ${error.message}`, error.stack);
                }
            }
            this.logger.log(`✅ Auto-cierre completado: ${successCount} exitosos, ${errorCount} errores`);
        }
        catch (error) {
            this.logger.error(`Error en proceso de auto-cierre: ${error.message}`, error.stack);
        }
    }
    async findChatsToAutoClose() {
        const threshold = new Date();
        threshold.setHours(threshold.getHours() - this.AUTO_CLOSE_HOURS);
        const chats = await this.chatRepository
            .createQueryBuilder('chat')
            .leftJoinAndSelect('chat.assignedAgent', 'agent')
            .leftJoinAndSelect('chat.whatsappNumber', 'whatsappNumber')
            .where('chat.status IN (:...statuses)', {
            statuses: ['active', 'waiting', 'pending'],
        })
            .andWhere('(chat.lastClientMessageAt < :threshold OR chat.lastAgentMessageAt < :threshold)', { threshold })
            .orderBy('chat.lastClientMessageAt', 'ASC')
            .take(this.BATCH_SIZE)
            .getMany();
        return chats;
    }
    async autoCloseChat(chat) {
        this.logger.log(`🔒 Cerrando chat ${chat.id} por inactividad...`);
        try {
            if (chat.assignedAgentId) {
                try {
                    await this.chatsExportService.exportChatToPDF(chat.id, 'promise', chat.assignedAgentId);
                    this.logger.log(`📄 PDF generado para chat ${chat.id}`);
                }
                catch (pdfError) {
                    this.logger.warn(`No se pudo generar PDF para chat ${chat.id}: ${pdfError.message}`);
                }
            }
            await this.chatStateService.transition(chat.id, 'closed', 'closed_auto', {
                reason: `Chat cerrado automáticamente por inactividad de ${this.AUTO_CLOSE_HOURS} horas`,
                triggeredBy: 'system',
                agentId: chat.assignedAgentId,
            });
            this.eventEmitter.emit('chat.auto.closed', {
                chatId: chat.id,
                agentId: chat.assignedAgentId,
                inactiveHours: this.AUTO_CLOSE_HOURS,
                lastActivity: chat.lastClientMessageAt || chat.lastAgentMessageAt,
            });
            this.logger.log(`✅ Chat ${chat.id} cerrado automáticamente`);
        }
        catch (error) {
            this.logger.error(`Error en auto-cierre de chat ${chat.id}: ${error.message}`, error.stack);
            throw error;
        }
    }
    async scheduleAutoClose(chatId) {
        const scheduledAt = new Date();
        scheduledAt.setHours(scheduledAt.getHours() + this.AUTO_CLOSE_HOURS);
        await this.chatRepository.update(chatId, {
            autoCloseScheduledAt: scheduledAt,
        });
        this.logger.log(`📅 Auto-cierre programado para chat ${chatId} a las ${scheduledAt.toISOString()}`);
    }
    async cancelAutoClose(chatId) {
        await this.chatRepository.update(chatId, {
            autoCloseScheduledAt: null,
        });
        this.logger.log(`❌ Auto-cierre cancelado para chat ${chatId}`);
    }
    async getUpcomingAutoClose(hours = 2) {
        const now = new Date();
        const threshold = new Date();
        threshold.setHours(threshold.getHours() - (this.AUTO_CLOSE_HOURS - hours));
        const chats = await this.chatRepository
            .createQueryBuilder('chat')
            .leftJoinAndSelect('chat.assignedAgent', 'agent')
            .leftJoinAndSelect('chat.debtor', 'debtor')
            .where('chat.status IN (:...statuses)', {
            statuses: ['active', 'waiting', 'pending'],
        })
            .andWhere('(chat.lastClientMessageAt < :threshold OR chat.lastAgentMessageAt < :threshold)', { threshold })
            .orderBy('chat.lastClientMessageAt', 'ASC')
            .take(50)
            .getMany();
        return chats.map((chat) => {
            const lastActivity = chat.lastClientMessageAt > chat.lastAgentMessageAt
                ? chat.lastClientMessageAt
                : chat.lastAgentMessageAt;
            const hoursInactive = Math.floor((now.getTime() - lastActivity.getTime()) / (1000 * 60 * 60));
            const hoursRemaining = this.AUTO_CLOSE_HOURS - hoursInactive;
            return {
                ...chat,
                hoursInactive,
                hoursRemaining: Math.max(0, hoursRemaining),
                willCloseAt: new Date(lastActivity.getTime() + this.AUTO_CLOSE_HOURS * 60 * 60 * 1000),
            };
        });
    }
    async getAutoCloseStats(startDate, endDate) {
        const autoClosed = await this.chatRepository
            .createQueryBuilder('chat')
            .where('chat.subStatus = :status', { status: 'closed_auto' })
            .andWhere('chat.closedAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .getCount();
        const avgHoursToClose = await this.chatRepository
            .createQueryBuilder('chat')
            .select('AVG(EXTRACT(EPOCH FROM (chat.closedAt - chat.lastClientMessageAt)) / 3600)', 'avgHours')
            .where('chat.subStatus = :status', { status: 'closed_auto' })
            .andWhere('chat.closedAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .getRawOne();
        return {
            totalAutoClosed: autoClosed,
            averageHoursToClose: parseFloat(avgHoursToClose?.avgHours || '0'),
            autoCloseThreshold: this.AUTO_CLOSE_HOURS,
        };
    }
};
exports.AutoCloseWorker = AutoCloseWorker;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_MINUTE),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AutoCloseWorker.prototype, "processAutoClose", null);
exports.AutoCloseWorker = AutoCloseWorker = AutoCloseWorker_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        chat_state_service_1.ChatStateService,
        chats_export_service_1.ChatsExportService,
        event_emitter_1.EventEmitter2])
], AutoCloseWorker);
//# sourceMappingURL=auto-close.worker.js.map