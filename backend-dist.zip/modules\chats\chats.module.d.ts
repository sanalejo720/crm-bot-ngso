export declare class ChatsModule {
}
