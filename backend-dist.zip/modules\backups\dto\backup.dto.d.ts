import { BackupType } from '../entities/backup.entity';
export declare class CreateBackupDto {
    type?: BackupType;
    notes?: string;
}
export declare class DownloadBackupDto {
    password: string;
}
export declare class BackupResponseDto {
    id: string;
    fileName: string;
    fileSize: number;
    status: string;
    type: string;
    isEncrypted: boolean;
    createdAt: Date;
    completedAt?: Date;
    createdBy?: {
        id: string;
        name: string;
    };
    metadata?: any;
}
export declare class BackupScheduleDto {
    frequency: 'daily' | 'weekly' | 'monthly';
    hour: number;
}
