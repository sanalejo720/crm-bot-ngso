import { Repository } from 'typeorm';
import { User, UserStatus, AgentState } from './entities/user.entity';
import { UserCampaign } from './entities/user-campaign.entity';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { WorkdayService } from '../workday/workday.service';
export declare class UsersService {
    private userRepository;
    private userCampaignRepository;
    private workdayService;
    private readonly logger;
    constructor(userRepository: Repository<User>, userCampaignRepository: Repository<UserCampaign>, workdayService: WorkdayService);
    create(createUserDto: CreateUserDto): Promise<User>;
    findAll(filters?: {
        status?: UserStatus;
        roleId?: string;
        campaignId?: string;
        isAgent?: boolean;
    }): Promise<any[]>;
    findOne(id: string): Promise<User>;
    findByEmail(email: string): Promise<User | null>;
    update(id: string, updateUserDto: UpdateUserDto): Promise<User>;
    remove(id: string): Promise<void>;
    changePassword(id: string, newPassword: string): Promise<void>;
    updateAgentState(id: string, state: AgentState): Promise<User>;
    incrementChatCount(id: string): Promise<void>;
    decrementChatCount(id: string): Promise<void>;
    getAvailableAgents(campaignId: string): Promise<User[]>;
}
