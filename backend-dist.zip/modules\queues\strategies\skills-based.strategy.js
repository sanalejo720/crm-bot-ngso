"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var SkillsBasedStrategy_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SkillsBasedStrategy = void 0;
const common_1 = require("@nestjs/common");
let SkillsBasedStrategy = SkillsBasedStrategy_1 = class SkillsBasedStrategy {
    constructor() {
        this.logger = new common_1.Logger(SkillsBasedStrategy_1.name);
    }
    selectAgent(availableAgents, chat) {
        if (!availableAgents || availableAgents.length === 0) {
            this.logger.warn('No hay agentes disponibles para asignación');
            return null;
        }
        const requiredSkills = chat.tags || [];
        if (requiredSkills.length === 0) {
            const sortedAgents = [...availableAgents].sort((a, b) => a.currentChatsCount - b.currentChatsCount);
            return sortedAgents[0];
        }
        const matchingAgents = availableAgents.filter((agent) => {
            if (!agent.skills || agent.skills.length === 0) {
                return false;
            }
            return requiredSkills.some((skill) => agent.skills.includes(skill));
        });
        if (matchingAgents.length === 0) {
            this.logger.warn(`No hay agentes con habilidades requeridas: ${requiredSkills.join(', ')}`);
            const sortedAgents = [...availableAgents].sort((a, b) => a.currentChatsCount - b.currentChatsCount);
            return sortedAgents[0];
        }
        const sortedMatching = [...matchingAgents].sort((a, b) => a.currentChatsCount - b.currentChatsCount);
        const agent = sortedMatching[0];
        this.logger.log(`Agente seleccionado por Skills: ${agent.fullName} (${agent.currentChatsCount} chats, skills: ${agent.skills.join(', ')})`);
        return agent;
    }
    getName() {
        return 'skills-based';
    }
};
exports.SkillsBasedStrategy = SkillsBasedStrategy;
exports.SkillsBasedStrategy = SkillsBasedStrategy = SkillsBasedStrategy_1 = __decorate([
    (0, common_1.Injectable)()
], SkillsBasedStrategy);
//# sourceMappingURL=skills-based.strategy.js.map