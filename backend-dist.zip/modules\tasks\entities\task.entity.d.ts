import { User } from '../../users/entities/user.entity';
import { Client } from '../../clients/entities/client.entity';
export declare enum TaskStatus {
    PENDING = "pending",
    IN_PROGRESS = "in_progress",
    COMPLETED = "completed",
    CANCELLED = "cancelled"
}
export declare enum TaskPriority {
    LOW = "low",
    MEDIUM = "medium",
    HIGH = "high",
    URGENT = "urgent"
}
export declare class Task {
    id: string;
    title: string;
    description: string;
    status: TaskStatus;
    priority: TaskPriority;
    dueDate: Date;
    completedAt: Date;
    completedBy: string;
    completionNotes: string;
    assignedTo: User;
    assignedToId: string;
    createdBy: User;
    createdById: string;
    client: Client;
    clientId: string;
    createdAt: Date;
    updatedAt: Date;
}
