"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var TwilioService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TwilioService = void 0;
const common_1 = require("@nestjs/common");
const event_emitter_1 = require("@nestjs/event-emitter");
const twilio_1 = __importDefault(require("twilio"));
let TwilioService = TwilioService_1 = class TwilioService {
    constructor(eventEmitter) {
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(TwilioService_1.name);
        this.clients = new Map();
    }
    initializeClient(whatsappNumberId, accountSid, authToken) {
        try {
            const client = (0, twilio_1.default)(accountSid, authToken);
            this.clients.set(whatsappNumberId, client);
            this.logger.log(`Cliente Twilio inicializado para ${whatsappNumberId}`);
        }
        catch (error) {
            this.logger.error(`Error inicializando Twilio: ${error.message}`);
            throw error;
        }
    }
    getClient(whatsappNumberId) {
        const client = this.clients.get(whatsappNumberId);
        if (!client) {
            throw new common_1.BadRequestException('Cliente Twilio no inicializado');
        }
        return client;
    }
    async sendTextMessage(whatsappNumberId, from, to, body) {
        try {
            const client = this.getClient(whatsappNumberId);
            const fromNumber = from.startsWith('whatsapp:') ? from : `whatsapp:${from}`;
            const toNumber = to.startsWith('whatsapp:') ? to : `whatsapp:${to}`;
            const message = await client.messages.create({
                from: fromNumber,
                to: toNumber,
                body,
            });
            this.logger.log(`Mensaje enviado vía Twilio: ${message.sid}`);
            return {
                messageId: message.sid,
                metadata: {
                    status: message.status,
                    dateCreated: message.dateCreated,
                    dateSent: message.dateSent,
                    errorCode: message.errorCode,
                    errorMessage: message.errorMessage,
                },
            };
        }
        catch (error) {
            this.logger.error(`Error enviando mensaje Twilio: ${error.message}`, error.stack);
            throw error;
        }
    }
    async sendMediaMessage(whatsappNumberId, from, to, body, mediaUrl) {
        try {
            const client = this.getClient(whatsappNumberId);
            const fromNumber = from.startsWith('whatsapp:') ? from : `whatsapp:${from}`;
            const toNumber = to.startsWith('whatsapp:') ? to : `whatsapp:${to}`;
            const message = await client.messages.create({
                from: fromNumber,
                to: toNumber,
                body,
                mediaUrl: [mediaUrl],
            });
            this.logger.log(`Mensaje con media enviado vía Twilio: ${message.sid}`);
            return {
                messageId: message.sid,
                metadata: {
                    status: message.status,
                    dateCreated: message.dateCreated,
                },
            };
        }
        catch (error) {
            this.logger.error(`Error enviando media Twilio: ${error.message}`, error.stack);
            throw error;
        }
    }
    async processWebhook(payload) {
        try {
            this.logger.log('Webhook de Twilio recibido');
            this.logger.debug(JSON.stringify(payload, null, 2));
            const { From: from, To: to, Body: body, MessageSid: messageSid, MediaUrl0: mediaUrl, NumMedia: numMedia, ProfileName: profileName, MessageStatus: messageStatus, SmsStatus: smsStatus, } = payload;
            const status = messageStatus || smsStatus;
            if (status && !body) {
                this.logger.log(`📊 Status update recibido: ${status} para mensaje ${messageSid}`);
                this.eventEmitter.emit('whatsapp.message.status', {
                    provider: 'twilio',
                    messageId: messageSid,
                    status: status,
                    errorCode: payload.ErrorCode,
                    errorMessage: payload.ErrorMessage,
                    timestamp: new Date(),
                });
                this.logger.log(`✅ Status update procesado: ${messageSid} -> ${status}`);
                return;
            }
            if (!body && (!numMedia || numMedia === '0')) {
                this.logger.warn(`⚠️ Webhook sin contenido de mensaje, ignorando`);
                return;
            }
            const contactPhone = from.replace('whatsapp:', '').replace('+', '');
            const whatsappNumberClean = to.replace('whatsapp:', '').replace('+', '');
            this.logger.log(`📱 Mensaje entrante de: ${contactPhone}, Para: ${whatsappNumberClean}, Contenido: "${body}"`);
            this.eventEmitter.emit('whatsapp.message.received', {
                provider: 'twilio',
                from: contactPhone,
                content: body || '',
                type: numMedia > 0 ? 'image' : 'text',
                messageId: messageSid,
                timestamp: new Date(),
                sessionName: whatsappNumberClean,
                mediaUrl: numMedia > 0 ? mediaUrl : null,
                isMedia: numMedia > 0,
                contactName: profileName || contactPhone,
                twilioData: {
                    whatsappNumber: whatsappNumberClean,
                    contactPhone,
                    numMedia,
                },
            });
            this.logger.log(`✅ Mensaje entrante procesado: ${messageSid}`);
        }
        catch (error) {
            this.logger.error(`Error procesando webhook Twilio: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getMessageStatus(whatsappNumberId, messageSid) {
        try {
            const client = this.getClient(whatsappNumberId);
            const message = await client.messages(messageSid).fetch();
            return {
                sid: message.sid,
                status: message.status,
                dateCreated: message.dateCreated,
                dateSent: message.dateSent,
                dateUpdated: message.dateUpdated,
                errorCode: message.errorCode,
                errorMessage: message.errorMessage,
            };
        }
        catch (error) {
            this.logger.error(`Error obteniendo estado de mensaje: ${error.message}`);
            throw error;
        }
    }
    removeClient(whatsappNumberId) {
        this.clients.delete(whatsappNumberId);
        this.logger.log(`Cliente Twilio removido: ${whatsappNumberId}`);
    }
};
exports.TwilioService = TwilioService;
exports.TwilioService = TwilioService = TwilioService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [event_emitter_1.EventEmitter2])
], TwilioService);
//# sourceMappingURL=twilio.service.js.map