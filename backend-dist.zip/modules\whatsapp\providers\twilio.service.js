"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var TwilioService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TwilioService = void 0;
const common_1 = require("@nestjs/common");
const event_emitter_1 = require("@nestjs/event-emitter");
const twilio_1 = __importDefault(require("twilio"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const axios_1 = __importDefault(require("axios"));
let TwilioService = TwilioService_1 = class TwilioService {
    constructor(eventEmitter) {
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(TwilioService_1.name);
        this.clients = new Map();
        this.credentials = new Map();
    }
    initializeClient(whatsappNumberId, accountSid, authToken) {
        try {
            const client = (0, twilio_1.default)(accountSid, authToken);
            this.clients.set(whatsappNumberId, client);
            this.credentials.set(whatsappNumberId, { accountSid, authToken });
            this.logger.log(`Cliente Twilio inicializado para ${whatsappNumberId}`);
        }
        catch (error) {
            this.logger.error(`Error inicializando Twilio: ${error.message}`);
            throw error;
        }
    }
    getClient(whatsappNumberId) {
        const client = this.clients.get(whatsappNumberId);
        if (!client) {
            throw new common_1.BadRequestException('Cliente Twilio no inicializado');
        }
        return client;
    }
    async sendTextMessage(whatsappNumberId, from, to, body) {
        try {
            const client = this.getClient(whatsappNumberId);
            const fromNumber = from.startsWith('whatsapp:') ? from : `whatsapp:${from}`;
            const toNumber = to.startsWith('whatsapp:') ? to : `whatsapp:${to}`;
            const message = await client.messages.create({
                from: fromNumber,
                to: toNumber,
                body,
            });
            this.logger.log(`Mensaje enviado vía Twilio: ${message.sid}`);
            return {
                messageId: message.sid,
                metadata: {
                    status: message.status,
                    dateCreated: message.dateCreated,
                    dateSent: message.dateSent,
                    errorCode: message.errorCode,
                    errorMessage: message.errorMessage,
                },
            };
        }
        catch (error) {
            this.logger.error(`Error enviando mensaje Twilio: ${error.message}`, error.stack);
            throw error;
        }
    }
    async sendMediaMessage(whatsappNumberId, from, to, body, mediaUrl) {
        try {
            const client = this.getClient(whatsappNumberId);
            const fromNumber = from.startsWith('whatsapp:') ? from : `whatsapp:${from}`;
            const toNumber = to.startsWith('whatsapp:') ? to : `whatsapp:${to}`;
            const message = await client.messages.create({
                from: fromNumber,
                to: toNumber,
                body,
                mediaUrl: [mediaUrl],
            });
            this.logger.log(`Mensaje con media enviado vía Twilio: ${message.sid}`);
            return {
                messageId: message.sid,
                metadata: {
                    status: message.status,
                    dateCreated: message.dateCreated,
                },
            };
        }
        catch (error) {
            this.logger.error(`Error enviando media Twilio: ${error.message}`, error.stack);
            throw error;
        }
    }
    async processWebhook(payload) {
        try {
            this.logger.log('Webhook de Twilio recibido');
            this.logger.debug(JSON.stringify(payload, null, 2));
            const { From: from, To: to, Body: body, MessageSid: messageSid, MediaUrl0: mediaUrl, NumMedia: numMedia, ProfileName: profileName, MessageStatus: messageStatus, SmsStatus: smsStatus, ButtonText: buttonText, ButtonPayload: buttonPayload, } = payload;
            const status = messageStatus || smsStatus;
            if (status && !body && !buttonText) {
                this.logger.log(`📊 Status update recibido: ${status} para mensaje ${messageSid}`);
                this.eventEmitter.emit('whatsapp.message.status', {
                    provider: 'twilio',
                    messageId: messageSid,
                    status: status,
                    errorCode: payload.ErrorCode,
                    errorMessage: payload.ErrorMessage,
                    timestamp: new Date(),
                });
                this.logger.log(`✅ Status update procesado: ${messageSid} -> ${status}`);
                return;
            }
            const messageContent = buttonText || body || '';
            if (!messageContent && (!numMedia || numMedia === '0')) {
                this.logger.warn(`⚠️ Webhook sin contenido de mensaje, ignorando`);
                return;
            }
            const contactPhone = from.replace('whatsapp:', '').replace('+', '');
            const whatsappNumberClean = to.replace('whatsapp:', '').replace('+', '');
            if (buttonText) {
                this.logger.log(`🔘 BOTÓN PRESIONADO - Texto: "${buttonText}", Payload: "${buttonPayload}"`);
            }
            this.logger.log(`📱 Mensaje entrante de: ${contactPhone}, Para: ${whatsappNumberClean}, Contenido: "${messageContent}"`);
            let localMediaUrl = null;
            let fileName = null;
            let mimeType = null;
            this.logger.log(`📊 Media check: NumMedia=${numMedia}, MediaUrl0=${mediaUrl || 'N/A'}`);
            if (numMedia && parseInt(numMedia) > 0 && mediaUrl) {
                try {
                    this.logger.log(`📎 Descargando media de Twilio: ${mediaUrl}`);
                    const downloadedMedia = await this.downloadTwilioMedia(mediaUrl, whatsappNumberClean, messageSid);
                    if (downloadedMedia) {
                        localMediaUrl = downloadedMedia.localUrl;
                        fileName = downloadedMedia.fileName;
                        mimeType = downloadedMedia.mimeType;
                        this.logger.log(`✅ Media descargado y guardado: ${fileName}, URL local: ${localMediaUrl}`);
                    }
                    else {
                        this.logger.warn(`⚠️ downloadTwilioMedia retornó null`);
                    }
                }
                catch (mediaError) {
                    this.logger.error(`❌ Error descargando media de Twilio: ${mediaError.message}`);
                }
            }
            this.eventEmitter.emit('whatsapp.message.received', {
                provider: 'twilio',
                from: contactPhone,
                content: messageContent || (localMediaUrl ? '[IMAGEN]' : ''),
                type: localMediaUrl ? 'image' : 'text',
                messageId: messageSid,
                timestamp: new Date(),
                sessionName: whatsappNumberClean,
                mediaUrl: localMediaUrl,
                fileName: fileName,
                mimeType: mimeType,
                isMedia: !!localMediaUrl,
                contactName: profileName || contactPhone,
                buttonText: buttonText || null,
                buttonPayload: buttonPayload || null,
                twilioData: {
                    whatsappNumber: whatsappNumberClean,
                    contactPhone,
                    numMedia,
                    buttonText,
                    buttonPayload,
                },
            });
            this.logger.log(`✅ Mensaje entrante procesado: ${messageSid}`);
        }
        catch (error) {
            this.logger.error(`Error procesando webhook Twilio: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getMessageStatus(whatsappNumberId, messageSid) {
        try {
            const client = this.getClient(whatsappNumberId);
            const message = await client.messages(messageSid).fetch();
            return {
                sid: message.sid,
                status: message.status,
                dateCreated: message.dateCreated,
                dateSent: message.dateSent,
                dateUpdated: message.dateUpdated,
                errorCode: message.errorCode,
                errorMessage: message.errorMessage,
            };
        }
        catch (error) {
            this.logger.error(`Error obteniendo estado de mensaje: ${error.message}`);
            throw error;
        }
    }
    async sendContentMessage(whatsappNumberId, from, to, contentSid, contentVariables) {
        try {
            const client = this.getClient(whatsappNumberId);
            const fromNumber = from.startsWith('whatsapp:') ? from : `whatsapp:${from}`;
            const toNumber = to.startsWith('whatsapp:') ? to : `whatsapp:${to}`;
            const messageParams = {
                from: fromNumber,
                to: toNumber,
                contentSid,
            };
            if (contentVariables && Object.keys(contentVariables).length > 0) {
                messageParams.contentVariables = JSON.stringify(contentVariables);
            }
            this.logger.log(`📤 Enviando Content Template: ${contentSid} a ${to}`);
            const message = await client.messages.create(messageParams);
            this.logger.log(`✅ Content Template enviado vía Twilio: ${message.sid}`);
            return {
                messageId: message.sid,
                metadata: {
                    status: message.status,
                    contentSid,
                    dateCreated: message.dateCreated,
                },
            };
        }
        catch (error) {
            this.logger.error(`❌ Error enviando Content Template: ${error.message}`, error.stack);
            throw error;
        }
    }
    removeClient(whatsappNumberId) {
        this.clients.delete(whatsappNumberId);
        this.credentials.delete(whatsappNumberId);
        this.logger.log(`Cliente Twilio removido: ${whatsappNumberId}`);
    }
    async downloadTwilioMedia(mediaUrl, whatsappNumber, messageSid) {
        try {
            let credentials;
            for (const [id, creds] of this.credentials.entries()) {
                credentials = creds;
                this.logger.log(`📋 Usando credenciales de: ${id}`);
                break;
            }
            if (!credentials) {
                this.logger.error(`❌ No hay credenciales de Twilio disponibles para descargar media. Total en cache: ${this.credentials.size}`);
                return null;
            }
            const uploadsDir = path.join(process.cwd(), 'uploads', 'media');
            if (!fs.existsSync(uploadsDir)) {
                fs.mkdirSync(uploadsDir, { recursive: true });
                this.logger.log(`📁 Directorio de uploads creado: ${uploadsDir}`);
            }
            this.logger.log(`📥 Descargando media de: ${mediaUrl}`);
            const response = await axios_1.default.get(mediaUrl, {
                auth: {
                    username: credentials.accountSid,
                    password: credentials.authToken,
                },
                responseType: 'arraybuffer',
            });
            const contentType = response.headers['content-type'] || 'application/octet-stream';
            const ext = this.getExtensionFromContentType(contentType);
            const fileName = `${Date.now()}_${messageSid.substring(0, 10)}.${ext}`;
            const filePath = path.join(uploadsDir, fileName);
            fs.writeFileSync(filePath, Buffer.from(response.data));
            this.logger.log(`✅ Media guardado: ${filePath}, Tipo: ${contentType}, Tamaño: ${response.data.length} bytes`);
            return {
                localUrl: `/uploads/media/${fileName}`,
                fileName,
                mimeType: contentType,
            };
        }
        catch (error) {
            this.logger.error(`❌ Error descargando media de Twilio: ${error.message}`, error.stack);
            return null;
        }
    }
    getExtensionFromContentType(contentType) {
        const mimeMap = {
            'image/jpeg': 'jpg',
            'image/jpg': 'jpg',
            'image/png': 'png',
            'image/gif': 'gif',
            'image/webp': 'webp',
            'audio/ogg': 'ogg',
            'audio/mpeg': 'mp3',
            'audio/mp4': 'm4a',
            'video/mp4': 'mp4',
            'application/pdf': 'pdf',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
        };
        return mimeMap[contentType] || 'bin';
    }
};
exports.TwilioService = TwilioService;
exports.TwilioService = TwilioService = TwilioService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [event_emitter_1.EventEmitter2])
], TwilioService);
//# sourceMappingURL=twilio.service.js.map