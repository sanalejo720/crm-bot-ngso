"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentPromisesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const payment_promises_service_1 = require("./payment-promises.service");
let PaymentPromisesController = class PaymentPromisesController {
    constructor(paymentPromisesService) {
        this.paymentPromisesService = paymentPromisesService;
    }
    async getUpcomingPromises(days = 7) {
        const promises = await this.paymentPromisesService.getUpcomingPromises(days);
        return {
            success: true,
            data: promises,
            total: promises.length,
        };
    }
    async getPromisesDueToday() {
        const promises = await this.paymentPromisesService.getPromisesDueToday();
        return {
            success: true,
            data: promises,
            total: promises.length,
        };
    }
    async getOverduePromises() {
        const promises = await this.paymentPromisesService.getOverduePromises();
        return {
            success: true,
            data: promises,
            total: promises.length,
        };
    }
    async sendReminder(clientId, reminderType) {
        const sent = await this.paymentPromisesService.sendPaymentReminder(clientId, reminderType);
        return {
            success: sent,
            message: sent
                ? 'Recordatorio enviado exitosamente'
                : 'No se pudo enviar el recordatorio',
        };
    }
    async markPromiseAsPaid(clientId, actualPaymentAmount) {
        const client = await this.paymentPromisesService.markPromiseAsPaid(clientId, actualPaymentAmount);
        return {
            success: true,
            data: client,
            message: 'Promesa marcada como pagada exitosamente',
        };
    }
    async triggerDailyReminders() {
        await this.paymentPromisesService.sendDailyReminders();
        return {
            success: true,
            message: 'Recordatorios diarios enviados',
        };
    }
};
exports.PaymentPromisesController = PaymentPromisesController;
__decorate([
    (0, common_1.Get)('upcoming'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener promesas próximas a vencer' }),
    (0, swagger_1.ApiQuery)({
        name: 'days',
        required: false,
        type: Number,
        description: 'Días hacia adelante (default: 7)',
    }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'read' }),
    __param(0, (0, common_1.Query)('days', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], PaymentPromisesController.prototype, "getUpcomingPromises", null);
__decorate([
    (0, common_1.Get)('due-today'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener promesas que vencen HOY' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PaymentPromisesController.prototype, "getPromisesDueToday", null);
__decorate([
    (0, common_1.Get)('overdue'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener promesas vencidas' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PaymentPromisesController.prototype, "getOverduePromises", null);
__decorate([
    (0, common_1.Post)(':clientId/send-reminder'),
    (0, swagger_1.ApiOperation)({ summary: 'Enviar recordatorio manual a un cliente' }),
    (0, swagger_1.ApiBody)({
        schema: {
            type: 'object',
            properties: {
                reminderType: {
                    type: 'string',
                    enum: ['upcoming', 'today', 'overdue'],
                    description: 'Tipo de recordatorio',
                },
            },
            required: ['reminderType'],
        },
    }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'update' }),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)('reminderType')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], PaymentPromisesController.prototype, "sendReminder", null);
__decorate([
    (0, common_1.Patch)(':clientId/mark-paid'),
    (0, swagger_1.ApiOperation)({ summary: 'Marcar promesa como pagada y mover a recuperado' }),
    (0, swagger_1.ApiBody)({
        schema: {
            type: 'object',
            properties: {
                actualPaymentAmount: {
                    type: 'number',
                    description: 'Monto real del pago (opcional)',
                },
            },
        },
    }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'update' }),
    __param(0, (0, common_1.Param)('clientId')),
    __param(1, (0, common_1.Body)('actualPaymentAmount')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number]),
    __metadata("design:returntype", Promise)
], PaymentPromisesController.prototype, "markPromiseAsPaid", null);
__decorate([
    (0, common_1.Post)('send-daily-reminders'),
    (0, swagger_1.ApiOperation)({
        summary: 'Ejecutar manualmente el envío de recordatorios diarios (solo admin)',
    }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'clients', action: 'update' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PaymentPromisesController.prototype, "triggerDailyReminders", null);
exports.PaymentPromisesController = PaymentPromisesController = __decorate([
    (0, swagger_1.ApiTags)('Payment Promises'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, common_1.Controller)('payment-promises'),
    __metadata("design:paramtypes", [payment_promises_service_1.PaymentPromisesService])
], PaymentPromisesController);
//# sourceMappingURL=payment-promises.controller.js.map