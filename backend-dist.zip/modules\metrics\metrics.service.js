"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var MetricsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MetricsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const chat_entity_1 = require("../chats/entities/chat.entity");
const message_entity_1 = require("../messages/entities/message.entity");
const user_entity_1 = require("../users/entities/user.entity");
const agent_session_entity_1 = require("../users/entities/agent-session.entity");
const campaign_entity_1 = require("../campaigns/entities/campaign.entity");
const client_entity_1 = require("../clients/entities/client.entity");
const payment_record_entity_1 = require("./entities/payment-record.entity");
let MetricsService = MetricsService_1 = class MetricsService {
    constructor(chatRepository, messageRepository, userRepository, sessionRepository, campaignRepository, clientRepository, paymentRecordRepository) {
        this.chatRepository = chatRepository;
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
        this.sessionRepository = sessionRepository;
        this.campaignRepository = campaignRepository;
        this.clientRepository = clientRepository;
        this.paymentRecordRepository = paymentRecordRepository;
        this.logger = new common_1.Logger(MetricsService_1.name);
    }
    async getAgentTMO(agentId, startDate, endDate) {
        const chats = await this.chatRepository
            .createQueryBuilder('chat')
            .where('chat.assignedAgentId = :agentId', { agentId })
            .andWhere('chat.status IN (:...statuses)', {
            statuses: ['closed', 'resolved']
        })
            .andWhere('chat.assignedAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .andWhere('chat.closedAt IS NOT NULL')
            .getMany();
        if (chats.length === 0) {
            return { tmoMinutes: 0, totalChats: 0 };
        }
        let totalMinutes = 0;
        for (const chat of chats) {
            if (chat.assignedAt && chat.closedAt) {
                const duration = (chat.closedAt.getTime() - chat.assignedAt.getTime()) / 60000;
                totalMinutes += duration;
            }
        }
        return {
            tmoMinutes: Math.round((totalMinutes / chats.length) * 100) / 100,
            totalChats: chats.length,
        };
    }
    async getAgentFRT(agentId, startDate, endDate) {
        const chats = await this.chatRepository
            .createQueryBuilder('chat')
            .where('chat.assignedAgentId = :agentId', { agentId })
            .andWhere('chat.assignedAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .andWhere('chat.firstResponseAt IS NOT NULL')
            .getMany();
        if (chats.length === 0) {
            return { frtSeconds: 0, totalChats: 0 };
        }
        let totalSeconds = 0;
        for (const chat of chats) {
            if (chat.assignedAt && chat.firstResponseAt) {
                const duration = (chat.firstResponseAt.getTime() - chat.assignedAt.getTime()) / 1000;
                totalSeconds += duration;
            }
        }
        return {
            frtSeconds: Math.round(totalSeconds / chats.length),
            totalChats: chats.length,
        };
    }
    async getAgentMetrics(agentId, startDate, endDate) {
        const agent = await this.userRepository.findOne({ where: { id: agentId } });
        if (!agent)
            throw new Error(`Agente ${agentId} no encontrado`);
        const [total, active, closed, resolved] = await Promise.all([
            this.chatRepository.count({
                where: {
                    assignedAgentId: agentId,
                    createdAt: (0, typeorm_2.Between)(startDate, endDate),
                },
            }),
            this.chatRepository.count({
                where: {
                    assignedAgentId: agentId,
                    status: chat_entity_1.ChatStatus.ACTIVE,
                    createdAt: (0, typeorm_2.Between)(startDate, endDate),
                },
            }),
            this.chatRepository.count({
                where: {
                    assignedAgentId: agentId,
                    status: chat_entity_1.ChatStatus.CLOSED,
                    createdAt: (0, typeorm_2.Between)(startDate, endDate),
                },
            }),
            this.chatRepository.count({
                where: {
                    assignedAgentId: agentId,
                    status: chat_entity_1.ChatStatus.RESOLVED,
                    createdAt: (0, typeorm_2.Between)(startDate, endDate),
                },
            }),
        ]);
        const chatIds = await this.chatRepository
            .createQueryBuilder('chat')
            .select('chat.id')
            .where('chat.assignedAgentId = :agentId', { agentId })
            .andWhere('chat.createdAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .getMany();
        const chatIdsList = chatIds.map(c => c.id);
        let sent = 0;
        let received = 0;
        if (chatIdsList.length > 0) {
            [sent, received] = await Promise.all([
                this.messageRepository.count({
                    where: {
                        chatId: chatIdsList.length > 0 ? chatIdsList[0] : undefined,
                        direction: message_entity_1.MessageDirection.OUTBOUND,
                        senderId: agentId,
                    },
                }),
                this.messageRepository.count({
                    where: {
                        chatId: chatIdsList.length > 0 ? chatIdsList[0] : undefined,
                        direction: message_entity_1.MessageDirection.INBOUND,
                    },
                }),
            ]);
        }
        const tmo = await this.getAgentTMO(agentId, startDate, endDate);
        const frt = await this.getAgentFRT(agentId, startDate, endDate);
        const avgMessagesPerChat = total > 0 ? Math.round((sent + received) / total) : 0;
        const closureRate = total > 0 ? ((closed + resolved) / total) * 100 : 0;
        const sessions = await this.sessionRepository.find({
            where: {
                userId: agentId,
                startedAt: (0, typeorm_2.Between)(startDate, endDate),
            },
        });
        const totalTimeSeconds = sessions.reduce((acc, s) => acc + (s.durationSeconds || 0), 0);
        const avgSessionDuration = sessions.length > 0
            ? Math.round(totalTimeSeconds / sessions.length)
            : 0;
        return {
            agentId,
            agentName: agent.fullName,
            period: { start: startDate, end: endDate },
            chats: { total, active, closed, resolved },
            messages: { sent, received },
            performance: {
                tmoMinutes: tmo.tmoMinutes,
                frtSeconds: frt.frtSeconds,
                avgMessagesPerChat,
                closureRate: Math.round(closureRate * 100) / 100,
            },
            session: {
                totalTimeHours: Math.round((totalTimeSeconds / 3600) * 100) / 100,
                avgSessionDuration,
                totalSessions: sessions.length,
            },
        };
    }
    async getCampaignMetrics(campaignId, startDate, endDate) {
        const campaign = await this.campaignRepository.findOne({
            where: { id: campaignId },
        });
        if (!campaign)
            throw new Error(`Campaña ${campaignId} no encontrada`);
        const [total, botOnly, transferred] = await Promise.all([
            this.chatRepository.count({
                where: {
                    campaignId,
                    createdAt: (0, typeorm_2.Between)(startDate, endDate),
                },
            }),
            this.chatRepository.count({
                where: {
                    campaignId,
                    assignedAgentId: null,
                    status: chat_entity_1.ChatStatus.CLOSED,
                    createdAt: (0, typeorm_2.Between)(startDate, endDate),
                },
            }),
            this.chatRepository.count({
                where: {
                    campaignId,
                    createdAt: (0, typeorm_2.Between)(startDate, endDate),
                },
            }),
        ]);
        const attended = await this.chatRepository.count({
            where: {
                campaignId,
                createdAt: (0, typeorm_2.Between)(startDate, endDate),
            },
        });
        const unattended = total - attended - botOnly;
        const currentInQueue = await this.chatRepository.count({
            where: {
                campaignId,
                status: chat_entity_1.ChatStatus.BOT,
                subStatus: 'bot_waiting_queue',
            },
        });
        const waitingChats = await this.chatRepository
            .createQueryBuilder('chat')
            .where('chat.campaignId = :campaignId', { campaignId })
            .andWhere('chat.assignedAt IS NOT NULL')
            .andWhere('chat.createdAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .getMany();
        let totalWaitTime = 0;
        let maxWaitTime = 0;
        for (const chat of waitingChats) {
            if (chat.assignedAt && chat.createdAt) {
                const waitTime = (chat.assignedAt.getTime() - chat.createdAt.getTime()) / 1000;
                totalWaitTime += waitTime;
                if (waitTime > maxWaitTime)
                    maxWaitTime = waitTime;
            }
        }
        const avgWaitTime = waitingChats.length > 0
            ? Math.round(totalWaitTime / waitingChats.length)
            : 0;
        const agents = await this.userRepository.find({
            where: {
                campaignId,
                isAgent: true,
            },
        });
        const available = agents.filter(a => a.agentState === 'available').length;
        const loadDistribution = [];
        for (const agent of agents) {
            const chatCount = await this.chatRepository.count({
                where: {
                    assignedAgentId: agent.id,
                    status: chat_entity_1.ChatStatus.ACTIVE,
                },
            });
            loadDistribution.push({
                agentId: agent.id,
                agentName: agent.fullName,
                chatCount,
            });
        }
        loadDistribution.sort((a, b) => b.chatCount - a.chatCount);
        return {
            campaignId,
            campaignName: campaign.name,
            period: { start: startDate, end: endDate },
            chats: {
                total,
                attended,
                unattended: unattended > 0 ? unattended : 0,
                botOnly,
                transferred,
            },
            queue: {
                avgWaitTimeSeconds: avgWaitTime,
                maxWaitTimeSeconds: Math.round(maxWaitTime),
                currentInQueue,
            },
            agents: {
                total: agents.length,
                available,
                loadDistribution,
            },
        };
    }
    async getBotMetrics(campaignId, startDate, endDate) {
        const query = this.chatRepository.createQueryBuilder('chat');
        query.where('chat.createdAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        });
        if (campaignId) {
            query.andWhere('chat.campaignId = :campaignId', { campaignId });
        }
        const allChats = await query.getMany();
        const totalChats = allChats.length;
        const resolvedByBot = allChats.filter(c => c.status === chat_entity_1.ChatStatus.CLOSED && !c.assignedAgentId).length;
        const transferredToAgent = allChats.filter(c => c.assignedAgentId !== null).length;
        const resolutionRate = totalChats > 0
            ? (resolvedByBot / totalChats) * 100
            : 0;
        const abandoned = allChats.filter(c => c.status === chat_entity_1.ChatStatus.BOT &&
            c.subStatus !== 'bot_waiting_queue' &&
            !c.assignedAgentId).length;
        const dropRate = totalChats > 0
            ? (abandoned / totalChats) * 100
            : 0;
        let totalBotTime = 0;
        let botInteractions = 0;
        for (const chat of allChats) {
            if (chat.botContext) {
                botInteractions += chat.botContext.interactionCount || 0;
            }
            if (chat.assignedAt && chat.createdAt) {
                totalBotTime += (chat.assignedAt.getTime() - chat.createdAt.getTime()) / 1000;
            }
        }
        const avgBotInteractions = totalChats > 0
            ? Math.round(botInteractions / totalChats)
            : 0;
        const avgTimeInBot = transferredToAgent > 0
            ? Math.round(totalBotTime / transferredToAgent)
            : 0;
        return {
            period: { start: startDate, end: endDate },
            resolution: {
                totalChats,
                resolvedByBot,
                transferredToAgent,
                resolutionRate: Math.round(resolutionRate * 100) / 100,
            },
            dropRate: {
                totalStarted: totalChats,
                abandoned,
                dropRate: Math.round(dropRate * 100) / 100,
            },
            performance: {
                avgBotInteractions,
                avgTimeInBotSeconds: avgTimeInBot,
            },
        };
    }
    async getSupervisorDashboard(campaignId, startDate, endDate) {
        const query = this.chatRepository.createQueryBuilder('chat');
        query.where('chat.createdAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        });
        if (campaignId) {
            query.andWhere('chat.campaignId = :campaignId', { campaignId });
        }
        const [totalChats, activeChats, closedChats, inQueueChats,] = await Promise.all([
            query.clone().getCount(),
            query.clone().andWhere('chat.status = :status', { status: 'active' }).getCount(),
            query.clone().andWhere('chat.status = :status', { status: 'closed' }).getCount(),
            query.clone()
                .andWhere('chat.status = :status', { status: 'bot' })
                .andWhere('chat.subStatus = :subStatus', { subStatus: 'bot_waiting_queue' })
                .getCount(),
        ]);
        const agentsQuery = this.userRepository
            .createQueryBuilder('user')
            .where('user.isAgent = :isAgent', { isAgent: true })
            .andWhere('user.status = :status', { status: 'active' });
        if (campaignId) {
            agentsQuery.andWhere('user.campaignId = :campaignId', { campaignId });
        }
        const agents = await agentsQuery.getMany();
        const availableAgents = agents.filter(a => a.agentState === 'available').length;
        const busyAgents = agents.filter(a => a.agentState === 'busy').length;
        const onBreakAgents = agents.filter(a => a.agentState === 'break').length;
        const botMetrics = await this.getBotMetrics(campaignId, startDate, endDate);
        return {
            summary: {
                totalChats,
                activeChats,
                closedChats,
                inQueueChats,
                closureRate: totalChats > 0
                    ? Math.round((closedChats / totalChats) * 100 * 100) / 100
                    : 0,
            },
            agents: {
                total: agents.length,
                available: availableAgents,
                busy: busyAgents,
                onBreak: onBreakAgents,
                offline: agents.length - availableAgents - busyAgents - onBreakAgents,
            },
            bot: {
                resolutionRate: botMetrics.resolution.resolutionRate,
                dropRate: botMetrics.dropRate.dropRate,
                transferRate: totalChats > 0
                    ? Math.round((botMetrics.resolution.transferredToAgent / totalChats) * 100 * 100) / 100
                    : 0,
            },
            period: {
                start: startDate,
                end: endDate,
            },
        };
    }
    async recordPayment(dto, recordedBy) {
        const client = await this.clientRepository.findOne({
            where: { id: dto.clientId },
        });
        if (!client) {
            throw new common_1.NotFoundException(`Cliente ${dto.clientId} no encontrado`);
        }
        const originalDebt = Number(client.originalDebtAmount || client.debtAmount || 0);
        const currentDebt = Number(client.debtAmount || 0);
        const paymentAmount = Number(dto.amount);
        const remainingDebt = Math.max(0, currentDebt - paymentAmount);
        const recoveryPercentage = originalDebt > 0
            ? (paymentAmount / originalDebt) * 100
            : 100;
        const paymentRecord = this.paymentRecordRepository.create({
            clientId: dto.clientId,
            agentId: dto.agentId || recordedBy,
            campaignId: dto.campaignId || client.campaignId,
            amount: paymentAmount,
            originalDebt,
            remainingDebt,
            recoveryPercentage: Math.min(recoveryPercentage, 100),
            paymentDate: new Date(dto.paymentDate),
            source: dto.source || payment_record_entity_1.PaymentSource.MANUAL,
            status: dto.status || payment_record_entity_1.PaymentStatus.CONFIRMED,
            referenceId: dto.referenceId,
            notes: dto.notes,
            metadata: {
                documentNumber: client.documentNumber,
            },
        });
        await this.paymentRecordRepository.save(paymentRecord);
        await this.clientRepository.update(dto.clientId, {
            debtAmount: remainingDebt,
            lastPaymentAmount: paymentAmount,
            lastPaymentDate: new Date(dto.paymentDate),
            collectionStatus: remainingDebt <= 0 ? 'paid' : 'partial',
        });
        this.logger.log(`💰 Pago registrado: ${paymentAmount} del cliente ${client.fullName} (${recoveryPercentage.toFixed(2)}% recuperado)`);
        return paymentRecord;
    }
    async getCollectionMetrics(filters) {
        const whereConditions = {
            status: payment_record_entity_1.PaymentStatus.CONFIRMED,
        };
        if (filters.startDate && filters.endDate) {
            whereConditions.paymentDate = (0, typeorm_2.Between)(new Date(filters.startDate), new Date(filters.endDate));
        }
        else if (filters.startDate) {
            whereConditions.paymentDate = (0, typeorm_2.MoreThanOrEqual)(new Date(filters.startDate));
        }
        else if (filters.endDate) {
            whereConditions.paymentDate = (0, typeorm_2.LessThanOrEqual)(new Date(filters.endDate));
        }
        if (filters.agentId) {
            whereConditions.agentId = filters.agentId;
        }
        if (filters.campaignId) {
            whereConditions.campaignId = filters.campaignId;
        }
        const payments = await this.paymentRecordRepository.find({
            where: whereConditions,
        });
        const totalCollected = payments.reduce((sum, p) => sum + Number(p.amount), 0);
        const totalDebtAssigned = payments.reduce((sum, p) => sum + Number(p.originalDebt), 0);
        const paymentsCount = payments.length;
        const averagePayment = paymentsCount > 0 ? totalCollected / paymentsCount : 0;
        const recoveryPercentage = totalDebtAssigned > 0
            ? (totalCollected / totalDebtAssigned) * 100
            : 0;
        return {
            totalCollected,
            totalDebtAssigned,
            recoveryPercentage,
            paymentsCount,
            averagePayment,
        };
    }
    async getAgentCollectionMetrics(filters) {
        const queryBuilder = this.paymentRecordRepository
            .createQueryBuilder('payment')
            .select('payment.agentId', 'agentId')
            .addSelect('SUM(payment.amount)', 'totalCollected')
            .addSelect('SUM(payment.originalDebt)', 'totalAssigned')
            .addSelect('COUNT(*)', 'paymentsCount')
            .leftJoin('users', 'agent', 'agent.id = payment.agentId')
            .addSelect('agent.fullName', 'agentName')
            .where('payment.status = :status', { status: payment_record_entity_1.PaymentStatus.CONFIRMED })
            .groupBy('payment.agentId')
            .addGroupBy('agent.fullName')
            .orderBy('SUM(payment.amount)', 'DESC');
        if (filters.startDate) {
            queryBuilder.andWhere('payment.paymentDate >= :startDate', {
                startDate: filters.startDate,
            });
        }
        if (filters.endDate) {
            queryBuilder.andWhere('payment.paymentDate <= :endDate', {
                endDate: filters.endDate,
            });
        }
        if (filters.campaignId) {
            queryBuilder.andWhere('payment.campaignId = :campaignId', {
                campaignId: filters.campaignId,
            });
        }
        const results = await queryBuilder.getRawMany();
        return results.map((r, index) => ({
            agentId: r.agentId,
            agentName: r.agentName || 'Sin asignar',
            totalCollected: Number(r.totalCollected) || 0,
            totalAssigned: Number(r.totalAssigned) || 0,
            recoveryPercentage: r.totalAssigned > 0
                ? (Number(r.totalCollected) / Number(r.totalAssigned)) * 100
                : 0,
            paymentsCount: Number(r.paymentsCount) || 0,
            ranking: index + 1,
        }));
    }
    async getCollectionTimeSeries(filters) {
        const groupBy = filters.groupBy || 'day';
        let dateFormat;
        switch (groupBy) {
            case 'week':
                dateFormat = "TO_CHAR(payment.paymentDate, 'IYYY-IW')";
                break;
            case 'month':
                dateFormat = "TO_CHAR(payment.paymentDate, 'YYYY-MM')";
                break;
            default:
                dateFormat = "TO_CHAR(payment.paymentDate, 'YYYY-MM-DD')";
        }
        const queryBuilder = this.paymentRecordRepository
            .createQueryBuilder('payment')
            .select(dateFormat, 'date')
            .addSelect('SUM(payment.amount)', 'totalCollected')
            .addSelect('SUM(payment.originalDebt)', 'totalAssigned')
            .addSelect('COUNT(*)', 'paymentsCount')
            .where('payment.status = :status', { status: payment_record_entity_1.PaymentStatus.CONFIRMED })
            .groupBy(dateFormat)
            .orderBy(dateFormat, 'ASC');
        if (filters.startDate) {
            queryBuilder.andWhere('payment.paymentDate >= :startDate', {
                startDate: filters.startDate,
            });
        }
        if (filters.endDate) {
            queryBuilder.andWhere('payment.paymentDate <= :endDate', {
                endDate: filters.endDate,
            });
        }
        if (filters.agentId) {
            queryBuilder.andWhere('payment.agentId = :agentId', {
                agentId: filters.agentId,
            });
        }
        if (filters.campaignId) {
            queryBuilder.andWhere('payment.campaignId = :campaignId', {
                campaignId: filters.campaignId,
            });
        }
        const results = await queryBuilder.getRawMany();
        return results.map((r) => ({
            date: r.date,
            totalCollected: Number(r.totalCollected) || 0,
            paymentsCount: Number(r.paymentsCount) || 0,
            recoveryPercentage: r.totalAssigned > 0
                ? (Number(r.totalCollected) / Number(r.totalAssigned)) * 100
                : 0,
        }));
    }
    async getPortfolioSummary(campaignId) {
        const clientQuery = this.clientRepository.createQueryBuilder('client');
        if (campaignId) {
            clientQuery.where('client.campaignId = :campaignId', { campaignId });
        }
        const clients = await clientQuery.getMany();
        const totalPortfolio = clients.reduce((sum, c) => sum + Number(c.originalDebtAmount || c.debtAmount || 0), 0);
        const totalPending = clients.reduce((sum, c) => sum + Number(c.debtAmount || 0), 0);
        const totalCollected = totalPortfolio - totalPending;
        const paidClients = clients.filter(c => c.collectionStatus === 'paid').length;
        const pendingClients = clients.filter(c => c.collectionStatus !== 'paid').length;
        return {
            totalPortfolio,
            totalCollected,
            totalPending,
            recoveryPercentage: totalPortfolio > 0 ? (totalCollected / totalPortfolio) * 100 : 0,
            clientsCount: clients.length,
            paidClients,
            pendingClients,
        };
    }
};
exports.MetricsService = MetricsService;
exports.MetricsService = MetricsService = MetricsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __param(1, (0, typeorm_1.InjectRepository)(message_entity_1.Message)),
    __param(2, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __param(3, (0, typeorm_1.InjectRepository)(agent_session_entity_1.AgentSession)),
    __param(4, (0, typeorm_1.InjectRepository)(campaign_entity_1.Campaign)),
    __param(5, (0, typeorm_1.InjectRepository)(client_entity_1.Client)),
    __param(6, (0, typeorm_1.InjectRepository)(payment_record_entity_1.PaymentRecord)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], MetricsService);
//# sourceMappingURL=metrics.service.js.map