import { Repository } from 'typeorm';
import { BotFlow } from './entities/bot-flow.entity';
import { BotNode } from './entities/bot-node.entity';
import { MessagesService } from '../messages/messages.service';
import { ChatsService } from '../chats/chats.service';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { DebtorsService } from '../debtors/debtors.service';
export interface BotSession {
    chatId: string;
    flowId: string;
    currentNodeId: string;
    variables: Record<string, any>;
    createdAt: Date;
    lastActivityAt: Date;
}
export declare class BotEngineService {
    private botFlowRepository;
    private botNodeRepository;
    private messagesService;
    private chatsService;
    private whatsappService;
    private debtorsService;
    private readonly logger;
    private sessions;
    constructor(botFlowRepository: Repository<BotFlow>, botNodeRepository: Repository<BotNode>, messagesService: MessagesService, chatsService: ChatsService, whatsappService: WhatsappService, debtorsService: DebtorsService);
    startFlow(chatId: string, flowId: string): Promise<void>;
    processUserInput(chatId: string, userInput: string): Promise<void>;
    private executeNode;
    private executeMessageNode;
    private executeMenuNode;
    private executeInputNode;
    private executeConditionNode;
    private executeApiCallNode;
    private executeTransferNode;
    private executeEndNode;
    private handleMenuInput;
    private handleTextInput;
    private handleCondition;
    private initializeVariables;
    private replaceVariables;
    hasActiveSession(chatId: string): boolean;
    cleanInactiveSessions(maxInactivityMinutes?: number): void;
}
