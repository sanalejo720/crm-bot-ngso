import { Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { Backup } from './entities/backup.entity';
import { CreateBackupDto } from './dto/backup.dto';
import { EmailService } from '../../common/services/email.service';
import { User } from '../users/entities/user.entity';
export declare class BackupsService {
    private backupRepo;
    private userRepo;
    private configService;
    private emailService;
    private readonly logger;
    private readonly backupsPath;
    constructor(backupRepo: Repository<Backup>, userRepo: Repository<User>, configService: ConfigService, emailService: EmailService);
    createBackup(createBackupDto: CreateBackupDto, userId?: string): Promise<Backup>;
    private executeBackup;
    private createDatabaseDump;
    private createZipArchive;
    private encryptFile;
    private decryptFile;
    private generateMasterPassword;
    private getDirectorySize;
    private calculateCompressionRatio;
    private updateBackupStatus;
    findAll(): Promise<Backup[]>;
    findOne(id: string): Promise<Backup>;
    downloadBackup(id: string, password: string): Promise<{
        buffer: Buffer;
        fileName: string;
    }>;
    remove(id: string): Promise<void>;
    handleDailyBackup(): Promise<void>;
}
