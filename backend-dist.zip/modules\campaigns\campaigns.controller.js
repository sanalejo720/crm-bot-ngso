"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampaignsController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const campaigns_service_1 = require("./campaigns.service");
const create_campaign_dto_1 = require("./dto/create-campaign.dto");
const update_campaign_dto_1 = require("./dto/update-campaign.dto");
const create_mass_campaign_dto_1 = require("./dto/create-mass-campaign.dto");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const campaign_entity_1 = require("./entities/campaign.entity");
const csv_parser_1 = __importDefault(require("csv-parser"));
const stream_1 = require("stream");
let CampaignsController = class CampaignsController {
    constructor(campaignsService) {
        this.campaignsService = campaignsService;
    }
    create(createCampaignDto, user) {
        return this.campaignsService.create(createCampaignDto, user.sub);
    }
    findAll(status, search) {
        return this.campaignsService.findAll({ status, search });
    }
    findActive() {
        return this.campaignsService.findActive();
    }
    async getMyCampaigns(userId) {
        return this.campaignsService.getUserCampaigns(userId);
    }
    findOne(id) {
        return this.campaignsService.findOne(id);
    }
    getStats(id) {
        return this.campaignsService.getStats(id);
    }
    getWhatsappNumbers(id) {
        return this.campaignsService.getWhatsappNumbers(id);
    }
    update(id, updateCampaignDto) {
        return this.campaignsService.update(id, updateCampaignDto);
    }
    updateStatus(id, body) {
        return this.campaignsService.updateStatus(id, body.status);
    }
    updateSettings(id, body) {
        return this.campaignsService.updateSettings(id, body.settings);
    }
    activate(id) {
        return this.campaignsService.activate(id);
    }
    pause(id) {
        return this.campaignsService.pause(id);
    }
    duplicate(id, body, user) {
        return this.campaignsService.duplicate(id, body.name, user.sub);
    }
    remove(id) {
        return this.campaignsService.remove(id);
    }
    async sendMassCampaign(createMassCampaignDto, req) {
        const userRole = req.user?.role?.name;
        if (userRole !== 'Administrador' && userRole !== 'Super Admin') {
            throw new common_1.BadRequestException('Solo administradores pueden enviar campañas masivas');
        }
        return this.campaignsService.sendMassCampaign(createMassCampaignDto, req.user.userId);
    }
    async validateCsv(file) {
        if (!file) {
            throw new common_1.BadRequestException('No se proporcionó archivo CSV');
        }
        try {
            const csvData = await this.parseCsv(file.buffer);
            const validation = await this.campaignsService.validateCsvData(csvData);
            return {
                valid: validation.valid,
                errors: validation.errors,
                recipientCount: validation.recipients.length,
                preview: validation.recipients.slice(0, 5),
            };
        }
        catch (error) {
            throw new common_1.BadRequestException(`Error al procesar CSV: ${error.message}`);
        }
    }
    async uploadAndSend(file, campaignName, templateSid, description, messageDelay, batchSize, req) {
        if (!file) {
            throw new common_1.BadRequestException('No se proporcionó archivo CSV');
        }
        if (!campaignName || !templateSid) {
            throw new common_1.BadRequestException('Nombre de campaña y template son requeridos');
        }
        try {
            const csvData = await this.parseCsv(file.buffer);
            const validation = await this.campaignsService.validateCsvData(csvData);
            if (!validation.valid) {
                return {
                    success: false,
                    errors: validation.errors,
                };
            }
            const result = await this.campaignsService.sendMassCampaign({
                name: campaignName,
                templateSid,
                recipients: validation.recipients,
                description,
                messageDelay: messageDelay ? parseInt(messageDelay) : 1000,
                batchSize: batchSize ? parseInt(batchSize) : 10,
            }, req.user.userId);
            return {
                success: true,
                ...result,
            };
        }
        catch (error) {
            throw new common_1.BadRequestException(`Error al procesar campaña: ${error.message}`);
        }
    }
    parseCsv(buffer) {
        return new Promise((resolve, reject) => {
            const results = [];
            const stream = stream_1.Readable.from(buffer.toString());
            stream
                .pipe((0, csv_parser_1.default)())
                .on('data', (data) => results.push(data))
                .on('end', () => resolve(results))
                .on('error', (error) => reject(error));
        });
    }
};
exports.CampaignsController = CampaignsController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Crear nueva campaña' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_campaign_dto_1.CreateCampaignDto, Object]),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener todas las campañas' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'read' }),
    __param(0, (0, common_1.Query)('status')),
    __param(1, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('active'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener campañas activas' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "findActive", null);
__decorate([
    (0, common_1.Get)('my-campaigns'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener campañas asignadas al usuario actual (para agentes)' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CampaignsController.prototype, "getMyCampaigns", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener campaña por ID' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Get)(':id/stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas de campaña' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)(':id/whatsapp-numbers'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener números WhatsApp de campaña' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "getWhatsappNumbers", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Actualizar campaña' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_campaign_dto_1.UpdateCampaignDto]),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "update", null);
__decorate([
    (0, common_1.Patch)(':id/status'),
    (0, swagger_1.ApiOperation)({ summary: 'Cambiar estado de campaña' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Patch)(':id/settings'),
    (0, swagger_1.ApiOperation)({ summary: 'Actualizar configuración de campaña' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "updateSettings", null);
__decorate([
    (0, common_1.Post)(':id/activate'),
    (0, swagger_1.ApiOperation)({ summary: 'Activar campaña' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "activate", null);
__decorate([
    (0, common_1.Post)(':id/pause'),
    (0, swagger_1.ApiOperation)({ summary: 'Pausar campaña' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "pause", null);
__decorate([
    (0, common_1.Post)(':id/duplicate'),
    (0, swagger_1.ApiOperation)({ summary: 'Duplicar campaña' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'create' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "duplicate", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Eliminar campaña (soft delete)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'delete' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], CampaignsController.prototype, "remove", null);
__decorate([
    (0, common_1.Post)('mass/send'),
    (0, swagger_1.ApiOperation)({ summary: 'Enviar campaña masiva de WhatsApp' }),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_mass_campaign_dto_1.CreateMassCampaignDto, Object]),
    __metadata("design:returntype", Promise)
], CampaignsController.prototype, "sendMassCampaign", null);
__decorate([
    (0, common_1.Post)('mass/validate-csv'),
    (0, swagger_1.ApiOperation)({ summary: 'Validar archivo CSV para envío masivo' }),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'create' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], CampaignsController.prototype, "validateCsv", null);
__decorate([
    (0, common_1.Post)('mass/upload-and-send'),
    (0, swagger_1.ApiOperation)({ summary: 'Subir CSV y enviar campaña masiva' }),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'campaigns', action: 'create' }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)('campaignName')),
    __param(2, (0, common_1.Body)('templateSid')),
    __param(3, (0, common_1.Body)('description')),
    __param(4, (0, common_1.Body)('messageDelay')),
    __param(5, (0, common_1.Body)('batchSize')),
    __param(6, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String, String, String, String, Object]),
    __metadata("design:returntype", Promise)
], CampaignsController.prototype, "uploadAndSend", null);
exports.CampaignsController = CampaignsController = __decorate([
    (0, swagger_1.ApiTags)('campaigns'),
    (0, common_1.Controller)('campaigns'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [campaigns_service_1.CampaignsService])
], CampaignsController);
//# sourceMappingURL=campaigns.controller.js.map