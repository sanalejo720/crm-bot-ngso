import { Repository } from 'typeorm';
import { Campaign, CampaignStatus } from './entities/campaign.entity';
import { PendingAgentAssignment } from './entities/pending-agent-assignment.entity';
import { CreateCampaignDto } from './dto/create-campaign.dto';
import { UpdateCampaignDto } from './dto/update-campaign.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { UserCampaign } from '../users/entities/user-campaign.entity';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { CreateMassCampaignDto } from './dto/create-mass-campaign.dto';
export declare class CampaignsService {
    private campaignRepository;
    private userCampaignRepository;
    private pendingAssignmentRepository;
    private eventEmitter;
    private readonly whatsappService;
    private readonly logger;
    constructor(campaignRepository: Repository<Campaign>, userCampaignRepository: Repository<UserCampaign>, pendingAssignmentRepository: Repository<PendingAgentAssignment>, eventEmitter: EventEmitter2, whatsappService: WhatsappService);
    create(createCampaignDto: CreateCampaignDto, createdBy: string): Promise<Campaign>;
    findAll(filters?: {
        status?: CampaignStatus;
        search?: string;
    }): Promise<Campaign[]>;
    findActive(): Promise<Campaign[]>;
    findOne(id: string): Promise<Campaign>;
    update(id: string, updateCampaignDto: UpdateCampaignDto): Promise<Campaign>;
    updateStatus(id: string, status: CampaignStatus): Promise<Campaign>;
    updateSettings(id: string, settings: Record<string, any>): Promise<Campaign>;
    activate(id: string): Promise<Campaign>;
    pause(id: string): Promise<Campaign>;
    remove(id: string): Promise<void>;
    getStats(id: string): Promise<{
        id: string;
        name: string;
        status: CampaignStatus;
        totalChats: number;
        chatsByStatus: any;
        totalDebtors: number;
        debtorsByStatus: any;
    }>;
    getWhatsappNumbers(id: string): Promise<import("../whatsapp/entities/whatsapp-number.entity").WhatsappNumber[]>;
    duplicate(id: string, newName: string, createdBy: string): Promise<Campaign>;
    getUserCampaigns(userId: string): Promise<Campaign[]>;
    sendMassCampaign(dto: CreateMassCampaignDto, userId: number): Promise<{
        startedBy: number;
        completedAt: Date;
        total: number;
        sent: number;
        failed: number;
        errors: Array<{
            phone: string;
            error: string;
        }>;
        campaignName: string;
        templateSid: string;
        success: boolean;
    }>;
    validateCsvData(csvData: any[]): Promise<{
        valid: boolean;
        errors: string[];
        recipients: Array<{
            phone: string;
            variables: Record<string, string>;
        }>;
    }>;
    findPendingAssignment(phone: string): Promise<string | null>;
    markAssignmentAsCompleted(phone: string, agentEmail: string): Promise<void>;
}
