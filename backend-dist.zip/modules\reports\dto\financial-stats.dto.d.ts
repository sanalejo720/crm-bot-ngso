export declare class CampaignFinancialsDto {
    campaignId: string;
    campaignName: string;
    totalToRecover: number;
    totalRecovered: number;
    totalInPromises: number;
    recoveryPercentage: number;
    paymentsCount: number;
    promisesCount: number;
    clientsWithDebt: number;
    clientsPaid: number;
    trend?: 'up' | 'down' | 'stable';
}
export declare class AgentRecaudoDto {
    agentId: string;
    agentName: string;
    totalRecovered: number;
    paymentsCount: number;
    promisesCount: number;
    totalInPromises: number;
    effectivenessRate: number;
    averageTicket: number;
    clientsAttended: number;
    ranking?: number;
}
export declare class FinancialSummaryDto {
    period: string;
    totalToRecover: number;
    totalRecovered: number;
    totalInPromises: number;
    globalRecoveryRate: number;
    campaignsStats: CampaignFinancialsDto[];
    topAgents: AgentRecaudoDto[];
}
export declare class DailyFinancialsDto {
    date: string;
    totalRecovered: number;
    paymentsCount: number;
    promisesCount: number;
}
export declare class FinancialTrendDto {
    dates: string[];
    recovered: number[];
    promises: number[];
}
