"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientsModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const clients_service_1 = require("./clients.service");
const clients_controller_1 = require("./clients.controller");
const payment_promises_controller_1 = require("./payment-promises.controller");
const payment_promises_service_1 = require("./payment-promises.service");
const paz_y_salvo_controller_1 = require("./paz-y-salvo.controller");
const paz_y_salvo_service_1 = require("./paz-y-salvo.service");
const client_identification_service_1 = require("./client-identification.service");
const client_entity_1 = require("./entities/client.entity");
const client_phone_number_entity_1 = require("./entities/client-phone-number.entity");
const paz_y_salvo_entity_1 = require("./entities/paz-y-salvo.entity");
const chat_entity_1 = require("../chats/entities/chat.entity");
const whatsapp_module_1 = require("../whatsapp/whatsapp.module");
const payment_record_entity_1 = require("../metrics/entities/payment-record.entity");
let ClientsModule = class ClientsModule {
};
exports.ClientsModule = ClientsModule;
exports.ClientsModule = ClientsModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([client_entity_1.Client, client_phone_number_entity_1.ClientPhoneNumber, paz_y_salvo_entity_1.PazYSalvo, chat_entity_1.Chat, payment_record_entity_1.PaymentRecord]),
            (0, common_1.forwardRef)(() => whatsapp_module_1.WhatsappModule),
        ],
        controllers: [clients_controller_1.ClientsController, payment_promises_controller_1.PaymentPromisesController, paz_y_salvo_controller_1.PazYSalvoController],
        providers: [
            clients_service_1.ClientsService,
            payment_promises_service_1.PaymentPromisesService,
            client_identification_service_1.ClientIdentificationService,
            paz_y_salvo_service_1.PazYSalvoService,
        ],
        exports: [
            clients_service_1.ClientsService,
            payment_promises_service_1.PaymentPromisesService,
            client_identification_service_1.ClientIdentificationService,
            paz_y_salvo_service_1.PazYSalvoService,
        ],
    })
], ClientsModule);
//# sourceMappingURL=clients.module.js.map