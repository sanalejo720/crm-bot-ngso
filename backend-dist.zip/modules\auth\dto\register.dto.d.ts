export declare class RegisterDto {
    fullName: string;
    email: string;
    password: string;
}
