import { Repository } from 'typeorm';
import { Chat } from './entities/chat.entity';
import { Message } from '../messages/entities/message.entity';
import { User } from '../users/entities/user.entity';
import { EmailService } from '../../common/services/email.service';
import { ChatsService } from './chats.service';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { EvidencesService } from '../evidences/evidences.service';
export declare class ChatsExportService {
    private chatRepository;
    private messageRepository;
    private userRepository;
    private emailService;
    private chatsService;
    private whatsappService;
    private evidencesService;
    private readonly logger;
    constructor(chatRepository: Repository<Chat>, messageRepository: Repository<Message>, userRepository: Repository<User>, emailService: EmailService, chatsService: ChatsService, whatsappService: WhatsappService, evidencesService: EvidencesService);
    private sanitizeText;
    handleChatClosed(chat: Chat): Promise<void>;
    exportChatToPDF(chatId: string, closureType: 'paid' | 'promise', agentId: string): Promise<{
        filePath: string;
        fileName: string;
        ticketNumber: string;
    }>;
    private createPDF;
    private translateStatus;
    private getSenderName;
    private sendNotificationEmail;
    private isValidPhoneNumber;
    private generateFarewellMessage;
    generateAutomaticClosurePDF(chatId: string, agentId: string): Promise<void>;
    handleChatUnassigned(payload: {
        chat: Chat;
        previousAgentId: string;
        reason: string;
    }): Promise<void>;
}
