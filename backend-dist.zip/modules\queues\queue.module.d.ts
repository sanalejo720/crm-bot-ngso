export declare class QueueModule {
}
