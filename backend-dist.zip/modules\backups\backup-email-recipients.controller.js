"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BackupEmailRecipientsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const backup_email_recipients_service_1 = require("./backup-email-recipients.service");
const backup_email_recipient_dto_1 = require("./dto/backup-email-recipient.dto");
let BackupEmailRecipientsController = class BackupEmailRecipientsController {
    constructor(recipientsService) {
        this.recipientsService = recipientsService;
    }
    async findAll() {
        const recipients = await this.recipientsService.findAll();
        return {
            success: true,
            data: recipients.map(r => ({
                id: r.id,
                email: r.email,
                name: r.name,
                isActive: r.isActive,
                createdAt: r.createdAt,
                addedBy: r.addedBy ? {
                    id: r.addedBy.id,
                    name: r.addedBy.fullName,
                } : null,
            })),
        };
    }
    async create(dto, user) {
        const recipient = await this.recipientsService.create(dto, user.id);
        return {
            success: true,
            message: 'Destinatario agregado exitosamente',
            data: {
                id: recipient.id,
                email: recipient.email,
                name: recipient.name,
                isActive: recipient.isActive,
                createdAt: recipient.createdAt,
            },
        };
    }
    async update(id, dto) {
        const recipient = await this.recipientsService.update(id, dto);
        return {
            success: true,
            message: 'Destinatario actualizado exitosamente',
            data: {
                id: recipient.id,
                email: recipient.email,
                name: recipient.name,
                isActive: recipient.isActive,
                updatedAt: recipient.updatedAt,
            },
        };
    }
    async remove(id) {
        await this.recipientsService.remove(id);
        return {
            success: true,
            message: 'Destinatario eliminado correctamente',
        };
    }
};
exports.BackupEmailRecipientsController = BackupEmailRecipientsController;
__decorate([
    (0, common_1.Get)(),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'backups', action: 'read' }),
    (0, swagger_1.ApiOperation)({
        summary: 'Listar todos los destinatarios de email de backup',
        description: 'Obtiene la lista de correos electrónicos que reciben las contraseñas de backup'
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Lista de destinatarios' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BackupEmailRecipientsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Post)(),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'backups', action: 'create' }),
    (0, swagger_1.ApiOperation)({
        summary: 'Agregar nuevo destinatario de email de backup',
        description: 'Agrega un nuevo correo electrónico para recibir las contraseñas de backup'
    }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'Destinatario agregado exitosamente' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [backup_email_recipient_dto_1.CreateBackupEmailRecipientDto, Object]),
    __metadata("design:returntype", Promise)
], BackupEmailRecipientsController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'backups', action: 'update' }),
    (0, swagger_1.ApiOperation)({
        summary: 'Actualizar destinatario de email de backup',
        description: 'Modifica el correo electrónico o estado de un destinatario'
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Destinatario actualizado exitosamente' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, backup_email_recipient_dto_1.UpdateBackupEmailRecipientDto]),
    __metadata("design:returntype", Promise)
], BackupEmailRecipientsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'backups', action: 'delete' }),
    (0, swagger_1.ApiOperation)({
        summary: 'Eliminar destinatario de email de backup',
        description: 'Elimina un correo electrónico de la lista de destinatarios'
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Destinatario eliminado exitosamente' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BackupEmailRecipientsController.prototype, "remove", null);
exports.BackupEmailRecipientsController = BackupEmailRecipientsController = __decorate([
    (0, swagger_1.ApiTags)('backup-email-recipients'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, common_1.Controller)('backups/email-recipients'),
    __metadata("design:paramtypes", [backup_email_recipients_service_1.BackupEmailRecipientsService])
], BackupEmailRecipientsController);
//# sourceMappingURL=backup-email-recipients.controller.js.map