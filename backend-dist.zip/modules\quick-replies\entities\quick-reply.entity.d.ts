import { User } from '../../users/entities/user.entity';
import { Campaign } from '../../campaigns/entities/campaign.entity';
export declare class QuickReply {
    id: string;
    userId: string;
    campaignId: string;
    shortcut: string;
    title: string;
    content: string;
    variables: string[];
    category: string;
    isActive: boolean;
    usageCount: number;
    createdAt: Date;
    updatedAt: Date;
    createdBy: string;
    user: User;
    campaign: Campaign;
}
