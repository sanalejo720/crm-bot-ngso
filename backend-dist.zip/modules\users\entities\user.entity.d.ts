import { Role } from '../../roles/entities/role.entity';
import { Campaign } from '../../campaigns/entities/campaign.entity';
import { Chat } from '../../chats/entities/chat.entity';
import { Message } from '../../messages/entities/message.entity';
export declare enum UserStatus {
    ACTIVE = "active",
    INACTIVE = "inactive",
    SUSPENDED = "suspended"
}
export declare enum AgentState {
    AVAILABLE = "available",
    BUSY = "busy",
    BREAK = "break",
    OFFLINE = "offline"
}
export declare class User {
    id: string;
    fullName: string;
    email: string;
    password: string;
    phone: string;
    avatar: string;
    status: UserStatus;
    isAgent: boolean;
    agentState: AgentState;
    maxConcurrentChats: number;
    currentChatsCount: number;
    skills: string[];
    twoFactorSecret: string;
    twoFactorEnabled: boolean;
    refreshToken: string;
    lastLoginAt: Date;
    lastActivityAt: Date;
    role: Role;
    roleId: string;
    campaign: Campaign;
    campaignId: string;
    assignedChats: Chat[];
    sentMessages: Message[];
    createdAt: Date;
    updatedAt: Date;
}
