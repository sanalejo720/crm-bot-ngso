export declare class EvidencesModule {
}
