"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeWhatsAppPhone = normalizeWhatsAppPhone;
exports.formatPhoneForDisplay = formatPhoneForDisplay;
exports.extractPhoneDigits = extractPhoneDigits;
function normalizeWhatsAppPhone(phone) {
    if (!phone)
        return '';
    if (phone.includes('@lid')) {
        return phone.trim();
    }
    let normalized = phone.replace(/@c\.us|@g\.us|@s\.whatsapp\.net/gi, '');
    normalized = normalized.replace(/[\s\-\(\)]/g, '');
    normalized = normalized.replace(/[^\d+]/g, '');
    return normalized;
}
function formatPhoneForDisplay(phone) {
    if (!phone)
        return '';
    const normalized = normalizeWhatsAppPhone(phone);
    if (normalized.startsWith('57') && normalized.length === 12) {
        const country = normalized.substring(0, 2);
        const area = normalized.substring(2, 5);
        const part1 = normalized.substring(5, 8);
        const part2 = normalized.substring(8, 12);
        return `+${country} ${area} ${part1} ${part2}`;
    }
    if (!normalized.startsWith('+') && normalized.length > 10) {
        return `+${normalized}`;
    }
    return normalized;
}
function extractPhoneDigits(phone) {
    if (!phone)
        return '';
    return phone.replace(/\D/g, '');
}
//# sourceMappingURL=phone.utils.js.map