import { Repository } from 'typeorm';
import { WhatsappNumber } from './entities/whatsapp-number.entity';
import { WhatsappNumberCampaign } from './entities/whatsapp-number-campaign.entity';
import { CreateWhatsappNumberDto } from './dto/create-whatsapp-number.dto';
import { UpdateWhatsappNumberDto } from './dto/update-whatsapp-number.dto';
import { WppConnectService } from './providers/wppconnect.service';
import { MetaService } from './providers/meta.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ActiveSessionsDto, SessionStatsDto } from './dto/session-stats.dto';
export declare class WhatsappNumbersService {
    private whatsappNumberRepository;
    private whatsappNumberCampaignRepository;
    private wppConnectService;
    private metaService;
    private eventEmitter;
    private readonly MAX_ACTIVE_SESSIONS;
    private sessionStats;
    constructor(whatsappNumberRepository: Repository<WhatsappNumber>, whatsappNumberCampaignRepository: Repository<WhatsappNumberCampaign>, wppConnectService: WppConnectService, metaService: MetaService, eventEmitter: EventEmitter2);
    handleSessionStatusChange(data: {
        sessionName: string;
        status: string;
    }): Promise<void>;
    create(createDto: CreateWhatsappNumberDto): Promise<WhatsappNumber>;
    findAll(): Promise<WhatsappNumber[]>;
    findAllActive(): Promise<WhatsappNumber[]>;
    findOne(id: string): Promise<WhatsappNumber>;
    update(id: string, updateDto: UpdateWhatsappNumberDto): Promise<WhatsappNumber>;
    remove(id: string): Promise<void>;
    startWppConnectSession(id: string): Promise<any>;
    getWppConnectStatus(id: string): Promise<any>;
    disconnectWppConnect(id: string): Promise<any>;
    configureMeta(id: string, config: {
        accessToken: string;
        phoneNumberId: string;
        businessAccountId: string;
    }): Promise<WhatsappNumber>;
    verifyMetaConnection(id: string): Promise<any>;
    assignToCampaign(id: string, campaignId: string): Promise<WhatsappNumber>;
    assignToCampaigns(id: string, campaignIds: string[]): Promise<WhatsappNumber>;
    findByCampaign(campaignId: string): Promise<WhatsappNumber[]>;
    getActiveSessions(): Promise<ActiveSessionsDto>;
    forceCloseSession(id: string): Promise<any>;
    closeAllSessions(): Promise<any>;
    canCreateNewSession(): Promise<{
        allowed: boolean;
        message?: string;
    }>;
    updateSessionStats(numberId: string, updates: Partial<SessionStatsDto>): void;
    incrementMessageCount(numberId: string, direction: 'sent' | 'received'): void;
    incrementAlertCount(numberId: string): void;
    cleanupZombieProcesses(id: string): Promise<{
        message: string;
        success: boolean;
    }>;
}
