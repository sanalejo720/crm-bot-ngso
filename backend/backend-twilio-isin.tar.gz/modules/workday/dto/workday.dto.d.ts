import { PauseType } from '../entities/agent-pause.entity';
export declare class ClockInDto {
    notes?: string;
}
export declare class ClockOutDto {
    notes?: string;
}
export declare class StartPauseDto {
    pauseType: PauseType;
    reason?: string;
}
export declare class EndPauseDto {
    pauseId: string;
}
export declare class GetWorkdayStatsDto {
    startDate?: string;
    endDate?: string;
    agentId?: string;
}
