import { MonitoringService } from './monitoring.service';
export declare class MonitoringController {
    private readonly monitoringService;
    constructor(monitoringService: MonitoringService);
    getNumbersRanking(limit: number, days: number): Promise<any[]>;
    getNumberStats(numberId: string, days: number): Promise<any>;
    getRecentAlerts(limit: number): Promise<any[]>;
    getOffensiveWords(): any;
    addOffensiveWord(body: {
        word: string;
        category: 'abuse' | 'threat' | 'discrimination' | 'profanity';
        severity: 'low' | 'medium' | 'high' | 'critical';
        target: 'agent' | 'client' | 'both';
    }): {
        success: boolean;
        message: string;
    };
}
