"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ChatStateService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatStateService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const event_emitter_1 = require("@nestjs/event-emitter");
const chat_entity_1 = require("../entities/chat.entity");
const chat_state_transition_entity_1 = require("../entities/chat-state-transition.entity");
let ChatStateService = ChatStateService_1 = class ChatStateService {
    constructor(chatRepository, transitionRepository, dataSource, eventEmitter) {
        this.chatRepository = chatRepository;
        this.transitionRepository = transitionRepository;
        this.dataSource = dataSource;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(ChatStateService_1.name);
        this.allowedTransitions = {
            [chat_entity_1.ChatStatus.BOT]: [
                chat_entity_1.ChatStatus.ACTIVE,
                chat_entity_1.ChatStatus.WAITING,
                chat_entity_1.ChatStatus.CLOSED,
            ],
            [chat_entity_1.ChatStatus.WAITING]: [
                chat_entity_1.ChatStatus.ACTIVE,
                chat_entity_1.ChatStatus.BOT,
                chat_entity_1.ChatStatus.CLOSED,
            ],
            [chat_entity_1.ChatStatus.ACTIVE]: [
                chat_entity_1.ChatStatus.PENDING,
                chat_entity_1.ChatStatus.RESOLVED,
                chat_entity_1.ChatStatus.CLOSED,
                chat_entity_1.ChatStatus.BOT,
            ],
            [chat_entity_1.ChatStatus.PENDING]: [
                chat_entity_1.ChatStatus.ACTIVE,
                chat_entity_1.ChatStatus.CLOSED,
            ],
            [chat_entity_1.ChatStatus.RESOLVED]: [
                chat_entity_1.ChatStatus.ACTIVE,
                chat_entity_1.ChatStatus.CLOSED,
            ],
            [chat_entity_1.ChatStatus.CLOSED]: [],
        };
    }
    async transition(chatId, newStatus, subStatus, metadata) {
        const queryRunner = this.dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        try {
            const chat = await queryRunner.manager.findOne(chat_entity_1.Chat, {
                where: { id: chatId },
                lock: { mode: 'pessimistic_write' },
            });
            if (!chat) {
                throw new common_1.BadRequestException(`Chat ${chatId} no encontrado`);
            }
            const oldStatus = chat.status;
            const oldSubStatus = chat.subStatus;
            if (!this.validateTransition(oldStatus, newStatus)) {
                throw new common_1.BadRequestException(`Transición inválida: ${oldStatus} → ${newStatus}`);
            }
            this.logger.log(`[ChatStateService] Transitioning chat ${chatId}: ${oldStatus} → ${newStatus}`);
            chat.status = newStatus;
            chat.subStatus = subStatus;
            this.updateRelatedFields(chat, newStatus);
            await queryRunner.manager.save(chat_entity_1.Chat, chat);
            const transition = this.transitionRepository.create({
                chatId: chat.id,
                fromStatus: oldStatus,
                toStatus: newStatus,
                fromSubStatus: oldSubStatus,
                toSubStatus: subStatus,
                reason: metadata?.reason || 'Sin motivo especificado',
                triggeredBy: metadata?.triggeredBy || 'system',
                agentId: metadata?.agentId,
                metadata: metadata?.metadata || {},
            });
            await queryRunner.manager.save(chat_state_transition_entity_1.ChatStateTransition, transition);
            await queryRunner.commitTransaction();
            this.emitStateEvents(chat, oldStatus, newStatus, metadata);
            this.logger.log(`✅ [ChatStateService] Chat ${chatId} transitioned successfully`);
            return chat;
        }
        catch (error) {
            await queryRunner.rollbackTransaction();
            this.logger.error(`❌ [ChatStateService] Error transitioning chat ${chatId}: ${error.message}`, error.stack);
            throw error;
        }
        finally {
            await queryRunner.release();
        }
    }
    validateTransition(fromStatus, toStatus) {
        const allowed = this.allowedTransitions[fromStatus];
        return allowed?.includes(toStatus) ?? false;
    }
    updateRelatedFields(chat, newStatus) {
        const now = new Date();
        switch (newStatus) {
            case chat_entity_1.ChatStatus.ACTIVE:
                if (!chat.assignedAt) {
                    chat.assignedAt = now;
                }
                chat.isBotActive = false;
                break;
            case chat_entity_1.ChatStatus.BOT:
                chat.isBotActive = true;
                chat.assignedAgentId = null;
                chat.assignedAgent = null;
                break;
            case chat_entity_1.ChatStatus.RESOLVED:
                chat.resolvedAt = now;
                break;
            case chat_entity_1.ChatStatus.CLOSED:
                chat.closedAt = now;
                chat.isBotActive = false;
                break;
            case chat_entity_1.ChatStatus.PENDING:
                break;
        }
    }
    emitStateEvents(chat, oldStatus, newStatus, metadata) {
        this.eventEmitter.emit('chat.state.changed', {
            chat,
            oldStatus,
            newStatus,
            metadata,
        });
        if (newStatus === chat_entity_1.ChatStatus.ACTIVE && oldStatus === chat_entity_1.ChatStatus.WAITING) {
            this.eventEmitter.emit('chat.assigned', { chat });
        }
        if (newStatus === chat_entity_1.ChatStatus.CLOSED) {
            this.eventEmitter.emit('chat.closed', { chat });
        }
        if (newStatus === chat_entity_1.ChatStatus.BOT && oldStatus === chat_entity_1.ChatStatus.ACTIVE) {
            this.eventEmitter.emit('chat.returned.to.bot', { chat });
        }
    }
    async getTransitionHistory(chatId) {
        return this.transitionRepository.find({
            where: { chatId },
            relations: ['agent'],
            order: { createdAt: 'DESC' },
        });
    }
    canTransition(fromStatus, toStatus) {
        return this.validateTransition(fromStatus, toStatus);
    }
};
exports.ChatStateService = ChatStateService;
exports.ChatStateService = ChatStateService = ChatStateService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __param(1, (0, typeorm_1.InjectRepository)(chat_state_transition_entity_1.ChatStateTransition)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.DataSource,
        event_emitter_1.EventEmitter2])
], ChatStateService);
//# sourceMappingURL=chat-state.service.js.map