import { Repository } from 'typeorm';
import { Message } from '../../messages/entities/message.entity';
import { Chat } from '../../chats/entities/chat.entity';
import { EventEmitter2 } from '@nestjs/event-emitter';
export declare class TwilioSpamDetectorService {
    private messageRepository;
    private chatRepository;
    private eventEmitter;
    private readonly logger;
    private readonly THRESHOLDS;
    private readonly TWILIO_SPAM_ERROR_CODES;
    private errorCounters;
    constructor(messageRepository: Repository<Message>, chatRepository: Repository<Chat>, eventEmitter: EventEmitter2);
    canSendMessage(whatsappNumberId: string, toPhone: string): Promise<{
        allowed: boolean;
        reason?: string;
        riskLevel: 'low' | 'medium' | 'high';
    }>;
    recordSendResult(whatsappNumberId: string, success: boolean, errorCode?: number, errorMessage?: string): Promise<void>;
    getNumberStats(whatsappNumberId: string): Promise<{
        lastHour: {
            sent: number;
            received: number;
            errors: number;
        };
        lastDay: {
            sent: number;
            received: number;
            errors: number;
        };
        responseRatio: number;
        riskLevel: 'low' | 'medium' | 'high';
        consecutiveErrors: number;
    }>;
    checkNumbersHealth(): Promise<void>;
    private emitAlert;
}
