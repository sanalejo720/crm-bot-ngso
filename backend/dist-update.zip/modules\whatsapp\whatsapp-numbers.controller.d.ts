import { WhatsappNumbersService } from './whatsapp-numbers.service';
import { CreateWhatsappNumberDto } from './dto/create-whatsapp-number.dto';
import { UpdateWhatsappNumberDto } from './dto/update-whatsapp-number.dto';
export declare class WhatsappNumbersController {
    private readonly whatsappNumbersService;
    constructor(whatsappNumbersService: WhatsappNumbersService);
    create(createDto: CreateWhatsappNumberDto): Promise<import("./entities/whatsapp-number.entity").WhatsappNumber>;
    findAll(): Promise<import("./entities/whatsapp-number.entity").WhatsappNumber[]>;
    findAllActive(): Promise<import("./entities/whatsapp-number.entity").WhatsappNumber[]>;
    findOne(id: string): Promise<import("./entities/whatsapp-number.entity").WhatsappNumber>;
    startWppConnect(id: string): Promise<any>;
    getWppConnectStatus(id: string): Promise<any>;
    disconnectWppConnect(id: string): Promise<any>;
    configureMeta(id: string, config: {
        accessToken: string;
        phoneNumberId: string;
        businessAccountId: string;
    }): Promise<import("./entities/whatsapp-number.entity").WhatsappNumber>;
    verifyMeta(id: string): Promise<any>;
    update(id: string, updateDto: UpdateWhatsappNumberDto): Promise<import("./entities/whatsapp-number.entity").WhatsappNumber>;
    assignToCampaign(id: string, campaignId: string): Promise<import("./entities/whatsapp-number.entity").WhatsappNumber>;
    remove(id: string): Promise<void>;
    getActiveSessions(): Promise<import("./dto/session-stats.dto").ActiveSessionsDto>;
    forceCloseSession(id: string): Promise<any>;
    closeAllSessions(): Promise<any>;
    canCreateNewSession(): Promise<{
        allowed: boolean;
        message?: string;
    }>;
    cleanupZombieProcesses(id: string): Promise<{
        message: string;
        success: boolean;
    }>;
}
