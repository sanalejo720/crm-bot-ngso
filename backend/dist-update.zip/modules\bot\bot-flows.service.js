"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var BotFlowsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotFlowsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const bot_flow_entity_1 = require("./entities/bot-flow.entity");
const bot_node_entity_1 = require("./entities/bot-node.entity");
let BotFlowsService = BotFlowsService_1 = class BotFlowsService {
    constructor(botFlowRepository, botNodeRepository) {
        this.botFlowRepository = botFlowRepository;
        this.botNodeRepository = botNodeRepository;
        this.logger = new common_1.Logger(BotFlowsService_1.name);
    }
    async findAll(status, page = 1, limit = 50) {
        const query = this.botFlowRepository.createQueryBuilder('flow');
        if (status) {
            query.where('flow.status = :status', { status });
        }
        query
            .orderBy('flow.createdAt', 'DESC')
            .skip((page - 1) * limit)
            .take(limit);
        const [data, total] = await query.getManyAndCount();
        return { data, total };
    }
    async findOneWithNodes(id) {
        const flow = await this.botFlowRepository.findOne({
            where: { id },
            relations: ['nodes'],
        });
        if (!flow) {
            throw new common_1.NotFoundException(`Flujo con ID ${id} no encontrado`);
        }
        return flow;
    }
    async create(createDto) {
        const flow = this.botFlowRepository.create(createDto);
        return await this.botFlowRepository.save(flow);
    }
    async update(id, updateDto) {
        const flow = await this.botFlowRepository.findOne({ where: { id } });
        if (!flow) {
            throw new common_1.NotFoundException(`Flujo con ID ${id} no encontrado`);
        }
        Object.assign(flow, updateDto);
        return await this.botFlowRepository.save(flow);
    }
    async remove(id) {
        const flow = await this.botFlowRepository.findOne({ where: { id } });
        if (!flow) {
            throw new common_1.NotFoundException(`Flujo con ID ${id} no encontrado`);
        }
        await this.botFlowRepository.remove(flow);
        this.logger.log(`Flujo ${id} eliminado`);
    }
    async duplicate(id) {
        const originalFlow = await this.findOneWithNodes(id);
        const newFlow = this.botFlowRepository.create({
            name: `${originalFlow.name} (Copia)`,
            description: originalFlow.description,
            status: bot_flow_entity_1.BotFlowStatus.DRAFT,
            variables: originalFlow.variables,
            settings: originalFlow.settings,
        });
        const savedFlow = await this.botFlowRepository.save(newFlow);
        const nodeMapping = new Map();
        for (const originalNode of originalFlow.nodes) {
            const newNode = this.botNodeRepository.create({
                name: originalNode.name,
                type: originalNode.type,
                config: originalNode.config,
                positionX: originalNode.positionX + 50,
                positionY: originalNode.positionY + 50,
                flowId: savedFlow.id,
            });
            const savedNode = await this.botNodeRepository.save(newNode);
            nodeMapping.set(originalNode.id, savedNode.id);
            if (originalFlow.startNodeId === originalNode.id) {
                savedFlow.startNodeId = savedNode.id;
            }
        }
        for (const originalNode of originalFlow.nodes) {
            const newNodeId = nodeMapping.get(originalNode.id);
            if (newNodeId && originalNode.nextNodeId) {
                const newNextNodeId = nodeMapping.get(originalNode.nextNodeId);
                if (newNextNodeId) {
                    await this.botNodeRepository.update(newNodeId, {
                        nextNodeId: newNextNodeId,
                    });
                }
            }
        }
        await this.botFlowRepository.save(savedFlow);
        this.logger.log(`Flujo ${id} duplicado como ${savedFlow.id}`);
        return savedFlow;
    }
    async publish(id) {
        const flow = await this.findOneWithNodes(id);
        if (!flow.startNodeId) {
            throw new common_1.BadRequestException('El flujo debe tener un nodo inicial antes de publicarse');
        }
        if (flow.nodes.length === 0) {
            throw new common_1.BadRequestException('El flujo debe tener al menos un nodo');
        }
        flow.status = bot_flow_entity_1.BotFlowStatus.ACTIVE;
        return await this.botFlowRepository.save(flow);
    }
    async createNode(flowId, createDto) {
        const flow = await this.botFlowRepository.findOne({ where: { id: flowId } });
        if (!flow) {
            throw new common_1.NotFoundException(`Flujo con ID ${flowId} no encontrado`);
        }
        const node = this.botNodeRepository.create({
            name: createDto.name,
            type: createDto.type,
            config: createDto.config,
            nextNodeId: createDto.nextNodeId,
            positionX: createDto.positionX || 0,
            positionY: createDto.positionY || 0,
            flowId,
        });
        return await this.botNodeRepository.save(node);
    }
    async createNodesBulk(flowId, nodesDto) {
        const flow = await this.botFlowRepository.findOne({ where: { id: flowId } });
        if (!flow) {
            throw new common_1.NotFoundException(`Flujo con ID ${flowId} no encontrado`);
        }
        const createdNodes = [];
        for (const dto of nodesDto) {
            const node = this.botNodeRepository.create({
                name: dto.name,
                type: dto.type,
                config: dto.config,
                nextNodeId: dto.nextNodeId,
                positionX: dto.positionX || 0,
                positionY: dto.positionY || 0,
                flowId,
            });
            const savedNode = await this.botNodeRepository.save(node);
            createdNodes.push(savedNode);
        }
        return createdNodes;
    }
    async updateNode(nodeId, updateDto) {
        const node = await this.botNodeRepository.findOne({ where: { id: nodeId } });
        if (!node) {
            throw new common_1.NotFoundException(`Nodo con ID ${nodeId} no encontrado`);
        }
        Object.assign(node, updateDto);
        return await this.botNodeRepository.save(node);
    }
    async removeNode(nodeId) {
        const node = await this.botNodeRepository.findOne({ where: { id: nodeId } });
        if (!node) {
            throw new common_1.NotFoundException(`Nodo con ID ${nodeId} no encontrado`);
        }
        await this.botNodeRepository.remove(node);
        this.logger.log(`Nodo ${nodeId} eliminado`);
    }
    async getStats(id) {
        const flow = await this.findOneWithNodes(id);
        return {
            totalNodes: flow.nodes.length,
            nodesByType: flow.nodes.reduce((acc, node) => {
                acc[node.type] = (acc[node.type] || 0) + 1;
                return acc;
            }, {}),
            status: flow.status,
            hasStartNode: !!flow.startNodeId,
        };
    }
};
exports.BotFlowsService = BotFlowsService;
exports.BotFlowsService = BotFlowsService = BotFlowsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(bot_flow_entity_1.BotFlow)),
    __param(1, (0, typeorm_1.InjectRepository)(bot_node_entity_1.BotNode)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], BotFlowsService);
//# sourceMappingURL=bot-flows.service.js.map