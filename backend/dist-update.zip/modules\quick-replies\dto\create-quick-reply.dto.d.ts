export declare class CreateQuickReplyDto {
    shortcut: string;
    title: string;
    content: string;
    variables?: string[];
    category?: string;
    campaignId?: string;
    isActive?: boolean;
}
