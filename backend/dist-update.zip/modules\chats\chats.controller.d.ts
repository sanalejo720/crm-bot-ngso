import { ChatsService } from './chats.service';
import { ChatsExportService } from './chats-export.service';
import { AssignmentService } from './services/assignment.service';
import { ReturnToBotService } from './services/return-to-bot.service';
import { TransferService } from './services/transfer.service';
import { CreateChatDto } from './dto/create-chat.dto';
import { UpdateChatDto } from './dto/update-chat.dto';
import { AssignChatDto, TransferChatDto } from './dto/assign-chat.dto';
import { ReturnToBotDto } from './dto/return-to-bot.dto';
import { ChatStatus } from './entities/chat.entity';
export declare class ChatsController {
    private readonly chatsService;
    private readonly chatsExportService;
    private readonly assignmentService;
    private readonly returnToBotService;
    private readonly transferService;
    constructor(chatsService: ChatsService, chatsExportService: ChatsExportService, assignmentService: AssignmentService, returnToBotService: ReturnToBotService, transferService: TransferService);
    create(createChatDto: CreateChatDto): Promise<import("./entities/chat.entity").Chat>;
    findAll(status?: ChatStatus, campaignId?: string, assignedAgentId?: string, whatsappNumberId?: string): Promise<import("./entities/chat.entity").Chat[]>;
    getMyChats(userId: string, userRole: {
        name: string;
    }): Promise<import("./entities/chat.entity").Chat[]>;
    getWaitingChats(campaignId: string): Promise<import("./entities/chat.entity").Chat[]>;
    findOne(id: string): Promise<import("./entities/chat.entity").Chat>;
    update(id: string, updateChatDto: UpdateChatDto): Promise<import("./entities/chat.entity").Chat>;
    getWaitingQueue(campaignId?: string): Promise<{
        success: boolean;
        data: import("./entities/chat.entity").Chat[];
        total: number;
    }>;
    assign(id: string, assignDto: AssignChatDto, userId: string): Promise<{
        success: boolean;
        data: import("./entities/chat.entity").Chat;
        message: string;
    }>;
    reassign(id: string, assignDto: AssignChatDto): Promise<import("./entities/chat.entity").Chat>;
    updateStatus(id: string, body: {
        status: ChatStatus;
    }, userId: string): Promise<import("./entities/chat.entity").Chat>;
    returnToBot(id: string, returnDto: ReturnToBotDto, userId: string): Promise<{
        success: boolean;
        data: import("./entities/chat.entity").Chat;
        message: string;
    }>;
    transfer(id: string, currentUserId: string, transferDto: TransferChatDto): Promise<{
        success: boolean;
        data: import("./entities/chat.entity").Chat;
        message: string;
    }>;
    getTransferHistory(id: string): Promise<{
        success: boolean;
        data: any;
    }>;
    close(id: string, userId: string): Promise<import("./entities/chat.entity").Chat>;
    resolve(id: string, userId: string): Promise<import("./entities/chat.entity").Chat>;
    getAgentStats(agentId: string): Promise<{
        active: number;
        resolved: number;
        total: number;
    }>;
    exportChatToPDF(id: string, body: {
        closureType: 'paid' | 'promise';
    }, agentId: string): Promise<{
        success: boolean;
        message: string;
        data: {
            fileName: string;
            ticketNumber: string;
        };
    }>;
    updateContactInfo(id: string, body: {
        contactName?: string;
        contactPhone?: string;
    }): Promise<import("./entities/chat.entity").Chat>;
}
