import { User } from '../../users/entities/user.entity';
export declare enum AuditAction {
    CREATE = "create",
    READ = "read",
    UPDATE = "update",
    DELETE = "delete",
    LOGIN = "login",
    LOGOUT = "logout",
    ASSIGN = "assign",
    TRANSFER = "transfer",
    EXPORT = "export"
}
export declare class AuditLog {
    id: string;
    module: string;
    action: AuditAction;
    entityId: string;
    entityType: string;
    oldValue: Record<string, any>;
    newValue: Record<string, any>;
    description: string;
    ipAddress: string;
    userAgent: string;
    user: User;
    userId: string;
    createdAt: Date;
}
