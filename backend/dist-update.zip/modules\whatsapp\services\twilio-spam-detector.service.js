"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var TwilioSpamDetectorService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TwilioSpamDetectorService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const message_entity_1 = require("../../messages/entities/message.entity");
const chat_entity_1 = require("../../chats/entities/chat.entity");
const event_emitter_1 = require("@nestjs/event-emitter");
const schedule_1 = require("@nestjs/schedule");
let TwilioSpamDetectorService = TwilioSpamDetectorService_1 = class TwilioSpamDetectorService {
    constructor(messageRepository, chatRepository, eventEmitter) {
        this.messageRepository = messageRepository;
        this.chatRepository = chatRepository;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(TwilioSpamDetectorService_1.name);
        this.THRESHOLDS = {
            MAX_MESSAGES_PER_HOUR: 100,
            MAX_MESSAGES_PER_DAY: 800,
            MAX_TO_SAME_CONTACT_PER_HOUR: 10,
            MIN_RESPONSE_RATIO: 0.15,
            MAX_CONSECUTIVE_ERRORS: 5,
        };
        this.TWILIO_SPAM_ERROR_CODES = [
            21610, 21614, 21408, 30003, 30004, 30005, 30006, 30007, 30008, 63016, 63032,
        ];
        this.errorCounters = new Map();
    }
    async canSendMessage(whatsappNumberId, toPhone) {
        const now = new Date();
        const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);
        const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        const messagesLastHour = await this.messageRepository
            .createQueryBuilder('message')
            .innerJoin('message.chat', 'chat')
            .where('chat.whatsappNumberId = :whatsappNumberId', { whatsappNumberId })
            .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.OUTBOUND })
            .andWhere('message.createdAt > :oneHourAgo', { oneHourAgo })
            .getCount();
        if (messagesLastHour >= this.THRESHOLDS.MAX_MESSAGES_PER_HOUR) {
            this.emitAlert('high', 'RATE_LIMIT_HOUR', whatsappNumberId, {
                count: messagesLastHour,
                threshold: this.THRESHOLDS.MAX_MESSAGES_PER_HOUR,
            });
            return {
                allowed: false,
                reason: `Límite de mensajes por hora excedido (${messagesLastHour}/${this.THRESHOLDS.MAX_MESSAGES_PER_HOUR})`,
                riskLevel: 'high',
            };
        }
        const messagesLastDay = await this.messageRepository
            .createQueryBuilder('message')
            .innerJoin('message.chat', 'chat')
            .where('chat.whatsappNumberId = :whatsappNumberId', { whatsappNumberId })
            .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.OUTBOUND })
            .andWhere('message.createdAt > :oneDayAgo', { oneDayAgo })
            .getCount();
        if (messagesLastDay >= this.THRESHOLDS.MAX_MESSAGES_PER_DAY) {
            this.emitAlert('high', 'RATE_LIMIT_DAY', whatsappNumberId, {
                count: messagesLastDay,
                threshold: this.THRESHOLDS.MAX_MESSAGES_PER_DAY,
            });
            return {
                allowed: false,
                reason: `Límite de mensajes por día excedido (${messagesLastDay}/${this.THRESHOLDS.MAX_MESSAGES_PER_DAY})`,
                riskLevel: 'high',
            };
        }
        const errorCount = this.errorCounters.get(whatsappNumberId) || 0;
        if (errorCount >= this.THRESHOLDS.MAX_CONSECUTIVE_ERRORS) {
            this.emitAlert('high', 'CONSECUTIVE_ERRORS', whatsappNumberId, { errorCount });
            return {
                allowed: false,
                reason: `Demasiados errores consecutivos (${errorCount}). Posible bloqueo.`,
                riskLevel: 'high',
            };
        }
        const outboundCount = await this.messageRepository
            .createQueryBuilder('message')
            .innerJoin('message.chat', 'chat')
            .where('chat.whatsappNumberId = :whatsappNumberId', { whatsappNumberId })
            .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.OUTBOUND })
            .andWhere('message.createdAt > :oneDayAgo', { oneDayAgo })
            .getCount();
        const inboundCount = await this.messageRepository
            .createQueryBuilder('message')
            .innerJoin('message.chat', 'chat')
            .where('chat.whatsappNumberId = :whatsappNumberId', { whatsappNumberId })
            .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.INBOUND })
            .andWhere('message.createdAt > :oneDayAgo', { oneDayAgo })
            .getCount();
        if (outboundCount > 100) {
            const responseRatio = inboundCount / outboundCount;
            if (responseRatio < this.THRESHOLDS.MIN_RESPONSE_RATIO) {
                this.emitAlert('medium', 'LOW_RESPONSE_RATIO', whatsappNumberId, {
                    inbound: inboundCount,
                    outbound: outboundCount,
                    ratio: (responseRatio * 100).toFixed(2) + '%',
                });
                return {
                    allowed: true,
                    reason: `Ratio de respuesta bajo (${(responseRatio * 100).toFixed(2)}%). Riesgo de spam.`,
                    riskLevel: 'medium',
                };
            }
        }
        let riskLevel = 'low';
        if (messagesLastDay > this.THRESHOLDS.MAX_MESSAGES_PER_DAY * 0.7)
            riskLevel = 'medium';
        if (messagesLastHour > this.THRESHOLDS.MAX_MESSAGES_PER_HOUR * 0.8)
            riskLevel = 'medium';
        return { allowed: true, riskLevel };
    }
    async recordSendResult(whatsappNumberId, success, errorCode, errorMessage) {
        if (success) {
            this.errorCounters.set(whatsappNumberId, 0);
        }
        else {
            const currentCount = this.errorCounters.get(whatsappNumberId) || 0;
            this.errorCounters.set(whatsappNumberId, currentCount + 1);
            if (errorCode && this.TWILIO_SPAM_ERROR_CODES.includes(errorCode)) {
                this.emitAlert('high', 'SPAM_ERROR_CODE', whatsappNumberId, {
                    errorCode,
                    errorMessage,
                    consecutiveErrors: currentCount + 1,
                });
            }
        }
    }
    async getNumberStats(whatsappNumberId) {
        const now = new Date();
        const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);
        const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        const [sentHour, receivedHour, errorsHour] = await Promise.all([
            this.messageRepository.createQueryBuilder('message')
                .innerJoin('message.chat', 'chat')
                .where('chat.whatsappNumberId = :whatsappNumberId', { whatsappNumberId })
                .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.OUTBOUND })
                .andWhere('message.status = :status', { status: message_entity_1.MessageStatus.SENT })
                .andWhere('message.createdAt > :oneHourAgo', { oneHourAgo })
                .getCount(),
            this.messageRepository.createQueryBuilder('message')
                .innerJoin('message.chat', 'chat')
                .where('chat.whatsappNumberId = :whatsappNumberId', { whatsappNumberId })
                .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.INBOUND })
                .andWhere('message.createdAt > :oneHourAgo', { oneHourAgo })
                .getCount(),
            this.messageRepository.createQueryBuilder('message')
                .innerJoin('message.chat', 'chat')
                .where('chat.whatsappNumberId = :whatsappNumberId', { whatsappNumberId })
                .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.OUTBOUND })
                .andWhere('message.status = :status', { status: message_entity_1.MessageStatus.FAILED })
                .andWhere('message.createdAt > :oneHourAgo', { oneHourAgo })
                .getCount(),
        ]);
        const [sentDay, receivedDay, errorsDay] = await Promise.all([
            this.messageRepository.createQueryBuilder('message')
                .innerJoin('message.chat', 'chat')
                .where('chat.whatsappNumberId = :whatsappNumberId', { whatsappNumberId })
                .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.OUTBOUND })
                .andWhere('message.status = :status', { status: message_entity_1.MessageStatus.SENT })
                .andWhere('message.createdAt > :oneDayAgo', { oneDayAgo })
                .getCount(),
            this.messageRepository.createQueryBuilder('message')
                .innerJoin('message.chat', 'chat')
                .where('chat.whatsappNumberId = :whatsappNumberId', { whatsappNumberId })
                .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.INBOUND })
                .andWhere('message.createdAt > :oneDayAgo', { oneDayAgo })
                .getCount(),
            this.messageRepository.createQueryBuilder('message')
                .innerJoin('message.chat', 'chat')
                .where('chat.whatsappNumberId = :whatsappNumberId', { whatsappNumberId })
                .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.OUTBOUND })
                .andWhere('message.status = :status', { status: message_entity_1.MessageStatus.FAILED })
                .andWhere('message.createdAt > :oneDayAgo', { oneDayAgo })
                .getCount(),
        ]);
        const responseRatio = sentDay > 0 ? receivedDay / sentDay : 1;
        const consecutiveErrors = this.errorCounters.get(whatsappNumberId) || 0;
        let riskLevel = 'low';
        if (sentDay > this.THRESHOLDS.MAX_MESSAGES_PER_DAY * 0.7 ||
            responseRatio < this.THRESHOLDS.MIN_RESPONSE_RATIO ||
            consecutiveErrors > 2) {
            riskLevel = 'medium';
        }
        if (sentDay > this.THRESHOLDS.MAX_MESSAGES_PER_DAY * 0.9 ||
            consecutiveErrors >= this.THRESHOLDS.MAX_CONSECUTIVE_ERRORS) {
            riskLevel = 'high';
        }
        return {
            lastHour: { sent: sentHour, received: receivedHour, errors: errorsHour },
            lastDay: { sent: sentDay, received: receivedDay, errors: errorsDay },
            responseRatio,
            riskLevel,
            consecutiveErrors,
        };
    }
    async checkNumbersHealth() {
        this.logger.log('🔍 Verificando salud de números Twilio...');
        const activeChats = await this.chatRepository
            .createQueryBuilder('chat')
            .select('DISTINCT chat.whatsappNumberId', 'whatsappNumberId')
            .where('chat.createdAt > :date', {
            date: new Date(Date.now() - 24 * 60 * 60 * 1000)
        })
            .andWhere('chat.whatsappNumberId IS NOT NULL')
            .getRawMany();
        for (const { whatsappNumberId } of activeChats) {
            if (!whatsappNumberId)
                continue;
            const stats = await this.getNumberStats(whatsappNumberId);
            if (stats.riskLevel === 'high') {
                this.emitAlert('high', 'NUMBER_HIGH_RISK', whatsappNumberId, stats);
            }
            else if (stats.riskLevel === 'medium') {
                this.emitAlert('medium', 'NUMBER_MEDIUM_RISK', whatsappNumberId, stats);
            }
            this.logger.log(`📊 Número ${whatsappNumberId}: ` +
                `Enviados(día): ${stats.lastDay.sent}, ` +
                `Ratio: ${(stats.responseRatio * 100).toFixed(1)}%, ` +
                `Riesgo: ${stats.riskLevel}`);
        }
    }
    emitAlert(severity, type, whatsappNumberId, data) {
        const alert = {
            severity,
            type,
            whatsappNumberId,
            data,
            timestamp: new Date(),
        };
        this.logger.warn(`⚠️ ALERTA TWILIO [${severity.toUpperCase()}] - ${type}: ${JSON.stringify(data)}`);
        this.eventEmitter.emit('twilio.spam.alert', alert);
    }
};
exports.TwilioSpamDetectorService = TwilioSpamDetectorService;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_30_MINUTES),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TwilioSpamDetectorService.prototype, "checkNumbersHealth", null);
exports.TwilioSpamDetectorService = TwilioSpamDetectorService = TwilioSpamDetectorService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(message_entity_1.Message)),
    __param(1, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        event_emitter_1.EventEmitter2])
], TwilioSpamDetectorService);
//# sourceMappingURL=twilio-spam-detector.service.js.map