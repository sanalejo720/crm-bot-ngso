import { Repository } from 'typeorm';
import { QuickReply } from './entities/quick-reply.entity';
import { CreateQuickReplyDto } from './dto/create-quick-reply.dto';
import { UpdateQuickReplyDto } from './dto/update-quick-reply.dto';
export declare class QuickRepliesService {
    private quickReplyRepository;
    constructor(quickReplyRepository: Repository<QuickReply>);
    create(userId: string, createDto: CreateQuickReplyDto): Promise<QuickReply>;
    findAll(userId: string, campaignId?: string, category?: string): Promise<QuickReply[]>;
    findOne(id: string): Promise<QuickReply>;
    update(id: string, userId: string, updateDto: UpdateQuickReplyDto): Promise<QuickReply>;
    remove(id: string, userId: string): Promise<void>;
    replaceVariables(content: string, variables: Record<string, any>): string;
    applyTemplate(id: string, variables: Record<string, any>): Promise<string>;
    findByShortcut(shortcut: string, userId: string, campaignId?: string): Promise<QuickReply | null>;
    getStats(userId: string): Promise<any>;
}
