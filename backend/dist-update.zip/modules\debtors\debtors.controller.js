"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var DebtorsController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DebtorsController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const debtors_service_1 = require("./debtors.service");
const create_debtor_dto_1 = require("./dto/create-debtor.dto");
const upload_csv_dto_1 = require("./dto/upload-csv.dto");
const debtor_entity_1 = require("./entities/debtor.entity");
let DebtorsController = DebtorsController_1 = class DebtorsController {
    constructor(debtorsService) {
        this.debtorsService = debtorsService;
        this.logger = new common_1.Logger(DebtorsController_1.name);
    }
    async create(createDebtorDto) {
        const debtor = await this.debtorsService.create(createDebtorDto);
        return {
            message: 'Deudor creado exitosamente',
            data: debtor,
        };
    }
    async findAll(page = 1, limit = 50) {
        const result = await this.debtorsService.findAll(+page, +limit);
        return {
            message: 'Deudores recuperados exitosamente',
            data: result.data,
            meta: {
                page: +page,
                limit: +limit,
                total: result.total,
                totalPages: Math.ceil(result.total / +limit),
            },
        };
    }
    async findByDocument(documentType, documentNumber) {
        const debtor = await this.debtorsService.findByDocument(documentType, documentNumber);
        if (!debtor) {
            return {
                message: 'Deudor no encontrado',
                data: null,
            };
        }
        return {
            message: 'Deudor encontrado',
            data: debtor,
        };
    }
    async findByPhone(phone) {
        const debtor = await this.debtorsService.findByPhone(phone);
        if (!debtor) {
            return {
                message: 'Deudor no encontrado',
                data: null,
            };
        }
        return {
            message: 'Deudor encontrado',
            data: debtor,
        };
    }
    async uploadFile(file) {
        if (!file) {
            return {
                success: false,
                message: 'No se proporcionó ningún archivo',
            };
        }
        this.logger.log(`📁 Procesando archivo: ${file.originalname} (${(file.size / 1024).toFixed(2)} KB)`);
        const result = await this.debtorsService.uploadFromFile(file.buffer, file.originalname);
        const message = result.success
            ? 'Archivo procesado exitosamente'
            : 'Archivo procesado con errores';
        return {
            success: result.success,
            message,
            data: result,
        };
    }
    async uploadCsv(file) {
        if (!file) {
            return {
                success: false,
                message: 'No se proporcionó ningún archivo',
            };
        }
        const result = await this.debtorsService.uploadFromCsv(file.buffer);
        return {
            message: 'CSV procesado exitosamente',
            data: {
                created: result.created,
                updated: result.updated,
                errorsCount: result.errors.length,
                errors: result.errors.slice(0, 10),
            },
        };
    }
};
exports.DebtorsController = DebtorsController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Crear un deudor manualmente' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_debtor_dto_1.CreateDebtorDto]),
    __metadata("design:returntype", Promise)
], DebtorsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Listar todos los deudores' }),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], DebtorsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('search/:documentType/:documentNumber'),
    (0, swagger_1.ApiOperation)({ summary: 'Buscar deudor por tipo y número de documento' }),
    __param(0, (0, common_1.Param)('documentType')),
    __param(1, (0, common_1.Param)('documentNumber')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], DebtorsController.prototype, "findByDocument", null);
__decorate([
    (0, common_1.Get)('phone/:phone'),
    (0, swagger_1.ApiOperation)({ summary: 'Buscar deudor por número de teléfono' }),
    __param(0, (0, common_1.Param)('phone')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], DebtorsController.prototype, "findByPhone", null);
__decorate([
    (0, common_1.Post)('upload'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Cargar deudores masivamente desde archivo CSV o Excel',
        description: `
    Sube un archivo CSV o Excel (.xlsx, .xls) con la información de los deudores.
    
    Columnas requeridas:
    - nombre / fullName: Nombre completo del deudor
    - tipo_doc / documentType: Tipo de documento (CC, CE, NIT, TI, PASSPORT)
    - documento / documentNumber: Número de documento
    
    Columnas opcionales:
    - telefono / phone: Número de teléfono
    - correo / email: Correo electrónico
    - direccion / address: Dirección
    - deuda / debtAmount: Monto de la deuda
    - deuda_inicial / initialDebtAmount: Deuda inicial
    - mora / daysOverdue: Días de mora
    - ultimo_pago / lastPaymentDate: Fecha del último pago
    - promesa / promiseDate: Fecha de promesa de pago
    - estado / status: Estado del deudor
    - notas / notes: Observaciones
    - producto: Producto financiero
    - credito / numeroCredito: Número de crédito
    - vencimiento / fechaVencimiento: Fecha de vencimiento
    - compania: Compañía
    - campana / campaignId: ID de campaña
    `
    }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({
        schema: {
            type: 'object',
            properties: {
                file: {
                    type: 'string',
                    format: 'binary',
                    description: 'Archivo CSV o Excel (.xlsx, .xls)',
                },
            },
        },
    }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        limits: {
            fileSize: 10 * 1024 * 1024,
        },
        fileFilter: (req, file, cb) => {
            const allowedMimes = [
                'text/csv',
                'application/vnd.ms-excel',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            ];
            if (allowedMimes.includes(file.mimetype)) {
                cb(null, true);
            }
            else {
                cb(new Error('Formato de archivo no válido. Solo se permiten CSV y Excel'), false);
            }
        },
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], DebtorsController.prototype, "uploadFile", null);
__decorate([
    (0, common_1.Post)('upload-csv'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Cargar deudores desde CSV (usar /upload en su lugar)' }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({ type: upload_csv_dto_1.UploadCsvDto }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], DebtorsController.prototype, "uploadCsv", null);
exports.DebtorsController = DebtorsController = DebtorsController_1 = __decorate([
    (0, swagger_1.ApiTags)('Debtors'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.Controller)('debtors'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [debtors_service_1.DebtorsService])
], DebtorsController);
//# sourceMappingURL=debtors.controller.js.map