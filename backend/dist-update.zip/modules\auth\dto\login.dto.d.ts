export declare class LoginDto {
    email: string;
    password: string;
    twoFactorCode?: string;
    ipAddress?: string;
    userAgent?: string;
}
export declare class LoginResponseDto {
    accessToken: string;
    refreshToken: string;
    user: {
        id: string;
        fullName: string;
        email: string;
        role: {
            id: string;
            name: string;
            permissions: Array<{
                module: string;
                action: string;
            }>;
        };
    };
}
