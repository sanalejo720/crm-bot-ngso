import { Repository, DataSource } from 'typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Chat, ChatStatus } from '../entities/chat.entity';
import { ChatStateTransition } from '../entities/chat-state-transition.entity';
interface TransitionMetadata {
    reason: string;
    triggeredBy: 'system' | 'agent' | 'supervisor' | 'bot' | 'client';
    agentId?: string;
    metadata?: Record<string, any>;
}
export declare class ChatStateService {
    private chatRepository;
    private transitionRepository;
    private dataSource;
    private eventEmitter;
    private readonly logger;
    private readonly allowedTransitions;
    constructor(chatRepository: Repository<Chat>, transitionRepository: Repository<ChatStateTransition>, dataSource: DataSource, eventEmitter: EventEmitter2);
    transition(chatId: string, newStatus: ChatStatus, subStatus?: string, metadata?: TransitionMetadata): Promise<Chat>;
    private validateTransition;
    private updateRelatedFields;
    private emitStateEvents;
    getTransitionHistory(chatId: string): Promise<ChatStateTransition[]>;
    canTransition(fromStatus: ChatStatus, toStatus: ChatStatus): boolean;
}
export {};
