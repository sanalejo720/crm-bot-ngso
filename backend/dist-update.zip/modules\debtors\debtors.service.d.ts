import { Repository } from 'typeorm';
import { Debtor, DocumentType } from './entities/debtor.entity';
import { CreateDebtorDto } from './dto/create-debtor.dto';
import { UploadResultDto } from './dto/upload-result.dto';
export declare class DebtorsService {
    private debtorRepository;
    private readonly logger;
    constructor(debtorRepository: Repository<Debtor>);
    create(createDebtorDto: CreateDebtorDto): Promise<Debtor>;
    findByDocument(documentType: DocumentType, documentNumber: string): Promise<Debtor | null>;
    findByDocumentNumber(documentNumber: string): Promise<Debtor | null>;
    private normalizePhone;
    findByPhone(phone: string): Promise<Debtor | null>;
    findAll(page?: number, limit?: number): Promise<{
        data: Debtor[];
        total: number;
    }>;
    update(id: string, updateData: Partial<CreateDebtorDto>): Promise<Debtor>;
    updateLastContacted(id: string): Promise<void>;
    uploadFromFile(fileBuffer: Buffer, filename: string): Promise<UploadResultDto>;
    private parseCSV;
    private parseExcel;
    private normalizeRowKeys;
    private validateDebtorRow;
    private normalizeDocumentType;
    private parseDate;
    uploadFromCsv(fileBuffer: Buffer): Promise<{
        created: number;
        updated: number;
        errors: string[];
    }>;
    remove(id: string): Promise<void>;
}
