import { Repository } from 'typeorm';
import { Message } from '../messages/entities/message.entity';
import { EventEmitter2 } from '@nestjs/event-emitter';
export interface OffensiveWordMatch {
    word: string;
    category: 'abuse' | 'threat' | 'discrimination' | 'profanity';
    severity: 'low' | 'medium' | 'high' | 'critical';
}
export interface MessageAlert {
    messageId: string;
    chatId: string;
    direction: 'inbound' | 'outbound';
    sender: 'agent' | 'client';
    content: string;
    matches: OffensiveWordMatch[];
    timestamp: Date;
    agentId?: string;
    agentName?: string;
}
export declare class MonitoringService {
    private messageRepository;
    private eventEmitter;
    private readonly logger;
    private readonly agentOffensiveWords;
    private readonly clientOffensiveWords;
    constructor(messageRepository: Repository<Message>, eventEmitter: EventEmitter2);
    analyzeMessage(messageId: string, chatId: string, content: string, direction: 'inbound' | 'outbound', senderType: 'agent' | 'client', agentId?: string, agentName?: string): MessageAlert | null;
    getNumberStats(numberId: string, days?: number): Promise<any>;
    getNumbersRanking(limit?: number, days?: number): Promise<any[]>;
    getRecentAlerts(limit?: number): Promise<any[]>;
    addCustomOffensiveWord(word: string, category: 'abuse' | 'threat' | 'discrimination' | 'profanity', severity: 'low' | 'medium' | 'high' | 'critical', target: 'agent' | 'client' | 'both'): void;
    getOffensiveWords(): any;
}
