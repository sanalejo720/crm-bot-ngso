export declare class CreateChatDto {
    externalId: string;
    contactPhone: string;
    contactName?: string;
    campaignId: string;
    whatsappNumberId: string;
    tags?: string[];
    priority?: number;
    metadata?: Record<string, any>;
}
