"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuickRepliesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const quick_replies_service_1 = require("./quick-replies.service");
const create_quick_reply_dto_1 = require("./dto/create-quick-reply.dto");
const update_quick_reply_dto_1 = require("./dto/update-quick-reply.dto");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const seed_quick_replies_service_1 = require("../../scripts/seed-quick-replies.service");
let QuickRepliesController = class QuickRepliesController {
    constructor(quickRepliesService, seedService) {
        this.quickRepliesService = quickRepliesService;
        this.seedService = seedService;
    }
    create(req, createDto) {
        return this.quickRepliesService.create(req.user.id, createDto);
    }
    findAll(req, campaignId, category) {
        return this.quickRepliesService.findAll(req.user.id, campaignId, category);
    }
    getStats(req) {
        return this.quickRepliesService.getStats(req.user.id);
    }
    findOne(id) {
        return this.quickRepliesService.findOne(id);
    }
    async applyTemplate(id, variables) {
        const content = await this.quickRepliesService.applyTemplate(id, variables);
        return { content };
    }
    findByShortcut(req, shortcut, campaignId) {
        return this.quickRepliesService.findByShortcut(shortcut, req.user.id, campaignId);
    }
    update(req, id, updateDto) {
        return this.quickRepliesService.update(id, req.user.id, updateDto);
    }
    remove(req, id) {
        return this.quickRepliesService.remove(id, req.user.id);
    }
    async seedTemplates() {
        await this.seedService.seed();
        return {
            success: true,
            message: 'Plantillas predeterminadas creadas exitosamente',
        };
    }
};
exports.QuickRepliesController = QuickRepliesController;
__decorate([
    (0, common_1.Post)(),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'templates', action: 'create' }),
    (0, swagger_1.ApiOperation)({ summary: 'Crear plantilla de mensaje rápido' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'Plantilla creada exitosamente' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Shortcut duplicado' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, create_quick_reply_dto_1.CreateQuickReplyDto]),
    __metadata("design:returntype", void 0)
], QuickRepliesController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'templates', action: 'read' }),
    (0, swagger_1.ApiOperation)({ summary: 'Listar plantillas disponibles' }),
    (0, swagger_1.ApiQuery)({ name: 'campaignId', required: false, description: 'Filtrar por campaña' }),
    (0, swagger_1.ApiQuery)({ name: 'category', required: false, description: 'Filtrar por categoría' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Lista de plantillas' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Query)('campaignId')),
    __param(2, (0, common_1.Query)('category')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", void 0)
], QuickRepliesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('stats'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'templates', action: 'read' }),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas de uso de plantillas' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Estadísticas de uso' }),
    __param(0, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], QuickRepliesController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'templates', action: 'read' }),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener plantilla por ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Plantilla encontrada' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Plantilla no encontrada' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], QuickRepliesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(':id/apply'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'messages', action: 'create' }),
    (0, swagger_1.ApiOperation)({ summary: 'Aplicar plantilla con reemplazo de variables' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Contenido generado con variables reemplazadas' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Plantilla no encontrada' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], QuickRepliesController.prototype, "applyTemplate", null);
__decorate([
    (0, common_1.Get)('shortcut/:shortcut'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'templates', action: 'read' }),
    (0, swagger_1.ApiOperation)({ summary: 'Buscar plantilla por shortcut' }),
    (0, swagger_1.ApiQuery)({ name: 'campaignId', required: false, description: 'Campaña actual' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Plantilla encontrada' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Plantilla no encontrada' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Param)('shortcut')),
    __param(2, (0, common_1.Query)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", void 0)
], QuickRepliesController.prototype, "findByShortcut", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'templates', action: 'update' }),
    (0, swagger_1.ApiOperation)({ summary: 'Actualizar plantilla' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Plantilla actualizada' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Plantilla no encontrada' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, update_quick_reply_dto_1.UpdateQuickReplyDto]),
    __metadata("design:returntype", void 0)
], QuickRepliesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'templates', action: 'delete' }),
    (0, swagger_1.ApiOperation)({ summary: 'Eliminar plantilla' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Plantilla eliminada' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Plantilla no encontrada' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], QuickRepliesController.prototype, "remove", null);
__decorate([
    (0, common_1.Post)('seed'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'templates', action: 'create' }),
    (0, swagger_1.ApiOperation)({ summary: 'Crear plantillas predeterminadas (seed)' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Plantillas creadas exitosamente' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], QuickRepliesController.prototype, "seedTemplates", null);
exports.QuickRepliesController = QuickRepliesController = __decorate([
    (0, swagger_1.ApiTags)('quick-replies'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, common_1.Controller)('quick-replies'),
    __metadata("design:paramtypes", [quick_replies_service_1.QuickRepliesService,
        seed_quick_replies_service_1.QuickRepliesSeedService])
], QuickRepliesController);
//# sourceMappingURL=quick-replies.controller.js.map