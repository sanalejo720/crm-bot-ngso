import { WorkdayService } from './workday.service';
import { ClockInDto, ClockOutDto, StartPauseDto, EndPauseDto, GetWorkdayStatsDto } from './dto/workday.dto';
export declare class WorkdayController {
    private readonly workdayService;
    constructor(workdayService: WorkdayService);
    clockIn(req: any, dto: ClockInDto): Promise<{
        success: boolean;
        workday: import("./entities/agent-workday.entity").AgentWorkday;
        message: string;
    }>;
    clockOut(req: any, dto: ClockOutDto): Promise<{
        success: boolean;
        workday: import("./entities/agent-workday.entity").AgentWorkday;
        summary: {
            totalHours: number;
            totalMinutes: number;
            pauseMinutes: number;
            productiveMinutes: number;
        };
        message: string;
    }>;
    startPause(req: any, dto: StartPauseDto): Promise<{
        success: boolean;
        pause: import("./entities/agent-pause.entity").AgentPause;
        message: string;
    }>;
    endPause(req: any, dto: EndPauseDto): Promise<{
        success: boolean;
        pause: import("./entities/agent-pause.entity").AgentPause;
        duration: {
            minutes: number;
            hours: number;
        };
        message: string;
    }>;
    getCurrentWorkday(req: any): Promise<{
        totalWorkMinutes: number;
        totalPauseMinutes: number;
        totalProductiveMinutes: number;
        activePause: import("./entities/agent-pause.entity").AgentPause;
        isWorking: boolean;
        isOnPause: boolean;
        id: string;
        agentId: string;
        agent: import("../users/entities/user.entity").User;
        workDate: Date;
        clockInTime: Date;
        clockOutTime: Date;
        currentStatus: import("./entities/agent-workday.entity").WorkdayStatus;
        chatsHandled: number;
        messagesSent: number;
        avgResponseTimeSeconds: number;
        notes: string;
        pauses: import("./entities/agent-pause.entity").AgentPause[];
        events: import("./entities/agent-workday-event.entity").AgentWorkdayEvent[];
        createdAt: Date;
        updatedAt: Date;
    }>;
    getHistory(req: any, startDate?: string, endDate?: string): Promise<import("./entities/agent-workday.entity").AgentWorkday[]>;
    getStats(req: any, query: GetWorkdayStatsDto): Promise<{
        stats: {
            totalDays: number;
            totalWorkMinutes: number;
            totalPauseMinutes: number;
            totalProductiveMinutes: number;
            avgWorkMinutes: number;
            avgPauseMinutes: number;
            avgProductiveMinutes: number;
        };
        workdays: import("./entities/agent-workday.entity").AgentWorkday[];
    }>;
    getAgentWorkday(agentId: string): Promise<{
        totalWorkMinutes: number;
        totalPauseMinutes: number;
        totalProductiveMinutes: number;
        activePause: import("./entities/agent-pause.entity").AgentPause;
        isWorking: boolean;
        isOnPause: boolean;
        id: string;
        agentId: string;
        agent: import("../users/entities/user.entity").User;
        workDate: Date;
        clockInTime: Date;
        clockOutTime: Date;
        currentStatus: import("./entities/agent-workday.entity").WorkdayStatus;
        chatsHandled: number;
        messagesSent: number;
        avgResponseTimeSeconds: number;
        notes: string;
        pauses: import("./entities/agent-pause.entity").AgentPause[];
        events: import("./entities/agent-workday-event.entity").AgentWorkdayEvent[];
        createdAt: Date;
        updatedAt: Date;
    }>;
    getAttendanceReport(startDate: string, endDate: string, agentId?: string): Promise<{
        records: any[];
        summary: {
            totalAgents: number;
            presentToday: number;
            absentToday: number;
            lateToday: number;
            onPauseNow: number;
            avgWorkHours: number;
            avgProductiveHours: number;
        };
    }>;
    getAllAgentsStatus(): Promise<{
        success: boolean;
        data: {
            agentId: string;
            agentName: string;
            agentState: import("../users/entities/user.entity").AgentState;
            isOnline: boolean;
            workday: {
                clockInTime: Date;
                currentStatus: import("./entities/agent-workday.entity").WorkdayStatus;
                totalWorkMinutes: number;
                totalPauseMinutes: number;
                activePause: import("./entities/agent-pause.entity").AgentPause;
            };
        }[];
    }>;
}
