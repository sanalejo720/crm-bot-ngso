import { BotNode } from './bot-node.entity';
export declare enum BotFlowStatus {
    ACTIVE = "active",
    INACTIVE = "inactive",
    DRAFT = "draft"
}
export declare class BotFlow {
    id: string;
    name: string;
    description: string;
    status: BotFlowStatus;
    startNodeId: string;
    variables: {
        [key: string]: {
            name: string;
            type: 'string' | 'number' | 'boolean' | 'date';
            defaultValue?: any;
        };
    };
    settings: {
        maxInactivityTime?: number;
        transferToAgentOnError?: boolean;
        fallbackMessage?: string;
    };
    nodes: BotNode[];
    createdAt: Date;
    updatedAt: Date;
}
