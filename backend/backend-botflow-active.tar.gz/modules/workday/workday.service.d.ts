import { Repository } from 'typeorm';
import { AgentWorkday, WorkdayStatus } from './entities/agent-workday.entity';
import { AgentPause, PauseType } from './entities/agent-pause.entity';
import { AgentWorkdayEvent } from './entities/agent-workday-event.entity';
import { User } from '../users/entities/user.entity';
export declare class WorkdayService {
    private workdayRepository;
    private pauseRepository;
    private eventRepository;
    private userRepository;
    private readonly logger;
    constructor(workdayRepository: Repository<AgentWorkday>, pauseRepository: Repository<AgentPause>, eventRepository: Repository<AgentWorkdayEvent>, userRepository: Repository<User>);
    clockIn(agentId: string, notes?: string): Promise<{
        success: boolean;
        workday: AgentWorkday;
        message: string;
    }>;
    clockOut(agentId: string, notes?: string): Promise<{
        success: boolean;
        workday: AgentWorkday;
        summary: {
            totalHours: number;
            totalMinutes: number;
            pauseMinutes: number;
            productiveMinutes: number;
        };
        message: string;
    }>;
    startPause(agentId: string, pauseType: PauseType, reason?: string): Promise<{
        success: boolean;
        pause: AgentPause;
        message: string;
    }>;
    endPause(agentId: string, pauseId: string): Promise<{
        success: boolean;
        pause: AgentPause;
        duration: {
            minutes: number;
            hours: number;
        };
        message: string;
    }>;
    getCurrentWorkday(agentId: string): Promise<{
        totalWorkMinutes: number;
        totalPauseMinutes: number;
        totalProductiveMinutes: number;
        activePause: AgentPause;
        isWorking: boolean;
        isOnPause: boolean;
        id: string;
        agentId: string;
        agent: User;
        workDate: Date;
        clockInTime: Date;
        clockOutTime: Date;
        currentStatus: WorkdayStatus;
        chatsHandled: number;
        messagesSent: number;
        avgResponseTimeSeconds: number;
        notes: string;
        pauses: AgentPause[];
        events: AgentWorkdayEvent[];
        createdAt: Date;
        updatedAt: Date;
    }>;
    getWorkdayHistory(agentId: string, startDate?: Date, endDate?: Date): Promise<AgentWorkday[]>;
    getWorkdayStats(agentId?: string, startDate?: Date, endDate?: Date): Promise<{
        stats: {
            totalDays: number;
            totalWorkMinutes: number;
            totalPauseMinutes: number;
            totalProductiveMinutes: number;
            avgWorkMinutes: number;
            avgPauseMinutes: number;
            avgProductiveMinutes: number;
        };
        workdays: AgentWorkday[];
    }>;
    private createEvent;
    updateWorkdayStats(agentId: string, chatsHandled: number, messagesSent: number): Promise<void>;
}
