"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentEvidencesController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const payment_evidences_service_1 = require("./payment-evidences.service");
const evidence_dto_1 = require("./dto/evidence.dto");
let PaymentEvidencesController = class PaymentEvidencesController {
    constructor(evidencesService) {
        this.evidencesService = evidencesService;
    }
    async uploadEvidence(file, createDto, req) {
        if (!file) {
            throw new common_1.BadRequestException('No se ha proporcionado ningún archivo');
        }
        const evidence = await this.evidencesService.uploadEvidence(file, createDto, req.user.id);
        return {
            success: true,
            data: evidence,
            message: 'Evidencia de pago subida exitosamente',
            timestamp: new Date().toISOString(),
        };
    }
    async findAll(query, req) {
        const userRole = req.user.role?.name;
        const isSupervisorOrAdmin = ['Supervisor', 'Super Admin', 'Administrador'].includes(userRole);
        if (!isSupervisorOrAdmin && !query.uploadedBy) {
            query.uploadedBy = req.user.id;
        }
        const evidences = await this.evidencesService.findAll(query);
        return {
            success: true,
            data: evidences,
            timestamp: new Date().toISOString(),
        };
    }
    async getPendingCount() {
        const count = await this.evidencesService.getPendingCount();
        return {
            success: true,
            data: { count },
            timestamp: new Date().toISOString(),
        };
    }
    async getClientEvidences(clientId) {
        const evidences = await this.evidencesService.getEvidencesByClient(clientId);
        return {
            success: true,
            data: evidences,
            timestamp: new Date().toISOString(),
        };
    }
    async findOne(id) {
        const evidence = await this.evidencesService.findOne(id);
        return {
            success: true,
            data: evidence,
            timestamp: new Date().toISOString(),
        };
    }
    async reviewEvidence(id, reviewDto, req) {
        const evidence = await this.evidencesService.reviewEvidence(id, reviewDto, req.user.id);
        return {
            success: true,
            data: evidence,
            message: `Evidencia ${reviewDto.status === 'approved' ? 'aprobada' : 'rechazada'} exitosamente`,
            timestamp: new Date().toISOString(),
        };
    }
    async deleteEvidence(id) {
        await this.evidencesService.deleteEvidence(id);
        return {
            success: true,
            message: 'Evidencia eliminada exitosamente',
            timestamp: new Date().toISOString(),
        };
    }
};
exports.PaymentEvidencesController = PaymentEvidencesController;
__decorate([
    (0, common_1.Post)('upload'),
    (0, swagger_1.ApiOperation)({ summary: 'Subir evidencia de pago' }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, swagger_1.ApiBody)({
        schema: {
            type: 'object',
            properties: {
                file: {
                    type: 'string',
                    format: 'binary',
                },
                clientId: { type: 'string' },
                paymentAmount: { type: 'number' },
                paymentDate: { type: 'string', format: 'date' },
                notes: { type: 'string' },
                campaignId: { type: 'string' },
                referenceNumber: { type: 'string' },
            },
            required: ['file', 'clientId', 'paymentAmount', 'paymentDate'],
        },
    }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'evidences', action: 'create' }),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, evidence_dto_1.CreateEvidenceDto, Object]),
    __metadata("design:returntype", Promise)
], PaymentEvidencesController.prototype, "uploadEvidence", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Listar evidencias de pago' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'evidences', action: 'read' }),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [evidence_dto_1.QueryEvidencesDto, Object]),
    __metadata("design:returntype", Promise)
], PaymentEvidencesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('pending/count'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener cantidad de evidencias pendientes' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'evidences', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PaymentEvidencesController.prototype, "getPendingCount", null);
__decorate([
    (0, common_1.Get)('client/:clientId'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener evidencias de un cliente' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'evidences', action: 'read' }),
    __param(0, (0, common_1.Param)('clientId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentEvidencesController.prototype, "getClientEvidences", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener una evidencia por ID' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'evidences', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentEvidencesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id/review'),
    (0, swagger_1.ApiOperation)({ summary: 'Revisar evidencia (aprobar/rechazar)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'evidences', action: 'review' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, evidence_dto_1.ReviewEvidenceDto, Object]),
    __metadata("design:returntype", Promise)
], PaymentEvidencesController.prototype, "reviewEvidence", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Eliminar evidencia de pago' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'evidences', action: 'delete' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentEvidencesController.prototype, "deleteEvidence", null);
exports.PaymentEvidencesController = PaymentEvidencesController = __decorate([
    (0, swagger_1.ApiTags)('Payment Evidences'),
    (0, common_1.Controller)('payment-evidences'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [payment_evidences_service_1.PaymentEvidencesService])
], PaymentEvidencesController);
//# sourceMappingURL=payment-evidences.controller.js.map