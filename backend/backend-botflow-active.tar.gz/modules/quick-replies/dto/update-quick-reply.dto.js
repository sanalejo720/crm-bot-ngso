"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateQuickReplyDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const create_quick_reply_dto_1 = require("./create-quick-reply.dto");
class UpdateQuickReplyDto extends (0, swagger_1.PartialType)(create_quick_reply_dto_1.CreateQuickReplyDto) {
}
exports.UpdateQuickReplyDto = UpdateQuickReplyDto;
//# sourceMappingURL=update-quick-reply.dto.js.map