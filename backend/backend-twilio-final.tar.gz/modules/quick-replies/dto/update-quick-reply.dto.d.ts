import { CreateQuickReplyDto } from './create-quick-reply.dto';
declare const UpdateQuickReplyDto_base: import("@nestjs/common").Type<Partial<CreateQuickReplyDto>>;
export declare class UpdateQuickReplyDto extends UpdateQuickReplyDto_base {
}
export {};
