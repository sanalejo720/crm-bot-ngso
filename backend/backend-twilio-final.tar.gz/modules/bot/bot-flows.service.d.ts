import { Repository } from 'typeorm';
import { BotFlow } from './entities/bot-flow.entity';
import { BotNode } from './entities/bot-node.entity';
import { CreateBotFlowDto, UpdateBotFlowDto, CreateBotNodeDto, UpdateBotNodeDto } from './dto/bot-flow.dto';
export declare class BotFlowsService {
    private botFlowRepository;
    private botNodeRepository;
    private readonly logger;
    constructor(botFlowRepository: Repository<BotFlow>, botNodeRepository: Repository<BotNode>);
    findAll(status?: string, page?: number, limit?: number): Promise<{
        data: BotFlow[];
        total: number;
    }>;
    findOneWithNodes(id: string): Promise<BotFlow>;
    create(createDto: CreateBotFlowDto): Promise<BotFlow>;
    update(id: string, updateDto: UpdateBotFlowDto): Promise<BotFlow>;
    remove(id: string): Promise<void>;
    duplicate(id: string): Promise<BotFlow>;
    publish(id: string): Promise<BotFlow>;
    createNode(flowId: string, createDto: CreateBotNodeDto): Promise<BotNode>;
    createNodesBulk(flowId: string, nodesDto: CreateBotNodeDto[]): Promise<BotNode[]>;
    updateNode(nodeId: string, updateDto: UpdateBotNodeDto): Promise<BotNode>;
    removeNode(nodeId: string): Promise<void>;
    getStats(id: string): Promise<any>;
}
