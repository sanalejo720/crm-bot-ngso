"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var QueueService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueueService = void 0;
const common_1 = require("@nestjs/common");
const bull_1 = require("@nestjs/bull");
const event_emitter_1 = require("@nestjs/event-emitter");
const chats_service_1 = require("../chats/chats.service");
const users_service_1 = require("../users/users.service");
const chat_entity_1 = require("../chats/entities/chat.entity");
const round_robin_strategy_1 = require("./strategies/round-robin.strategy");
const least_busy_strategy_1 = require("./strategies/least-busy.strategy");
const skills_based_strategy_1 = require("./strategies/skills-based.strategy");
let QueueService = QueueService_1 = class QueueService {
    constructor(chatAssignmentQueue, chatsService, usersService, roundRobinStrategy, leastBusyStrategy, skillsBasedStrategy) {
        this.chatAssignmentQueue = chatAssignmentQueue;
        this.chatsService = chatsService;
        this.usersService = usersService;
        this.roundRobinStrategy = roundRobinStrategy;
        this.leastBusyStrategy = leastBusyStrategy;
        this.skillsBasedStrategy = skillsBasedStrategy;
        this.logger = new common_1.Logger(QueueService_1.name);
        this.strategies = new Map([
            ['round-robin', roundRobinStrategy],
            ['least-busy', leastBusyStrategy],
            ['skills-based', skillsBasedStrategy],
        ]);
    }
    async handleChatCreated(chat) {
        this.logger.log(`Chat creado detectado: ${chat.id}`);
        const campaign = chat.campaign;
        if (!campaign || !campaign.settings?.autoAssignment) {
            this.logger.log('Auto-asignación deshabilitada para esta campaña');
            return;
        }
        await this.addChatToQueue(chat.id, chat.campaignId, campaign.settings.assignmentStrategy);
    }
    async addChatToQueue(chatId, campaignId, strategy = 'least-busy') {
        const job = await this.chatAssignmentQueue.add('assign-chat', {
            chatId,
            campaignId,
            strategy,
        }, {
            attempts: 3,
            backoff: {
                type: 'exponential',
                delay: 2000,
            },
            removeOnComplete: true,
        });
        this.logger.log(`Chat ${chatId} agregado a cola con job ID: ${job.id}`);
    }
    async processAssignment(job) {
        const { chatId, campaignId, strategy } = job;
        this.logger.log(`Procesando asignación de chat ${chatId} con estrategia ${strategy}`);
        try {
            const chat = await this.chatsService.findOne(chatId);
            if (chat.assignedAgentId) {
                this.logger.log(`Chat ${chatId} ya fue asignado previamente`);
                return;
            }
            const availableAgents = await this.usersService.getAvailableAgents(campaignId);
            if (availableAgents.length === 0) {
                this.logger.warn(`No hay agentes disponibles para campaña ${campaignId}`);
                throw new Error('No hay agentes disponibles');
            }
            const routingStrategy = this.strategies.get(strategy) || this.leastBusyStrategy;
            const selectedAgent = routingStrategy.selectAgent(availableAgents, chat);
            if (!selectedAgent) {
                throw new Error('No se pudo seleccionar un agente');
            }
            await this.chatsService.assign(chatId, selectedAgent.id);
            this.logger.log(`Chat ${chatId} asignado exitosamente a ${selectedAgent.fullName}`);
        }
        catch (error) {
            this.logger.error(`Error procesando asignación de chat ${chatId}: ${error.message}`);
            throw error;
        }
    }
    async getQueueStats() {
        const [waiting, active, completed, failed] = await Promise.all([
            this.chatAssignmentQueue.getWaitingCount(),
            this.chatAssignmentQueue.getActiveCount(),
            this.chatAssignmentQueue.getCompletedCount(),
            this.chatAssignmentQueue.getFailedCount(),
        ]);
        return {
            waiting,
            active,
            completed,
            failed,
            total: waiting + active,
        };
    }
    async cleanQueue() {
        await this.chatAssignmentQueue.clean(3600000, 'completed');
        await this.chatAssignmentQueue.clean(86400000, 'failed');
        this.logger.log('Cola limpiada');
    }
    async pauseQueue() {
        await this.chatAssignmentQueue.pause();
        this.logger.log('Cola pausada');
    }
    async resumeQueue() {
        await this.chatAssignmentQueue.resume();
        this.logger.log('Cola reanudada');
    }
};
exports.QueueService = QueueService;
__decorate([
    (0, event_emitter_1.OnEvent)('chat.created'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [chat_entity_1.Chat]),
    __metadata("design:returntype", Promise)
], QueueService.prototype, "handleChatCreated", null);
exports.QueueService = QueueService = QueueService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, bull_1.InjectQueue)('chat-assignment')),
    __metadata("design:paramtypes", [Object, chats_service_1.ChatsService,
        users_service_1.UsersService,
        round_robin_strategy_1.RoundRobinStrategy,
        least_busy_strategy_1.LeastBusyStrategy,
        skills_based_strategy_1.SkillsBasedStrategy])
], QueueService);
//# sourceMappingURL=queue.service.js.map