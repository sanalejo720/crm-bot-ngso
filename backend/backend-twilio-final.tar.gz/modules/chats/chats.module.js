"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatsModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const chats_service_1 = require("./chats.service");
const chats_export_service_1 = require("./chats-export.service");
const chats_controller_1 = require("./chats.controller");
const chat_entity_1 = require("./entities/chat.entity");
const message_entity_1 = require("../messages/entities/message.entity");
const user_entity_1 = require("../users/entities/user.entity");
const debtor_entity_1 = require("../debtors/entities/debtor.entity");
const users_module_1 = require("../users/users.module");
const whatsapp_module_1 = require("../whatsapp/whatsapp.module");
const evidences_module_1 = require("../evidences/evidences.module");
const email_service_1 = require("../../common/services/email.service");
let ChatsModule = class ChatsModule {
};
exports.ChatsModule = ChatsModule;
exports.ChatsModule = ChatsModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([chat_entity_1.Chat, message_entity_1.Message, user_entity_1.User, debtor_entity_1.Debtor]),
            users_module_1.UsersModule,
            (0, common_1.forwardRef)(() => whatsapp_module_1.WhatsappModule),
            evidences_module_1.EvidencesModule,
        ],
        controllers: [chats_controller_1.ChatsController],
        providers: [chats_service_1.ChatsService, chats_export_service_1.ChatsExportService, email_service_1.EmailService],
        exports: [chats_service_1.ChatsService],
    })
], ChatsModule);
//# sourceMappingURL=chats.module.js.map