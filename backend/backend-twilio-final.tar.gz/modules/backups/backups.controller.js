"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BackupsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const backups_service_1 = require("./backups.service");
const backup_dto_1 = require("./dto/backup.dto");
let BackupsController = class BackupsController {
    constructor(backupsService) {
        this.backupsService = backupsService;
    }
    async create(createBackupDto, user) {
        const backup = await this.backupsService.createBackup(createBackupDto, user.id);
        return {
            success: true,
            message: 'Backup iniciado. GUARDA LA CONTRASEÑA MAESTRA, no se volverá a mostrar.',
            data: {
                id: backup.id,
                fileName: backup.fileName,
                status: backup.status,
                masterPassword: backup.masterPassword,
                createdAt: backup.createdAt,
            },
        };
    }
    async findAll() {
        const backups = await this.backupsService.findAll();
        return {
            success: true,
            data: backups.map(b => ({
                id: b.id,
                fileName: b.fileName,
                fileSize: b.fileSize,
                status: b.status,
                type: b.type,
                isEncrypted: b.isEncrypted,
                createdAt: b.createdAt,
                completedAt: b.completedAt,
                createdBy: b.createdBy ? {
                    id: b.createdBy.id,
                    name: b.createdBy.fullName,
                } : null,
                metadata: b.metadata,
            })),
        };
    }
    async findOne(id) {
        const backup = await this.backupsService.findOne(id);
        return {
            success: true,
            data: {
                id: backup.id,
                fileName: backup.fileName,
                fileSize: backup.fileSize,
                status: backup.status,
                type: backup.type,
                isEncrypted: backup.isEncrypted,
                createdAt: backup.createdAt,
                completedAt: backup.completedAt,
                errorMessage: backup.errorMessage,
                createdBy: backup.createdBy ? {
                    id: backup.createdBy.id,
                    name: backup.createdBy.fullName,
                    email: backup.createdBy.email,
                } : null,
                metadata: backup.metadata,
            },
        };
    }
    async download(id, downloadDto, res) {
        const { buffer, fileName } = await this.backupsService.downloadBackup(id, downloadDto.password);
        res.set({
            'Content-Type': 'application/zip',
            'Content-Disposition': `attachment; filename="${fileName}"`,
            'Content-Length': buffer.length,
        });
        res.send(buffer);
    }
    async remove(id) {
        await this.backupsService.remove(id);
        return {
            success: true,
            message: 'Backup eliminado correctamente',
        };
    }
};
exports.BackupsController = BackupsController;
__decorate([
    (0, common_1.Post)(),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'backups', action: 'create' }),
    (0, swagger_1.ApiOperation)({
        summary: 'Crear nuevo backup cifrado',
        description: 'Genera un backup completo de la base de datos y archivos, cifrado con AES-256. Retorna la contraseña maestra ÚNICA VEZ.'
    }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: 'Backup creado exitosamente. La contraseña maestra se retorna solo en esta respuesta.',
    }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [backup_dto_1.CreateBackupDto, Object]),
    __metadata("design:returntype", Promise)
], BackupsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'backups', action: 'read' }),
    (0, swagger_1.ApiOperation)({ summary: 'Listar todos los backups' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BackupsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'backups', action: 'read' }),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener detalles de un backup' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BackupsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(':id/download'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'backups', action: 'download' }),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Descargar backup cifrado',
        description: 'Descarga el archivo de backup. Requiere la contraseña maestra para descifrar.'
    }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, backup_dto_1.DownloadBackupDto, Object]),
    __metadata("design:returntype", Promise)
], BackupsController.prototype, "download", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'backups', action: 'delete' }),
    (0, swagger_1.ApiOperation)({ summary: 'Eliminar un backup' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BackupsController.prototype, "remove", null);
exports.BackupsController = BackupsController = __decorate([
    (0, swagger_1.ApiTags)('backups'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, common_1.Controller)('backups'),
    __metadata("design:paramtypes", [backups_service_1.BackupsService])
], BackupsController);
//# sourceMappingURL=backups.controller.js.map