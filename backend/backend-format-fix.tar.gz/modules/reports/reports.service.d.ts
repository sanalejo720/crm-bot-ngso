import { Repository } from 'typeorm';
import { Chat } from '../chats/entities/chat.entity';
import { Message } from '../messages/entities/message.entity';
import { User, AgentState } from '../users/entities/user.entity';
import { Client } from '../clients/entities/client.entity';
import { Task } from '../tasks/entities/task.entity';
export interface DateRange {
    startDate: Date;
    endDate: Date;
}
export interface AgentMetrics {
    agentId: string;
    agentName: string;
    totalChats: number;
    activeChats: number;
    resolvedChats: number;
    totalMessages: number;
    averageResponseTime: number;
    averageHandlingTime: number;
    sentMessagesPerHour: number;
    satisfactionRate?: number;
    state: AgentState;
}
export interface CampaignMetrics {
    campaignId: string;
    campaignName: string;
    totalChats: number;
    activeChats: number;
    waitingChats: number;
    resolvedChats: number;
    totalClients: number;
    newLeads: number;
    qualifiedLeads: number;
    convertedLeads: number;
    averageResponseTime: number;
    averageHandlingTime: number;
}
export interface SystemMetrics {
    totalChats: number;
    activeChats: number;
    waitingChats: number;
    botChats: number;
    totalAgents: number;
    availableAgents: number;
    busyAgents: number;
    offlineAgents: number;
    totalMessages24h: number;
    averageResponseTime: number;
    queueSize: number;
}
export declare class ReportsService {
    private chatRepository;
    private messageRepository;
    private userRepository;
    private clientRepository;
    private taskRepository;
    private readonly logger;
    constructor(chatRepository: Repository<Chat>, messageRepository: Repository<Message>, userRepository: Repository<User>, clientRepository: Repository<Client>, taskRepository: Repository<Task>);
    getSystemMetrics(): Promise<SystemMetrics>;
    getAgentMetrics(agentId: string, dateRange?: DateRange): Promise<AgentMetrics>;
    getCampaignMetrics(campaignId: string, dateRange?: DateRange): Promise<CampaignMetrics>;
    getAllAgentsMetrics(dateRange?: DateRange): Promise<AgentMetrics[]>;
    getAgentRanking(metric: 'totalChats' | 'resolvedChats' | 'averageResponseTime' | 'sentMessagesPerHour', dateRange?: DateRange, limit?: number): Promise<AgentMetrics[]>;
    private calculateAverageResponseTime;
    private calculateAgentResponseTime;
    private calculateCampaignResponseTime;
    private calculateAgentHandlingTime;
    private calculateCampaignHandlingTime;
    getChatsTrend(dateRange: DateRange, campaignId?: string): Promise<any[]>;
    getChatsDistribution(campaignId?: string): Promise<any>;
    getPendingTasksCount(): Promise<number>;
    getCollectionSummary(): Promise<{
        totalDebt: number;
        recoveredToday: number;
    }>;
    getAgentsPerformance(): Promise<any[]>;
    getAgentStats(agentId: string): Promise<{
        activeChats: number;
        totalChatsToday: number;
        maxConcurrentChats: number;
        messagesCount: number;
        promisesObtained: number;
        recoveredAmount: number;
        averageResponseTime: number;
        completionRate: number;
    }>;
    getAgentActivity(agentId: string): Promise<any[]>;
}
