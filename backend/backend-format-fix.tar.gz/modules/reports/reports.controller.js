"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const reports_service_1 = require("./reports.service");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
let ReportsController = class ReportsController {
    constructor(reportsService) {
        this.reportsService = reportsService;
    }
    getSystemMetrics() {
        return this.reportsService.getSystemMetrics();
    }
    async getDashboard() {
        const metrics = await this.reportsService.getSystemMetrics();
        const pendingTasks = await this.reportsService.getPendingTasksCount();
        const collectionSummary = await this.reportsService.getCollectionSummary();
        return {
            success: true,
            data: {
                totalAgents: metrics.totalAgents,
                activeAgents: metrics.availableAgents + metrics.busyAgents,
                totalChats: metrics.totalChats,
                activeChats: metrics.activeChats,
                totalDebt: collectionSummary.totalDebt,
                recoveredToday: collectionSummary.recoveredToday,
                pendingTasks,
            },
        };
    }
    async getDailyReport(date) {
        const targetDate = date ? new Date(date) : new Date();
        const startOfDay = new Date(targetDate.setHours(0, 0, 0, 0));
        const endOfDay = new Date(targetDate.setHours(23, 59, 59, 999));
        const chatsTrend = await this.reportsService.getChatsTrend({
            startDate: startOfDay,
            endDate: endOfDay
        });
        return {
            success: true,
            data: chatsTrend,
        };
    }
    async getChatStatistics(campaignId) {
        const distribution = await this.reportsService.getChatsDistribution(campaignId);
        return {
            success: true,
            data: distribution,
        };
    }
    async getSystemStats() {
        const metrics = await this.reportsService.getSystemMetrics();
        const pendingTasks = await this.reportsService.getPendingTasksCount();
        const collectionSummary = await this.reportsService.getCollectionSummary();
        return {
            totalAgents: metrics.totalAgents,
            activeAgents: metrics.availableAgents + metrics.busyAgents,
            totalChats: metrics.totalChats,
            activeChats: metrics.activeChats,
            totalDebt: collectionSummary.totalDebt,
            recoveredToday: collectionSummary.recoveredToday,
            pendingTasks,
        };
    }
    async getMyStats(userId) {
        return this.reportsService.getAgentStats(userId);
    }
    async getMyActivity(userId) {
        return this.reportsService.getAgentActivity(userId);
    }
    async getAgentsPerformance() {
        return this.reportsService.getAgentsPerformance();
    }
    getAgentMetrics(agentId, startDate, endDate) {
        const dateRange = startDate && endDate
            ? { startDate: new Date(startDate), endDate: new Date(endDate) }
            : undefined;
        return this.reportsService.getAgentMetrics(agentId, dateRange);
    }
    getAllAgentsMetrics(startDate, endDate) {
        const dateRange = startDate && endDate
            ? { startDate: new Date(startDate), endDate: new Date(endDate) }
            : undefined;
        return this.reportsService.getAllAgentsMetrics(dateRange);
    }
    getAgentRanking(metric, startDate, endDate, limit) {
        const dateRange = startDate && endDate
            ? { startDate: new Date(startDate), endDate: new Date(endDate) }
            : undefined;
        return this.reportsService.getAgentRanking(metric, dateRange, limit ? parseInt(limit) : 10);
    }
    getCampaignMetrics(campaignId, startDate, endDate) {
        const dateRange = startDate && endDate
            ? { startDate: new Date(startDate), endDate: new Date(endDate) }
            : undefined;
        return this.reportsService.getCampaignMetrics(campaignId, dateRange);
    }
    getChatsTrend(startDate, endDate, campaignId) {
        const dateRange = { startDate: new Date(startDate), endDate: new Date(endDate) };
        return this.reportsService.getChatsTrend(dateRange, campaignId);
    }
    getChatsDistribution(campaignId) {
        return this.reportsService.getChatsDistribution(campaignId);
    }
};
exports.ReportsController = ReportsController;
__decorate([
    (0, common_1.Get)('system'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener métricas del sistema en tiempo real' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "getSystemMetrics", null);
__decorate([
    (0, common_1.Get)('dashboard'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener datos del dashboard del supervisor' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getDashboard", null);
__decorate([
    (0, common_1.Get)('daily'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener reporte diario' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiQuery)({ name: 'date', required: false, type: String }),
    __param(0, (0, common_1.Query)('date')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getDailyReport", null);
__decorate([
    (0, common_1.Get)('chats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas de chats' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiQuery)({ name: 'campaignId', required: false, type: String }),
    __param(0, (0, common_1.Query)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getChatStatistics", null);
__decorate([
    (0, common_1.Get)('system/stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas del dashboard' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getSystemStats", null);
__decorate([
    (0, common_1.Get)('agent/stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas del agente actual' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getMyStats", null);
__decorate([
    (0, common_1.Get)('agent/activity'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener actividad reciente del agente actual' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getMyActivity", null);
__decorate([
    (0, common_1.Get)('agents/performance'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener rendimiento de todos los agentes para dashboard' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ReportsController.prototype, "getAgentsPerformance", null);
__decorate([
    (0, common_1.Get)('agents/:agentId'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener métricas de un agente específico' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, type: String }),
    __param(0, (0, common_1.Param)('agentId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "getAgentMetrics", null);
__decorate([
    (0, common_1.Get)('agents'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener métricas de todos los agentes' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, type: String }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "getAllAgentsMetrics", null);
__decorate([
    (0, common_1.Get)('agents/ranking/:metric'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener ranking de agentes por métrica' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, type: Number }),
    __param(0, (0, common_1.Param)('metric')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __param(3, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "getAgentRanking", null);
__decorate([
    (0, common_1.Get)('campaigns/:campaignId'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener métricas de una campaña específica' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, type: String }),
    __param(0, (0, common_1.Param)('campaignId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "getCampaignMetrics", null);
__decorate([
    (0, common_1.Get)('trends/chats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener tendencia de chats por día' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: true, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: true, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'campaignId', required: false, type: String }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "getChatsTrend", null);
__decorate([
    (0, common_1.Get)('distribution/chats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener distribución de chats por estado' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'reports', action: 'read' }),
    (0, swagger_1.ApiQuery)({ name: 'campaignId', required: false, type: String }),
    __param(0, (0, common_1.Query)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ReportsController.prototype, "getChatsDistribution", null);
exports.ReportsController = ReportsController = __decorate([
    (0, swagger_1.ApiTags)('reports'),
    (0, common_1.Controller)('reports'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [reports_service_1.ReportsService])
], ReportsController);
//# sourceMappingURL=reports.controller.js.map