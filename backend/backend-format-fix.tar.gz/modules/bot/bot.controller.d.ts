import { BotEngineService } from './bot-engine.service';
export declare class BotController {
    private readonly botEngineService;
    constructor(botEngineService: BotEngineService);
    startFlow(chatId: string, flowId: string): Promise<{
        success: boolean;
        message: string;
    }>;
    processInput(chatId: string, body: {
        userInput: string;
    }): Promise<{
        success: boolean;
        message: string;
    }>;
}
