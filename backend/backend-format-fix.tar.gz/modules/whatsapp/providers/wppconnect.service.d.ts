import { OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Repository } from 'typeorm';
import { WhatsappNumber } from '../entities/whatsapp-number.entity';
export declare class WppConnectService implements OnModuleInit {
    private readonly configService;
    private readonly eventEmitter;
    private readonly whatsappNumberRepository;
    private readonly logger;
    private clients;
    private readonly secretKey;
    private restoringSessionsInProgress;
    constructor(configService: ConfigService, eventEmitter: EventEmitter2, whatsappNumberRepository: Repository<WhatsappNumber>);
    onModuleInit(): Promise<void>;
    private restoreAllSessions;
    private restoreSession;
    private killZombieProcesses;
    startSession(sessionName: string, numberId?: string): Promise<{
        qrCode?: string;
        status: string;
    }>;
    private setupEventListeners;
    sendTextMessage(sessionName: string, to: string, text: string): Promise<any>;
    sendImageMessage(sessionName: string, to: string, imageUrl: string, caption?: string): Promise<any>;
    sendFileMessage(sessionName: string, to: string, fileUrl: string, filename?: string): Promise<any>;
    closeSession(sessionName: string): Promise<void>;
    getSessionStatus(sessionName: string): Promise<{
        connected: boolean;
        phone?: string;
    }>;
    getActiveSessions(): string[];
    private formatNumber;
    healthCheck(sessionName: string): Promise<boolean>;
    private getExtensionFromMimeType;
}
