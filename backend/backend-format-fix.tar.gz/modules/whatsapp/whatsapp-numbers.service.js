"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WhatsappNumbersService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const whatsapp_number_entity_1 = require("./entities/whatsapp-number.entity");
const wppconnect_service_1 = require("./providers/wppconnect.service");
const meta_service_1 = require("./providers/meta.service");
const event_emitter_1 = require("@nestjs/event-emitter");
const whatsapp_number_entity_2 = require("./entities/whatsapp-number.entity");
let WhatsappNumbersService = class WhatsappNumbersService {
    constructor(whatsappNumberRepository, wppConnectService, metaService, eventEmitter) {
        this.whatsappNumberRepository = whatsappNumberRepository;
        this.wppConnectService = wppConnectService;
        this.metaService = metaService;
        this.eventEmitter = eventEmitter;
        this.MAX_ACTIVE_SESSIONS = 10;
        this.sessionStats = new Map();
    }
    async handleSessionStatusChange(data) {
        if (data.status === 'isLogged' || data.status === 'qrReadSuccess') {
            const number = await this.whatsappNumberRepository.findOne({
                where: [
                    { sessionName: data.sessionName },
                    { phoneNumber: data.sessionName },
                ],
            });
            if (number) {
                number.status = whatsapp_number_entity_2.ConnectionStatus.CONNECTED;
                number.sessionName = data.sessionName;
                number.lastConnectedAt = new Date();
                await this.whatsappNumberRepository.save(number);
                this.eventEmitter.emit('whatsapp.session.connected', {
                    numberId: number.id,
                    sessionName: data.sessionName,
                });
            }
        }
    }
    async create(createDto) {
        const existing = await this.whatsappNumberRepository.findOne({
            where: { phoneNumber: createDto.phoneNumber },
        });
        if (existing) {
            throw new common_1.BadRequestException('Este número ya está registrado');
        }
        const initialStatus = createDto.provider === whatsapp_number_entity_1.WhatsappProvider.TWILIO &&
            createDto.twilioAccountSid &&
            createDto.twilioAuthToken &&
            createDto.twilioPhoneNumber
            ? whatsapp_number_entity_2.ConnectionStatus.CONNECTED
            : whatsapp_number_entity_2.ConnectionStatus.DISCONNECTED;
        const whatsappNumber = this.whatsappNumberRepository.create({
            phoneNumber: createDto.phoneNumber,
            displayName: createDto.displayName,
            provider: createDto.provider,
            status: initialStatus,
            isActive: createDto.isActive ?? true,
            campaignId: createDto.campaignId,
            botFlowId: createDto.botFlowId,
            accessToken: createDto.accessToken,
            phoneNumberId: createDto.phoneNumberId,
            sessionName: createDto.sessionName,
            twilioAccountSid: createDto.twilioAccountSid,
            twilioAuthToken: createDto.twilioAuthToken,
            twilioPhoneNumber: createDto.twilioPhoneNumber,
        });
        const saved = await this.whatsappNumberRepository.save(whatsappNumber);
        this.eventEmitter.emit('whatsapp.number.created', { number: saved });
        return saved;
    }
    async findAll() {
        return await this.whatsappNumberRepository.find({
            relations: ['campaign', 'botFlow'],
            order: { createdAt: 'DESC' },
        });
    }
    async findAllActive() {
        return await this.whatsappNumberRepository.find({
            where: { isActive: true },
            relations: ['campaign', 'botFlow'],
        });
    }
    async findOne(id) {
        const number = await this.whatsappNumberRepository.findOne({
            where: { id },
            relations: ['campaign', 'botFlow'],
        });
        if (!number) {
            throw new common_1.NotFoundException('Número WhatsApp no encontrado');
        }
        return number;
    }
    async update(id, updateDto) {
        const number = await this.findOne(id);
        Object.assign(number, updateDto);
        return await this.whatsappNumberRepository.save(number);
    }
    async remove(id) {
        const number = await this.findOne(id);
        if (number.status === whatsapp_number_entity_2.ConnectionStatus.CONNECTED && number.provider === 'wppconnect') {
            try {
                await this.wppConnectService.closeSession(number.sessionName);
                console.log(`✅ Sesión WPPConnect ${number.sessionName} cerrada antes de eliminar`);
            }
            catch (error) {
                console.warn(`⚠️ No se pudo cerrar sesión ${number.sessionName}: ${error.message}`);
            }
        }
        await this.whatsappNumberRepository.remove(number);
        this.eventEmitter.emit('whatsapp.number.deleted', { numberId: id });
        console.log(`🗑️ Número WhatsApp ${number.phoneNumber} eliminado exitosamente`);
    }
    async startWppConnectSession(id) {
        const number = await this.findOne(id);
        if (number.provider !== 'wppconnect') {
            throw new common_1.BadRequestException('Este número no usa WPPConnect');
        }
        number.status = whatsapp_number_entity_2.ConnectionStatus.QR_WAITING;
        await this.whatsappNumberRepository.save(number);
        try {
            const result = await this.wppConnectService.startSession(number.phoneNumber, id);
            return {
                success: true,
                data: {
                    qrCode: result.qrCode,
                    status: whatsapp_number_entity_2.ConnectionStatus.QR_WAITING,
                    message: 'Escanea el código QR con WhatsApp',
                },
            };
        }
        catch (error) {
            number.status = whatsapp_number_entity_2.ConnectionStatus.ERROR;
            await this.whatsappNumberRepository.save(number);
            throw new common_1.BadRequestException(`Error al iniciar sesión: ${error.message}`);
        }
    }
    async getWppConnectStatus(id) {
        const number = await this.findOne(id);
        if (number.provider !== 'wppconnect') {
            throw new common_1.BadRequestException('Este número no usa WPPConnect');
        }
        return {
            success: true,
            data: {
                status: number.status,
                phoneNumber: number.phoneNumber,
                sessionName: number.sessionName,
            },
        };
    }
    async disconnectWppConnect(id) {
        const number = await this.findOne(id);
        if (number.provider !== 'wppconnect') {
            throw new common_1.BadRequestException('Este número no usa WPPConnect');
        }
        number.status = whatsapp_number_entity_2.ConnectionStatus.DISCONNECTED;
        await this.whatsappNumberRepository.save(number);
        this.eventEmitter.emit('whatsapp.session.disconnected', { numberId: id });
        return {
            success: true,
            message: 'Sesión desconectada exitosamente',
        };
    }
    async configureMeta(id, config) {
        const number = await this.findOne(id);
        if (number.provider !== 'meta') {
            throw new common_1.BadRequestException('Este número no usa Meta Cloud API');
        }
        number.accessToken = config.accessToken;
        number.phoneNumberId = config.phoneNumberId;
        number.status = whatsapp_number_entity_2.ConnectionStatus.CONNECTING;
        const saved = await this.whatsappNumberRepository.save(number);
        await this.verifyMetaConnection(id);
        return saved;
    }
    async verifyMetaConnection(id) {
        const number = await this.findOne(id);
        if (number.provider !== 'meta') {
            throw new common_1.BadRequestException('Este número no usa Meta Cloud API');
        }
        if (!number.accessToken || !number.phoneNumberId) {
            throw new common_1.BadRequestException('Meta Cloud API no está configurado');
        }
        try {
            const isValid = await this.metaService.verifyToken(number.accessToken, number.phoneNumberId);
            if (isValid) {
                number.status = whatsapp_number_entity_2.ConnectionStatus.CONNECTED;
                number.lastConnectedAt = new Date();
                await this.whatsappNumberRepository.save(number);
                this.eventEmitter.emit('whatsapp.meta.connected', { numberId: id });
                return {
                    success: true,
                    data: {
                        status: whatsapp_number_entity_2.ConnectionStatus.CONNECTED,
                        message: 'Meta Cloud API configurado correctamente',
                    },
                };
            }
            else {
                throw new Error('Token inválido o sin permisos');
            }
        }
        catch (error) {
            number.status = whatsapp_number_entity_2.ConnectionStatus.ERROR;
            await this.whatsappNumberRepository.save(number);
            return {
                success: false,
                data: {
                    status: whatsapp_number_entity_2.ConnectionStatus.ERROR,
                    message: `Error al verificar Meta API: ${error.message}`,
                },
            };
        }
    }
    async assignToCampaign(id, campaignId) {
        const number = await this.findOne(id);
        number.campaignId = campaignId;
        const saved = await this.whatsappNumberRepository.save(number);
        this.eventEmitter.emit('whatsapp.number.assigned', {
            numberId: id,
            campaignId,
        });
        return saved;
    }
    async findByCampaign(campaignId) {
        return await this.whatsappNumberRepository.find({
            where: { campaignId, isActive: true },
        });
    }
    async getActiveSessions() {
        const allNumbers = await this.whatsappNumberRepository.find({
            where: { isActive: true },
        });
        const sessions = [];
        let totalUptime = 0;
        let activeCount = 0;
        for (const number of allNumbers) {
            const stats = this.sessionStats.get(number.id) || {
                numberId: number.id,
                phoneNumber: number.phoneNumber,
                displayName: number.displayName,
                status: number.status,
                isConnected: number.status === whatsapp_number_entity_2.ConnectionStatus.CONNECTED,
                messagesSent: 0,
                messagesReceived: 0,
                totalMessages: 0,
                connectedSince: number.lastConnectedAt,
                uptime: 0,
                alertCount: 0,
                offensiveWordsDetected: 0,
            };
            if (stats.isConnected) {
                activeCount++;
                if (stats.uptime) {
                    totalUptime += stats.uptime;
                }
            }
            sessions.push(stats);
        }
        return {
            totalSessions: allNumbers.length,
            activeSessions: activeCount,
            maxSessions: this.MAX_ACTIVE_SESSIONS,
            sessions: sessions.sort((a, b) => b.totalMessages - a.totalMessages),
            uptimeAverage: activeCount > 0 ? totalUptime / activeCount : 0,
        };
    }
    async forceCloseSession(id) {
        const number = await this.findOne(id);
        if (number.status !== whatsapp_number_entity_2.ConnectionStatus.CONNECTED) {
            throw new common_1.BadRequestException('Esta sesión no está activa');
        }
        try {
            if (number.provider === 'wppconnect') {
                await this.wppConnectService.closeSession(number.phoneNumber);
            }
            number.status = whatsapp_number_entity_2.ConnectionStatus.DISCONNECTED;
            await this.whatsappNumberRepository.save(number);
            this.sessionStats.delete(id);
            this.eventEmitter.emit('whatsapp.session.force-closed', { numberId: id });
            return {
                success: true,
                message: 'Sesión cerrada exitosamente',
            };
        }
        catch (error) {
            throw new common_1.BadRequestException(`Error al cerrar sesión: ${error.message}`);
        }
    }
    async closeAllSessions() {
        const activeNumbers = await this.whatsappNumberRepository.find({
            where: { status: whatsapp_number_entity_2.ConnectionStatus.CONNECTED },
        });
        const results = {
            total: activeNumbers.length,
            closed: 0,
            errors: 0,
        };
        for (const number of activeNumbers) {
            try {
                await this.forceCloseSession(number.id);
                results.closed++;
            }
            catch (error) {
                results.errors++;
            }
        }
        return {
            success: true,
            message: `${results.closed} sesiones cerradas exitosamente`,
            results,
        };
    }
    async canCreateNewSession() {
        const activeSessions = await this.whatsappNumberRepository.count({
            where: { status: whatsapp_number_entity_2.ConnectionStatus.CONNECTED },
        });
        if (activeSessions >= this.MAX_ACTIVE_SESSIONS) {
            return {
                allowed: false,
                message: `Límite de sesiones alcanzado (${activeSessions}/${this.MAX_ACTIVE_SESSIONS}). Cierra algunas sesiones antes de abrir nuevas.`,
            };
        }
        return {
            allowed: true,
        };
    }
    updateSessionStats(numberId, updates) {
        const current = this.sessionStats.get(numberId) || {};
        this.sessionStats.set(numberId, { ...current, ...updates });
    }
    incrementMessageCount(numberId, direction) {
        const stats = this.sessionStats.get(numberId);
        if (stats) {
            if (direction === 'sent') {
                stats.messagesSent++;
            }
            else {
                stats.messagesReceived++;
            }
            stats.totalMessages = stats.messagesSent + stats.messagesReceived;
            stats.lastMessageAt = new Date();
            this.sessionStats.set(numberId, stats);
        }
    }
    incrementAlertCount(numberId) {
        const stats = this.sessionStats.get(numberId);
        if (stats) {
            stats.alertCount = (stats.alertCount || 0) + 1;
            stats.offensiveWordsDetected = (stats.offensiveWordsDetected || 0) + 1;
            this.sessionStats.set(numberId, stats);
        }
    }
    async cleanupZombieProcesses(id) {
        const number = await this.whatsappNumberRepository.findOne({ where: { id } });
        if (!number) {
            throw new common_1.NotFoundException(`WhatsApp number with ID ${id} not found`);
        }
        if (number.provider !== 'wppconnect') {
            throw new common_1.BadRequestException('This operation is only available for WPPConnect sessions');
        }
        try {
            if (number.sessionName) {
                await this.wppConnectService.closeSession(number.sessionName);
            }
            number.status = whatsapp_number_entity_2.ConnectionStatus.DISCONNECTED;
            await this.whatsappNumberRepository.save(number);
            this.sessionStats.delete(id);
            return {
                success: true,
                message: `Procesos zombies limpiados exitosamente para ${number.displayName}`,
            };
        }
        catch (error) {
            throw new common_1.BadRequestException(`Error al limpiar procesos zombies: ${error.message}`);
        }
    }
};
exports.WhatsappNumbersService = WhatsappNumbersService;
__decorate([
    (0, event_emitter_1.OnEvent)('whatsapp.session.status'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], WhatsappNumbersService.prototype, "handleSessionStatusChange", null);
exports.WhatsappNumbersService = WhatsappNumbersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(whatsapp_number_entity_1.WhatsappNumber)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        wppconnect_service_1.WppConnectService,
        meta_service_1.MetaService,
        event_emitter_1.EventEmitter2])
], WhatsappNumbersService);
//# sourceMappingURL=whatsapp-numbers.service.js.map