import { WhatsappProvider } from '../entities/whatsapp-number.entity';
export declare class CreateWhatsappNumberDto {
    phoneNumber: string;
    displayName: string;
    provider: WhatsappProvider;
    campaignId?: string;
    botFlowId?: string;
    accessToken?: string;
    phoneNumberId?: string;
    sessionName?: string;
    twilioAccountSid?: string;
    twilioAuthToken?: string;
    twilioPhoneNumber?: string;
    isActive?: boolean;
}
