"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnidentifiedClientsModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const unidentified_client_entity_1 = require("./entities/unidentified-client.entity");
const chat_entity_1 = require("../chats/entities/chat.entity");
const user_entity_1 = require("../users/entities/user.entity");
const unidentified_clients_controller_1 = require("./unidentified-clients.controller");
const unidentified_clients_service_1 = require("./unidentified-clients.service");
let UnidentifiedClientsModule = class UnidentifiedClientsModule {
};
exports.UnidentifiedClientsModule = UnidentifiedClientsModule;
exports.UnidentifiedClientsModule = UnidentifiedClientsModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([unidentified_client_entity_1.UnidentifiedClient, chat_entity_1.Chat, user_entity_1.User])],
        controllers: [unidentified_clients_controller_1.UnidentifiedClientsController],
        providers: [unidentified_clients_service_1.UnidentifiedClientsService],
        exports: [unidentified_clients_service_1.UnidentifiedClientsService],
    })
], UnidentifiedClientsModule);
//# sourceMappingURL=unidentified-clients.module.js.map