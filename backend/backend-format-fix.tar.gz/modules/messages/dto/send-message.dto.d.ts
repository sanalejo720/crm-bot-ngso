export declare class SendMessageDto {
    chatId: string;
    content: string;
}
export declare class SendMediaMessageDto {
    chatId: string;
    mediaUrl: string;
    mediaType: 'image' | 'audio' | 'video' | 'document';
    caption?: string;
}
