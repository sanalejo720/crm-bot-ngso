import { Client } from '../../clients/entities/client.entity';
import { User } from '../../users/entities/user.entity';
export declare enum PazYSalvoStatus {
    PENDING = "pending",
    AVAILABLE = "available",
    DOWNLOADED = "downloaded"
}
export declare class PazYSalvo {
    id: string;
    certificateNumber: string;
    clientId: string;
    client: Client;
    paymentDate: Date;
    paidAmount: number;
    availableFromDate: Date;
    status: PazYSalvoStatus;
    filePath: string;
    generatedBy: string;
    generator: User;
    downloadedAt: Date;
    downloadedBy: string;
    downloader: User;
    metadata: {
        originalDebtAmount?: number;
        campaignName?: string;
        agentName?: string;
    };
    createdAt: Date;
}
