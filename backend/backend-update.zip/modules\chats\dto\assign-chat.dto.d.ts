export declare class AssignChatDto {
    agentId: string;
}
export declare class TransferChatDto {
    newAgentId: string;
    reason: string;
}
