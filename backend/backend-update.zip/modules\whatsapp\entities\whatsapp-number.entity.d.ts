import { Campaign } from '../../campaigns/entities/campaign.entity';
import { Chat } from '../../chats/entities/chat.entity';
export declare enum WhatsappProvider {
    META_CLOUD = "meta",
    WPPCONNECT = "wppconnect"
}
export declare enum ConnectionStatus {
    CONNECTED = "connected",
    DISCONNECTED = "disconnected",
    CONNECTING = "connecting",
    QR_WAITING = "qr_waiting",
    ERROR = "error"
}
export declare class WhatsappNumber {
    id: string;
    phoneNumber: string;
    displayName: string;
    provider: WhatsappProvider;
    status: ConnectionStatus;
    phoneNumberId: string;
    accessToken: string;
    sessionName: string;
    apiKey: string;
    serverUrl: string;
    qrCode: string;
    lastConnectedAt: Date;
    webhookConfig: {
        url?: string;
        secret?: string;
    };
    metadata: Record<string, any>;
    isActive: boolean;
    campaign: Campaign;
    campaignId: string;
    chats: Chat[];
    createdAt: Date;
    updatedAt: Date;
}
