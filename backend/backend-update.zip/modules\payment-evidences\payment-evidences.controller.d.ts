import { PaymentEvidencesService } from './payment-evidences.service';
import { CreateEvidenceDto, ReviewEvidenceDto, QueryEvidencesDto } from './dto/evidence.dto';
import { PaymentEvidence } from './entities/payment-evidence.entity';
export declare class PaymentEvidencesController {
    private readonly evidencesService;
    constructor(evidencesService: PaymentEvidencesService);
    uploadEvidence(file: Express.Multer.File, createDto: CreateEvidenceDto, req: any): Promise<{
        success: boolean;
        data: PaymentEvidence;
        message: string;
        timestamp: string;
    }>;
    findAll(query: QueryEvidencesDto, req: any): Promise<{
        success: boolean;
        data: PaymentEvidence[];
        timestamp: string;
    }>;
    getPendingCount(): Promise<{
        success: boolean;
        data: {
            count: number;
        };
        timestamp: string;
    }>;
    getClientEvidences(clientId: string): Promise<{
        success: boolean;
        data: PaymentEvidence[];
        timestamp: string;
    }>;
    findOne(id: string): Promise<{
        success: boolean;
        data: PaymentEvidence;
        timestamp: string;
    }>;
    reviewEvidence(id: string, reviewDto: ReviewEvidenceDto, req: any): Promise<{
        success: boolean;
        data: PaymentEvidence;
        message: string;
        timestamp: string;
    }>;
    deleteEvidence(id: string): Promise<{
        success: boolean;
        message: string;
        timestamp: string;
    }>;
}
