import { Repository } from 'typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Chat, ChatStatus } from './entities/chat.entity';
import { CreateChatDto } from './dto/create-chat.dto';
import { UpdateChatDto } from './dto/update-chat.dto';
import { UsersService } from '../users/users.service';
export declare class ChatsService {
    private chatRepository;
    private usersService;
    private eventEmitter;
    private readonly logger;
    constructor(chatRepository: Repository<Chat>, usersService: UsersService, eventEmitter: EventEmitter2);
    create(createChatDto: CreateChatDto): Promise<Chat>;
    findAll(filters?: {
        status?: ChatStatus;
        campaignId?: string;
        assignedAgentId?: string;
        whatsappNumberId?: string;
    }): Promise<Chat[]>;
    findOne(id: string): Promise<Chat>;
    findByExternalId(externalId: string): Promise<Chat | null>;
    update(id: string, updateChatDto: UpdateChatDto): Promise<Chat>;
    assign(chatId: string, agentId: string | null): Promise<Chat>;
    transfer(chatId: string, currentAgentId: string, newAgentId: string, reason: string): Promise<Chat>;
    close(chatId: string, userId: string): Promise<Chat>;
    resolve(chatId: string, userId: string): Promise<Chat>;
    getWaitingChats(campaignId: string): Promise<Chat[]>;
    updateLastActivity(chatId: string, messageText: string): Promise<void>;
    incrementUnreadCount(chatId: string): Promise<void>;
    resetUnreadCount(chatId: string): Promise<void>;
    getAgentStats(agentId: string): Promise<{
        active: number;
        resolved: number;
        total: number;
    }>;
}
