"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotFlowsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const bot_flows_service_1 = require("./bot-flows.service");
const bot_flow_dto_1 = require("./dto/bot-flow.dto");
let BotFlowsController = class BotFlowsController {
    constructor(botFlowsService) {
        this.botFlowsService = botFlowsService;
    }
    async findAll(status, page = 1, limit = 50) {
        const result = await this.botFlowsService.findAll(status, +page, +limit);
        return {
            message: 'Flujos recuperados exitosamente',
            data: result.data,
            meta: {
                page: +page,
                limit: +limit,
                total: result.total,
                totalPages: Math.ceil(result.total / +limit),
            },
        };
    }
    async findOne(id) {
        const flow = await this.botFlowsService.findOneWithNodes(id);
        return {
            message: 'Flujo recuperado exitosamente',
            data: flow,
        };
    }
    async create(createDto) {
        const flow = await this.botFlowsService.create(createDto);
        return {
            message: 'Flujo creado exitosamente',
            data: flow,
        };
    }
    async update(id, updateDto) {
        const flow = await this.botFlowsService.update(id, updateDto);
        return {
            message: 'Flujo actualizado exitosamente',
            data: flow,
        };
    }
    async remove(id) {
        await this.botFlowsService.remove(id);
    }
    async duplicate(id) {
        const flow = await this.botFlowsService.duplicate(id);
        return {
            message: 'Flujo duplicado exitosamente',
            data: flow,
        };
    }
    async publish(id) {
        const flow = await this.botFlowsService.publish(id);
        return {
            message: 'Flujo publicado exitosamente',
            data: flow,
        };
    }
    async createNode(flowId, createDto) {
        const node = await this.botFlowsService.createNode(flowId, createDto);
        return {
            message: 'Nodo creado exitosamente',
            data: node,
        };
    }
    async createNodesBulk(flowId, bulkDto) {
        const nodes = await this.botFlowsService.createNodesBulk(flowId, bulkDto.nodes);
        return {
            message: `${nodes.length} nodos creados exitosamente`,
            data: nodes,
        };
    }
    async updateNode(flowId, nodeId, updateDto) {
        const node = await this.botFlowsService.updateNode(nodeId, updateDto);
        return {
            message: 'Nodo actualizado exitosamente',
            data: node,
        };
    }
    async removeNode(flowId, nodeId) {
        await this.botFlowsService.removeNode(nodeId);
    }
    async getStats(id) {
        const stats = await this.botFlowsService.getStats(id);
        return {
            message: 'Estadísticas recuperadas exitosamente',
            data: stats,
        };
    }
};
exports.BotFlowsController = BotFlowsController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Listar todos los flujos de bot' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'bot', action: 'read' }),
    __param(0, (0, common_1.Query)('status')),
    __param(1, (0, common_1.Query)('page')),
    __param(2, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], BotFlowsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener flujo por ID con sus nodos' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'bot', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BotFlowsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Crear nuevo flujo de bot' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'bot', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [bot_flow_dto_1.CreateBotFlowDto]),
    __metadata("design:returntype", Promise)
], BotFlowsController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Actualizar flujo de bot' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'bot', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, bot_flow_dto_1.UpdateBotFlowDto]),
    __metadata("design:returntype", Promise)
], BotFlowsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Eliminar flujo de bot' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'bot', action: 'delete' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BotFlowsController.prototype, "remove", null);
__decorate([
    (0, common_1.Post)(':id/duplicate'),
    (0, swagger_1.ApiOperation)({ summary: 'Duplicar flujo de bot' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'bot', action: 'create' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BotFlowsController.prototype, "duplicate", null);
__decorate([
    (0, common_1.Post)(':id/publish'),
    (0, swagger_1.ApiOperation)({ summary: 'Publicar flujo de bot' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'bot', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BotFlowsController.prototype, "publish", null);
__decorate([
    (0, common_1.Post)(':flowId/nodes'),
    (0, swagger_1.ApiOperation)({ summary: 'Crear un nodo en el flujo' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'bot', action: 'create' }),
    __param(0, (0, common_1.Param)('flowId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, bot_flow_dto_1.CreateBotNodeDto]),
    __metadata("design:returntype", Promise)
], BotFlowsController.prototype, "createNode", null);
__decorate([
    (0, common_1.Post)(':flowId/nodes/bulk'),
    (0, swagger_1.ApiOperation)({ summary: 'Crear múltiples nodos en el flujo' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'bot', action: 'create' }),
    __param(0, (0, common_1.Param)('flowId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, bot_flow_dto_1.BulkCreateNodesDto]),
    __metadata("design:returntype", Promise)
], BotFlowsController.prototype, "createNodesBulk", null);
__decorate([
    (0, common_1.Put)(':flowId/nodes/:nodeId'),
    (0, swagger_1.ApiOperation)({ summary: 'Actualizar un nodo' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'bot', action: 'update' }),
    __param(0, (0, common_1.Param)('flowId')),
    __param(1, (0, common_1.Param)('nodeId')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, bot_flow_dto_1.UpdateBotNodeDto]),
    __metadata("design:returntype", Promise)
], BotFlowsController.prototype, "updateNode", null);
__decorate([
    (0, common_1.Delete)(':flowId/nodes/:nodeId'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Eliminar un nodo' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'bot', action: 'delete' }),
    __param(0, (0, common_1.Param)('flowId')),
    __param(1, (0, common_1.Param)('nodeId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], BotFlowsController.prototype, "removeNode", null);
__decorate([
    (0, common_1.Get)(':id/stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas del flujo' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'bot', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BotFlowsController.prototype, "getStats", null);
exports.BotFlowsController = BotFlowsController = __decorate([
    (0, swagger_1.ApiTags)('Bot Flows'),
    (0, common_1.Controller)('bot-flows'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [bot_flows_service_1.BotFlowsService])
], BotFlowsController);
//# sourceMappingURL=bot-flows.controller.js.map