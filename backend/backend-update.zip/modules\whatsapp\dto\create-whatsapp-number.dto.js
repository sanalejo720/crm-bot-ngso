"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateWhatsappNumberDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
const whatsapp_number_entity_1 = require("../entities/whatsapp-number.entity");
class CreateWhatsappNumberDto {
}
exports.CreateWhatsappNumberDto = CreateWhatsappNumberDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: '573001234567', description: 'Número de teléfono con código de país' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateWhatsappNumberDto.prototype, "phoneNumber", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Línea Principal', description: 'Nombre descriptivo del número' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateWhatsappNumberDto.prototype, "displayName", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: whatsapp_number_entity_1.WhatsappProvider.WPPCONNECT,
        description: 'Proveedor de WhatsApp',
        enum: whatsapp_number_entity_1.WhatsappProvider
    }),
    (0, class_validator_1.IsEnum)(whatsapp_number_entity_1.WhatsappProvider),
    __metadata("design:type", String)
], CreateWhatsappNumberDto.prototype, "provider", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'campaign-id', description: 'ID de la campaña asignada' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateWhatsappNumberDto.prototype, "campaignId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'xxx', description: 'Access Token para Meta Cloud API' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateWhatsappNumberDto.prototype, "accessToken", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'xxx', description: 'Phone Number ID para Meta Cloud API' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateWhatsappNumberDto.prototype, "phoneNumberId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'session-name', description: 'Session Name para WPPConnect' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateWhatsappNumberDto.prototype, "sessionName", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: true, description: 'Si está activo' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateWhatsappNumberDto.prototype, "isActive", void 0);
//# sourceMappingURL=create-whatsapp-number.dto.js.map