import { AuthService } from './auth.service';
import { LoginDto, LoginResponseDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';
export declare class AuthController {
    private readonly authService;
    constructor(authService: AuthService);
    login(loginDto: LoginDto): Promise<LoginResponseDto>;
    register(registerDto: RegisterDto): Promise<import("../users/entities/user.entity").User>;
    logout(userId: string): Promise<void>;
    getProfile(user: any): Promise<any>;
    refresh(body: {
        refreshToken: string;
    }): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    generate2FA(user: any): Promise<{
        secret: string;
        qrCode: string;
    }>;
    enable2FA(userId: string, body: {
        secret: string;
        token: string;
    }): Promise<void>;
    disable2FA(userId: string): Promise<void>;
}
