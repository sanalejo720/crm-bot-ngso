"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var WebhookController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookController = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const whatsapp_service_1 = require("./whatsapp.service");
let WebhookController = WebhookController_1 = class WebhookController {
    constructor(whatsappService, configService) {
        this.whatsappService = whatsappService;
        this.configService = configService;
        this.logger = new common_1.Logger(WebhookController_1.name);
        this.verifyToken = this.configService.get('META_WEBHOOK_VERIFY_TOKEN', 'your_verify_token');
    }
    verifyWebhook(mode, challenge, token) {
        if (mode === 'subscribe' && token === this.verifyToken) {
            this.logger.log('Webhook verified successfully');
            return challenge;
        }
        throw new common_1.BadRequestException('Webhook verification failed');
    }
    async receiveMetaWebhook(body, signature) {
        this.logger.log('Received Meta webhook');
        try {
            await this.whatsappService.processMetaWebhook(body);
            return { success: true };
        }
        catch (error) {
            this.logger.error(`Error processing Meta webhook: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('Failed to process webhook');
        }
    }
    async receiveWppConnectWebhook(body) {
        this.logger.log('Received WPPConnect webhook');
        try {
            return { success: true };
        }
        catch (error) {
            this.logger.error(`Error processing WPPConnect webhook: ${error.message}`, error.stack);
            throw new common_1.BadRequestException('Failed to process webhook');
        }
    }
};
exports.WebhookController = WebhookController;
__decorate([
    (0, common_1.Get)('meta'),
    __param(0, (0, common_1.Query)('hub.mode')),
    __param(1, (0, common_1.Query)('hub.challenge')),
    __param(2, (0, common_1.Query)('hub.verify_token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", void 0)
], WebhookController.prototype, "verifyWebhook", null);
__decorate([
    (0, common_1.Post)('meta'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)('x-hub-signature-256')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], WebhookController.prototype, "receiveMetaWebhook", null);
__decorate([
    (0, common_1.Post)('wppconnect'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], WebhookController.prototype, "receiveWppConnectWebhook", null);
exports.WebhookController = WebhookController = WebhookController_1 = __decorate([
    (0, common_1.Controller)('webhooks/whatsapp'),
    __metadata("design:paramtypes", [whatsapp_service_1.WhatsappService,
        config_1.ConfigService])
], WebhookController);
//# sourceMappingURL=webhook.controller.js.map