import { BotFlow } from './bot-flow.entity';
export declare enum BotNodeType {
    MESSAGE = "message",
    MENU = "menu",
    INPUT = "input",
    CONDITION = "condition",
    API_CALL = "api_call",
    TRANSFER_AGENT = "transfer_agent",
    END = "end"
}
export declare class BotNode {
    id: string;
    name: string;
    type: BotNodeType;
    config: {
        message?: string;
        mediaUrl?: string;
        options?: Array<{
            id: string;
            label: string;
            value: string;
            nextNodeId: string;
        }>;
        inputType?: 'text' | 'number' | 'email' | 'phone';
        variableName?: string;
        validation?: {
            required?: boolean;
            minLength?: number;
            maxLength?: number;
            pattern?: string;
            errorMessage?: string;
        };
        variable?: string;
        conditions?: Array<{
            variable: string;
            operator: 'equals' | 'contains' | 'contains_ignore_case' | 'greater' | 'less';
            value: any;
            nextNodeId: string;
        }>;
        elseNodeId?: string;
        apiConfig?: {
            method: 'GET' | 'POST' | 'PUT';
            url: string;
            headers?: Record<string, string>;
            body?: Record<string, any>;
            responseVariable?: string;
        };
        transferReason?: string;
        transferToSkill?: string;
    };
    nextNodeId: string;
    positionX: number;
    positionY: number;
    flow: BotFlow;
    flowId: string;
    createdAt: Date;
    updatedAt: Date;
}
