import { User } from '../../users/entities/user.entity';
import { WhatsappNumber } from '../../whatsapp/entities/whatsapp-number.entity';
import { Chat } from '../../chats/entities/chat.entity';
export declare enum CampaignStatus {
    DRAFT = "draft",
    ACTIVE = "active",
    PAUSED = "paused",
    FINISHED = "finished"
}
export declare class Campaign {
    id: string;
    name: string;
    description: string;
    status: CampaignStatus;
    startDate: Date;
    endDate: Date;
    settings: {
        autoAssignment?: boolean;
        assignmentStrategy?: 'round-robin' | 'least-busy' | 'skills-based';
        maxWaitTime?: number;
        botEnabled?: boolean;
        botFlowId?: string;
        businessHours?: {
            enabled: boolean;
            timezone: string;
            schedule: {
                [key: string]: {
                    start: string;
                    end: string;
                }[];
            };
        };
    };
    metadata: Record<string, any>;
    users: User[];
    whatsappNumbers: WhatsappNumber[];
    chats: Chat[];
    createdAt: Date;
    createdBy: string;
    updatedAt: Date;
}
