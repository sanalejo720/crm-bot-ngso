import { Repository } from 'typeorm';
import { Campaign, CampaignStatus } from './entities/campaign.entity';
import { CreateCampaignDto } from './dto/create-campaign.dto';
import { UpdateCampaignDto } from './dto/update-campaign.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
export declare class CampaignsService {
    private campaignRepository;
    private eventEmitter;
    private readonly logger;
    constructor(campaignRepository: Repository<Campaign>, eventEmitter: EventEmitter2);
    create(createCampaignDto: CreateCampaignDto, createdBy: string): Promise<Campaign>;
    findAll(filters?: {
        status?: CampaignStatus;
        search?: string;
    }): Promise<Campaign[]>;
    findActive(): Promise<Campaign[]>;
    findOne(id: string): Promise<Campaign>;
    update(id: string, updateCampaignDto: UpdateCampaignDto): Promise<Campaign>;
    updateStatus(id: string, status: CampaignStatus): Promise<Campaign>;
    updateSettings(id: string, settings: Record<string, any>): Promise<Campaign>;
    activate(id: string): Promise<Campaign>;
    pause(id: string): Promise<Campaign>;
    remove(id: string): Promise<void>;
    getStats(id: string): Promise<{
        id: string;
        name: string;
        status: CampaignStatus;
        totalChats: number;
        chatsByStatus: any;
        totalClients: number;
        clientsByLeadStatus: any;
    }>;
    getWhatsappNumbers(id: string): Promise<import("../whatsapp/entities/whatsapp-number.entity").WhatsappNumber[]>;
    duplicate(id: string, newName: string, createdBy: string): Promise<Campaign>;
}
