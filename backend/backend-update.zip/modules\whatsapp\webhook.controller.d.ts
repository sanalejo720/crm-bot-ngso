import { ConfigService } from '@nestjs/config';
import { WhatsappService } from './whatsapp.service';
export declare class WebhookController {
    private readonly whatsappService;
    private readonly configService;
    private readonly logger;
    private readonly verifyToken;
    constructor(whatsappService: WhatsappService, configService: ConfigService);
    verifyWebhook(mode: string, challenge: string, token: string): string;
    receiveMetaWebhook(body: any, signature: string): Promise<{
        success: boolean;
    }>;
    receiveWppConnectWebhook(body: any): Promise<{
        success: boolean;
    }>;
}
