export declare class BotModule {
}
