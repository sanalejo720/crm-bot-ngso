"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const typeorm_1 = require("typeorm");
const dotenv = __importStar(require("dotenv"));
dotenv.config();
const AppDataSource = new typeorm_1.DataSource({
    type: 'postgres',
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    username: process.env.DB_USERNAME || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
    database: process.env.DB_NAME || 'crm_ngso',
});
async function activateAdmin() {
    try {
        console.log('🔌 Conectando a la base de datos...');
        await AppDataSource.initialize();
        console.log('✅ Conectado exitosamente');
        console.log('🔄 Activando usuario admin@crm.com...');
        const result = await AppDataSource.query(`UPDATE users SET status = 'active' WHERE email = 'admin@crm.com' RETURNING id, "fullName", email, status`);
        if (result.length > 0) {
            console.log('✅ Usuario activado exitosamente:');
            console.log(result[0]);
        }
        else {
            console.log('⚠️ No se encontró el usuario admin@crm.com');
            const allUsers = await AppDataSource.query(`SELECT id, "fullName", email, status FROM users LIMIT 5`);
            console.log('\n📋 Usuarios en la base de datos:');
            console.table(allUsers);
        }
        await AppDataSource.destroy();
        console.log('✅ Proceso completado');
    }
    catch (error) {
        console.error('❌ Error:', error);
        process.exit(1);
    }
}
activateAdmin();
//# sourceMappingURL=activate-admin.js.map