"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var RolesService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RolesService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const role_entity_1 = require("./entities/role.entity");
const permission_entity_1 = require("./entities/permission.entity");
const event_emitter_1 = require("@nestjs/event-emitter");
let RolesService = RolesService_1 = class RolesService {
    constructor(roleRepository, permissionRepository, eventEmitter) {
        this.roleRepository = roleRepository;
        this.permissionRepository = permissionRepository;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(RolesService_1.name);
    }
    async create(createRoleDto) {
        this.logger.log(`Creando rol: ${createRoleDto.name}`);
        const existing = await this.roleRepository.findOne({
            where: { name: createRoleDto.name },
        });
        if (existing) {
            throw new common_1.ConflictException(`El rol "${createRoleDto.name}" ya existe`);
        }
        let permissions = [];
        if (createRoleDto.permissionIds && createRoleDto.permissionIds.length > 0) {
            permissions = await this.permissionRepository.findByIds(createRoleDto.permissionIds);
        }
        const role = this.roleRepository.create({
            name: createRoleDto.name,
            description: createRoleDto.description,
            permissions,
        });
        const savedRole = await this.roleRepository.save(role);
        this.eventEmitter.emit('role.created', savedRole);
        return this.findOne(savedRole.id);
    }
    async findAll() {
        return this.roleRepository.find({
            relations: ['permissions'],
            order: { name: 'ASC' },
        });
    }
    async findOne(id) {
        const role = await this.roleRepository.findOne({
            where: { id },
            relations: ['permissions', 'users'],
        });
        if (!role) {
            throw new common_1.NotFoundException(`Rol ${id} no encontrado`);
        }
        return role;
    }
    async findByName(name) {
        return this.roleRepository.findOne({
            where: { name },
            relations: ['permissions'],
        });
    }
    async update(id, updateRoleDto) {
        const role = await this.findOne(id);
        if (updateRoleDto.name && updateRoleDto.name !== role.name) {
            const existing = await this.roleRepository.findOne({
                where: { name: updateRoleDto.name },
            });
            if (existing) {
                throw new common_1.ConflictException(`El rol "${updateRoleDto.name}" ya existe`);
            }
        }
        if (updateRoleDto.permissionIds) {
            const permissions = await this.permissionRepository.findByIds(updateRoleDto.permissionIds);
            role.permissions = permissions;
        }
        if (updateRoleDto.name)
            role.name = updateRoleDto.name;
        if (updateRoleDto.description !== undefined)
            role.description = updateRoleDto.description;
        const updatedRole = await this.roleRepository.save(role);
        this.eventEmitter.emit('role.updated', updatedRole);
        return this.findOne(updatedRole.id);
    }
    async addPermissions(id, permissionIds) {
        const role = await this.findOne(id);
        const newPermissions = await this.permissionRepository.findByIds(permissionIds);
        const existingIds = role.permissions.map((p) => p.id);
        const toAdd = newPermissions.filter((p) => !existingIds.includes(p.id));
        role.permissions = [...role.permissions, ...toAdd];
        return this.roleRepository.save(role);
    }
    async removePermissions(id, permissionIds) {
        const role = await this.findOne(id);
        role.permissions = role.permissions.filter((p) => !permissionIds.includes(p.id));
        return this.roleRepository.save(role);
    }
    async remove(id) {
        const role = await this.findOne(id);
        if (role.users && role.users.length > 0) {
            throw new common_1.ConflictException(`No se puede eliminar el rol "${role.name}" porque tiene ${role.users.length} usuario(s) asignado(s)`);
        }
        await this.roleRepository.remove(role);
        this.eventEmitter.emit('role.deleted', { roleId: id, roleName: role.name });
        this.logger.log(`Rol ${role.name} eliminado`);
    }
    async hasPermission(roleId, module, action) {
        const role = await this.findOne(roleId);
        return role.permissions.some((p) => p.module === module && p.action === action);
    }
    async getAllPermissions() {
        return this.permissionRepository.find({
            order: { module: 'ASC', action: 'ASC' },
        });
    }
    async seedPermissions() {
        this.logger.log('Creando permisos por defecto...');
        const modules = [
            'users',
            'roles',
            'campaigns',
            'whatsapp',
            'chats',
            'messages',
            'clients',
            'tasks',
            'bot',
            'reports',
            'audit',
            'settings',
            'templates',
            'unidentified_clients',
            'backups',
            'payment_evidences',
            'quick_replies',
            'monitoring',
            'debtors',
        ];
        const actions = ['create', 'read', 'update', 'delete'];
        const specialPermissions = [
            { module: 'chats', action: 'assign' },
            { module: 'chats', action: 'transfer' },
            { module: 'chats', action: 'close' },
            { module: 'chats', action: 'manage' },
            { module: 'users', action: 'activate' },
            { module: 'users', action: 'deactivate' },
            { module: 'campaigns', action: 'activate' },
            { module: 'campaigns', action: 'pause' },
            { module: 'reports', action: 'export' },
            { module: 'whatsapp', action: 'send' },
            { module: 'templates', action: 'use' },
            { module: 'debtors', action: 'upload' },
            { module: 'debtors', action: 'import' },
        ];
        for (const module of modules) {
            for (const action of actions) {
                const existing = await this.permissionRepository.findOne({
                    where: { module, action },
                });
                if (!existing) {
                    const permission = this.permissionRepository.create({
                        module,
                        action,
                        description: `${action} ${module}`,
                    });
                    await this.permissionRepository.save(permission);
                    this.logger.log(`Permiso creado: ${module}.${action}`);
                }
            }
        }
        for (const { module, action } of specialPermissions) {
            const existing = await this.permissionRepository.findOne({
                where: { module, action },
            });
            if (!existing) {
                const permission = this.permissionRepository.create({
                    module,
                    action,
                    description: `${action} ${module}`,
                });
                await this.permissionRepository.save(permission);
                this.logger.log(`Permiso especial creado: ${module}.${action}`);
            }
        }
        this.logger.log('Permisos por defecto creados');
    }
    async seedRoles() {
        this.logger.log('Creando roles por defecto...');
        const allPermissions = await this.getAllPermissions();
        let superAdmin = await this.findByName('Super Admin');
        if (!superAdmin) {
            superAdmin = this.roleRepository.create({
                name: 'Super Admin',
                description: 'Acceso completo al sistema',
                permissions: allPermissions,
            });
            await this.roleRepository.save(superAdmin);
            this.logger.log('Rol Super Admin creado');
        }
        else {
            superAdmin.permissions = allPermissions;
            await this.roleRepository.save(superAdmin);
            this.logger.log('Rol Super Admin actualizado con TODOS los permisos');
        }
        const supervisorPermissions = await this.permissionRepository
            .createQueryBuilder('permission')
            .where('permission.module IN (:...modules)', {
            modules: ['campaigns', 'chats', 'messages', 'clients', 'tasks', 'reports', 'users', 'whatsapp'],
        })
            .getMany();
        let supervisor = await this.findByName('Supervisor');
        if (!supervisor) {
            supervisor = this.roleRepository.create({
                name: 'Supervisor',
                description: 'Supervisión de operaciones y reportes',
                permissions: supervisorPermissions,
            });
            await this.roleRepository.save(supervisor);
            this.logger.log('Rol Supervisor creado');
        }
        else {
            supervisor.permissions = supervisorPermissions;
            await this.roleRepository.save(supervisor);
            this.logger.log('Rol Supervisor actualizado con nuevos permisos');
        }
        const agentPermissions = await this.permissionRepository
            .createQueryBuilder('permission')
            .where('permission.module IN (:...modules)', {
            modules: ['chats', 'messages', 'clients', 'tasks'],
        })
            .andWhere('permission.action IN (:...actions)', {
            actions: ['read', 'create', 'update'],
        })
            .getMany();
        let agent = await this.findByName('Agente');
        if (!agent) {
            agent = this.roleRepository.create({
                name: 'Agente',
                description: 'Atención de chats y gestión de clientes',
                permissions: agentPermissions,
            });
            await this.roleRepository.save(agent);
            this.logger.log('Rol Agente creado');
        }
        else {
            agent.permissions = agentPermissions;
            await this.roleRepository.save(agent);
            this.logger.log('Rol Agente actualizado con nuevos permisos');
        }
        const qualityPermissions = await this.permissionRepository
            .createQueryBuilder('permission')
            .where('permission.module IN (:...modules)', {
            modules: ['chats', 'messages', 'reports', 'audit'],
        })
            .andWhere('permission.action = :action', { action: 'read' })
            .getMany();
        let quality = await this.findByName('Calidad');
        if (!quality) {
            quality = this.roleRepository.create({
                name: 'Calidad',
                description: 'Monitoreo y auditoría de calidad',
                permissions: qualityPermissions,
            });
            await this.roleRepository.save(quality);
            this.logger.log('Rol Calidad creado');
        }
        const auditPermissions = await this.permissionRepository
            .createQueryBuilder('permission')
            .where('permission.action = :action', { action: 'read' })
            .getMany();
        let audit = await this.findByName('Auditoría');
        if (!audit) {
            audit = this.roleRepository.create({
                name: 'Auditoría',
                description: 'Acceso solo lectura para auditoría',
                permissions: auditPermissions,
            });
            await this.roleRepository.save(audit);
            this.logger.log('Rol Auditoría creado');
        }
        this.logger.log('Roles por defecto creados');
    }
};
exports.RolesService = RolesService;
exports.RolesService = RolesService = RolesService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(role_entity_1.Role)),
    __param(1, (0, typeorm_1.InjectRepository)(permission_entity_1.Permission)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        event_emitter_1.EventEmitter2])
], RolesService);
//# sourceMappingURL=roles.service.js.map