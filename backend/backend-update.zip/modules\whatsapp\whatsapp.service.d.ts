import { Repository } from 'typeorm';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { WhatsappNumber, ConnectionStatus } from './entities/whatsapp-number.entity';
import { MetaCloudService } from './providers/meta-cloud.service';
import { WppConnectService } from './providers/wppconnect.service';
import { MessageType } from '../messages/entities/message.entity';
export declare class WhatsappService {
    private whatsappNumberRepository;
    private metaCloudService;
    private wppConnectService;
    private eventEmitter;
    private readonly logger;
    constructor(whatsappNumberRepository: Repository<WhatsappNumber>, metaCloudService: MetaCloudService, wppConnectService: WppConnectService, eventEmitter: EventEmitter2);
    findOne(id: string): Promise<WhatsappNumber>;
    sendMessage(whatsappNumberId: string, to: string, content: string, type: MessageType, mediaUrl?: string): Promise<{
        messageId: string;
        metadata?: any;
    }>;
    processMetaWebhook(payload: any): Promise<void>;
    private sendViaMeta;
    private sendViaWppConnect;
    startWppConnectSession(whatsappNumberId: string): Promise<{
        success: boolean;
        message: string;
        sessionName: string;
        qrCode: string;
        status: string;
    }>;
    getWppConnectStatus(whatsappNumberId: string): Promise<{
        connected: boolean;
        phone?: string;
    }>;
    updateConnectionStatus(whatsappNumberId: string, status: ConnectionStatus): Promise<void>;
    findAllActive(): Promise<WhatsappNumber[]>;
    findByCampaign(campaignId: string): Promise<WhatsappNumber[]>;
    getDebugSessions(): Promise<{
        wppConnectSessions: string[];
        databaseNumbers: {
            id: string;
            phone: string;
            sessionName: string;
            status: ConnectionStatus;
        }[];
    }>;
}
