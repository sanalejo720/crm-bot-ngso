import { Repository } from 'typeorm';
import { Campaign } from '../campaigns/entities/campaign.entity';
import { Client } from '../clients/entities/client.entity';
import { Chat } from '../chats/entities/chat.entity';
import { User } from '../users/entities/user.entity';
import { CampaignFinancialsDto, AgentRecaudoDto, FinancialSummaryDto, DailyFinancialsDto, FinancialTrendDto } from './dto/financial-stats.dto';
export declare class FinancialStatsService {
    private campaignRepo;
    private clientRepo;
    private chatRepo;
    private userRepo;
    constructor(campaignRepo: Repository<Campaign>, clientRepo: Repository<Client>, chatRepo: Repository<Chat>, userRepo: Repository<User>);
    getCampaignFinancials(campaignId: string, startDate: Date, endDate: Date): Promise<CampaignFinancialsDto>;
    getAgentRecaudo(agentId: string, startDate: Date, endDate: Date): Promise<AgentRecaudoDto>;
    getFinancialSummary(period: 'daily' | 'weekly' | 'monthly' | 'custom', startDate?: Date, endDate?: Date): Promise<FinancialSummaryDto>;
    getDailyFinancials(date: Date): Promise<DailyFinancialsDto>;
    getFinancialTrend(startDate: Date, endDate: Date): Promise<FinancialTrendDto>;
    private calculateDateRange;
    private formatPeriod;
}
