import { Chat } from '../../chats/entities/chat.entity';
import { User } from '../../users/entities/user.entity';
import { Client } from '../../clients/entities/client.entity';
export declare enum EvidenceType {
    PAID = "paid",
    PROMISE = "promise"
}
export declare class Evidence {
    id: string;
    ticketNumber: string;
    closureType: EvidenceType;
    filePath: string;
    fileName: string;
    chat: Chat;
    chatId: string;
    client: Client;
    clientId: string;
    clientName: string;
    agent: User;
    agentId: string;
    agentName: string;
    amount: number;
    promiseDate: Date;
    createdAt: Date;
}
