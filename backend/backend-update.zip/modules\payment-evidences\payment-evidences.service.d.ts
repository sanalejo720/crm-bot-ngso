import { Repository } from 'typeorm';
import { PaymentEvidence } from './entities/payment-evidence.entity';
import { CreateEvidenceDto, ReviewEvidenceDto, QueryEvidencesDto } from './dto/evidence.dto';
export declare class PaymentEvidencesService {
    private evidenceRepository;
    private readonly uploadDir;
    constructor(evidenceRepository: Repository<PaymentEvidence>);
    private ensureUploadDir;
    uploadEvidence(file: Express.Multer.File, createDto: CreateEvidenceDto, userId: string): Promise<PaymentEvidence>;
    findAll(query: QueryEvidencesDto): Promise<PaymentEvidence[]>;
    findOne(id: string): Promise<PaymentEvidence>;
    reviewEvidence(id: string, reviewDto: ReviewEvidenceDto, reviewerId: string): Promise<PaymentEvidence>;
    deleteEvidence(id: string): Promise<void>;
    getEvidencesByClient(clientId: string): Promise<PaymentEvidence[]>;
    getPendingCount(): Promise<number>;
}
