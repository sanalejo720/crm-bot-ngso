"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnidentifiedClient = exports.UnidentifiedClientStatus = void 0;
const typeorm_1 = require("typeorm");
const chat_entity_1 = require("../../chats/entities/chat.entity");
const user_entity_1 = require("../../users/entities/user.entity");
var UnidentifiedClientStatus;
(function (UnidentifiedClientStatus) {
    UnidentifiedClientStatus["PENDING"] = "pending";
    UnidentifiedClientStatus["CONTACTED"] = "contacted";
    UnidentifiedClientStatus["RESOLVED"] = "resolved";
    UnidentifiedClientStatus["TRANSFERRED"] = "transferred";
})(UnidentifiedClientStatus || (exports.UnidentifiedClientStatus = UnidentifiedClientStatus = {}));
let UnidentifiedClient = class UnidentifiedClient {
};
exports.UnidentifiedClient = UnidentifiedClient;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], UnidentifiedClient.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ unique: true }),
    __metadata("design:type", String)
], UnidentifiedClient.prototype, "phone", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], UnidentifiedClient.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], UnidentifiedClient.prototype, "documentType", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], UnidentifiedClient.prototype, "documentNumber", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], UnidentifiedClient.prototype, "notes", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: UnidentifiedClientStatus,
        default: UnidentifiedClientStatus.PENDING,
    }),
    __metadata("design:type", String)
], UnidentifiedClient.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', nullable: true }),
    __metadata("design:type", Object)
], UnidentifiedClient.prototype, "metadata", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => chat_entity_1.Chat, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'chatId' }),
    __metadata("design:type", chat_entity_1.Chat)
], UnidentifiedClient.prototype, "chat", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], UnidentifiedClient.prototype, "chatId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.User, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'assignedToId' }),
    __metadata("design:type", user_entity_1.User)
], UnidentifiedClient.prototype, "assignedTo", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], UnidentifiedClient.prototype, "assignedToId", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)(),
    __metadata("design:type", Date)
], UnidentifiedClient.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)(),
    __metadata("design:type", Date)
], UnidentifiedClient.prototype, "updatedAt", void 0);
exports.UnidentifiedClient = UnidentifiedClient = __decorate([
    (0, typeorm_1.Entity)('unidentified_clients'),
    (0, typeorm_1.Index)(['phone']),
    (0, typeorm_1.Index)(['status']),
    (0, typeorm_1.Index)(['createdAt'])
], UnidentifiedClient);
//# sourceMappingURL=unidentified-client.entity.js.map