"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var CampaignsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CampaignsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const campaign_entity_1 = require("./entities/campaign.entity");
const event_emitter_1 = require("@nestjs/event-emitter");
let CampaignsService = CampaignsService_1 = class CampaignsService {
    constructor(campaignRepository, eventEmitter) {
        this.campaignRepository = campaignRepository;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(CampaignsService_1.name);
    }
    async create(createCampaignDto, createdBy) {
        this.logger.log(`Creando campaña: ${createCampaignDto.name}`);
        const campaign = this.campaignRepository.create({
            ...createCampaignDto,
            createdBy,
        });
        const saved = await this.campaignRepository.save(campaign);
        const savedCampaign = Array.isArray(saved) ? saved[0] : saved;
        this.eventEmitter.emit('campaign.created', savedCampaign);
        return savedCampaign;
    }
    async findAll(filters) {
        const query = this.campaignRepository.createQueryBuilder('campaign');
        if (filters?.status) {
            query.andWhere('campaign.status = :status', { status: filters.status });
        }
        if (filters?.search) {
            query.andWhere('(campaign.name LIKE :search OR campaign.description LIKE :search)', { search: `%${filters.search}%` });
        }
        query
            .leftJoinAndSelect('campaign.whatsappNumbers', 'whatsappNumbers')
            .orderBy('campaign.createdAt', 'DESC');
        return query.getMany();
    }
    async findActive() {
        return this.campaignRepository.find({
            where: { status: campaign_entity_1.CampaignStatus.ACTIVE },
            relations: ['whatsappNumbers'],
        });
    }
    async findOne(id) {
        const campaign = await this.campaignRepository.findOne({
            where: { id },
            relations: ['whatsappNumbers', 'chats', 'debtors'],
        });
        if (!campaign) {
            throw new common_1.NotFoundException(`Campaña ${id} no encontrada`);
        }
        return campaign;
    }
    async update(id, updateCampaignDto) {
        const campaign = await this.findOne(id);
        Object.assign(campaign, updateCampaignDto);
        const updatedCampaign = await this.campaignRepository.save(campaign);
        this.eventEmitter.emit('campaign.updated', updatedCampaign);
        return updatedCampaign;
    }
    async updateStatus(id, status) {
        const campaign = await this.findOne(id);
        const oldStatus = campaign.status;
        campaign.status = status;
        const updatedCampaign = await this.campaignRepository.save(campaign);
        this.eventEmitter.emit('campaign.status-changed', {
            campaign: updatedCampaign,
            oldStatus,
            newStatus: status,
        });
        return updatedCampaign;
    }
    async updateSettings(id, settings) {
        const campaign = await this.findOne(id);
        campaign.settings = {
            ...campaign.settings,
            ...settings,
        };
        return this.campaignRepository.save(campaign);
    }
    async activate(id) {
        return this.updateStatus(id, campaign_entity_1.CampaignStatus.ACTIVE);
    }
    async pause(id) {
        return this.updateStatus(id, campaign_entity_1.CampaignStatus.PAUSED);
    }
    async remove(id) {
        const campaign = await this.findOne(id);
        await this.campaignRepository.softRemove(campaign);
        this.eventEmitter.emit('campaign.deleted', { campaignId: id });
        this.logger.log(`Campaña ${id} eliminada`);
    }
    async getStats(id) {
        const campaign = await this.findOne(id);
        const totalChats = await this.campaignRepository
            .createQueryBuilder('campaign')
            .leftJoin('campaign.chats', 'chat')
            .where('campaign.id = :id', { id })
            .getCount();
        const chatsByStatus = await this.campaignRepository
            .createQueryBuilder('campaign')
            .leftJoin('campaign.chats', 'chat')
            .select('chat.status', 'status')
            .addSelect('COUNT(*)', 'count')
            .where('campaign.id = :id', { id })
            .groupBy('chat.status')
            .getRawMany();
        const totalDebtors = await this.campaignRepository
            .createQueryBuilder('campaign')
            .leftJoin('campaign.debtors', 'debtor')
            .where('campaign.id = :id', { id })
            .getCount();
        const debtorsByStatus = await this.campaignRepository
            .createQueryBuilder('campaign')
            .leftJoin('campaign.debtors', 'debtor')
            .select('debtor.status', 'status')
            .addSelect('COUNT(*)', 'count')
            .where('campaign.id = :id', { id })
            .groupBy('debtor.status')
            .getRawMany();
        return {
            id: campaign.id,
            name: campaign.name,
            status: campaign.status,
            totalChats,
            chatsByStatus: chatsByStatus.reduce((acc, item) => {
                acc[item.status] = parseInt(item.count);
                return acc;
            }, {}),
            totalDebtors,
            debtorsByStatus: debtorsByStatus.reduce((acc, item) => {
                acc[item.status] = parseInt(item.count);
                return acc;
            }, {}),
        };
    }
    async getWhatsappNumbers(id) {
        const campaign = await this.campaignRepository.findOne({
            where: { id },
            relations: ['whatsappNumbers'],
        });
        if (!campaign) {
            throw new common_1.NotFoundException(`Campaña ${id} no encontrada`);
        }
        return campaign.whatsappNumbers;
    }
    async duplicate(id, newName, createdBy) {
        const original = await this.findOne(id);
        const duplicated = this.campaignRepository.create({
            name: newName,
            description: original.description ? `${original.description} (Copia)` : undefined,
            status: campaign_entity_1.CampaignStatus.DRAFT,
            settings: { ...original.settings },
            createdBy,
        });
        const saved = await this.campaignRepository.save(duplicated);
        const savedCampaign = Array.isArray(saved) ? saved[0] : saved;
        this.logger.log(`Campaña ${id} duplicada como ${savedCampaign.id}`);
        return savedCampaign;
    }
};
exports.CampaignsService = CampaignsService;
exports.CampaignsService = CampaignsService = CampaignsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(campaign_entity_1.Campaign)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        event_emitter_1.EventEmitter2])
], CampaignsService);
//# sourceMappingURL=campaigns.service.js.map