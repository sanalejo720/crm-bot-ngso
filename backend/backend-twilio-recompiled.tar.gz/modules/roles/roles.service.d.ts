import { Repository } from 'typeorm';
import { Role } from './entities/role.entity';
import { Permission } from './entities/permission.entity';
import { CreateRoleDto } from './dto/create-role.dto';
import { UpdateRoleDto } from './dto/update-role.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
export declare class RolesService {
    private roleRepository;
    private permissionRepository;
    private eventEmitter;
    private readonly logger;
    constructor(roleRepository: Repository<Role>, permissionRepository: Repository<Permission>, eventEmitter: EventEmitter2);
    create(createRoleDto: CreateRoleDto): Promise<Role>;
    findAll(): Promise<Role[]>;
    findOne(id: string): Promise<Role>;
    findByName(name: string): Promise<Role | null>;
    update(id: string, updateRoleDto: UpdateRoleDto): Promise<Role>;
    addPermissions(id: string, permissionIds: string[]): Promise<Role>;
    removePermissions(id: string, permissionIds: string[]): Promise<Role>;
    remove(id: string): Promise<void>;
    hasPermission(roleId: string, module: string, action: string): Promise<boolean>;
    getAllPermissions(): Promise<Permission[]>;
    seedPermissions(): Promise<void>;
    seedRoles(): Promise<void>;
}
