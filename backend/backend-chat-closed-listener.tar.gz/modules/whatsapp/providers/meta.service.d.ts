export declare class MetaService {
    private readonly logger;
    private readonly baseUrl;
    verifyToken(accessToken: string, phoneNumberId: string): Promise<boolean>;
    getPhoneNumberInfo(accessToken: string, phoneNumberId: string): Promise<any>;
    getBusinessAccountInfo(accessToken: string, businessAccountId: string): Promise<any>;
}
