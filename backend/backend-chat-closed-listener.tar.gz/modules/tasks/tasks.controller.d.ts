import { TasksService } from './tasks.service';
import { CreateTaskDto } from './dto/create-task.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { TaskStatus, TaskPriority } from './entities/task.entity';
export declare class TasksController {
    private readonly tasksService;
    constructor(tasksService: TasksService);
    create(createTaskDto: CreateTaskDto, user: any): Promise<import("./entities/task.entity").Task>;
    findAll(assignedTo?: string, createdBy?: string, status?: TaskStatus, priority?: TaskPriority, clientId?: string, campaignId?: string, chatId?: string): Promise<import("./entities/task.entity").Task[]>;
    getMyTasks(user: any): Promise<import("./entities/task.entity").Task[]>;
    getOverdue(user: any): Promise<import("./entities/task.entity").Task[]>;
    getStats(userId?: string): Promise<{
        total: number;
        pending: number;
        completed: number;
        overdue: number;
        completionRate: string | number;
        byPriority: any;
    }>;
    findOne(id: string): Promise<import("./entities/task.entity").Task>;
    update(id: string, updateTaskDto: UpdateTaskDto): Promise<import("./entities/task.entity").Task>;
    updateStatus(id: string, body: {
        status: TaskStatus;
    }, user: any): Promise<import("./entities/task.entity").Task>;
    complete(id: string, user: any): Promise<import("./entities/task.entity").Task>;
    assignTo(id: string, body: {
        userId: string;
    }): Promise<import("./entities/task.entity").Task>;
    remove(id: string): Promise<void>;
}
