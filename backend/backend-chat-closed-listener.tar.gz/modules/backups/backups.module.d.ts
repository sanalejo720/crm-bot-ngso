export declare class BackupsModule {
}
