import { ConfigService } from '@nestjs/config';
export declare class EmailService {
    private configService;
    private readonly logger;
    private transporter;
    constructor(configService: ConfigService);
    sendBackupPasswordEmail(backupId: string, fileName: string, masterPassword: string, createdBy: string): Promise<void>;
    verifyConnection(): Promise<boolean>;
}
