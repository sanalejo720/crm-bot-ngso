import { QuickRepliesService } from './quick-replies.service';
import { CreateQuickReplyDto } from './dto/create-quick-reply.dto';
import { UpdateQuickReplyDto } from './dto/update-quick-reply.dto';
import { QuickRepliesSeedService } from '../../scripts/seed-quick-replies.service';
export declare class QuickRepliesController {
    private readonly quickRepliesService;
    private readonly seedService;
    constructor(quickRepliesService: QuickRepliesService, seedService: QuickRepliesSeedService);
    create(req: any, createDto: CreateQuickReplyDto): Promise<import("./entities/quick-reply.entity").QuickReply>;
    findAll(req: any, campaignId?: string, category?: string): Promise<import("./entities/quick-reply.entity").QuickReply[]>;
    getStats(req: any): Promise<any>;
    findOne(id: string): Promise<import("./entities/quick-reply.entity").QuickReply>;
    applyTemplate(id: string, variables: Record<string, any>): Promise<{
        content: string;
    }>;
    findByShortcut(req: any, shortcut: string, campaignId?: string): Promise<import("./entities/quick-reply.entity").QuickReply>;
    update(req: any, id: string, updateDto: UpdateQuickReplyDto): Promise<import("./entities/quick-reply.entity").QuickReply>;
    remove(req: any, id: string): Promise<void>;
    seedTemplates(): Promise<{
        success: boolean;
        message: string;
    }>;
}
