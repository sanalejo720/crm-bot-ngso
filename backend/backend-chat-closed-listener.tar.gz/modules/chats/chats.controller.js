"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const chats_service_1 = require("./chats.service");
const chats_export_service_1 = require("./chats-export.service");
const create_chat_dto_1 = require("./dto/create-chat.dto");
const update_chat_dto_1 = require("./dto/update-chat.dto");
const assign_chat_dto_1 = require("./dto/assign-chat.dto");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const chat_entity_1 = require("./entities/chat.entity");
let ChatsController = class ChatsController {
    constructor(chatsService, chatsExportService) {
        this.chatsService = chatsService;
        this.chatsExportService = chatsExportService;
    }
    create(createChatDto) {
        return this.chatsService.create(createChatDto);
    }
    findAll(status, campaignId, assignedAgentId, whatsappNumberId) {
        return this.chatsService.findAll({
            status,
            campaignId,
            assignedAgentId,
            whatsappNumberId,
        });
    }
    getMyChats(userId, userRole) {
        if (userRole.name === 'Supervisor' || userRole.name === 'Super Admin') {
            return this.chatsService.findAll({});
        }
        return this.chatsService.findAll({ assignedAgentId: userId });
    }
    getWaitingChats(campaignId) {
        return this.chatsService.getWaitingChats(campaignId);
    }
    findOne(id) {
        return this.chatsService.findOne(id);
    }
    update(id, updateChatDto) {
        return this.chatsService.update(id, updateChatDto);
    }
    assign(id, assignDto) {
        return this.chatsService.assign(id, assignDto.agentId, assignDto.reason);
    }
    reassign(id, assignDto) {
        return this.chatsService.assign(id, assignDto.agentId, assignDto.reason);
    }
    updateStatus(id, body, userId) {
        if (body.status === chat_entity_1.ChatStatus.CLOSED) {
            return this.chatsService.close(id, userId);
        }
        if (body.status === chat_entity_1.ChatStatus.RESOLVED) {
            return this.chatsService.resolve(id, userId);
        }
        return this.chatsService.update(id, { status: body.status });
    }
    transfer(id, currentUserId, transferDto) {
        return this.chatsService.transfer(id, currentUserId, transferDto.newAgentId, transferDto.reason);
    }
    close(id, userId) {
        return this.chatsService.close(id, userId);
    }
    resolve(id, userId) {
        return this.chatsService.resolve(id, userId);
    }
    getAgentStats(agentId) {
        return this.chatsService.getAgentStats(agentId);
    }
    async exportChatToPDF(id, body, agentId) {
        const result = await this.chatsExportService.exportChatToPDF(id, body.closureType, agentId);
        return {
            success: true,
            message: 'Cierre de negociación enviado exitosamente a supervisores',
            data: {
                fileName: result.fileName,
                ticketNumber: result.ticketNumber,
            },
        };
    }
};
exports.ChatsController = ChatsController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Crear nuevo chat' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_chat_dto_1.CreateChatDto]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener todos los chats (solo supervisores)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'manage' }),
    __param(0, (0, common_1.Query)('status')),
    __param(1, (0, common_1.Query)('campaignId')),
    __param(2, (0, common_1.Query)('assignedAgentId')),
    __param(3, (0, common_1.Query)('whatsappNumberId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('my-chats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener mis chats asignados (agentes) o todos (supervisores)' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('role')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "getMyChats", null);
__decorate([
    (0, common_1.Get)('waiting/:campaignId'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener chats en cola' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Param)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "getWaitingChats", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener chat por ID' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Actualizar chat' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_chat_dto_1.UpdateChatDto]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "update", null);
__decorate([
    (0, common_1.Post)(':id/assign'),
    (0, swagger_1.ApiOperation)({ summary: 'Asignar chat a un agente' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'assign' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, assign_chat_dto_1.AssignChatDto]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "assign", null);
__decorate([
    (0, common_1.Patch)(':id/assign'),
    (0, swagger_1.ApiOperation)({ summary: 'Asignar/Reasignar chat a un agente (para supervisores)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'assign' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, assign_chat_dto_1.AssignChatDto]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "reassign", null);
__decorate([
    (0, common_1.Patch)(':id/status'),
    (0, swagger_1.ApiOperation)({ summary: 'Cambiar estado del chat' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Post)(':id/transfer'),
    (0, swagger_1.ApiOperation)({ summary: 'Transferir chat a otro agente' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'transfer' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, assign_chat_dto_1.TransferChatDto]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "transfer", null);
__decorate([
    (0, common_1.Post)(':id/close'),
    (0, swagger_1.ApiOperation)({ summary: 'Cerrar chat' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "close", null);
__decorate([
    (0, common_1.Post)(':id/resolve'),
    (0, swagger_1.ApiOperation)({ summary: 'Resolver chat' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "resolve", null);
__decorate([
    (0, common_1.Get)(':id/stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas de un agente' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], ChatsController.prototype, "getAgentStats", null);
__decorate([
    (0, common_1.Post)(':id/export-pdf'),
    (0, swagger_1.ApiOperation)({ summary: 'Enviar cierre de negociación (PDF cifrado a supervisores)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'chats', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, String]),
    __metadata("design:returntype", Promise)
], ChatsController.prototype, "exportChatToPDF", null);
exports.ChatsController = ChatsController = __decorate([
    (0, swagger_1.ApiTags)('chats'),
    (0, common_1.Controller)('chats'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [chats_service_1.ChatsService,
        chats_export_service_1.ChatsExportService])
], ChatsController);
//# sourceMappingURL=chats.controller.js.map