import { Repository } from 'typeorm';
import { PazYSalvo } from './entities/paz-y-salvo.entity';
import { Client } from './entities/client.entity';
import { ClientIdentificationService } from './client-identification.service';
export declare class PazYSalvoService {
    private pazYSalvoRepository;
    private clientRepository;
    private clientIdentificationService;
    private readonly logger;
    constructor(pazYSalvoRepository: Repository<PazYSalvo>, clientRepository: Repository<Client>, clientIdentificationService: ClientIdentificationService);
    createPazYSalvo(clientId: string, paymentDate: Date, paidAmount: number, metadata?: any): Promise<PazYSalvo>;
    checkAvailability(clientId: string): Promise<{
        isAvailable: boolean;
        pazYSalvo?: PazYSalvo;
        message: string;
        daysRemaining?: number;
    }>;
    generatePDF(pazYSalvoId: string, userId?: string): Promise<string>;
    registerDownload(pazYSalvoId: string, userId?: string): Promise<void>;
    private createPDF;
    private generateCertificateNumber;
    getByClientId(clientId: string): Promise<PazYSalvo | null>;
}
