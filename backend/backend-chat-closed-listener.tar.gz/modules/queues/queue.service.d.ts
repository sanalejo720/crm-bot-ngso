import { Queue } from 'bull';
import { ChatsService } from '../chats/chats.service';
import { UsersService } from '../users/users.service';
import { Chat } from '../chats/entities/chat.entity';
import { RoundRobinStrategy } from './strategies/round-robin.strategy';
import { LeastBusyStrategy } from './strategies/least-busy.strategy';
import { SkillsBasedStrategy } from './strategies/skills-based.strategy';
export interface ChatAssignmentJob {
    chatId: string;
    campaignId: string;
    strategy?: string;
}
export declare class QueueService {
    private chatAssignmentQueue;
    private chatsService;
    private usersService;
    private roundRobinStrategy;
    private leastBusyStrategy;
    private skillsBasedStrategy;
    private readonly logger;
    private strategies;
    constructor(chatAssignmentQueue: Queue, chatsService: ChatsService, usersService: UsersService, roundRobinStrategy: RoundRobinStrategy, leastBusyStrategy: LeastBusyStrategy, skillsBasedStrategy: SkillsBasedStrategy);
    handleChatCreated(chat: Chat): Promise<void>;
    addChatToQueue(chatId: string, campaignId: string, strategy?: string): Promise<void>;
    processAssignment(job: ChatAssignmentJob): Promise<void>;
    getQueueStats(): Promise<{
        waiting: number;
        active: number;
        completed: number;
        failed: number;
        total: number;
    }>;
    cleanQueue(): Promise<void>;
    pauseQueue(): Promise<void>;
    resumeQueue(): Promise<void>;
}
