"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var EventsGateway_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventsGateway = void 0;
const websockets_1 = require("@nestjs/websockets");
const socket_io_1 = require("socket.io");
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const event_emitter_1 = require("@nestjs/event-emitter");
const chat_entity_1 = require("../chats/entities/chat.entity");
let EventsGateway = EventsGateway_1 = class EventsGateway {
    constructor(jwtService) {
        this.jwtService = jwtService;
        this.logger = new common_1.Logger(EventsGateway_1.name);
        this.connectedUsers = new Map();
    }
    async handleConnection(client) {
        try {
            const token = client.handshake.auth?.token || client.handshake.headers?.authorization?.replace('Bearer ', '');
            if (!token) {
                this.logger.warn(`❌ Cliente sin token rechazado: ${client.id}`);
                client.disconnect();
                return;
            }
            this.logger.log(`🔍 Validando token para cliente: ${client.id}`);
            const payload = await this.jwtService.verifyAsync(token);
            client.userId = payload.sub;
            client.user = payload;
            this.connectedUsers.set(payload.sub, client.id);
            client.join(`user:${payload.sub}`);
            if (payload.role?.name === 'Agente' || payload.role?.name === 'Supervisor') {
                client.join('agents');
            }
            if (payload.role?.name === 'Supervisor' || payload.role?.name === 'Super Admin' || payload.role?.name === 'Administrador') {
                client.join('supervisors');
            }
            this.logger.log(`✅ Cliente conectado exitosamente: ${payload.email} (${client.id})`);
            this.server.to('supervisors').emit('agent:online', {
                userId: payload.sub,
                userName: payload.fullName,
                timestamp: new Date(),
            });
        }
        catch (error) {
            this.logger.error(`❌ Error en autenticación WebSocket (${client.id}): ${error.message}`);
            client.disconnect();
        }
    }
    handleDisconnect(client) {
        if (client.userId) {
            this.connectedUsers.delete(client.userId);
            this.logger.log(`Cliente desconectado: ${client.userId} (${client.id})`);
            this.server.to('supervisors').emit('agent:offline', {
                userId: client.userId,
                timestamp: new Date(),
            });
        }
    }
    handleSubscribeChat(client, data) {
        client.join(`chat:${data.chatId}`);
        this.logger.log(`Usuario ${client.userId} suscrito a chat ${data.chatId}`);
        return { success: true };
    }
    handleUnsubscribeChat(client, data) {
        client.leave(`chat:${data.chatId}`);
        this.logger.log(`Usuario ${client.userId} desuscrito de chat ${data.chatId}`);
        return { success: true };
    }
    handleAgentJoin(client, data) {
        const roomName = `user:${data.agentId}`;
        client.join(roomName);
        this.logger.log(`✅ Agente ${data.agentId} unido a sala ${roomName} (Socket: ${client.id})`);
        return { success: true, room: roomName };
    }
    handleTyping(client, data) {
        this.server.to(`chat:${data.chatId}`).emit('chat:typing', {
            chatId: data.chatId,
            userId: client.userId,
            userName: client.user?.fullName,
            isTyping: data.isTyping,
            timestamp: new Date(),
        });
    }
    handleAgentStateChange(client, data) {
        this.server.to('supervisors').emit('agent:state-changed', {
            userId: client.userId,
            userName: client.user?.fullName,
            state: data.state,
            timestamp: new Date(),
        });
        return { success: true };
    }
    handleChatCreated(chat) {
        this.logger.log(`Evento chat.created: ${chat.id}`);
        this.server.to('agents').emit('chat:new', {
            chatId: chat.id,
            campaignId: chat.campaignId,
            contactPhone: chat.contactPhone,
            contactName: chat.contactName,
            lastMessage: chat.lastMessage,
            timestamp: new Date(),
        });
        this.server.to('supervisors').emit('chat:created', {
            chatId: chat.id,
            campaignId: chat.campaignId,
            status: chat.status,
            timestamp: new Date(),
        });
    }
    handleChatAssigned(data) {
        this.logger.log(`📨 Evento chat.assigned recibido: Chat ${data.chat.id} -> Agente ${data.agentName} (${data.agentId})`);
        const roomName = `user:${data.agentId}`;
        const socketId = this.connectedUsers.get(data.agentId);
        this.logger.log(`🎯 Emitiendo a sala: ${roomName} (Socket: ${socketId || 'no conectado'})`);
        this.server.to(roomName).emit('chat:assigned', {
            chatId: data.chat.id,
            campaignId: data.chat.campaignId,
            contactPhone: data.chat.contactPhone,
            contactName: data.chat.contactName,
            lastMessage: data.chat.lastMessage,
            timestamp: new Date(),
        });
        this.server.to('supervisors').emit('chat:assignment', {
            chatId: data.chat.id,
            agentId: data.agentId,
            agentName: data.agentName,
            timestamp: new Date(),
        });
        this.logger.log(`✅ Evento chat:assigned emitido correctamente`);
    }
    handleChatTransferred(data) {
        this.logger.log(`Evento chat.transferred: ${data.chat.id} -> ${data.toAgentName}`);
        this.server.to(`user:${data.fromAgentId}`).emit('chat:transferred-out', {
            chatId: data.chat.id,
            toAgentName: data.toAgentName,
            timestamp: new Date(),
        });
        this.server.to(`user:${data.toAgentId}`).emit('chat:transferred-in', {
            chatId: data.chat.id,
            campaignId: data.chat.campaignId,
            contactPhone: data.chat.contactPhone,
            contactName: data.chat.contactName,
            fromAgentName: data.fromAgentName,
            timestamp: new Date(),
        });
        this.server.to('supervisors').emit('chat:transfer', {
            chatId: data.chat.id,
            fromAgentId: data.fromAgentId,
            toAgentId: data.toAgentId,
            timestamp: new Date(),
        });
    }
    handleChatUnassigned(data) {
        this.logger.log(`Evento chat.unassigned: ${data.chat.id} desasignado del agente ${data.previousAgentId}`);
        this.server.to(`user:${data.previousAgentId}`).emit('chat:unassigned', {
            chatId: data.chat.id,
            reason: data.reason,
            timestamp: new Date(),
        });
        this.server.to('supervisors').emit('chat:unassigned', {
            chatId: data.chat.id,
            previousAgentId: data.previousAgentId,
            reason: data.reason,
            timestamp: new Date(),
        });
    }
    handleChatClosed(chat) {
        this.logger.log(`Evento chat.closed: ${chat.id}`);
        this.server.to(`chat:${chat.id}`).emit('chat:closed', {
            chatId: chat.id,
            status: chat.status,
            timestamp: new Date(),
        });
        if (chat.assignedAgentId) {
            this.server.to(`user:${chat.assignedAgentId}`).emit('chat:closed', {
                chatId: chat.id,
                timestamp: new Date(),
            });
        }
        this.server.to('supervisors').emit('chat:status-changed', {
            chatId: chat.id,
            status: chat.status,
            timestamp: new Date(),
        });
    }
    handleMessageCreated(event) {
        const { message, chat } = event;
        this.logger.log(`Evento message.created: ${message.id} en chat ${message.chatId}`);
        this.server.to(`chat:${message.chatId}`).emit('message:new', {
            messageId: message.id,
            chatId: message.chatId,
            type: message.type,
            direction: message.direction,
            senderType: message.senderType,
            content: message.content,
            mediaUrl: message.mediaUrl,
            status: message.status,
            timestamp: message.createdAt,
        });
        if (chat?.assignedAgentId) {
            this.server.to(`user:${chat.assignedAgentId}`).emit('message:new', {
                messageId: message.id,
                chatId: message.chatId,
                type: message.type,
                direction: message.direction,
                senderType: message.senderType,
                content: message.content,
                mediaUrl: message.mediaUrl,
                status: message.status,
                timestamp: message.createdAt,
            });
        }
    }
    handleMessageStatusUpdated(data) {
        this.logger.log(`Evento message.status-updated: ${data.messageId} -> ${data.status}`);
        this.server.to(`chat:${data.chatId}`).emit('message:status', {
            messageId: data.messageId,
            status: data.status,
            timestamp: new Date(),
        });
    }
    handleAgentStateChanged(data) {
        this.logger.log(`Evento user.agent-state-changed: ${data.userName} -> ${data.state}`);
        this.server.to('supervisors').emit('agent:state-changed', {
            userId: data.userId,
            userName: data.userName,
            state: data.state,
            timestamp: new Date(),
        });
    }
    handleWhatsAppQRGenerated(data) {
        this.logger.log(`Evento whatsapp.qrcode.generated: ${data.numberId || data.sessionName}`);
        this.server.emit('whatsapp.qrcode.generated', {
            numberId: data.numberId,
            sessionName: data.sessionName,
            qrCode: data.qrCode,
            timestamp: new Date(),
        });
    }
    handleWhatsAppSessionStatus(data) {
        this.logger.log(`Evento whatsapp.session.status: ${data.sessionName} -> ${data.status}`);
        this.server.emit('whatsapp.session.status', {
            sessionName: data.sessionName,
            status: data.status,
            timestamp: new Date(),
        });
        if (data.status === 'isLogged' || data.status === 'qrReadSuccess') {
            this.server.emit('whatsapp.session.connected', {
                sessionName: data.sessionName,
                timestamp: new Date(),
            });
        }
    }
    handleWhatsAppSessionDisconnected(data) {
        this.logger.log(`Evento whatsapp.session.disconnected: ${data.numberId}`);
        this.server.emit('whatsapp.session.disconnected', {
            numberId: data.numberId,
            timestamp: new Date(),
        });
    }
    handleWhatsAppMessageReceived(data) {
        this.logger.log(`Evento whatsapp.message.received: ${data.from}`);
        this.server.to('agents').emit('whatsapp.message.incoming', {
            from: data.from,
            content: data.content,
            timestamp: data.timestamp,
        });
    }
    emitToUser(userId, event, data) {
        this.server.to(`user:${userId}`).emit(event, data);
    }
    emitToChat(chatId, event, data) {
        this.server.to(`chat:${chatId}`).emit(event, data);
    }
    emitToAgents(event, data) {
        this.server.to('agents').emit(event, data);
    }
    emitToSupervisors(event, data) {
        this.server.to('supervisors').emit(event, data);
    }
    isUserConnected(userId) {
        return this.connectedUsers.has(userId);
    }
    getConnectedUsers() {
        return Array.from(this.connectedUsers.keys());
    }
};
exports.EventsGateway = EventsGateway;
__decorate([
    (0, websockets_1.WebSocketServer)(),
    __metadata("design:type", socket_io_1.Server)
], EventsGateway.prototype, "server", void 0);
__decorate([
    (0, websockets_1.SubscribeMessage)('chat:subscribe'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleSubscribeChat", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('chat:unsubscribe'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleUnsubscribeChat", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('agent:join'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleAgentJoin", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('chat:typing'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleTyping", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('agent:state'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleAgentStateChange", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.created'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [chat_entity_1.Chat]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatCreated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.assigned'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatAssigned", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.transferred'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatTransferred", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.unassigned'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatUnassigned", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.closed'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [chat_entity_1.Chat]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleChatClosed", null);
__decorate([
    (0, event_emitter_1.OnEvent)('message.created'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleMessageCreated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('message.status-updated'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleMessageStatusUpdated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('user.agent-state-changed'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleAgentStateChanged", null);
__decorate([
    (0, event_emitter_1.OnEvent)('whatsapp.qrcode.generated'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleWhatsAppQRGenerated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('whatsapp.session.status'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleWhatsAppSessionStatus", null);
__decorate([
    (0, event_emitter_1.OnEvent)('whatsapp.session.disconnected'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleWhatsAppSessionDisconnected", null);
__decorate([
    (0, event_emitter_1.OnEvent)('whatsapp.message.received'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], EventsGateway.prototype, "handleWhatsAppMessageReceived", null);
exports.EventsGateway = EventsGateway = EventsGateway_1 = __decorate([
    (0, websockets_1.WebSocketGateway)({
        cors: {
            origin: [
                process.env.FRONTEND_URL || 'http://localhost:5173',
                'http://localhost:5174',
            ],
            credentials: true,
        },
        namespace: '/events',
    }),
    __metadata("design:paramtypes", [jwt_1.JwtService])
], EventsGateway);
//# sourceMappingURL=events.gateway.js.map