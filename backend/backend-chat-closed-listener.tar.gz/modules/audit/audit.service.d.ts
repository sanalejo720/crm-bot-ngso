import { Repository } from 'typeorm';
import { AuditLog } from './entities/audit-log.entity';
import { EventEmitter2 } from '@nestjs/event-emitter';
export interface CreateAuditLogDto {
    userId?: string;
    userName?: string;
    action: string;
    module: string;
    entityId?: string;
    entityType?: string;
    oldValues?: Record<string, any>;
    newValues?: Record<string, any>;
    metadata?: Record<string, any>;
    ipAddress?: string;
    userAgent?: string;
}
export declare class AuditService {
    private auditLogRepository;
    private eventEmitter;
    private readonly logger;
    constructor(auditLogRepository: Repository<AuditLog>, eventEmitter: EventEmitter2);
    log(data: CreateAuditLogDto): Promise<AuditLog>;
    findAll(filters?: {
        userId?: string;
        module?: string;
        action?: string;
        entityType?: string;
        startDate?: Date;
        endDate?: Date;
        limit?: number;
    }): Promise<AuditLog[]>;
    findByEntity(entityType: string, entityId: string): Promise<AuditLog[]>;
    findByUser(userId: string, limit?: number): Promise<AuditLog[]>;
    getStats(startDate?: Date, endDate?: Date): Promise<{
        total: number;
        byModule: any;
        byAction: any;
        topUsers: {
            userId: any;
            userName: any;
            count: number;
        }[];
    }>;
    handleUserCreated(data: any): void;
    handleUserUpdated(data: any): void;
    handleUserDeleted(data: any): void;
    handleChatAssigned(data: any): void;
    handleChatTransferred(data: any): void;
    handleCampaignCreated(data: any): void;
    handleCampaignStatusChanged(data: any): void;
    handleRoleCreated(data: any): void;
    handleClientLeadStatusChanged(data: any): void;
    handleTaskStatusChanged(data: any): void;
    handleMessageCreated(event: {
        message: any;
        chat: any;
    }): void;
}
