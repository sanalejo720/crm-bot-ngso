"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var QuickRepliesSeedService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuickRepliesSeedService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const quick_reply_entity_1 = require("../modules/quick-replies/entities/quick-reply.entity");
let QuickRepliesSeedService = QuickRepliesSeedService_1 = class QuickRepliesSeedService {
    constructor(quickReplyRepository) {
        this.quickReplyRepository = quickReplyRepository;
        this.logger = new common_1.Logger(QuickRepliesSeedService_1.name);
    }
    async seed() {
        this.logger.log('Creando plantillas de mensajes predeterminadas...');
        const templates = [
            {
                shortcut: '/saludo',
                title: 'Saludo Inicial',
                content: 'Hola {{clientName}}, soy {{agentName}} de NGS&O. ¿En qué puedo ayudarte hoy?',
                variables: ['clientName', 'agentName'],
                category: 'Saludo',
            },
            {
                shortcut: '/bienvenida',
                title: 'Bienvenida Formal',
                content: 'Buenos días {{clientName}}, mi nombre es {{agentName}} y te atiendo desde NGS&O Gestión. Estoy aquí para ayudarte.',
                variables: ['clientName', 'agentName'],
                category: 'Saludo',
            },
            {
                shortcut: '/recordatorio',
                title: 'Recordatorio de Deuda',
                content: '{{clientName}}, te recordamos que tienes una deuda pendiente de ${{debtAmount}} con {{daysOverdue}} días de mora. ¿Cuándo podrás realizar el pago?',
                variables: ['clientName', 'debtAmount', 'daysOverdue'],
                category: 'Recordatorio',
            },
            {
                shortcut: '/seguimiento',
                title: 'Seguimiento General',
                content: 'Hola {{clientName}}, te contacto para dar seguimiento a tu caso. ¿Has podido revisar la información que te envié?',
                variables: ['clientName'],
                category: 'Seguimiento',
            },
            {
                shortcut: '/compromiso',
                title: 'Confirmar Compromiso',
                content: 'Perfecto {{clientName}}, confirmamos tu compromiso de pago de ${{debtAmount}} para el día {{paymentDate}}. Te enviaremos un recordatorio.',
                variables: ['clientName', 'debtAmount', 'paymentDate'],
                category: 'Seguimiento',
            },
            {
                shortcut: '/pago',
                title: 'Información de Pago',
                content: 'Para realizar el pago puedes usar:\n\n💳 Transferencia bancaria\n🏦 Pago en sucursal\n📱 PSE\n\n¿Qué método prefieres?',
                variables: [],
                category: 'Informativo',
            },
            {
                shortcut: '/descuento',
                title: 'Oferta de Descuento',
                content: '{{clientName}}, tenemos una oferta especial para ti. Si cancelas tu deuda de ${{debtAmount}} antes del {{expirationDate}}, aplicamos un descuento del {{discountPercent}}%.',
                variables: ['clientName', 'debtAmount', 'expirationDate', 'discountPercent'],
                category: 'Informativo',
            },
            {
                shortcut: '/despedida',
                title: 'Despedida Cordial',
                content: 'Gracias por tu atención {{clientName}}. Quedamos atentos a tu pago. ¡Que tengas excelente día!',
                variables: ['clientName'],
                category: 'Cierre',
            },
            {
                shortcut: '/gracias',
                title: 'Agradecimiento',
                content: '¡Muchas gracias {{clientName}}! Tu pago ha sido registrado exitosamente. Recibirás un comprobante por correo.',
                variables: ['clientName'],
                category: 'Cierre',
            },
            {
                shortcut: '/espera',
                title: 'Solicitar Espera',
                content: '{{clientName}}, dame un momento por favor mientras consulto la información en el sistema.',
                variables: ['clientName'],
                category: 'Informativo',
            },
            {
                shortcut: '/ausente',
                title: 'Mensaje Fuera de Horario',
                content: 'Hola {{clientName}}, en este momento nos encontramos fuera de nuestro horario de atención (Lun-Vie 8am-6pm). Te responderemos a primera hora. Gracias por tu paciencia.',
                variables: ['clientName'],
                category: 'Informativo',
            },
            {
                shortcut: '/noencontrado',
                title: 'No se Encuentra Información',
                content: '{{clientName}}, no encuentro tu información en el sistema. ¿Podrías confirmarme tu número de documento?',
                variables: ['clientName'],
                category: 'Seguimiento',
            },
        ];
        for (const template of templates) {
            const existing = await this.quickReplyRepository.findOne({
                where: { shortcut: template.shortcut },
            });
            if (!existing) {
                const quickReply = this.quickReplyRepository.create({
                    ...template,
                    userId: null,
                    campaignId: null,
                    isActive: true,
                    usageCount: 0,
                });
                await this.quickReplyRepository.save(quickReply);
                this.logger.log(`✅ Plantilla creada: ${template.shortcut} - ${template.title}`);
            }
            else {
                this.logger.log(`⏭️  Plantilla ya existe: ${template.shortcut}`);
            }
        }
        this.logger.log('✅ Seed de plantillas completado');
    }
};
exports.QuickRepliesSeedService = QuickRepliesSeedService;
exports.QuickRepliesSeedService = QuickRepliesSeedService = QuickRepliesSeedService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(quick_reply_entity_1.QuickReply)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], QuickRepliesSeedService);
//# sourceMappingURL=seed-quick-replies.service.js.map