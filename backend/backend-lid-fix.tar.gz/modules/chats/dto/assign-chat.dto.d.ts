export declare class AssignChatDto {
    agentId: string | null;
    reason?: string;
}
export declare class TransferChatDto {
    newAgentId: string;
    reason: string;
}
