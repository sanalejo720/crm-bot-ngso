import { PermissionRequirement } from '../guards/permissions.guard';
export declare const RequirePermissions: (...permissions: PermissionRequirement[]) => import("@nestjs/common").CustomDecorator<string>;
