"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentEvidencesService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const payment_evidence_entity_1 = require("./entities/payment-evidence.entity");
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const uuid_1 = require("uuid");
let PaymentEvidencesService = class PaymentEvidencesService {
    constructor(evidenceRepository) {
        this.evidenceRepository = evidenceRepository;
        this.uploadDir = path.join(process.cwd(), 'uploads', 'payment-evidences');
        this.ensureUploadDir();
    }
    async ensureUploadDir() {
        try {
            await fs.mkdir(this.uploadDir, { recursive: true });
        }
        catch (error) {
            console.error('Error creating upload directory:', error);
        }
    }
    async uploadEvidence(file, createDto, userId) {
        const allowedMimes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
        if (!allowedMimes.includes(file.mimetype)) {
            throw new common_1.BadRequestException('Tipo de archivo no permitido. Solo se aceptan imágenes (JPEG, PNG) o PDF');
        }
        const maxSize = 10 * 1024 * 1024;
        if (file.size > maxSize) {
            throw new common_1.BadRequestException('El archivo excede el tamaño máximo permitido (10MB)');
        }
        const evidenceType = file.mimetype === 'application/pdf' ? payment_evidence_entity_1.EvidenceType.PDF : payment_evidence_entity_1.EvidenceType.IMAGE;
        const fileExt = path.extname(file.originalname);
        const fileName = `${(0, uuid_1.v4)()}${fileExt}`;
        const filePath = path.join(this.uploadDir, fileName);
        await fs.writeFile(filePath, file.buffer);
        const evidence = this.evidenceRepository.create({
            clientId: createDto.clientId,
            uploadedBy: userId,
            fileName,
            filePath: `/uploads/payment-evidences/${fileName}`,
            fileType: file.mimetype,
            fileSize: file.size,
            evidenceType,
            paymentAmount: createDto.paymentAmount,
            paymentDate: new Date(createDto.paymentDate),
            notes: createDto.notes,
            metadata: {
                originalName: file.originalname,
                mimeType: file.mimetype,
                campaignId: createDto.campaignId,
                referenceNumber: createDto.referenceNumber,
            },
        });
        return this.evidenceRepository.save(evidence);
    }
    async findAll(query) {
        const where = {};
        if (query.clientId) {
            where.clientId = query.clientId;
        }
        if (query.status) {
            where.status = query.status;
        }
        if (query.uploadedBy) {
            where.uploadedBy = query.uploadedBy;
        }
        if (query.startDate && query.endDate) {
            where.paymentDate = (0, typeorm_2.Between)(new Date(query.startDate), new Date(query.endDate));
        }
        return this.evidenceRepository.find({
            where,
            relations: ['client', 'uploader', 'reviewer'],
            order: { uploadedAt: 'DESC' },
        });
    }
    async findOne(id) {
        const evidence = await this.evidenceRepository.findOne({
            where: { id },
            relations: ['client', 'uploader', 'reviewer'],
        });
        if (!evidence) {
            throw new common_1.NotFoundException(`Evidencia con ID ${id} no encontrada`);
        }
        return evidence;
    }
    async reviewEvidence(id, reviewDto, reviewerId) {
        const evidence = await this.findOne(id);
        if (evidence.status !== payment_evidence_entity_1.EvidenceStatus.PENDING) {
            throw new common_1.BadRequestException('Esta evidencia ya fue revisada');
        }
        evidence.status = reviewDto.status === 'approved' ? payment_evidence_entity_1.EvidenceStatus.APPROVED : payment_evidence_entity_1.EvidenceStatus.REJECTED;
        evidence.reviewedBy = reviewerId;
        evidence.reviewedAt = new Date();
        evidence.reviewNotes = reviewDto.reviewNotes;
        return this.evidenceRepository.save(evidence);
    }
    async deleteEvidence(id) {
        const evidence = await this.findOne(id);
        try {
            const fullPath = path.join(process.cwd(), evidence.filePath);
            await fs.unlink(fullPath);
        }
        catch (error) {
            console.error('Error al eliminar archivo:', error);
        }
        await this.evidenceRepository.remove(evidence);
    }
    async getEvidencesByClient(clientId) {
        return this.evidenceRepository.find({
            where: { clientId },
            relations: ['uploader', 'reviewer'],
            order: { uploadedAt: 'DESC' },
        });
    }
    async getPendingCount() {
        return this.evidenceRepository.count({
            where: { status: payment_evidence_entity_1.EvidenceStatus.PENDING },
        });
    }
};
exports.PaymentEvidencesService = PaymentEvidencesService;
exports.PaymentEvidencesService = PaymentEvidencesService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(payment_evidence_entity_1.PaymentEvidence)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], PaymentEvidencesService);
//# sourceMappingURL=payment-evidences.service.js.map