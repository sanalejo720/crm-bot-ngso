export declare class QuickRepliesModule {
}
