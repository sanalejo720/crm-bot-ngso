import { TaskStatus, TaskPriority } from '../entities/task.entity';
export declare class CreateTaskDto {
    title: string;
    description?: string;
    status?: TaskStatus;
    priority?: TaskPriority;
    dueDate?: Date;
    assignedTo?: string;
    clientId?: string;
    campaignId?: string;
    chatId?: string;
}
