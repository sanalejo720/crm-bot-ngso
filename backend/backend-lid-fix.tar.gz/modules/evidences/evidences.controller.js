"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EvidencesController = void 0;
const common_1 = require("@nestjs/common");
const evidences_service_1 = require("./evidences.service");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const swagger_1 = require("@nestjs/swagger");
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
let EvidencesController = class EvidencesController {
    constructor(evidencesService) {
        this.evidencesService = evidencesService;
    }
    async findAll(closureType, agentId, startDate, endDate) {
        const filters = {};
        if (closureType)
            filters.closureType = closureType;
        if (agentId)
            filters.agentId = agentId;
        if (startDate)
            filters.startDate = new Date(startDate);
        if (endDate)
            filters.endDate = new Date(endDate);
        const evidences = await this.evidencesService.findAll(filters);
        return {
            success: true,
            data: evidences,
            total: evidences.length,
        };
    }
    async getStats(agentId) {
        const stats = await this.evidencesService.getAgentStats(agentId);
        return {
            success: true,
            data: stats,
        };
    }
    async downloadEvidence(ticketNumber, res, req) {
        const userRole = req.user?.role?.name;
        if (userRole !== 'Supervisor' && userRole !== 'Super Admin') {
            return res.status(403).json({
                success: false,
                message: 'Solo Supervisores y Administradores pueden descargar evidencias',
            });
        }
        const evidence = await this.evidencesService.findByTicket(ticketNumber);
        const filePath = path.join(process.cwd(), evidence.filePath.replace(/^\//, ''));
        if (!fs.existsSync(filePath)) {
            return res.status(404).json({
                success: false,
                message: 'Archivo no encontrado',
            });
        }
        res.download(filePath, evidence.fileName, (err) => {
            if (err) {
                console.error('Error descargando archivo:', err);
                if (!res.headersSent) {
                    res.status(500).json({
                        success: false,
                        message: 'Error al descargar el archivo',
                    });
                }
            }
        });
    }
    async findOne(ticketNumber) {
        const evidence = await this.evidencesService.findByTicket(ticketNumber);
        return {
            success: true,
            data: evidence,
        };
    }
};
exports.EvidencesController = EvidencesController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Listar evidencias de pago (Solo Supervisores y Super Admin)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'evidences', action: 'read' }),
    __param(0, (0, common_1.Query)('closureType')),
    __param(1, (0, common_1.Query)('agentId')),
    __param(2, (0, common_1.Query)('startDate')),
    __param(3, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], EvidencesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Estadísticas de evidencias por agente' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'evidences', action: 'read' }),
    __param(0, (0, common_1.Query)('agentId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EvidencesController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)('download/:ticketNumber'),
    (0, swagger_1.ApiOperation)({ summary: 'Descargar PDF de evidencia con QR (Solo Supervisores/Admins)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'evidences', action: 'download' }),
    __param(0, (0, common_1.Param)('ticketNumber')),
    __param(1, (0, common_1.Res)()),
    __param(2, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], EvidencesController.prototype, "downloadEvidence", null);
__decorate([
    (0, common_1.Get)(':ticketNumber'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener detalles de evidencia por ticket' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'evidences', action: 'read' }),
    __param(0, (0, common_1.Param)('ticketNumber')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EvidencesController.prototype, "findOne", null);
exports.EvidencesController = EvidencesController = __decorate([
    (0, swagger_1.ApiTags)('Evidencias de Pago'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.Controller)('evidences'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    __metadata("design:paramtypes", [evidences_service_1.EvidencesService])
], EvidencesController);
//# sourceMappingURL=evidences.controller.js.map