import { WhatsappService } from './whatsapp.service';
export declare class WhatsappController {
    private readonly whatsappService;
    constructor(whatsappService: WhatsappService);
    getGeneralStatus(): Promise<{
        success: boolean;
        data: {
            connected: boolean;
            totalNumbers: number;
            numbers: import("./entities/whatsapp-number.entity").WhatsappNumber[];
        };
    }>;
    getQR(): Promise<{
        success: boolean;
        data: {
            message: string;
            instruction: string;
        };
    }>;
    checkConnection(): Promise<{
        success: boolean;
        data: {
            connected: boolean;
            message: string;
        };
    }>;
    findAllActive(): Promise<import("./entities/whatsapp-number.entity").WhatsappNumber[]>;
    findOne(id: string): Promise<import("./entities/whatsapp-number.entity").WhatsappNumber>;
    findByCampaign(campaignId: string): Promise<import("./entities/whatsapp-number.entity").WhatsappNumber[]>;
    startWppConnectSession(id: string): Promise<{
        success: boolean;
        message: string;
        sessionName: string;
        qrCode: string;
        status: string;
    }>;
    getWppConnectStatus(id: string): Promise<{
        connected: boolean;
        phone?: string;
    }>;
    sendMessage(body: {
        whatsappNumberId: string;
        to: string;
        content: string;
        type?: string;
    }): Promise<{
        success: boolean;
        data: {
            messageId: string;
            metadata?: any;
        };
        message: string;
    }>;
    getDebugSessions(): Promise<{
        wppConnectSessions: string[];
        databaseNumbers: {
            id: string;
            phone: string;
            sessionName: string;
            status: import("./entities/whatsapp-number.entity").ConnectionStatus;
        }[];
    }>;
}
