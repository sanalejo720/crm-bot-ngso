export declare class ClientsModule {
}
