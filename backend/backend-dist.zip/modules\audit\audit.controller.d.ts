import { AuditService } from './audit.service';
export declare class AuditController {
    private readonly auditService;
    constructor(auditService: AuditService);
    findAll(userId?: string, module?: string, action?: string, entityType?: string, startDate?: string, endDate?: string, limit?: string): Promise<import("./entities/audit-log.entity").AuditLog[]>;
    getStats(startDate?: string, endDate?: string): Promise<{
        total: number;
        byModule: any;
        byAction: any;
        topUsers: {
            userId: any;
            userName: any;
            count: number;
        }[];
    }>;
    findByEntity(entityType: string, entityId: string): Promise<import("./entities/audit-log.entity").AuditLog[]>;
    findByUser(userId: string, limit?: string): Promise<import("./entities/audit-log.entity").AuditLog[]>;
}
