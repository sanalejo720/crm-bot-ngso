"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var BotEngineService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotEngineService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const event_emitter_1 = require("@nestjs/event-emitter");
const bot_flow_entity_1 = require("./entities/bot-flow.entity");
const bot_node_entity_1 = require("./entities/bot-node.entity");
const messages_service_1 = require("../messages/messages.service");
const chats_service_1 = require("../chats/chats.service");
const whatsapp_service_1 = require("../whatsapp/whatsapp.service");
const debtors_service_1 = require("../debtors/debtors.service");
const chat_entity_1 = require("../chats/entities/chat.entity");
const user_entity_1 = require("../users/entities/user.entity");
const campaign_entity_1 = require("../campaigns/entities/campaign.entity");
const message_entity_1 = require("../messages/entities/message.entity");
let BotEngineService = BotEngineService_1 = class BotEngineService {
    constructor(botFlowRepository, botNodeRepository, userRepository, campaignRepository, messagesService, chatsService, whatsappService, debtorsService, eventEmitter) {
        this.botFlowRepository = botFlowRepository;
        this.botNodeRepository = botNodeRepository;
        this.userRepository = userRepository;
        this.campaignRepository = campaignRepository;
        this.messagesService = messagesService;
        this.chatsService = chatsService;
        this.whatsappService = whatsappService;
        this.debtorsService = debtorsService;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(BotEngineService_1.name);
        this.sessions = new Map();
    }
    async startFlow(chatId, flowId) {
        this.logger.log(`Iniciando flujo ${flowId} para chat ${chatId}`);
        const flow = await this.botFlowRepository.findOne({
            where: { id: flowId, status: bot_flow_entity_1.BotFlowStatus.ACTIVE },
            relations: ['nodes'],
        });
        if (!flow) {
            throw new common_1.NotFoundException(`Flujo de bot ${flowId} no encontrado o inactivo`);
        }
        if (!flow.startNodeId) {
            throw new Error('El flujo no tiene nodo inicial configurado');
        }
        const chat = await this.chatsService.findOne(chatId);
        const variables = this.initializeVariables(flow);
        variables['clientName'] = chat.contactName || 'Cliente';
        variables['clientPhone'] = chat.contactPhone;
        variables['debtorFound'] = false;
        const session = {
            chatId,
            flowId,
            currentNodeId: flow.startNodeId,
            variables,
            createdAt: new Date(),
            lastActivityAt: new Date(),
        };
        this.sessions.set(chatId, session);
        await this.chatsService.update(chatId, {
            status: chat_entity_1.ChatStatus.BOT,
            botContext: {
                sessionId: chatId,
                flowId,
                currentNodeId: flow.startNodeId,
                variables: session.variables,
                transferredToAgent: false,
            },
        });
        await this.executeNode(chatId, flow.startNodeId);
    }
    async processUserInput(chatId, userInput) {
        const session = this.sessions.get(chatId);
        if (!session) {
            this.logger.warn(`No hay sesión activa para chat ${chatId}`);
            return;
        }
        session.lastActivityAt = new Date();
        const currentNode = await this.botNodeRepository.findOne({
            where: { id: session.currentNodeId },
        });
        if (!currentNode) {
            throw new common_1.NotFoundException(`Nodo ${session.currentNodeId} no encontrado`);
        }
        let nextNodeId = null;
        switch (currentNode.type) {
            case bot_node_entity_1.BotNodeType.MESSAGE:
                if (currentNode.config.useButtons && currentNode.config.buttons) {
                    session.variables['user_response'] = userInput;
                    const buttons = currentNode.config.buttons;
                    const inputLower = userInput.toLowerCase().trim();
                    let matchedButton = null;
                    const numericInput = parseInt(inputLower, 10);
                    if (!isNaN(numericInput) && numericInput >= 1 && numericInput <= buttons.length) {
                        matchedButton = buttons[numericInput - 1];
                        this.logger.log(`🔢 Respuesta numérica ${numericInput} -> Botón: ${matchedButton?.text}`);
                    }
                    else {
                        matchedButton = buttons.find((btn) => btn.id?.toLowerCase() === inputLower ||
                            btn.text?.toLowerCase() === inputLower ||
                            btn.value?.toLowerCase() === inputLower ||
                            btn.text?.toLowerCase().includes(inputLower) ||
                            inputLower.includes(btn.text?.toLowerCase() || ''));
                    }
                    if (matchedButton) {
                        session.variables['selected_button'] = matchedButton.id || matchedButton.value;
                        this.logger.log(`🔘 Botón seleccionado: ${matchedButton.text} (ID: ${matchedButton.id})`);
                    }
                    else {
                        this.logger.warn(`⚠️ No se encontró botón para respuesta: "${userInput}"`);
                    }
                    if (currentNode.config.responseNodeId) {
                        nextNodeId = currentNode.config.responseNodeId;
                    }
                    else {
                        nextNodeId = currentNode.nextNodeId;
                    }
                }
                else {
                    nextNodeId = currentNode.nextNodeId;
                }
                break;
            case bot_node_entity_1.BotNodeType.MENU:
                nextNodeId = this.handleMenuInput(currentNode, userInput);
                break;
            case bot_node_entity_1.BotNodeType.INPUT:
                nextNodeId = await this.handleTextInput(currentNode, userInput, session);
                break;
            case bot_node_entity_1.BotNodeType.CONDITION:
                session.variables['user_response'] = userInput;
                nextNodeId = this.handleCondition(currentNode, session);
                break;
            default:
                nextNodeId = currentNode.nextNodeId;
        }
        if (!nextNodeId) {
            this.logger.warn(`No se encontró siguiente nodo para ${currentNode.id}`);
            return;
        }
        session.currentNodeId = nextNodeId;
        session.lastActivityAt = new Date();
        this.sessions.set(chatId, session);
        await this.chatsService.update(chatId, {
            botContext: {
                ...session,
                sessionId: chatId,
            },
        });
        this.logger.log(`➡️ Procesando respuesta, avanzando a nodo: ${nextNodeId}`);
        await this.executeNode(chatId, nextNodeId);
    }
    async executeNode(chatId, nodeId) {
        const node = await this.botNodeRepository.findOne({ where: { id: nodeId } });
        if (!node) {
            throw new common_1.NotFoundException(`Nodo ${nodeId} no encontrado`);
        }
        this.logger.log(`Ejecutando nodo ${node.name} (${node.type}) para chat ${chatId}`);
        switch (node.type) {
            case bot_node_entity_1.BotNodeType.MESSAGE:
                await this.executeMessageNode(chatId, node);
                break;
            case bot_node_entity_1.BotNodeType.MENU:
                await this.executeMenuNode(chatId, node);
                break;
            case bot_node_entity_1.BotNodeType.INPUT:
                await this.executeInputNode(chatId, node);
                break;
            case bot_node_entity_1.BotNodeType.CONDITION:
                this.logger.log(`⏸️ Nodo CONDITION alcanzado. Esperando respuesta del usuario...`);
                break;
            case bot_node_entity_1.BotNodeType.API_CALL:
                await this.executeApiCallNode(chatId, node);
                break;
            case bot_node_entity_1.BotNodeType.TRANSFER_AGENT:
                await this.executeTransferNode(chatId, node);
                break;
            case bot_node_entity_1.BotNodeType.END:
                await this.executeEndNode(chatId, node);
                break;
            default:
                this.logger.warn(`Tipo de nodo no soportado: ${node.type}`);
        }
    }
    async executeMessageNode(chatId, node) {
        const message = node.config.message;
        if (!message) {
            this.logger.warn('Nodo de mensaje sin contenido');
            return;
        }
        const chat = await this.chatsService.findOne(chatId);
        const session = this.sessions.get(chatId);
        const processedMessage = this.replaceVariables(message, session?.variables);
        try {
            let result;
            let savedContent = processedMessage;
            if (node.config.contentSid && chat.whatsappNumber?.provider === 'twilio') {
                const contentVariables = {};
                if (node.config.contentVariables) {
                    for (const [templateVar, botVar] of Object.entries(node.config.contentVariables)) {
                        const value = session?.variables?.[botVar] || '';
                        contentVariables[templateVar] = String(value);
                    }
                }
                this.logger.log(`📤 Enviando Content Template: ${node.config.contentSid}`);
                this.logger.log(`📝 Variables: ${JSON.stringify(contentVariables)}`);
                result = await this.whatsappService.sendContentTemplate(chat.whatsappNumber.id, chat.contactPhone, node.config.contentSid, Object.keys(contentVariables).length > 0 ? contentVariables : undefined);
                savedContent = processedMessage;
            }
            else if (node.config.useButtons && node.config.buttons && node.config.buttons.length > 0) {
                const buttons = node.config.buttons.map(btn => ({
                    id: btn.id,
                    text: btn.text,
                }));
                const title = node.config.buttonTitle || 'Seleccione una opción';
                this.logger.log(`📤 Enviando mensaje con botones: ${buttons.length} botones`);
                result = await this.whatsappService.sendButtonsMessage(chat.whatsappNumber.id, chat.contactPhone, title, processedMessage, buttons);
                let buttonsText = '';
                buttons.forEach((btn, index) => {
                    buttonsText += `${index + 1}. ${btn.text}\n`;
                });
                savedContent = `${processedMessage}\n\n${buttonsText}\n_Responde con el número de tu opción_`;
            }
            else {
                result = await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, processedMessage, message_entity_1.MessageType.TEXT);
            }
            const savedMessage = await this.messagesService.create({
                chatId,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
                content: savedContent,
                externalId: result.messageId,
            });
            await this.messagesService.updateStatus(savedMessage.id, message_entity_1.MessageStatus.SENT);
            this.logger.log(`Bot envió mensaje a ${chat.contactPhone}: "${processedMessage.substring(0, 50)}..."`);
        }
        catch (error) {
            this.logger.error(`Error enviando mensaje del bot: ${error.message}`);
            const savedMessage = await this.messagesService.create({
                chatId,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
                content: processedMessage,
            });
            await this.messagesService.updateStatus(savedMessage.id, message_entity_1.MessageStatus.FAILED, error.message);
        }
        if (node.config.useButtons && node.config.responseNodeId) {
            const session = this.sessions.get(chatId);
            if (session) {
                session.currentNodeId = node.config.responseNodeId;
                session.lastActivityAt = new Date();
                this.sessions.set(chatId, session);
                await this.chatsService.update(chatId, {
                    botContext: {
                        ...session,
                        sessionId: chatId,
                    },
                });
                this.logger.log(`🔘 Mensaje con botones enviado. Esperando respuesta del usuario...`);
                this.logger.log(`📍 Próximo nodo a procesar (responseNodeId): ${node.config.responseNodeId}`);
            }
            return;
        }
        if (node.nextNodeId) {
            const session = this.sessions.get(chatId);
            if (session) {
                session.currentNodeId = node.nextNodeId;
                session.lastActivityAt = new Date();
                this.sessions.set(chatId, session);
                await this.chatsService.update(chatId, {
                    botContext: {
                        ...session,
                        sessionId: chatId,
                    },
                });
                this.logger.log(`⏭️ Avanzando automáticamente al nodo: ${node.nextNodeId}`);
                await this.executeNode(chatId, node.nextNodeId);
            }
        }
    }
    async executeMenuNode(chatId, node) {
        const options = node.config.options || [];
        if (options.length === 0) {
            this.logger.warn('Nodo de menú sin opciones');
            return;
        }
        const chat = await this.chatsService.findOne(chatId);
        const session = this.sessions.get(chatId);
        try {
            let result;
            let savedContent;
            if (options.length <= 3) {
                const buttons = options.map((opt) => ({
                    id: opt.id || opt.value,
                    text: opt.label.substring(0, 20),
                }));
                const title = node.config.buttonTitle || 'Menú de opciones';
                const description = node.config.message || 'Por favor seleccione una opción:';
                const processedDesc = this.replaceVariables(description, session?.variables);
                this.logger.log(`📤 Enviando menú con ${buttons.length} botones`);
                result = await this.whatsappService.sendButtonsMessage(chat.whatsappNumber.id, chat.contactPhone, title, processedDesc, buttons);
                savedContent = `${processedDesc}\n\n[Botones: ${buttons.map(b => b.text).join(' | ')}]`;
            }
            else {
                const rows = options.map((opt) => ({
                    id: opt.id || opt.value,
                    title: opt.label.substring(0, 24),
                    description: opt.description || '',
                }));
                const title = node.config.buttonTitle || 'Menú de opciones';
                const description = node.config.message || 'Por favor seleccione una opción:';
                const processedDesc = this.replaceVariables(description, session?.variables);
                this.logger.log(`📤 Enviando menú como lista con ${rows.length} opciones`);
                result = await this.whatsappService.sendListMessage(chat.whatsappNumber.id, chat.contactPhone, title, processedDesc, 'Ver opciones', [{ title: 'Opciones', rows }]);
                savedContent = `${processedDesc}\n\n[Lista: ${rows.map(r => r.title).join(' | ')}]`;
            }
            const savedMessage = await this.messagesService.create({
                chatId,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
                content: savedContent,
                externalId: result?.messageId,
            });
            await this.messagesService.updateStatus(savedMessage.id, message_entity_1.MessageStatus.SENT);
            this.logger.log(`✅ Menú enviado exitosamente`);
        }
        catch (error) {
            this.logger.error(`Error enviando menú: ${error.message}`);
            const menuText = options
                .map((opt, index) => `${index + 1}. ${opt.label}`)
                .join('\n');
            try {
                await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, menuText, message_entity_1.MessageType.TEXT);
                await this.messagesService.create({
                    chatId,
                    type: message_entity_1.MessageType.TEXT,
                    direction: message_entity_1.MessageDirection.OUTBOUND,
                    senderType: message_entity_1.MessageSenderType.BOT,
                    content: menuText,
                });
            }
            catch (fallbackError) {
                this.logger.error(`Error en fallback de menú: ${fallbackError.message}`);
            }
        }
    }
    async executeInputNode(chatId, node) {
        const message = node.config.message || '¿Cuál es tu respuesta?';
        const chat = await this.chatsService.findOne(chatId);
        const session = this.sessions.get(chatId);
        const processedMessage = this.replaceVariables(message, session?.variables);
        try {
            let result;
            let savedContent = processedMessage;
            if (node.config.useButtons && node.config.buttons && node.config.buttons.length > 0) {
                const buttons = node.config.buttons.map(btn => ({
                    id: btn.id,
                    text: btn.text,
                }));
                const title = node.config.buttonTitle || 'Responda';
                this.logger.log(`📤 Enviando input con botones: ${buttons.length} botones`);
                result = await this.whatsappService.sendButtonsMessage(chat.whatsappNumber.id, chat.contactPhone, title, processedMessage, buttons);
                savedContent = `${processedMessage}\n\n[Botones: ${buttons.map(b => b.text).join(' | ')}]`;
            }
            else {
                result = await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, processedMessage, message_entity_1.MessageType.TEXT);
            }
            const savedMessage = await this.messagesService.create({
                chatId,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
                content: savedContent,
                externalId: result?.messageId,
            });
            await this.messagesService.updateStatus(savedMessage.id, message_entity_1.MessageStatus.SENT);
            this.logger.log(`📝 Bot solicitó input: "${processedMessage.substring(0, 50)}..."`);
        }
        catch (error) {
            this.logger.error(`Error enviando solicitud de input: ${error.message}`);
        }
        this.logger.log(`⏸️ Nodo INPUT alcanzado. Esperando respuesta del usuario...`);
    }
    async executeConditionNode(chatId, node) {
        const session = this.sessions.get(chatId);
        if (!session)
            return;
        const nextNodeId = this.handleCondition(node, session);
        if (nextNodeId) {
            session.currentNodeId = nextNodeId;
            this.sessions.set(chatId, session);
            await this.executeNode(chatId, nextNodeId);
        }
    }
    async executeApiCallNode(chatId, node) {
        const session = this.sessions.get(chatId);
        if (!session) {
            this.logger.warn(`No hay sesión activa para chat ${chatId}`);
            return;
        }
        const apiConfig = node.config.apiConfig;
        this.logger.log(`🔍 Ejecutando API Call: ${apiConfig?.url || 'búsqueda de deudor'}`);
        try {
            const documentNumber = session.variables?.debtorDocument;
            if (documentNumber) {
                this.logger.log(`📋 Buscando deudor con documento: ${documentNumber}`);
                const debtor = await this.debtorsService.findByDocumentNumber(documentNumber);
                if (debtor) {
                    this.logger.log(`✅ Deudor encontrado: ${debtor.fullName}`);
                    session.variables.debtor_encontrado = true;
                    session.variables.debtor_id = debtor.id;
                    session.variables.debtor_nombre = debtor.fullName || 'No disponible';
                    session.variables.debtor_documento = debtor.documentNumber || 'No disponible';
                    session.variables.debtor_telefono = debtor.phone || 'No disponible';
                    session.variables.debtor_correo = debtor.email || 'No disponible';
                    session.variables.debtor_valor_deuda = debtor.debtAmount
                        ? `$${Number(debtor.debtAmount).toLocaleString('es-CO')}`
                        : 'No disponible';
                    session.variables.debtor_estado = debtor.status || 'No disponible';
                    session.variables.debtor_compania = 'NGSO Abogados S.A.S.';
                    session.variables.debtor_campana = debtor.campaign?.name || 'No disponible';
                    const chat = await this.chatsService.findOne(chatId);
                    const updateData = {};
                    if (debtor.campaign?.id && !chat.campaignId) {
                        updateData.campaignId = debtor.campaign.id;
                    }
                    if (debtor.id) {
                        updateData.debtorId = debtor.id;
                    }
                    if (Object.keys(updateData).length > 0) {
                        await this.chatsService.update(chatId, updateData);
                        this.logger.log(`📝 Chat actualizado con debtorId: ${debtor.id}`);
                        this.eventEmitter.emit('chat.debtor.linked', {
                            chatId,
                            debtorId: debtor.id,
                            debtorInfo: {
                                id: debtor.id,
                                fullName: debtor.fullName,
                                documentNumber: debtor.documentNumber,
                                phone: debtor.phone,
                                email: debtor.email,
                                debtAmount: debtor.debtAmount,
                                status: debtor.status,
                                campaignName: debtor.campaign?.name,
                            },
                        });
                    }
                }
                else {
                    this.logger.log(`❌ Deudor no encontrado con documento: ${documentNumber}`);
                    session.variables.debtor_encontrado = false;
                    session.variables.debtor_nombre = 'No encontrado';
                    session.variables.debtor_documento = documentNumber;
                }
            }
            else {
                this.logger.warn('No se proporcionó número de documento para buscar');
                session.variables.debtor_encontrado = false;
            }
            this.sessions.set(chatId, session);
        }
        catch (error) {
            this.logger.error(`Error en API Call: ${error.message}`);
            session.variables.debtor_encontrado = false;
            session.variables.api_error = error.message;
            this.sessions.set(chatId, session);
        }
        if (node.nextNodeId) {
            session.currentNodeId = node.nextNodeId;
            this.sessions.set(chatId, session);
            await this.executeNode(chatId, node.nextNodeId);
        }
    }
    async executeTransferNode(chatId, node) {
        this.logger.log(`📤 Transfiriendo chat ${chatId} a agente humano`);
        const chat = await this.chatsService.findOne(chatId);
        const session = this.sessions.get(chatId);
        let campaign = null;
        if (chat.campaignId) {
            campaign = await this.campaignRepository.findOne({ where: { id: chat.campaignId } });
        }
        const autoAssignment = campaign?.settings?.autoAssignment ?? true;
        let assignedAgent = null;
        if (autoAssignment) {
            this.logger.log(`🔄 Intentando asignación automática${campaign ? ` para campaña: ${campaign.name}` : ''}`);
            assignedAgent = await this.findAvailableAgent(chat.campaignId);
        }
        let transferMessage;
        if (assignedAgent) {
            transferMessage = `✅ *¡Excelente!*\n\nHas sido asignado a *${assignedAgent.fullName}*, quien te ayudará con tu solicitud.\n\nEn un momento te contactará. 🙌`;
        }
        else {
            const isOutsideBusinessHours = await this.checkIfOutsideBusinessHours();
            if (isOutsideBusinessHours) {
                transferMessage = `📋 *Tu solicitud ha sido registrada*\n\nEn este momento nos encontramos fuera de nuestro horario de atención.\n\n🕐 *Horario de atención:*\nLunes a Viernes: 7:00 AM - 6:00 PM\nSábados: 8:00 AM - 1:00 PM\n\nTu caso será asignado a uno de nuestros asesores y te contactaremos tan pronto estemos en horario hábil.\n\n¡Gracias por tu comprensión! 🙌`;
            }
            else {
                transferMessage = node.config.message || '📋 *Tu solicitud ha sido registrada*\n\nEn este momento todos nuestros asesores están ocupados.\n\nTu caso ha quedado en cola de atención y serás asignado al próximo asesor disponible.\n\n¡Gracias por tu paciencia! ⏳';
            }
        }
        const processedMessage = this.replaceVariables(transferMessage, session?.variables);
        try {
            const result = await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, processedMessage, message_entity_1.MessageType.TEXT);
            const savedMessage = await this.messagesService.create({
                chatId,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
                content: processedMessage,
                externalId: result.messageId,
            });
            await this.messagesService.updateStatus(savedMessage.id, message_entity_1.MessageStatus.SENT);
            this.logger.log(`📤 Mensaje de transferencia enviado a ${chat.contactPhone}`);
        }
        catch (error) {
            this.logger.error(`Error enviando mensaje de transferencia: ${error.message}`);
        }
        if (assignedAgent) {
            await this.chatsService.update(chatId, {
                status: chat_entity_1.ChatStatus.ACTIVE,
                assignedAgentId: assignedAgent.id,
                assignedAt: new Date(),
                botContext: {
                    ...session,
                    transferredToAgent: true,
                    autoAssigned: true,
                    assignedAgentName: assignedAgent.fullName,
                },
            });
            await this.userRepository.increment({ id: assignedAgent.id }, 'currentChatsCount', 1);
            this.eventEmitter.emit('chat.assigned', {
                chat,
                agentId: assignedAgent.id,
                agentName: assignedAgent.fullName,
                autoAssigned: true,
            });
            this.logger.log(`✅ Chat ${chatId} asignado automáticamente a ${assignedAgent.fullName}`);
        }
        else {
            await this.chatsService.update(chatId, {
                status: chat_entity_1.ChatStatus.WAITING,
                subStatus: 'waiting_for_agent',
                botContext: {
                    ...session,
                    transferredToAgent: true,
                    autoAssigned: false,
                },
            });
            this.logger.log(`📋 Chat ${chatId} puesto en cola de espera para asignación manual`);
        }
        this.sessions.delete(chatId);
    }
    async checkIfOutsideBusinessHours() {
        const today = new Date();
        const todayStr = today.toISOString().split('T')[0];
        const activeWorkdaysCount = await this.userRepository
            .createQueryBuilder('user')
            .innerJoin('agent_workdays', 'workday', 'workday.agentId = user.id')
            .where('user.isAgent = :isAgent', { isAgent: true })
            .andWhere('user.status = :status', { status: 'active' })
            .andWhere('workday.workDate = :today', { today: todayStr })
            .andWhere('workday.clockInTime IS NOT NULL')
            .andWhere('workday.clockOutTime IS NULL')
            .getCount();
        this.logger.debug(`🕐 Agentes con jornada activa: ${activeWorkdaysCount}`);
        return activeWorkdaysCount === 0;
    }
    async findAvailableAgent(campaignId) {
        if (campaignId) {
            const campaignAgent = await this.findAvailableAgentForCampaign(campaignId);
            if (campaignAgent) {
                return campaignAgent;
            }
        }
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const agent = await this.userRepository
            .createQueryBuilder('user')
            .innerJoin('agent_workdays', 'workday', 'workday.agentId = user.id')
            .where('user.isAgent = :isAgent', { isAgent: true })
            .andWhere('user.status = :status', { status: 'active' })
            .andWhere('user.agentState = :agentState', { agentState: 'available' })
            .andWhere('user.currentChatsCount < user.maxConcurrentChats')
            .andWhere('workday.workDate = :today', { today: today.toISOString().split('T')[0] })
            .andWhere('workday.clockInTime IS NOT NULL')
            .andWhere('workday.clockOutTime IS NULL')
            .orderBy('user.currentChatsCount', 'ASC')
            .getOne();
        if (agent) {
            this.logger.log(`✅ Agente disponible encontrado (general con jornada activa): ${agent.fullName}`);
            return agent;
        }
        this.logger.warn(`⚠️ No hay agentes disponibles CON JORNADA ACTIVA en el sistema`);
        return null;
    }
    async findAvailableAgentForCampaign(campaignId) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayStr = today.toISOString().split('T')[0];
        let agent = await this.userRepository
            .createQueryBuilder('user')
            .innerJoin('agent_workdays', 'workday', 'workday.agentId = user.id')
            .where('user.isAgent = :isAgent', { isAgent: true })
            .andWhere('user.status = :status', { status: 'active' })
            .andWhere('user.agentState = :agentState', { agentState: 'available' })
            .andWhere('user.currentChatsCount < user.maxConcurrentChats')
            .andWhere('user.campaignId = :campaignId', { campaignId })
            .andWhere('workday.workDate = :today', { today: todayStr })
            .andWhere('workday.clockInTime IS NOT NULL')
            .andWhere('workday.clockOutTime IS NULL')
            .orderBy('user.currentChatsCount', 'ASC')
            .getOne();
        if (agent) {
            this.logger.log(`✅ Agente encontrado (campaña directa con jornada): ${agent.fullName}`);
            return agent;
        }
        agent = await this.userRepository
            .createQueryBuilder('user')
            .innerJoin('user_campaigns', 'uc', 'uc.userId = user.id')
            .innerJoin('agent_workdays', 'workday', 'workday.agentId = user.id')
            .where('user.isAgent = :isAgent', { isAgent: true })
            .andWhere('user.status = :status', { status: 'active' })
            .andWhere('user.agentState = :agentState', { agentState: 'available' })
            .andWhere('user.currentChatsCount < user.maxConcurrentChats')
            .andWhere('uc.campaignId = :campaignId', { campaignId })
            .andWhere('workday.workDate = :today', { today: todayStr })
            .andWhere('workday.clockInTime IS NOT NULL')
            .andWhere('workday.clockOutTime IS NULL')
            .orderBy('user.currentChatsCount', 'ASC')
            .getOne();
        if (agent) {
            this.logger.log(`✅ Agente encontrado (user_campaigns con jornada): ${agent.fullName}`);
            return agent;
        }
        this.logger.warn(`⚠️ No hay agentes disponibles CON JORNADA ACTIVA para campaña ${campaignId}`);
        return null;
    }
    async executeEndNode(chatId, node) {
        this.logger.log(`Finalizando flujo para chat ${chatId}`);
        const session = this.sessions.get(chatId);
        const defaultMessage = '¡Gracias por tu tiempo! Si necesitas más ayuda, no dudes en escribirnos.';
        const message = node?.config?.message
            ? this.replaceVariables(node.config.message, session?.variables)
            : defaultMessage;
        const chat = await this.chatsService.findOne(chatId);
        try {
            await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, message, message_entity_1.MessageType.TEXT);
            await this.messagesService.create({
                chatId,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
                content: message,
            });
        }
        catch (error) {
            this.logger.error(`Error enviando mensaje de cierre: ${error.message}`);
        }
        await this.chatsService.update(chatId, {
            status: chat_entity_1.ChatStatus.RESOLVED,
            closedAt: new Date(),
        });
        this.logger.log(`✅ Chat ${chatId} cerrado automáticamente por el bot`);
        this.sessions.delete(chatId);
    }
    handleMenuInput(node, userInput) {
        const options = node.config.options || [];
        const inputTrimmed = userInput.trim().toLowerCase();
        const inputNum = parseInt(inputTrimmed);
        if (!isNaN(inputNum) && inputNum >= 1 && inputNum <= options.length) {
            this.logger.log(`🎯 Menú: seleccionado por número ${inputNum}`);
            return options[inputNum - 1].nextNodeId;
        }
        const matchById = options.find((opt) => (opt.id && opt.id.toLowerCase() === inputTrimmed) ||
            (opt.value && opt.value.toLowerCase() === inputTrimmed));
        if (matchById) {
            this.logger.log(`🎯 Menú: seleccionado por ID "${inputTrimmed}"`);
            return matchById.nextNodeId;
        }
        const matchByLabel = options.find((opt) => opt.label && opt.label.toLowerCase() === inputTrimmed);
        if (matchByLabel) {
            this.logger.log(`🎯 Menú: seleccionado por label "${inputTrimmed}"`);
            return matchByLabel.nextNodeId;
        }
        const matchByPartialLabel = options.find((opt) => opt.label && opt.label.toLowerCase().includes(inputTrimmed));
        if (matchByPartialLabel) {
            this.logger.log(`🎯 Menú: seleccionado por coincidencia parcial "${inputTrimmed}"`);
            return matchByPartialLabel.nextNodeId;
        }
        this.logger.warn(`⚠️ Menú: entrada "${inputTrimmed}" no coincide con ninguna opción`);
        return null;
    }
    async handleTextInput(node, userInput, session) {
        const variableName = node.config.variableName;
        const validation = node.config.validation;
        if (validation) {
            if (validation.required && !userInput.trim()) {
                await this.messagesService.create({
                    chatId: session.chatId,
                    type: message_entity_1.MessageType.TEXT,
                    direction: message_entity_1.MessageDirection.OUTBOUND,
                    senderType: message_entity_1.MessageSenderType.BOT,
                    content: validation.errorMessage || 'Este campo es requerido',
                });
                return null;
            }
            if (validation.pattern) {
                const regex = new RegExp(validation.pattern);
                if (!regex.test(userInput)) {
                    await this.messagesService.create({
                        chatId: session.chatId,
                        type: message_entity_1.MessageType.TEXT,
                        direction: message_entity_1.MessageDirection.OUTBOUND,
                        senderType: message_entity_1.MessageSenderType.BOT,
                        content: validation.errorMessage || 'Formato inválido',
                    });
                    return null;
                }
            }
        }
        if (variableName) {
            session.variables[variableName] = userInput;
            if (variableName === 'documento_validado' || variableName === 'documentNumber' || variableName === 'documento') {
                this.logger.log(`🔍 Capturado documento: ${userInput}, buscando deudor...`);
                const cleanDocument = userInput.replace(/[.\-\s]/g, '');
                let debtor = await this.debtorsService.findByDocument('CC', cleanDocument);
                if (!debtor) {
                    debtor = await this.debtorsService.findByDocumentNumber(cleanDocument);
                }
                if (!debtor) {
                    const docWithoutLeadingZeros = cleanDocument.replace(/^0+/, '');
                    debtor = await this.debtorsService.findByDocumentNumber(docWithoutLeadingZeros);
                }
                if (debtor) {
                    session.variables.debtor = {
                        id: debtor.id,
                        fullName: debtor.fullName,
                        documentType: debtor.documentType,
                        documentNumber: debtor.documentNumber,
                        phone: debtor.phone,
                        email: debtor.email || '[No disponible]',
                        debtAmount: this.formatCurrency(debtor.debtAmount),
                        debtAmountRaw: debtor.debtAmount,
                        initialDebtAmount: this.formatCurrency(debtor.initialDebtAmount),
                        daysOverdue: debtor.daysOverdue,
                        status: debtor.status,
                        campaignId: debtor.campaignId,
                        lastPaymentDate: '[No disponible]',
                        producto: '[No disponible]',
                        numeroCredito: '[No disponible]',
                        fechaVencimiento: '[No disponible]',
                    };
                    if (debtor.lastPaymentDate) {
                        const paymentDate = debtor.lastPaymentDate;
                        if (paymentDate instanceof Date) {
                            session.variables.debtor.lastPaymentDate = paymentDate.toISOString().split('T')[0];
                        }
                        else if (typeof paymentDate === 'string') {
                            session.variables.debtor.lastPaymentDate = paymentDate.split('T')[0];
                        }
                    }
                    if (debtor.metadata) {
                        session.variables.debtor.producto = debtor.metadata.producto || '[No disponible]';
                        session.variables.debtor.numeroCredito = debtor.metadata.numeroCredito || '[No disponible]';
                        session.variables.debtor.fechaVencimiento = debtor.metadata.fechaVencimiento || '[No disponible]';
                    }
                    session.variables.debtorFound = true;
                    this.logger.log(`✅ Deudor encontrado: ${debtor.fullName} - ${debtor.documentType} ${debtor.documentNumber} - Deuda: ${session.variables.debtor.debtAmount}`);
                    try {
                        const updateData = {
                            debtorId: debtor.id,
                            contactName: debtor.fullName,
                        };
                        if (debtor.campaignId) {
                            updateData.campaignId = debtor.campaignId;
                            this.logger.log(`🔄 Actualizando chat con deudor ${debtor.fullName} y campaña ${debtor.campaignId}`);
                        }
                        else {
                            this.logger.log(`🔄 Actualizando chat con deudor ${debtor.fullName}`);
                        }
                        await this.chatsService.update(session.chatId, updateData);
                        session.variables.clientName = debtor.fullName;
                    }
                    catch (error) {
                        this.logger.error(`Error actualizando chat con información del deudor: ${error.message}`);
                    }
                    await this.debtorsService.updateLastContacted(debtor.id);
                }
                else {
                    this.logger.warn(`❌ No se encontró deudor con documento: ${cleanDocument}`);
                    session.variables['debtorFound'] = false;
                }
            }
        }
        return node.nextNodeId;
    }
    handleCondition(node, session) {
        const conditions = node.config.conditions || [];
        this.logger.log(`🔍 Evaluando condición en nodo: ${node.name}`);
        this.logger.log(`   Variables disponibles:`, session.variables);
        const userResponse = session.variables['user_response'];
        this.logger.log(`   Respuesta del usuario: "${userResponse}"`);
        for (const condition of conditions) {
            const variableName = condition.variable || 'user_response';
            const variableValue = session.variables[variableName] || userResponse;
            this.logger.log(`   Evaluando: "${variableValue}" ${condition.operator} "${condition.value}"`);
            let matches = false;
            switch (condition.operator) {
                case 'equals':
                    const normalizedValue = String(variableValue || '').toLowerCase().trim();
                    const normalizedCondition = String(condition.value || '').toLowerCase().trim();
                    matches = normalizedValue === normalizedCondition;
                    break;
                case 'contains':
                    matches = String(variableValue || '').includes(String(condition.value || ''));
                    break;
                case 'contains_ignore_case':
                    matches = String(variableValue || '').toLowerCase().includes(String(condition.value || '').toLowerCase());
                    break;
                case 'greater':
                    matches = Number(variableValue) > Number(condition.value);
                    break;
                case 'less':
                    matches = Number(variableValue) < Number(condition.value);
                    break;
            }
            if (matches) {
                const nextNode = condition.targetNodeId || condition.nextNodeId;
                this.logger.log(`   ✅ Match encontrado! Siguiente nodo: ${nextNode}`);
                return nextNode;
            }
        }
        const fallbackNodeId = node.config.defaultNodeId || node.config.elseNodeId || node.nextNodeId;
        this.logger.log(`   ❌ Ninguna condición match. Usando fallback: ${fallbackNodeId}`);
        return fallbackNodeId;
    }
    initializeVariables(flow) {
        const variables = {};
        if (flow.variables) {
            Object.entries(flow.variables).forEach(([key, config]) => {
                variables[key] = config.defaultValue || null;
            });
        }
        return variables;
    }
    replaceVariables(text, variables) {
        if (!variables) {
            return text.replace(/\{\{([^}]+)\}\}/g, '[No disponible]');
        }
        let result = text;
        const regex = /\{\{([^}]+)\}\}/g;
        result = result.replace(regex, (match, path) => {
            const keys = path.split('.');
            let value = variables;
            for (const key of keys) {
                if (value && typeof value === 'object' && key in value) {
                    value = value[key];
                }
                else {
                    return '[No disponible]';
                }
            }
            if (typeof value === 'number') {
                if (value >= 1000) {
                    return value.toLocaleString('es-CO');
                }
            }
            return value != null ? String(value) : '[No disponible]';
        });
        return result;
    }
    formatCurrency(amount) {
        if (!amount && amount !== 0)
            return '$0';
        return '$' + amount.toLocaleString('es-CO', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    }
    hasActiveSession(chatId) {
        return this.sessions.has(chatId);
    }
    cleanInactiveSessions(maxInactivityMinutes = 30) {
        const now = new Date();
        this.sessions.forEach((session, chatId) => {
            const inactiveMinutes = (now.getTime() - session.lastActivityAt.getTime()) / 1000 / 60;
            if (inactiveMinutes > maxInactivityMinutes) {
                this.logger.log(`Limpiando sesión inactiva: ${chatId}`);
                this.sessions.delete(chatId);
            }
        });
    }
};
exports.BotEngineService = BotEngineService;
exports.BotEngineService = BotEngineService = BotEngineService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(bot_flow_entity_1.BotFlow)),
    __param(1, (0, typeorm_1.InjectRepository)(bot_node_entity_1.BotNode)),
    __param(2, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __param(3, (0, typeorm_1.InjectRepository)(campaign_entity_1.Campaign)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        messages_service_1.MessagesService,
        chats_service_1.ChatsService,
        whatsapp_service_1.WhatsappService,
        debtors_service_1.DebtorsService,
        event_emitter_1.EventEmitter2])
], BotEngineService);
//# sourceMappingURL=bot-engine.service.js.map