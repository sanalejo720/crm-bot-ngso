import { FinancialStatsService } from './financial-stats.service';
export declare class FinancialController {
    private readonly financialStatsService;
    constructor(financialStatsService: FinancialStatsService);
    getFinancialSummary(period?: 'daily' | 'weekly' | 'monthly' | 'custom', startDate?: string, endDate?: string): Promise<{
        success: boolean;
        data: import("./dto/financial-stats.dto").FinancialSummaryDto;
    }>;
    getCampaignFinancials(campaignId: string, startDate?: string, endDate?: string): Promise<{
        success: boolean;
        data: import("./dto/financial-stats.dto").CampaignFinancialsDto;
    }>;
    getAgentRecaudo(agentId: string, startDate?: string, endDate?: string): Promise<{
        success: boolean;
        data: import("./dto/financial-stats.dto").AgentRecaudoDto;
    }>;
    getDailyFinancials(date?: string): Promise<{
        success: boolean;
        data: import("./dto/financial-stats.dto").DailyFinancialsDto;
    }>;
    getFinancialTrend(startDate: string, endDate: string): Promise<{
        success: boolean;
        data: import("./dto/financial-stats.dto").FinancialTrendDto;
    }>;
    getAgentsRanking(period?: 'daily' | 'weekly' | 'monthly' | 'custom', startDate?: string, endDate?: string): Promise<{
        success: boolean;
        data: import("./dto/financial-stats.dto").AgentRecaudoDto[];
    }>;
}
