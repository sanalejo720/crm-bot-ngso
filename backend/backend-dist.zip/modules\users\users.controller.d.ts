import { UsersService } from './users.service';
import { AgentSessionsService } from './services/agent-sessions.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UserStatus } from './entities/user.entity';
export declare class UsersController {
    private readonly usersService;
    private readonly agentSessionsService;
    constructor(usersService: UsersService, agentSessionsService: AgentSessionsService);
    create(createUserDto: CreateUserDto): Promise<import("./entities/user.entity").User>;
    findAll(status?: UserStatus, roleId?: string, campaignId?: string, isAgent?: string): Promise<import("./entities/user.entity").User[]>;
    findOne(id: string): Promise<import("./entities/user.entity").User>;
    update(id: string, updateUserDto: UpdateUserDto): Promise<import("./entities/user.entity").User>;
    remove(id: string): Promise<void>;
    getAvailableAgents(campaignId: string): Promise<import("./entities/user.entity").User[]>;
    changeStatus(id: string, body: {
        status: UserStatus;
    }): Promise<import("./entities/user.entity").User>;
    getAgentSessionHistory(id: string, startDate?: string, endDate?: string): Promise<{
        success: boolean;
        data: import("./entities/agent-session.entity").AgentSession[];
    }>;
    getAgentAttendanceStats(id: string, startDate: string, endDate: string): Promise<{
        success: boolean;
        data: any;
    }>;
    getAllActiveSessions(): Promise<{
        success: boolean;
        data: import("./entities/agent-session.entity").AgentSession[];
        count: number;
    }>;
}
