import { CampaignsService } from './campaigns.service';
import { CreateCampaignDto } from './dto/create-campaign.dto';
import { UpdateCampaignDto } from './dto/update-campaign.dto';
import { CampaignStatus } from './entities/campaign.entity';
export declare class CampaignsController {
    private readonly campaignsService;
    constructor(campaignsService: CampaignsService);
    create(createCampaignDto: CreateCampaignDto, user: any): Promise<import("./entities/campaign.entity").Campaign>;
    findAll(status?: CampaignStatus, search?: string): Promise<import("./entities/campaign.entity").Campaign[]>;
    findActive(): Promise<import("./entities/campaign.entity").Campaign[]>;
    findOne(id: string): Promise<import("./entities/campaign.entity").Campaign>;
    getStats(id: string): Promise<{
        id: string;
        name: string;
        status: CampaignStatus;
        totalChats: number;
        chatsByStatus: any;
        totalDebtors: number;
        debtorsByStatus: any;
    }>;
    getWhatsappNumbers(id: string): Promise<import("../whatsapp/entities/whatsapp-number.entity").WhatsappNumber[]>;
    update(id: string, updateCampaignDto: UpdateCampaignDto): Promise<import("./entities/campaign.entity").Campaign>;
    updateStatus(id: string, body: {
        status: CampaignStatus;
    }): Promise<import("./entities/campaign.entity").Campaign>;
    updateSettings(id: string, body: {
        settings: Record<string, any>;
    }): Promise<import("./entities/campaign.entity").Campaign>;
    activate(id: string): Promise<import("./entities/campaign.entity").Campaign>;
    pause(id: string): Promise<import("./entities/campaign.entity").Campaign>;
    duplicate(id: string, body: {
        name: string;
    }, user: any): Promise<import("./entities/campaign.entity").Campaign>;
    remove(id: string): Promise<void>;
}
