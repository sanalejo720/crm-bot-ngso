export declare class CreateManualChatDto {
    phone: string;
    contactName?: string;
    campaignId?: string;
    assignToAgentId?: string;
    initialMessage?: string;
    templateSid?: string;
    templateVariables?: Record<string, string>;
}
