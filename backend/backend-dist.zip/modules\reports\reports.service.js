"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ReportsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const chat_entity_1 = require("../chats/entities/chat.entity");
const message_entity_1 = require("../messages/entities/message.entity");
const user_entity_1 = require("../users/entities/user.entity");
const client_entity_1 = require("../clients/entities/client.entity");
const task_entity_1 = require("../tasks/entities/task.entity");
let ReportsService = ReportsService_1 = class ReportsService {
    constructor(chatRepository, messageRepository, userRepository, clientRepository, taskRepository) {
        this.chatRepository = chatRepository;
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
        this.clientRepository = clientRepository;
        this.taskRepository = taskRepository;
        this.logger = new common_1.Logger(ReportsService_1.name);
    }
    async getSystemMetrics() {
        const now = new Date();
        const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        const [totalChats, activeChats, waitingChats, botChats, totalAgents, availableAgents, busyAgents, offlineAgents, totalMessages24h,] = await Promise.all([
            this.chatRepository.count(),
            this.chatRepository.count({ where: { status: chat_entity_1.ChatStatus.ACTIVE } }),
            this.chatRepository.count({ where: { status: chat_entity_1.ChatStatus.WAITING } }),
            this.chatRepository.count({ where: { status: chat_entity_1.ChatStatus.BOT } }),
            this.userRepository.count({ where: { isAgent: true } }),
            this.userRepository.count({ where: { isAgent: true, agentState: user_entity_1.AgentState.AVAILABLE } }),
            this.userRepository.count({ where: { isAgent: true, agentState: user_entity_1.AgentState.BUSY } }),
            this.userRepository.count({ where: { isAgent: true, agentState: user_entity_1.AgentState.OFFLINE } }),
            this.messageRepository.count({ where: { createdAt: (0, typeorm_2.Between)(yesterday, now) } }),
        ]);
        const averageResponseTime = await this.calculateAverageResponseTime({ startDate: yesterday, endDate: now });
        return {
            totalChats,
            activeChats,
            waitingChats,
            botChats,
            totalAgents,
            availableAgents,
            busyAgents,
            offlineAgents,
            totalMessages24h,
            averageResponseTime,
            queueSize: waitingChats,
        };
    }
    async getAgentMetrics(agentId, dateRange) {
        const agent = await this.userRepository.findOne({ where: { id: agentId } });
        if (!agent) {
            throw new Error(`Agente ${agentId} no encontrado`);
        }
        const query = this.chatRepository
            .createQueryBuilder('chat')
            .where('chat.assignedAgentId = :agentId', { agentId });
        if (dateRange) {
            query.andWhere('chat.createdAt BETWEEN :startDate AND :endDate', dateRange);
        }
        const totalChats = await query.getCount();
        const activeChats = await query.clone().andWhere('chat.status = :status', { status: chat_entity_1.ChatStatus.ACTIVE }).getCount();
        const resolvedChats = await query.clone().andWhere('chat.status = :status', { status: chat_entity_1.ChatStatus.RESOLVED }).getCount();
        const messageQuery = this.messageRepository
            .createQueryBuilder('message')
            .innerJoin('message.chat', 'chat')
            .where('chat.assignedAgentId = :agentId', { agentId })
            .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.OUTBOUND });
        if (dateRange) {
            messageQuery.andWhere('message.createdAt BETWEEN :startDate AND :endDate', dateRange);
        }
        const totalMessages = await messageQuery.getCount();
        const averageResponseTime = await this.calculateAgentResponseTime(agentId, dateRange);
        const averageHandlingTime = await this.calculateAgentHandlingTime(agentId, dateRange);
        const hoursInPeriod = dateRange
            ? (dateRange.endDate.getTime() - dateRange.startDate.getTime()) / (1000 * 60 * 60)
            : 24;
        const sentMessagesPerHour = totalMessages / hoursInPeriod;
        return {
            agentId: agent.id,
            agentName: agent.fullName,
            totalChats,
            activeChats,
            resolvedChats,
            totalMessages,
            averageResponseTime,
            averageHandlingTime,
            sentMessagesPerHour,
            state: agent.agentState,
        };
    }
    async getCampaignMetrics(campaignId, dateRange) {
        const query = this.chatRepository
            .createQueryBuilder('chat')
            .leftJoin('chat.campaign', 'campaign')
            .where('chat.campaignId = :campaignId', { campaignId });
        if (dateRange) {
            query.andWhere('chat.createdAt BETWEEN :startDate AND :endDate', dateRange);
        }
        const totalChats = await query.getCount();
        const activeChats = await query.clone().andWhere('chat.status = :status', { status: chat_entity_1.ChatStatus.ACTIVE }).getCount();
        const waitingChats = await query.clone().andWhere('chat.status = :status', { status: chat_entity_1.ChatStatus.WAITING }).getCount();
        const resolvedChats = await query.clone().andWhere('chat.status = :status', { status: chat_entity_1.ChatStatus.RESOLVED }).getCount();
        const clientQuery = this.clientRepository
            .createQueryBuilder('client')
            .where('client.campaignId = :campaignId', { campaignId });
        if (dateRange) {
            clientQuery.andWhere('client.createdAt BETWEEN :startDate AND :endDate', dateRange);
        }
        const totalClients = await clientQuery.getCount();
        const newLeads = await clientQuery.clone().andWhere('client.leadStatus = :status', { status: client_entity_1.LeadStatus.NEW }).getCount();
        const qualifiedLeads = await clientQuery.clone().andWhere('client.leadStatus = :status', { status: client_entity_1.LeadStatus.QUALIFIED }).getCount();
        const convertedLeads = await clientQuery.clone().andWhere('client.leadStatus = :status', { status: client_entity_1.LeadStatus.WON }).getCount();
        const averageResponseTime = await this.calculateCampaignResponseTime(campaignId, dateRange);
        const averageHandlingTime = await this.calculateCampaignHandlingTime(campaignId, dateRange);
        const campaign = await query.select('campaign.name').getRawOne();
        return {
            campaignId,
            campaignName: campaign?.campaign_name || 'Sin nombre',
            totalChats,
            activeChats,
            waitingChats,
            resolvedChats,
            totalClients,
            newLeads,
            qualifiedLeads,
            convertedLeads,
            averageResponseTime,
            averageHandlingTime,
        };
    }
    async getAllAgentsMetrics(dateRange) {
        const agents = await this.userRepository.find({ where: { isAgent: true } });
        const metrics = await Promise.all(agents.map((agent) => this.getAgentMetrics(agent.id, dateRange)));
        return metrics.sort((a, b) => b.totalChats - a.totalChats);
    }
    async getAgentRanking(metric, dateRange, limit = 10) {
        const allMetrics = await this.getAllAgentsMetrics(dateRange);
        const sorted = allMetrics.sort((a, b) => {
            if (metric === 'averageResponseTime') {
                return a[metric] - b[metric];
            }
            return b[metric] - a[metric];
        });
        return sorted.slice(0, limit);
    }
    async calculateAverageResponseTime(dateRange) {
        const chats = await this.chatRepository.find({
            where: dateRange
                ? { createdAt: (0, typeorm_2.Between)(dateRange.startDate, dateRange.endDate) }
                : {},
            relations: ['messages'],
            take: 100,
        });
        const responseTimes = [];
        for (const chat of chats) {
            if (!chat.messages || chat.messages.length < 2)
                continue;
            const firstInbound = chat.messages.find((m) => m.direction === message_entity_1.MessageDirection.INBOUND);
            const firstOutbound = chat.messages.find((m) => m.direction === message_entity_1.MessageDirection.OUTBOUND);
            if (firstInbound && firstOutbound && firstOutbound.createdAt > firstInbound.createdAt) {
                const responseTime = (firstOutbound.createdAt.getTime() - firstInbound.createdAt.getTime()) / 1000;
                responseTimes.push(responseTime);
            }
        }
        if (responseTimes.length === 0)
            return 0;
        const average = responseTimes.reduce((sum, time) => sum + time, 0) / responseTimes.length;
        return Math.round(average);
    }
    async calculateAgentResponseTime(agentId, dateRange) {
        const chats = await this.chatRepository.find({
            where: {
                assignedAgentId: agentId,
                ...(dateRange ? { createdAt: (0, typeorm_2.Between)(dateRange.startDate, dateRange.endDate) } : {}),
            },
            relations: ['messages'],
            take: 100,
        });
        const responseTimes = [];
        for (const chat of chats) {
            if (!chat.messages || chat.messages.length < 2)
                continue;
            const firstInbound = chat.messages.find((m) => m.direction === message_entity_1.MessageDirection.INBOUND);
            const firstOutbound = chat.messages.find((m) => m.direction === message_entity_1.MessageDirection.OUTBOUND);
            if (firstInbound && firstOutbound && firstOutbound.createdAt > firstInbound.createdAt) {
                const responseTime = (firstOutbound.createdAt.getTime() - firstInbound.createdAt.getTime()) / 1000;
                responseTimes.push(responseTime);
            }
        }
        if (responseTimes.length === 0)
            return 0;
        return Math.round(responseTimes.reduce((sum, time) => sum + time, 0) / responseTimes.length);
    }
    async calculateCampaignResponseTime(campaignId, dateRange) {
        const chats = await this.chatRepository.find({
            where: {
                campaignId,
                ...(dateRange ? { createdAt: (0, typeorm_2.Between)(dateRange.startDate, dateRange.endDate) } : {}),
            },
            relations: ['messages'],
            take: 100,
        });
        const responseTimes = [];
        for (const chat of chats) {
            if (!chat.messages || chat.messages.length < 2)
                continue;
            const firstInbound = chat.messages.find((m) => m.direction === message_entity_1.MessageDirection.INBOUND);
            const firstOutbound = chat.messages.find((m) => m.direction === message_entity_1.MessageDirection.OUTBOUND);
            if (firstInbound && firstOutbound && firstOutbound.createdAt > firstInbound.createdAt) {
                const responseTime = (firstOutbound.createdAt.getTime() - firstInbound.createdAt.getTime()) / 1000;
                responseTimes.push(responseTime);
            }
        }
        if (responseTimes.length === 0)
            return 0;
        return Math.round(responseTimes.reduce((sum, time) => sum + time, 0) / responseTimes.length);
    }
    async calculateAgentHandlingTime(agentId, dateRange) {
        const chats = await this.chatRepository.find({
            where: {
                assignedAgentId: agentId,
                status: chat_entity_1.ChatStatus.RESOLVED,
                ...(dateRange ? { createdAt: (0, typeorm_2.Between)(dateRange.startDate, dateRange.endDate) } : {}),
            },
            take: 100,
        });
        const handlingTimes = [];
        for (const chat of chats) {
            if (chat.resolvedAt && chat.createdAt) {
                const handlingTime = (chat.resolvedAt.getTime() - chat.createdAt.getTime()) / 1000;
                handlingTimes.push(handlingTime);
            }
        }
        if (handlingTimes.length === 0)
            return 0;
        return Math.round(handlingTimes.reduce((sum, time) => sum + time, 0) / handlingTimes.length);
    }
    async calculateCampaignHandlingTime(campaignId, dateRange) {
        const chats = await this.chatRepository.find({
            where: {
                campaignId,
                status: chat_entity_1.ChatStatus.RESOLVED,
                ...(dateRange ? { createdAt: (0, typeorm_2.Between)(dateRange.startDate, dateRange.endDate) } : {}),
            },
            take: 100,
        });
        const handlingTimes = [];
        for (const chat of chats) {
            if (chat.resolvedAt && chat.createdAt) {
                const handlingTime = (chat.resolvedAt.getTime() - chat.createdAt.getTime()) / 1000;
                handlingTimes.push(handlingTime);
            }
        }
        if (handlingTimes.length === 0)
            return 0;
        return Math.round(handlingTimes.reduce((sum, time) => sum + time, 0) / handlingTimes.length);
    }
    async getChatsTrend(dateRange, campaignId) {
        const query = this.chatRepository
            .createQueryBuilder('chat')
            .select('DATE(chat.createdAt)', 'date')
            .addSelect('COUNT(*)', 'count')
            .where('chat.createdAt BETWEEN :startDate AND :endDate', dateRange)
            .groupBy('DATE(chat.createdAt)')
            .orderBy('DATE(chat.createdAt)', 'ASC');
        if (campaignId) {
            query.andWhere('chat.campaignId = :campaignId', { campaignId });
        }
        return query.getRawMany();
    }
    async getChatsDistribution(campaignId) {
        const query = this.chatRepository
            .createQueryBuilder('chat')
            .select('chat.status', 'status')
            .addSelect('COUNT(*)', 'count')
            .groupBy('chat.status');
        if (campaignId) {
            query.where('chat.campaignId = :campaignId', { campaignId });
        }
        const results = await query.getRawMany();
        return results.reduce((acc, item) => {
            acc[item.status] = parseInt(item.count);
            return acc;
        }, {});
    }
    async getPendingTasksCount() {
        return this.taskRepository.count({
            where: [
                { status: task_entity_1.TaskStatus.PENDING },
                { status: task_entity_1.TaskStatus.IN_PROGRESS },
            ],
        });
    }
    async getCollectionSummary() {
        const debtResult = await this.clientRepository
            .createQueryBuilder('client')
            .select('SUM(client.debtAmount)', 'totalDebt')
            .where('client.debtAmount > 0')
            .getRawOne();
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        const recoveredResult = await this.clientRepository
            .createQueryBuilder('client')
            .select('SUM(client.promisePaymentAmount)', 'recovered')
            .where('client.promisePaymentDate >= :today', { today })
            .andWhere('client.promisePaymentDate < :tomorrow', { tomorrow })
            .andWhere('client.collectionStatus = :status', { status: 'promise' })
            .getRawOne();
        return {
            totalDebt: parseFloat(debtResult?.totalDebt || '0'),
            recoveredToday: parseFloat(recoveredResult?.recovered || '0'),
        };
    }
    async getAgentsPerformance() {
        const agents = await this.userRepository.find({
            where: { isAgent: true },
            select: ['id', 'fullName', 'email', 'agentState', 'maxConcurrentChats'],
        });
        const performance = await Promise.all(agents.map(async (agent) => {
            const currentChats = await this.chatRepository.count({
                where: {
                    assignedAgentId: agent.id,
                    status: chat_entity_1.ChatStatus.ACTIVE,
                },
            });
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const messagesSent = await this.messageRepository
                .createQueryBuilder('message')
                .innerJoin('message.chat', 'chat')
                .where('chat.assignedAgentId = :agentId', { agentId: agent.id })
                .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.OUTBOUND })
                .andWhere('message.createdAt >= :today', { today })
                .getCount();
            const promisesObtained = await this.clientRepository
                .createQueryBuilder('client')
                .innerJoin('client.chats', 'chat')
                .where('chat.assignedAgentId = :agentId', { agentId: agent.id })
                .andWhere('client.collectionStatus = :status', { status: 'promise' })
                .andWhere('client.promisePaymentDate >= :today', { today })
                .getCount();
            const averageResponseTime = await this.calculateAgentResponseTime(agent.id);
            return {
                id: agent.id,
                name: agent.fullName,
                email: agent.email,
                currentChats,
                maxChats: agent.maxConcurrentChats || 5,
                messagesSent,
                promisesObtained,
                averageResponseTime,
                status: agent.agentState,
            };
        }));
        return performance;
    }
    async getAgentStats(agentId) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const activeChats = await this.chatRepository.count({
            where: { assignedAgentId: agentId, status: chat_entity_1.ChatStatus.ACTIVE },
        });
        const totalChatsToday = await this.chatRepository.count({
            where: {
                assignedAgentId: agentId,
                assignedAt: (0, typeorm_2.Between)(today, new Date()),
            },
        });
        const messagesCount = await this.messageRepository.count({
            where: {
                senderId: agentId,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                createdAt: (0, typeorm_2.Between)(today, new Date()),
            },
        });
        const promisesObtained = await this.clientRepository
            .createQueryBuilder('client')
            .innerJoin('client.chats', 'chat')
            .where('chat.assignedAgentId = :agentId', { agentId })
            .andWhere('client.collectionStatus = :status', { status: 'promise' })
            .andWhere('client.promisePaymentDate >= :today', { today })
            .getCount();
        const recoveredAmount = promisesObtained * 500000;
        const averageResponseTime = await this.calculateAgentResponseTime(agentId);
        const resolvedChatsToday = await this.chatRepository.count({
            where: {
                assignedAgentId: agentId,
                status: chat_entity_1.ChatStatus.RESOLVED,
                resolvedAt: (0, typeorm_2.Between)(today, new Date()),
            },
        });
        const completionRate = totalChatsToday > 0
            ? Math.round((resolvedChatsToday / totalChatsToday) * 100)
            : 0;
        const agent = await this.userRepository.findOne({ where: { id: agentId } });
        return {
            activeChats,
            totalChatsToday,
            maxConcurrentChats: agent?.maxConcurrentChats || 5,
            messagesCount,
            promisesObtained,
            recoveredAmount,
            averageResponseTime,
            completionRate,
        };
    }
    async getAgentActivity(agentId) {
        const activities = [];
        const recentMessages = await this.messageRepository
            .createQueryBuilder('message')
            .leftJoinAndSelect('message.chat', 'chat')
            .where('message.senderId = :agentId', { agentId })
            .andWhere('message.direction = :direction', { direction: message_entity_1.MessageDirection.OUTBOUND })
            .orderBy('message.createdAt', 'DESC')
            .take(5)
            .getMany();
        for (const msg of recentMessages) {
            activities.push({
                id: msg.id,
                type: 'message',
                description: `Mensaje enviado: ${msg.content.substring(0, 50)}...`,
                timestamp: msg.createdAt,
            });
        }
        const recentPromises = await this.clientRepository
            .createQueryBuilder('client')
            .innerJoin('client.chats', 'chat')
            .where('chat.assignedAgentId = :agentId', { agentId })
            .andWhere('client.collectionStatus = :status', { status: 'promise' })
            .orderBy('client.updatedAt', 'DESC')
            .take(5)
            .getMany();
        for (const client of recentPromises) {
            activities.push({
                id: client.id,
                type: 'promise',
                description: `Promesa de pago: ${client.fullName}`,
                timestamp: client.updatedAt,
                amount: client.promisePaymentAmount || 0,
            });
        }
        const closedChats = await this.chatRepository
            .createQueryBuilder('chat')
            .leftJoinAndSelect('chat.client', 'client')
            .where('chat.assignedAgentId = :agentId', { agentId })
            .andWhere('chat.status = :status', { status: chat_entity_1.ChatStatus.CLOSED })
            .orderBy('chat.closedAt', 'DESC')
            .take(5)
            .getMany();
        for (const chat of closedChats) {
            activities.push({
                id: chat.id,
                type: 'chat_closed',
                description: `Chat cerrado: ${chat.contactName}`,
                timestamp: chat.closedAt,
            });
        }
        return activities
            .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
            .slice(0, 10);
    }
};
exports.ReportsService = ReportsService;
exports.ReportsService = ReportsService = ReportsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __param(1, (0, typeorm_1.InjectRepository)(message_entity_1.Message)),
    __param(2, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __param(3, (0, typeorm_1.InjectRepository)(client_entity_1.Client)),
    __param(4, (0, typeorm_1.InjectRepository)(task_entity_1.Task)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], ReportsService);
//# sourceMappingURL=reports.service.js.map