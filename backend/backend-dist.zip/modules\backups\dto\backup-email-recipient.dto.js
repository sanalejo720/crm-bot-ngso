"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateBackupEmailRecipientDto = exports.CreateBackupEmailRecipientDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
class CreateBackupEmailRecipientDto {
}
exports.CreateBackupEmailRecipientDto = CreateBackupEmailRecipientDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'gerencia@empresa.com',
        description: 'Correo electrónico del destinatario',
    }),
    (0, class_validator_1.IsEmail)({}, { message: 'El correo electrónico no es válido' }),
    __metadata("design:type", String)
], CreateBackupEmailRecipientDto.prototype, "email", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'Gerente General',
        description: 'Nombre del destinatario',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateBackupEmailRecipientDto.prototype, "name", void 0);
class UpdateBackupEmailRecipientDto {
}
exports.UpdateBackupEmailRecipientDto = UpdateBackupEmailRecipientDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'gerencia@empresa.com',
        description: 'Correo electrónico del destinatario',
        required: false,
    }),
    (0, class_validator_1.IsEmail)({}, { message: 'El correo electrónico no es válido' }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateBackupEmailRecipientDto.prototype, "email", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'Gerente General',
        description: 'Nombre del destinatario',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateBackupEmailRecipientDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: true,
        description: 'Si el destinatario está activo',
        required: false,
    }),
    (0, class_validator_1.IsBoolean)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], UpdateBackupEmailRecipientDto.prototype, "isActive", void 0);
//# sourceMappingURL=backup-email-recipient.dto.js.map