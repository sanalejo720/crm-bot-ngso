import { Client } from '../../clients/entities/client.entity';
import { User } from '../../users/entities/user.entity';
export declare enum EvidenceStatus {
    PENDING = "pending",
    APPROVED = "approved",
    REJECTED = "rejected"
}
export declare enum EvidenceType {
    IMAGE = "image",
    PDF = "pdf"
}
export declare class PaymentEvidence {
    id: string;
    clientId: string;
    client: Client;
    uploadedBy: string;
    uploader: User;
    fileName: string;
    filePath: string;
    fileType: string;
    fileSize: number;
    evidenceType: EvidenceType;
    paymentAmount: number;
    paymentDate: Date;
    notes: string;
    status: EvidenceStatus;
    reviewedBy: string;
    reviewer: User;
    reviewedAt: Date;
    reviewNotes: string;
    uploadedAt: Date;
    updatedAt: Date;
    metadata: {
        originalName?: string;
        mimeType?: string;
        campaignId?: string;
        referenceNumber?: string;
    };
}
