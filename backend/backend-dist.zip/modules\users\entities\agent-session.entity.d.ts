import { User } from './user.entity';
import { Campaign } from '../../campaigns/entities/campaign.entity';
export declare enum AgentSessionStatus {
    AVAILABLE = "available",
    BUSY = "busy",
    BREAK = "break",
    OFFLINE = "offline"
}
export declare class AgentSession {
    id: string;
    status: AgentSessionStatus;
    reason: string;
    startedAt: Date;
    endedAt: Date;
    durationSeconds: number;
    ipAddress: string;
    userAgent: string;
    user: User;
    userId: string;
    campaign: Campaign;
    campaignId: string;
    createdAt: Date;
}
