export declare class CreateBackupEmailRecipientDto {
    email: string;
    name?: string;
}
export declare class UpdateBackupEmailRecipientDto {
    email?: string;
    name?: string;
    isActive?: boolean;
}
