import { Chat } from '../../chats/entities/chat.entity';
import { Task } from '../../tasks/entities/task.entity';
import { Campaign } from '../../campaigns/entities/campaign.entity';
export declare enum ClientStatus {
    LEAD = "lead",
    PROSPECT = "prospect",
    CUSTOMER = "customer",
    INACTIVE = "inactive"
}
export declare enum LeadStatus {
    NEW = "new",
    CONTACTED = "contacted",
    QUALIFIED = "qualified",
    PROPOSAL = "proposal",
    NEGOTIATION = "negotiation",
    WON = "won",
    LOST = "lost"
}
export declare class Client {
    id: string;
    fullName: string;
    phone: string;
    email: string;
    status: ClientStatus;
    company: string;
    position: string;
    leadStatus: LeadStatus;
    assignedTo: string;
    notes: any[];
    tags: string[];
    customFields: Record<string, any>;
    lastContactAt: Date;
    interactionCount: number;
    debtAmount: number;
    originalDebtAmount: number;
    daysOverdue: number;
    dueDate: Date;
    lastPaymentAmount: number;
    lastPaymentDate: Date;
    promisePaymentDate: Date;
    promisePaymentAmount: number;
    collectionStatus: string;
    paymentMethod: string;
    paymentDate: Date;
    promiseDate: Date;
    lastContactDate: Date;
    callbackDate: Date;
    priority: string;
    documentNumber: string;
    address: string;
    city: string;
    country: string;
    campaign: Campaign;
    campaignId: string;
    chats: Chat[];
    tasks: Task[];
    createdAt: Date;
    updatedAt: Date;
}
