"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var UserCampaignsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserCampaignsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const user_campaign_entity_1 = require("../entities/user-campaign.entity");
let UserCampaignsService = UserCampaignsService_1 = class UserCampaignsService {
    constructor(userCampaignRepository) {
        this.userCampaignRepository = userCampaignRepository;
        this.logger = new common_1.Logger(UserCampaignsService_1.name);
    }
    async assignUserToCampaigns(userId, campaignIds, primaryCampaignId) {
        await this.userCampaignRepository.update({ userId, isActive: true }, { isActive: false, isPrimary: false });
        const assignments = [];
        for (const campaignId of campaignIds) {
            let existing = await this.userCampaignRepository.findOne({
                where: { userId, campaignId },
            });
            if (existing) {
                existing.isActive = true;
                existing.isPrimary = campaignId === primaryCampaignId;
                existing = await this.userCampaignRepository.save(existing);
                assignments.push(existing);
            }
            else {
                const newAssignment = this.userCampaignRepository.create({
                    userId,
                    campaignId,
                    isActive: true,
                    isPrimary: campaignId === primaryCampaignId,
                });
                assignments.push(await this.userCampaignRepository.save(newAssignment));
            }
        }
        if (!primaryCampaignId && assignments.length > 0) {
            assignments[0].isPrimary = true;
            await this.userCampaignRepository.save(assignments[0]);
        }
        this.logger.log(`Usuario ${userId} asignado a ${campaignIds.length} campañas`);
        return assignments;
    }
    async getUserCampaigns(userId) {
        return this.userCampaignRepository.find({
            where: { userId, isActive: true },
            relations: ['campaign'],
            order: { isPrimary: 'DESC', assignedAt: 'ASC' },
        });
    }
    async getUserCampaignIds(userId) {
        const assignments = await this.userCampaignRepository.find({
            where: { userId, isActive: true },
            select: ['campaignId'],
        });
        return assignments.map((a) => a.campaignId);
    }
    async getCampaignAgents(campaignId) {
        return this.userCampaignRepository.find({
            where: { campaignId, isActive: true },
            relations: ['user'],
        });
    }
    async getCampaignAgentIds(campaignId) {
        const assignments = await this.userCampaignRepository.find({
            where: { campaignId, isActive: true },
            select: ['userId'],
        });
        return assignments.map((a) => a.userId);
    }
    async isUserInCampaign(userId, campaignId) {
        const count = await this.userCampaignRepository.count({
            where: { userId, campaignId, isActive: true },
        });
        return count > 0;
    }
    async getPrimaryCampaign(userId) {
        return this.userCampaignRepository.findOne({
            where: { userId, isPrimary: true, isActive: true },
            relations: ['campaign'],
        });
    }
    async removeUserFromCampaign(userId, campaignId) {
        await this.userCampaignRepository.update({ userId, campaignId }, { isActive: false });
        this.logger.log(`Usuario ${userId} removido de campaña ${campaignId}`);
    }
    async removeUserFromAllCampaigns(userId) {
        await this.userCampaignRepository.update({ userId }, { isActive: false });
        this.logger.log(`Usuario ${userId} removido de todas las campañas`);
    }
};
exports.UserCampaignsService = UserCampaignsService;
exports.UserCampaignsService = UserCampaignsService = UserCampaignsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_campaign_entity_1.UserCampaign)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], UserCampaignsService);
//# sourceMappingURL=user-campaigns.service.js.map