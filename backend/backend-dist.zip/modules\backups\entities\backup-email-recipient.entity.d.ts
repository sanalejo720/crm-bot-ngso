import { User } from '../../users/entities/user.entity';
export declare class BackupEmailRecipient {
    id: string;
    email: string;
    name: string;
    isActive: boolean;
    addedById: string;
    addedBy: User;
    createdAt: Date;
    updatedAt: Date;
}
