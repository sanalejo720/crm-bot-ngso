import { WhatsappNumber } from './whatsapp-number.entity';
import { Campaign } from '../../campaigns/entities/campaign.entity';
export declare class WhatsappNumberCampaign {
    id: string;
    whatsappNumberId: string;
    campaignId: string;
    whatsappNumber: WhatsappNumber;
    campaign: Campaign;
    createdAt: Date;
}
