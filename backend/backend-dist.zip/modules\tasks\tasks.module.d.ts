export declare class TasksModule {
}
