import { UnidentifiedClientsService } from './unidentified-clients.service';
import { CreateUnidentifiedClientDto, UpdateUnidentifiedClientDto, UpdateStatusDto } from './dto/unidentified-client.dto';
export declare class UnidentifiedClientsController {
    private readonly unidentifiedClientsService;
    constructor(unidentifiedClientsService: UnidentifiedClientsService);
    create(createDto: CreateUnidentifiedClientDto): Promise<import("./entities/unidentified-client.entity").UnidentifiedClient>;
    findAll(page?: string, limit?: string, status?: string, assignedTo?: string, search?: string): Promise<{
        data: import("./entities/unidentified-client.entity").UnidentifiedClient[];
        total: number;
        page: number;
        lastPage: number;
    }>;
    getStats(): Promise<any>;
    findByPhone(phone: string): Promise<import("./entities/unidentified-client.entity").UnidentifiedClient>;
    findOne(id: string): Promise<import("./entities/unidentified-client.entity").UnidentifiedClient>;
    update(id: string, updateDto: UpdateUnidentifiedClientDto): Promise<import("./entities/unidentified-client.entity").UnidentifiedClient>;
    updateStatus(id: string, statusDto: UpdateStatusDto): Promise<import("./entities/unidentified-client.entity").UnidentifiedClient>;
    assignTo(id: string, userId: string): Promise<import("./entities/unidentified-client.entity").UnidentifiedClient>;
    remove(id: string): Promise<{
        message: string;
    }>;
}
