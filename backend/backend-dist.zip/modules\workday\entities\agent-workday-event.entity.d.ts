import { User } from '../../users/entities/user.entity';
import { AgentWorkday } from './agent-workday.entity';
export declare enum WorkdayEventType {
    CLOCK_IN = "clock_in",
    CLOCK_OUT = "clock_out",
    PAUSE_START = "pause_start",
    PAUSE_END = "pause_end",
    STATUS_CHANGE = "status_change"
}
export declare class AgentWorkdayEvent {
    id: string;
    workdayId: string;
    workday: AgentWorkday;
    agentId: string;
    agent: User;
    eventType: WorkdayEventType;
    eventData: any;
    eventTime: Date;
    createdAt: Date;
}
