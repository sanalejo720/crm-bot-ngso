"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var AssignmentService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AssignmentService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const chat_entity_1 = require("../entities/chat.entity");
const user_entity_1 = require("../../users/entities/user.entity");
const chat_state_service_1 = require("./chat-state.service");
let AssignmentService = AssignmentService_1 = class AssignmentService {
    constructor(chatRepository, userRepository, chatStateService) {
        this.chatRepository = chatRepository;
        this.userRepository = userRepository;
        this.chatStateService = chatStateService;
        this.logger = new common_1.Logger(AssignmentService_1.name);
    }
    async assignChatToAgent(chatId, agentId, assignedBy) {
        const chat = await this.chatRepository.findOne({
            where: { id: chatId },
            relations: ['assignedAgent', 'campaign'],
        });
        if (!chat) {
            throw new common_1.NotFoundException(`Chat ${chatId} no encontrado`);
        }
        if (chat.status !== 'bot' || chat.subStatus !== 'bot_waiting_queue') {
            throw new common_1.BadRequestException(`El chat debe estar en estado BOT_WAITING_QUEUE para asignarse. Estado actual: ${chat.status}/${chat.subStatus}`);
        }
        const agent = await this.userRepository.findOne({
            where: { id: agentId, isAgent: true },
        });
        if (!agent) {
            throw new common_1.NotFoundException(`Agente ${agentId} no encontrado o no disponible`);
        }
        if (agent.currentChatsCount >= agent.maxConcurrentChats) {
            throw new common_1.BadRequestException(`El agente ${agent.fullName} ha alcanzado su capacidad máxima de chats (${agent.maxConcurrentChats})`);
        }
        await this.chatStateService.transition(chatId, 'waiting', 'waiting_agent_response', {
            reason: 'Asignación manual de chat desde cola de espera',
            triggeredBy: 'supervisor',
            agentId: assignedBy,
        });
        await this.chatRepository.update(chatId, {
            assignedAgentId: agentId,
        });
        await this.userRepository.increment({ id: agentId }, 'currentChatsCount', 1);
        this.logger.log(`✅ Chat ${chatId} asignado a agente ${agent.fullName} (${agentId}) por ${assignedBy}`);
        return this.chatRepository.findOne({
            where: { id: chatId },
            relations: ['assignedAgent', 'campaign', 'debtor'],
        });
    }
    async getWaitingQueue(campaignId) {
        const query = this.chatRepository
            .createQueryBuilder('chat')
            .leftJoinAndSelect('chat.debtor', 'debtor')
            .leftJoinAndSelect('chat.campaign', 'campaign')
            .where('chat.status = :status', { status: 'bot' })
            .andWhere('chat.subStatus = :subStatus', { subStatus: 'bot_waiting_queue' })
            .andWhere('chat.assignedAgentId IS NULL')
            .orderBy('chat.priority', 'DESC')
            .addOrderBy('chat.createdAt', 'ASC');
        if (campaignId) {
            query.andWhere('chat.campaignId = :campaignId', { campaignId });
        }
        return query.getMany();
    }
    async findAvailableAgent(campaignId) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayStr = today.toISOString().split('T')[0];
        const query = this.userRepository
            .createQueryBuilder('user')
            .innerJoin('agent_workdays', 'workday', 'workday.agentId = user.id')
            .where('user.isAgent = :isAgent', { isAgent: true })
            .andWhere('user.status = :status', { status: 'active' })
            .andWhere('user.agentState = :agentState', { agentState: 'available' })
            .andWhere('user.currentChatsCount < user.maxConcurrentChats')
            .andWhere('workday.workDate = :today', { today: todayStr })
            .andWhere('workday.clockInTime IS NOT NULL')
            .andWhere('workday.clockOutTime IS NULL');
        if (campaignId) {
            query.andWhere('user.campaignId = :campaignId', { campaignId });
        }
        query.orderBy('user.currentChatsCount', 'ASC');
        return query.getOne();
    }
    calculatePriority(chat) {
        let priority = 0;
        const waitingTimeMinutes = (Date.now() - chat.createdAt.getTime()) / 60000;
        priority += Math.floor(waitingTimeMinutes);
        return priority;
    }
    async updateQueuePriorities() {
        const waitingChats = await this.getWaitingQueue();
        for (const chat of waitingChats) {
            const newPriority = this.calculatePriority(chat);
            await this.chatRepository.update(chat.id, { priority: newPriority });
        }
        this.logger.log(`📊 Prioridades actualizadas para ${waitingChats.length} chats en cola`);
    }
};
exports.AssignmentService = AssignmentService;
exports.AssignmentService = AssignmentService = AssignmentService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        chat_state_service_1.ChatStateService])
], AssignmentService);
//# sourceMappingURL=assignment.service.js.map