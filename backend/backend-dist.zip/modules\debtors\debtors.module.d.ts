export declare class DebtorsModule {
}
