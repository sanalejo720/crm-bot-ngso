import { Repository } from 'typeorm';
import { Chat } from '../chats/entities/chat.entity';
import { ChatStateService } from '../chats/services/chat-state.service';
import { ChatsExportService } from '../chats/chats-export.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
export declare class AutoCloseWorker {
    private chatRepository;
    private chatStateService;
    private chatsExportService;
    private eventEmitter;
    private readonly logger;
    private readonly AUTO_CLOSE_HOURS;
    private readonly BATCH_SIZE;
    constructor(chatRepository: Repository<Chat>, chatStateService: ChatStateService, chatsExportService: ChatsExportService, eventEmitter: EventEmitter2);
    processAutoClose(): Promise<void>;
    private findChatsToAutoClose;
    private autoCloseChat;
    scheduleAutoClose(chatId: number): Promise<void>;
    cancelAutoClose(chatId: number): Promise<void>;
    getUpcomingAutoClose(hours?: number): Promise<Chat[]>;
    getAutoCloseStats(startDate: Date, endDate: Date): Promise<{
        totalAutoClosed: number;
        averageHoursToClose: number;
        autoCloseThreshold: number;
    }>;
}
