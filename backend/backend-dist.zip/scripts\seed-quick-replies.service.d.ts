import { Repository } from 'typeorm';
import { QuickReply } from '../modules/quick-replies/entities/quick-reply.entity';
export declare class QuickRepliesSeedService {
    private quickReplyRepository;
    private readonly logger;
    constructor(quickReplyRepository: Repository<QuickReply>);
    seed(): Promise<void>;
}
