import { User } from '../../users/entities/user.entity';
import { AgentWorkday } from './agent-workday.entity';
export declare enum PauseType {
    LUNCH = "lunch",
    BREAK = "break",
    BATHROOM = "bathroom",
    MEETING = "meeting",
    OTHER = "other"
}
export declare class AgentPause {
    id: string;
    workdayId: string;
    workday: AgentWorkday;
    agentId: string;
    agent: User;
    pauseType: PauseType;
    startTime: Date;
    endTime: Date;
    durationMinutes: number;
    reason: string;
    createdAt: Date;
    updatedAt: Date;
}
