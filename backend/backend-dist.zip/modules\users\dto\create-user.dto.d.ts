import { UserStatus } from '../entities/user.entity';
export declare class CreateUserDto {
    fullName: string;
    email: string;
    password: string;
    phone?: string;
    roleId: string;
    campaignId?: string;
    status?: UserStatus;
    isAgent?: boolean;
    maxConcurrentChats?: number;
    skills?: string[];
}
