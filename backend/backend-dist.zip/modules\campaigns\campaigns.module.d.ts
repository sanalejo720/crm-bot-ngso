export declare class CampaignsModule {
}
