export declare class WhatsappModule {
}
