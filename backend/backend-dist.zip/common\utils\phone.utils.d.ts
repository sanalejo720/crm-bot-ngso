export declare function normalizeWhatsAppPhone(phone: string): string;
export declare function formatPhoneForDisplay(phone: string): string;
export declare function extractPhoneDigits(phone: string): string;
