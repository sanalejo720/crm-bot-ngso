"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var BackupsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BackupsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const config_1 = require("@nestjs/config");
const schedule_1 = require("@nestjs/schedule");
const backup_entity_1 = require("./entities/backup.entity");
const email_service_1 = require("../../common/services/email.service");
const user_entity_1 = require("../users/entities/user.entity");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const crypto = __importStar(require("crypto"));
const bcrypt = __importStar(require("bcrypt"));
const archiver_1 = __importDefault(require("archiver"));
const child_process_1 = require("child_process");
const util_1 = require("util");
const execAsync = (0, util_1.promisify)(child_process_1.exec);
let BackupsService = BackupsService_1 = class BackupsService {
    constructor(backupRepo, userRepo, configService, emailService) {
        this.backupRepo = backupRepo;
        this.userRepo = userRepo;
        this.configService = configService;
        this.emailService = emailService;
        this.logger = new common_1.Logger(BackupsService_1.name);
        this.backupsPath = path.join(process.cwd(), 'backups');
        if (!fs.existsSync(this.backupsPath)) {
            fs.mkdirSync(this.backupsPath, { recursive: true });
        }
    }
    async createBackup(createBackupDto, userId) {
        this.logger.log(`Iniciando creación de backup tipo: ${createBackupDto.type || backup_entity_1.BackupType.MANUAL}`);
        const masterPassword = this.generateMasterPassword();
        const passwordHash = await bcrypt.hash(masterPassword, 12);
        const backup = this.backupRepo.create({
            fileName: `backup_${Date.now()}.zip`,
            filePath: '',
            fileSize: 0,
            status: backup_entity_1.BackupStatus.PROCESSING,
            type: createBackupDto.type || backup_entity_1.BackupType.MANUAL,
            passwordHash,
            isEncrypted: true,
            createdById: userId,
        });
        const savedBackup = await this.backupRepo.save(backup);
        this.executeBackup(savedBackup.id, masterPassword, userId)
            .catch(error => {
            this.logger.error(`Error en backup ${savedBackup.id}:`, error);
            this.updateBackupStatus(savedBackup.id, backup_entity_1.BackupStatus.FAILED, error.message);
        });
        return savedBackup;
    }
    async executeBackup(backupId, masterPassword, userId) {
        const backup = await this.backupRepo.findOne({ where: { id: backupId } });
        if (!backup)
            throw new Error('Backup no encontrado');
        try {
            const dbDumpPath = await this.createDatabaseDump();
            const uploadsPath = path.join(process.cwd(), 'uploads');
            const zipPath = path.join(this.backupsPath, backup.fileName);
            await this.createZipArchive(zipPath, dbDumpPath, uploadsPath);
            const databaseSize = fs.statSync(dbDumpPath).size;
            const filesSize = this.getDirectorySize(uploadsPath);
            const encryptedPath = await this.encryptFile(zipPath, masterPassword);
            fs.unlinkSync(dbDumpPath);
            fs.unlinkSync(zipPath);
            const fileSize = fs.statSync(encryptedPath).size;
            backup.filePath = encryptedPath;
            backup.fileSize = fileSize;
            backup.status = backup_entity_1.BackupStatus.COMPLETED;
            backup.completedAt = new Date();
            backup.metadata = {
                databaseSize,
                filesSize,
                compressionRatio: this.calculateCompressionRatio(fileSize, databaseSize),
            };
            await this.backupRepo.save(backup);
            try {
                let createdByName = 'Sistema Automático';
                if (userId) {
                    const user = await this.userRepo.findOne({ where: { id: userId } });
                    if (user) {
                        createdByName = user.fullName || user.email;
                    }
                }
                await this.emailService.sendBackupPasswordEmail(backup.id, masterPassword, createdByName, backup.fileName);
                this.logger.log(`📧 Email con contraseña maestra enviado a gerencia para backup ${backupId}`);
            }
            catch (emailError) {
                this.logger.error(`❌ Error enviando email para backup ${backupId}:`, emailError.message);
            }
            this.logger.log(`✅ Backup ${backupId} completado exitosamente`);
        }
        catch (error) {
            this.logger.error(`❌ Error en backup ${backupId}:`, error);
            backup.status = backup_entity_1.BackupStatus.FAILED;
            backup.errorMessage = error.message;
            await this.backupRepo.save(backup);
            throw error;
        }
    }
    async createDatabaseDump() {
        const dbUser = this.configService.get('DB_USERNAME');
        const dbPassword = this.configService.get('DB_PASSWORD');
        const dbName = this.configService.get('DB_NAME');
        const dumpPath = path.join(this.backupsPath, `dump_${Date.now()}.sql`);
        const dockerContainer = 'crm-postgres';
        try {
            await execAsync(`docker inspect ${dockerContainer}`);
            this.logger.log(`🐳 Detectado PostgreSQL en Docker (${dockerContainer})`);
            const { stdout } = await execAsync(`docker exec -e PGPASSWORD=${dbPassword} ${dockerContainer} pg_dump -U ${dbUser} ${dbName}`);
            fs.writeFileSync(dumpPath, stdout);
            this.logger.log(`✅ Database dump creado desde Docker: ${dumpPath}`);
            return dumpPath;
        }
        catch (dockerError) {
            this.logger.warn('⚠️ Contenedor Docker no encontrado, intentando pg_dump local...');
            const dbHost = this.configService.get('DB_HOST');
            const dbPort = this.configService.get('DB_PORT');
            const pgDumpPaths = [
                'pg_dump',
                'C:\\Program Files\\PostgreSQL\\16\\bin\\pg_dump.exe',
                'C:\\Program Files\\PostgreSQL\\15\\bin\\pg_dump.exe',
                'C:\\Program Files\\PostgreSQL\\14\\bin\\pg_dump.exe',
            ];
            let pgDumpCommand = 'pg_dump';
            for (const pgPath of pgDumpPaths) {
                if (fs.existsSync(pgPath)) {
                    pgDumpCommand = `"${pgPath}"`;
                    break;
                }
            }
            const env = {
                ...process.env,
                PGPASSWORD: dbPassword,
            };
            const command = `${pgDumpCommand} -h ${dbHost} -p ${dbPort} -U ${dbUser} -d ${dbName} -F p -f "${dumpPath}"`;
            try {
                await execAsync(command, { env });
                this.logger.log(`✅ Database dump creado: ${dumpPath}`);
                return dumpPath;
            }
            catch (error) {
                this.logger.error('❌ Error creando database dump:', error);
                this.logger.error(`💡 Tip: Asegúrate de que PostgreSQL esté en Docker (crm-postgres) o pg_dump esté en el PATH`);
                throw new Error(`Error al crear dump de base de datos: ${error.message}`);
            }
        }
    }
    createZipArchive(outputPath, ...inputPaths) {
        return new Promise((resolve, reject) => {
            const output = fs.createWriteStream(outputPath);
            const archive = (0, archiver_1.default)('zip', { zlib: { level: 9 } });
            output.on('close', () => {
                this.logger.log(`✅ ZIP creado: ${outputPath} (${archive.pointer()} bytes)`);
                resolve();
            });
            archive.on('error', (err) => {
                this.logger.error('❌ Error creando ZIP:', err);
                reject(err);
            });
            archive.pipe(output);
            for (const inputPath of inputPaths) {
                if (fs.existsSync(inputPath)) {
                    const stats = fs.statSync(inputPath);
                    if (stats.isDirectory()) {
                        archive.directory(inputPath, path.basename(inputPath));
                    }
                    else {
                        archive.file(inputPath, { name: path.basename(inputPath) });
                    }
                }
            }
            archive.finalize();
        });
    }
    async encryptFile(filePath, password) {
        const inputData = fs.readFileSync(filePath);
        const salt = crypto.randomBytes(32);
        const iv = crypto.randomBytes(16);
        const key = crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256');
        const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
        const encrypted = Buffer.concat([cipher.update(inputData), cipher.final()]);
        const outputData = Buffer.concat([salt, iv, encrypted]);
        const encryptedPath = filePath + '.enc';
        fs.writeFileSync(encryptedPath, outputData);
        this.logger.log(`🔒 Archivo cifrado: ${encryptedPath}`);
        return encryptedPath;
    }
    async decryptFile(filePath, password) {
        const encryptedData = fs.readFileSync(filePath);
        const salt = encryptedData.subarray(0, 32);
        const iv = encryptedData.subarray(32, 48);
        const encrypted = encryptedData.subarray(48);
        const key = crypto.pbkdf2Sync(password, salt, 100000, 32, 'sha256');
        try {
            const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
            const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
            return decrypted;
        }
        catch (error) {
            throw new common_1.BadRequestException('Contraseña incorrecta');
        }
    }
    generateMasterPassword() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
        let password = '';
        for (let i = 0; i < 32; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return password;
    }
    getDirectorySize(dirPath) {
        if (!fs.existsSync(dirPath))
            return 0;
        let size = 0;
        const files = fs.readdirSync(dirPath, { withFileTypes: true });
        for (const file of files) {
            const filePath = path.join(dirPath, file.name);
            if (file.isDirectory()) {
                size += this.getDirectorySize(filePath);
            }
            else {
                size += fs.statSync(filePath).size;
            }
        }
        return size;
    }
    calculateCompressionRatio(compressedSize, originalSize) {
        return Math.round((1 - compressedSize / originalSize) * 100);
    }
    async updateBackupStatus(backupId, status, errorMessage) {
        await this.backupRepo.update(backupId, {
            status,
            errorMessage,
            completedAt: status === backup_entity_1.BackupStatus.COMPLETED ? new Date() : undefined,
        });
    }
    async findAll() {
        return this.backupRepo.find({
            relations: ['createdBy'],
            order: { createdAt: 'DESC' },
        });
    }
    async findOne(id) {
        const backup = await this.backupRepo.findOne({
            where: { id },
            relations: ['createdBy'],
        });
        if (!backup) {
            throw new common_1.NotFoundException('Backup no encontrado');
        }
        return backup;
    }
    async downloadBackup(id, password) {
        const backup = await this.findOne(id);
        if (backup.status !== backup_entity_1.BackupStatus.COMPLETED) {
            throw new common_1.BadRequestException('El backup no está completado');
        }
        const isValid = await bcrypt.compare(password, backup.passwordHash);
        if (!isValid) {
            throw new common_1.BadRequestException('Contraseña incorrecta');
        }
        const decryptedBuffer = await this.decryptFile(backup.filePath, password);
        return {
            buffer: decryptedBuffer,
            fileName: backup.fileName,
        };
    }
    async remove(id) {
        const backup = await this.findOne(id);
        if (fs.existsSync(backup.filePath)) {
            fs.unlinkSync(backup.filePath);
        }
        await this.backupRepo.remove(backup);
        this.logger.log(`🗑️ Backup ${id} eliminado`);
    }
    async handleDailyBackup() {
        this.logger.log('🕐 Ejecutando backup automático diario...');
        await this.createBackup({ type: backup_entity_1.BackupType.SCHEDULED });
    }
};
exports.BackupsService = BackupsService;
__decorate([
    (0, schedule_1.Cron)('0 2 * * *'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], BackupsService.prototype, "handleDailyBackup", null);
exports.BackupsService = BackupsService = BackupsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(backup_entity_1.Backup)),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        config_1.ConfigService,
        email_service_1.EmailService])
], BackupsService);
//# sourceMappingURL=backups.service.js.map