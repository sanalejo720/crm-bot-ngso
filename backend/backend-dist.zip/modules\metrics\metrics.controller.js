"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MetricsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const metrics_service_1 = require("./metrics.service");
let MetricsController = class MetricsController {
    constructor(metricsService) {
        this.metricsService = metricsService;
    }
    async getAgentMetrics(agentId, startDate, endDate) {
        const start = startDate
            ? new Date(startDate)
            : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        const end = endDate ? new Date(endDate) : new Date();
        return this.metricsService.getAgentMetrics(agentId, start, end);
    }
    async getAgentTMO(agentId, startDate, endDate) {
        const start = startDate
            ? new Date(startDate)
            : new Date(Date.now() - 24 * 60 * 60 * 1000);
        const end = endDate ? new Date(endDate) : new Date();
        return this.metricsService.getAgentTMO(agentId, start, end);
    }
    async getAgentFRT(agentId, startDate, endDate) {
        const start = startDate
            ? new Date(startDate)
            : new Date(Date.now() - 24 * 60 * 60 * 1000);
        const end = endDate ? new Date(endDate) : new Date();
        return this.metricsService.getAgentFRT(agentId, start, end);
    }
    async getCampaignMetrics(campaignId, startDate, endDate) {
        const start = startDate
            ? new Date(startDate)
            : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        const end = endDate ? new Date(endDate) : new Date();
        return this.metricsService.getCampaignMetrics(campaignId, start, end);
    }
    async getBotMetrics(campaignId, startDate, endDate) {
        const start = startDate
            ? new Date(startDate)
            : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        const end = endDate ? new Date(endDate) : new Date();
        return this.metricsService.getBotMetrics(campaignId || null, start, end);
    }
    async getSupervisorDashboard(campaignId, startDate, endDate) {
        const start = startDate
            ? new Date(startDate)
            : new Date(Date.now() - 24 * 60 * 60 * 1000);
        const end = endDate ? new Date(endDate) : new Date();
        return this.metricsService.getSupervisorDashboard(campaignId || null, start, end);
    }
    async getRealtimeMetrics(campaignId) {
        const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
        const now = new Date();
        return this.metricsService.getSupervisorDashboard(campaignId || null, fiveMinutesAgo, now);
    }
    async recordPayment(dto, req) {
        return this.metricsService.recordPayment(dto, req.user?.id);
    }
    async getCollectionMetrics(startDate, endDate, agentId, campaignId) {
        return this.metricsService.getCollectionMetrics({
            startDate,
            endDate,
            agentId,
            campaignId,
        });
    }
    async getAgentCollectionMetrics(startDate, endDate, campaignId) {
        return this.metricsService.getAgentCollectionMetrics({
            startDate,
            endDate,
            campaignId,
        });
    }
    async getCollectionTimeSeries(startDate, endDate, agentId, campaignId, groupBy) {
        return this.metricsService.getCollectionTimeSeries({
            startDate,
            endDate,
            agentId,
            campaignId,
            groupBy,
        });
    }
    async getPortfolioSummary(campaignId) {
        return this.metricsService.getPortfolioSummary(campaignId);
    }
};
exports.MetricsController = MetricsController;
__decorate([
    (0, common_1.Get)('agent/:agentId'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener métricas de un agente' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false, description: 'Fecha inicio (ISO)' }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false, description: 'Fecha fin (ISO)' }),
    __param(0, (0, common_1.Param)('agentId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], MetricsController.prototype, "getAgentMetrics", null);
__decorate([
    (0, common_1.Get)('agent/:agentId/tmo'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener TMO (Tiempo Medio de Operación) de un agente' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false }),
    __param(0, (0, common_1.Param)('agentId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], MetricsController.prototype, "getAgentTMO", null);
__decorate([
    (0, common_1.Get)('agent/:agentId/frt'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener FRT (First Response Time) de un agente' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false }),
    __param(0, (0, common_1.Param)('agentId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], MetricsController.prototype, "getAgentFRT", null);
__decorate([
    (0, common_1.Get)('campaign/:campaignId'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener métricas de una campaña' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false }),
    __param(0, (0, common_1.Param)('campaignId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], MetricsController.prototype, "getCampaignMetrics", null);
__decorate([
    (0, common_1.Get)('bot'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener métricas del bot' }),
    (0, swagger_1.ApiQuery)({ name: 'campaignId', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false }),
    __param(0, (0, common_1.Query)('campaignId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], MetricsController.prototype, "getBotMetrics", null);
__decorate([
    (0, common_1.Get)('dashboard'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener dashboard consolidado para supervisores' }),
    (0, swagger_1.ApiQuery)({ name: 'campaignId', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false }),
    __param(0, (0, common_1.Query)('campaignId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], MetricsController.prototype, "getSupervisorDashboard", null);
__decorate([
    (0, common_1.Get)('realtime'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener métricas en tiempo real' }),
    (0, swagger_1.ApiQuery)({ name: 'campaignId', required: false }),
    __param(0, (0, common_1.Query)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MetricsController.prototype, "getRealtimeMetrics", null);
__decorate([
    (0, common_1.Post)('payments'),
    (0, swagger_1.ApiOperation)({ summary: 'Registrar un pago' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], MetricsController.prototype, "recordPayment", null);
__decorate([
    (0, common_1.Get)('collection'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener métricas generales de recaudo' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'agentId', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'campaignId', required: false }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('agentId')),
    __param(3, (0, common_1.Query)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], MetricsController.prototype, "getCollectionMetrics", null);
__decorate([
    (0, common_1.Get)('collection/agents'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener ranking de recaudo por agente' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'campaignId', required: false }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], MetricsController.prototype, "getAgentCollectionMetrics", null);
__decorate([
    (0, common_1.Get)('collection/timeseries'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener métricas de recaudo en serie de tiempo' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'agentId', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'campaignId', required: false }),
    (0, swagger_1.ApiQuery)({ name: 'groupBy', required: false, enum: ['day', 'week', 'month'] }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __param(2, (0, common_1.Query)('agentId')),
    __param(3, (0, common_1.Query)('campaignId')),
    __param(4, (0, common_1.Query)('groupBy')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String]),
    __metadata("design:returntype", Promise)
], MetricsController.prototype, "getCollectionTimeSeries", null);
__decorate([
    (0, common_1.Get)('portfolio'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener resumen de cartera' }),
    (0, swagger_1.ApiQuery)({ name: 'campaignId', required: false }),
    __param(0, (0, common_1.Query)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MetricsController.prototype, "getPortfolioSummary", null);
exports.MetricsController = MetricsController = __decorate([
    (0, swagger_1.ApiTags)('Metrics'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.Controller)('metrics'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [metrics_service_1.MetricsService])
], MetricsController);
//# sourceMappingURL=metrics.controller.js.map