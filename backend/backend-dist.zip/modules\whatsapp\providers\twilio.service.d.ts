import { EventEmitter2 } from '@nestjs/event-emitter';
export declare class TwilioService {
    private eventEmitter;
    private readonly logger;
    private clients;
    private credentials;
    constructor(eventEmitter: EventEmitter2);
    initializeClient(whatsappNumberId: string, accountSid: string, authToken: string): void;
    private getClient;
    sendTextMessage(whatsappNumberId: string, from: string, to: string, body: string): Promise<{
        messageId: string;
        metadata?: any;
    }>;
    sendMediaMessage(whatsappNumberId: string, from: string, to: string, body: string, mediaUrl: string): Promise<{
        messageId: string;
        metadata?: any;
    }>;
    processWebhook(payload: any): Promise<void>;
    getMessageStatus(whatsappNumberId: string, messageSid: string): Promise<any>;
    sendContentMessage(whatsappNumberId: string, from: string, to: string, contentSid: string, contentVariables?: Record<string, string>): Promise<{
        messageId: string;
        metadata?: any;
    }>;
    removeClient(whatsappNumberId: string): void;
    private downloadTwilioMedia;
    private getExtensionFromContentType;
}
