export declare class MonitoringModule {
}
