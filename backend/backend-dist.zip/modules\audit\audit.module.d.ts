export declare class AuditModule {
}
