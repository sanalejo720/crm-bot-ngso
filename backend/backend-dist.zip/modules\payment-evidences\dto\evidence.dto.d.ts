export declare class CreateEvidenceDto {
    clientId: string;
    paymentAmount: number;
    paymentDate: string;
    notes?: string;
    campaignId?: string;
    referenceNumber?: string;
}
export declare class ReviewEvidenceDto {
    status: 'approved' | 'rejected';
    reviewNotes?: string;
}
export declare class QueryEvidencesDto {
    clientId?: string;
    status?: 'pending' | 'approved' | 'rejected';
    startDate?: string;
    endDate?: string;
    uploadedBy?: string;
}
