import { Response } from 'express';
import { EvidencesService } from './evidences.service';
export declare class EvidencesController {
    private readonly evidencesService;
    constructor(evidencesService: EvidencesService);
    findAll(closureType?: 'paid' | 'promise' | 'transfer', agentId?: string, startDate?: string, endDate?: string): Promise<{
        success: boolean;
        data: import("./entities/evidence.entity").Evidence[];
        total: number;
    }>;
    getStats(agentId?: string): Promise<{
        success: boolean;
        data: any[];
    }>;
    downloadEvidence(ticketNumber: string, res: Response, req: any): Promise<Response<any, Record<string, any>>>;
    findOne(ticketNumber: string): Promise<{
        success: boolean;
        data: import("./entities/evidence.entity").Evidence;
    }>;
}
