import { MetricsService } from './metrics.service';
import { PaymentSource, PaymentStatus } from './entities/payment-record.entity';
export declare class MetricsController {
    private readonly metricsService;
    constructor(metricsService: MetricsService);
    getAgentMetrics(agentId: string, startDate?: string, endDate?: string): Promise<{
        agentId: string;
        agentName: string;
        period: {
            start: Date;
            end: Date;
        };
        chats: {
            total: number;
            active: number;
            closed: number;
            resolved: number;
        };
        messages: {
            sent: number;
            received: number;
        };
        performance: {
            tmoMinutes: number;
            frtSeconds: number;
            avgMessagesPerChat: number;
            closureRate: number;
        };
        session: {
            totalTimeHours: number;
            avgSessionDuration: number;
            totalSessions: number;
        };
    }>;
    getAgentTMO(agentId: string, startDate?: string, endDate?: string): Promise<{
        tmoMinutes: number;
        totalChats: number;
    }>;
    getAgentFRT(agentId: string, startDate?: string, endDate?: string): Promise<{
        frtSeconds: number;
        totalChats: number;
    }>;
    getCampaignMetrics(campaignId: string, startDate?: string, endDate?: string): Promise<{
        campaignId: string;
        campaignName: string;
        period: {
            start: Date;
            end: Date;
        };
        chats: {
            total: number;
            attended: number;
            unattended: number;
            botOnly: number;
            transferred: number;
        };
        queue: {
            avgWaitTimeSeconds: number;
            maxWaitTimeSeconds: number;
            currentInQueue: number;
        };
        agents: {
            total: number;
            available: number;
            loadDistribution: Array<{
                agentId: string;
                agentName: string;
                chatCount: number;
            }>;
        };
    }>;
    getBotMetrics(campaignId?: string, startDate?: string, endDate?: string): Promise<{
        period: {
            start: Date;
            end: Date;
        };
        resolution: {
            totalChats: number;
            resolvedByBot: number;
            transferredToAgent: number;
            resolutionRate: number;
        };
        dropRate: {
            totalStarted: number;
            abandoned: number;
            dropRate: number;
        };
        performance: {
            avgBotInteractions: number;
            avgTimeInBotSeconds: number;
        };
    }>;
    getSupervisorDashboard(campaignId?: string, startDate?: string, endDate?: string): Promise<any>;
    getRealtimeMetrics(campaignId?: string): Promise<any>;
    recordPayment(dto: {
        clientId: string;
        agentId?: string;
        campaignId?: string;
        amount: number;
        paymentDate: string;
        source?: PaymentSource;
        status?: PaymentStatus;
        referenceId?: string;
        notes?: string;
    }, req: any): Promise<import("./entities/payment-record.entity").PaymentRecord>;
    getCollectionMetrics(startDate?: string, endDate?: string, agentId?: string, campaignId?: string): Promise<{
        totalCollected: number;
        totalDebtAssigned: number;
        recoveryPercentage: number;
        paymentsCount: number;
        averagePayment: number;
    }>;
    getAgentCollectionMetrics(startDate?: string, endDate?: string, campaignId?: string): Promise<{
        agentId: string;
        agentName: string;
        totalCollected: number;
        totalAssigned: number;
        recoveryPercentage: number;
        paymentsCount: number;
        ranking: number;
    }[]>;
    getCollectionTimeSeries(startDate?: string, endDate?: string, agentId?: string, campaignId?: string, groupBy?: 'day' | 'week' | 'month'): Promise<{
        date: string;
        totalCollected: number;
        paymentsCount: number;
        recoveryPercentage: number;
    }[]>;
    getPortfolioSummary(campaignId?: string): Promise<{
        totalPortfolio: number;
        totalCollected: number;
        totalPending: number;
        recoveryPercentage: number;
        clientsCount: number;
        paidClients: number;
        pendingClients: number;
    }>;
}
