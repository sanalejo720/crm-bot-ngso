import { CreateClientDto } from './create-client.dto';
import { CollectionStatus } from '../enums/collection-status.enum';
declare const UpdateClientDto_base: import("@nestjs/common").Type<Partial<CreateClientDto>>;
export declare class UpdateClientDto extends UpdateClientDto_base {
    fullName?: string;
    name?: string;
    debtAmount?: number;
    daysOverdue?: number;
    status?: string;
    collectionStatus?: CollectionStatus;
    promisePaymentDate?: Date;
    promisePaymentAmount?: number;
    lastPaymentAmount?: number;
    lastPaymentDate?: Date;
}
export {};
