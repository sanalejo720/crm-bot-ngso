"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ChatResolutionService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatResolutionService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const event_emitter_1 = require("@nestjs/event-emitter");
const schedule_1 = require("@nestjs/schedule");
const chat_entity_1 = require("../entities/chat.entity");
const resolve_chat_dto_1 = require("../dto/resolve-chat.dto");
const client_entity_1 = require("../../clients/entities/client.entity");
const payment_record_entity_1 = require("../../metrics/entities/payment-record.entity");
const whatsapp_service_1 = require("../../whatsapp/whatsapp.service");
const chats_export_service_1 = require("../chats-export.service");
const message_entity_1 = require("../../messages/entities/message.entity");
const messages_service_1 = require("../../messages/messages.service");
let ChatResolutionService = ChatResolutionService_1 = class ChatResolutionService {
    constructor(chatRepository, clientRepository, paymentRecordRepository, eventEmitter, whatsappService, chatsExportService, messagesService) {
        this.chatRepository = chatRepository;
        this.clientRepository = clientRepository;
        this.paymentRecordRepository = paymentRecordRepository;
        this.eventEmitter = eventEmitter;
        this.whatsappService = whatsappService;
        this.chatsExportService = chatsExportService;
        this.messagesService = messagesService;
        this.logger = new common_1.Logger(ChatResolutionService_1.name);
    }
    async resolveChat(chatId, resolveDto, agentId) {
        const chat = await this.chatRepository.findOne({
            where: { id: chatId },
            relations: ['client', 'campaign', 'whatsappNumber', 'assignedAgent'],
        });
        if (!chat) {
            throw new common_1.NotFoundException(`Chat ${chatId} no encontrado`);
        }
        this.logger.log(`Resolviendo chat ${chatId} con tipo: ${resolveDto.resolutionType}`);
        switch (resolveDto.resolutionType) {
            case resolve_chat_dto_1.ResolutionType.PAID:
                await this.handlePaymentResolution(chat, resolveDto, agentId);
                break;
            case resolve_chat_dto_1.ResolutionType.PROMISE:
                await this.handlePromiseResolution(chat, resolveDto, agentId);
                break;
            case resolve_chat_dto_1.ResolutionType.NO_AGREEMENT:
                await this.handleNoAgreementResolution(chat, resolveDto, agentId);
                break;
            case resolve_chat_dto_1.ResolutionType.CALLBACK:
                await this.handleCallbackResolution(chat, resolveDto, agentId);
                break;
        }
        chat.status = chat_entity_1.ChatStatus.RESOLVED;
        chat.resolvedAt = new Date();
        chat.resolutionType = resolveDto.resolutionType;
        chat.resolutionNotes = resolveDto.notes || '';
        chat.resolutionMetadata = {
            type: resolveDto.resolutionType,
            paymentMethod: resolveDto.paymentMethod,
            paymentAmount: resolveDto.paymentAmount,
            promiseDate: resolveDto.promiseDate,
            promiseAmount: resolveDto.promiseAmount,
            promisePaymentMethod: resolveDto.promisePaymentMethod,
            noAgreementReason: resolveDto.noAgreementReason,
            callbackDate: resolveDto.callbackDate,
            callbackNotes: resolveDto.callbackNotes,
            resolvedBy: agentId,
            resolvedAt: new Date().toISOString(),
        };
        await this.chatRepository.save(chat);
        if (resolveDto.sendClosingMessage) {
            await this.sendClosingMessage(chat, resolveDto);
        }
        try {
            if (resolveDto.resolutionType === resolve_chat_dto_1.ResolutionType.PAID || resolveDto.resolutionType === resolve_chat_dto_1.ResolutionType.PROMISE) {
                const closureType = resolveDto.resolutionType === resolve_chat_dto_1.ResolutionType.PAID ? 'paid' : 'promise';
                await this.chatsExportService.exportChatToPDF(chatId, closureType, agentId, false, true);
            }
        }
        catch (error) {
            this.logger.error(`Error generando PDF de cierre: ${error.message}`);
        }
        this.eventEmitter.emit('chat.resolved', {
            chat,
            resolutionType: resolveDto.resolutionType,
            agentId,
        });
        return chat;
    }
    async handlePaymentResolution(chat, resolveDto, agentId) {
        if (!chat.client) {
            this.logger.warn(`Chat ${chat.id} no tiene cliente asociado para registrar pago`);
            return;
        }
        const client = chat.client;
        client.collectionStatus = 'paid';
        client.paymentMethod = resolveDto.paymentMethod;
        client.paymentDate = new Date();
        await this.clientRepository.save(client);
        const paymentRecord = this.paymentRecordRepository.create({
            clientId: client.id,
            agentId,
            campaignId: chat.campaignId,
            amount: resolveDto.paymentAmount || client.debtAmount || 0,
            originalDebt: client.debtAmount || 0,
            remainingDebt: Math.max(0, (client.debtAmount || 0) - (resolveDto.paymentAmount || 0)),
            recoveryPercentage: client.debtAmount
                ? ((resolveDto.paymentAmount || client.debtAmount) / client.debtAmount) * 100
                : 100,
            paymentDate: new Date(),
            source: payment_record_entity_1.PaymentSource.MANUAL,
            status: payment_record_entity_1.PaymentStatus.CONFIRMED,
            notes: `Pago registrado por agente. Método: ${resolveDto.paymentMethod}`,
            metadata: {
                chatId: chat.id,
                resolutionType: 'paid',
                paymentMethod: resolveDto.paymentMethod,
            },
        });
        await this.paymentRecordRepository.save(paymentRecord);
        this.logger.log(`Pago registrado para cliente ${client.id}: $${paymentRecord.amount}`);
    }
    async handlePromiseResolution(chat, resolveDto, agentId) {
        if (!chat.client) {
            this.logger.warn(`Chat ${chat.id} no tiene cliente asociado para registrar promesa`);
            return;
        }
        const client = chat.client;
        client.collectionStatus = 'promise';
        client.promiseDate = resolveDto.promiseDate ? new Date(resolveDto.promiseDate) : null;
        client.promisePaymentAmount = resolveDto.promiseAmount;
        client.paymentMethod = resolveDto.promisePaymentMethod;
        await this.clientRepository.save(client);
        const paymentRecord = this.paymentRecordRepository.create({
            clientId: client.id,
            agentId,
            campaignId: chat.campaignId,
            amount: resolveDto.promiseAmount || client.debtAmount || 0,
            originalDebt: client.debtAmount || 0,
            remainingDebt: client.debtAmount || 0,
            recoveryPercentage: 0,
            paymentDate: resolveDto.promiseDate ? new Date(resolveDto.promiseDate) : new Date(),
            source: payment_record_entity_1.PaymentSource.BOT_PROMISE,
            status: payment_record_entity_1.PaymentStatus.PENDING,
            notes: `Promesa de pago para ${resolveDto.promiseDate}. Método: ${resolveDto.promisePaymentMethod}`,
            metadata: {
                chatId: chat.id,
                resolutionType: 'promise',
                promiseDate: resolveDto.promiseDate,
                promiseAmount: resolveDto.promiseAmount,
                promisePaymentMethod: resolveDto.promisePaymentMethod,
            },
        });
        await this.paymentRecordRepository.save(paymentRecord);
        this.logger.log(`Promesa de pago registrada para cliente ${client.id}: $${paymentRecord.amount} para ${resolveDto.promiseDate}`);
    }
    async handleNoAgreementResolution(chat, resolveDto, agentId) {
        if (!chat.client) {
            return;
        }
        const client = chat.client;
        client.collectionStatus = 'no_agreement';
        client.lastContactDate = new Date();
        const newNote = {
            date: new Date().toISOString(),
            type: 'no_agreement',
            text: `Sin acuerdo: ${resolveDto.noAgreementReason}`,
            agentId,
        };
        client.notes = [...(client.notes || []), newNote];
        await this.clientRepository.save(client);
        this.logger.log(`Cliente ${client.id} marcado sin acuerdo: ${resolveDto.noAgreementReason}`);
    }
    async handleCallbackResolution(chat, resolveDto, agentId) {
        if (!chat.client) {
            return;
        }
        const client = chat.client;
        client.collectionStatus = 'callback';
        client.callbackDate = resolveDto.callbackDate ? new Date(resolveDto.callbackDate) : null;
        const newNote = {
            date: new Date().toISOString(),
            type: 'callback',
            text: `Cliente se comunicará: ${resolveDto.callbackNotes || 'Sin notas'}`,
            callbackDate: resolveDto.callbackDate,
            agentId,
        };
        client.notes = [...(client.notes || []), newNote];
        await this.clientRepository.save(client);
        this.logger.log(`Cliente ${client.id} marcado para callback: ${resolveDto.callbackDate}`);
    }
    async sendClosingMessage(chat, resolveDto) {
        let message = '';
        const paymentMethodLabel = this.getPaymentMethodLabel(resolveDto.paymentMethod || '');
        switch (resolveDto.resolutionType) {
            case resolve_chat_dto_1.ResolutionType.PAID:
                message = `✅ *Gracias por confirmar su pago*\n\nHemos registrado su pago por medio de: *${paymentMethodLabel}*\n\n📎 Por favor, envíenos una foto o imagen del comprobante de pago para completar el registro.\n\n_NGS&O - Gestión de Cobranza_`;
                break;
            case resolve_chat_dto_1.ResolutionType.PROMISE:
                const formattedDate = resolveDto.promiseDate
                    ? new Date(resolveDto.promiseDate).toLocaleDateString('es-CO', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                    })
                    : 'la fecha acordada';
                const promisePaymentMethodLabel = this.getPaymentMethodLabel(resolveDto.promisePaymentMethod || '');
                message = `📅 *Acuerdo de Pago Registrado*\n\nHemos registrado su compromiso de pago:\n• Fecha: ${formattedDate}\n• Monto: $${resolveDto.promiseAmount?.toLocaleString('es-CO') || 'N/A'}\n• Medio de pago: ${promisePaymentMethodLabel}\n\nLe recordaremos el día del pago. ¡Gracias por su compromiso!\n\n_NGS&O - Gestión de Cobranza_`;
                break;
            case resolve_chat_dto_1.ResolutionType.NO_AGREEMENT:
                message = `📝 *Gestión Finalizada*\n\nHemos registrado su respuesta. Si cambia de opinión o necesita más información sobre opciones de pago, puede contactarnos nuevamente.\n\n_NGS&O - Gestión de Cobranza_`;
                break;
            case resolve_chat_dto_1.ResolutionType.CALLBACK:
                message = `📞 *Le esperamos*\n\nHemos tomado nota de que se comunicará con nosotros próximamente. Estaremos atentos a su llamada.\n\n_NGS&O - Gestión de Cobranza_`;
                break;
        }
        if (message && chat.whatsappNumber?.id) {
            try {
                await this.messagesService.sendTextMessage(chat.id, chat.assignedAgentId || 'system', message);
                this.logger.log(`✅ Mensaje de cierre enviado y guardado para chat ${chat.id}`);
            }
            catch (error) {
                this.logger.error(`Error enviando mensaje de cierre: ${error.message}`);
                try {
                    await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, message, message_entity_1.MessageType.TEXT);
                    this.logger.log(`⚠️ Mensaje de cierre enviado (fallback) pero no guardado en BD`);
                }
                catch (fallbackError) {
                    this.logger.error(`Error en fallback de mensaje de cierre: ${fallbackError.message}`);
                }
            }
        }
    }
    async sendPaymentReminders() {
        this.logger.log('🔔 Ejecutando job de recordatorios de promesas de pago...');
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        const clientsWithPromises = await this.clientRepository
            .createQueryBuilder('client')
            .where('client.collectionStatus = :status', { status: 'promise' })
            .andWhere('client.promiseDate >= :today', { today })
            .andWhere('client.promiseDate < :tomorrow', { tomorrow })
            .leftJoinAndSelect('client.chats', 'chat')
            .leftJoinAndSelect('chat.whatsappNumber', 'whatsappNumber')
            .getMany();
        this.logger.log(`Encontrados ${clientsWithPromises.length} clientes con promesa de pago para hoy`);
        for (const client of clientsWithPromises) {
            const lastChat = client.chats?.[0];
            if (!lastChat?.whatsappNumber?.id) {
                this.logger.warn(`Cliente ${client.id} no tiene chat con número de WhatsApp asociado`);
                continue;
            }
            const message = `🔔 *Recordatorio de Pago*\n\nHola ${client.fullName || 'estimado cliente'},\n\nLe recordamos que hoy vence su compromiso de pago por $${client.promisePaymentAmount?.toLocaleString() || client.debtAmount?.toLocaleString() || 'N/A'}.\n\nMedio de pago acordado: ${client.paymentMethod || 'No especificado'}\n\nSi ya realizó el pago, por favor envíenos el comprobante. Si tiene alguna dificultad, comuníquese con nosotros.\n\n_NGS&O - Gestión de Cobranza_`;
            try {
                await this.whatsappService.sendMessage(lastChat.whatsappNumber.id, client.phone || lastChat.contactPhone, message, message_entity_1.MessageType.TEXT);
                this.logger.log(`Recordatorio enviado a cliente ${client.id}: ${client.phone}`);
            }
            catch (error) {
                this.logger.error(`Error enviando recordatorio a ${client.id}: ${error.message}`);
            }
        }
    }
    async getResolutionStatsByAgent(agentId, startDate, endDate) {
        const query = this.chatRepository
            .createQueryBuilder('chat')
            .select('chat.resolutionType', 'type')
            .addSelect('COUNT(*)', 'count')
            .where('chat.assignedAgentId = :agentId', { agentId })
            .andWhere('chat.status = :status', { status: chat_entity_1.ChatStatus.RESOLVED })
            .groupBy('chat.resolutionType');
        if (startDate) {
            query.andWhere('chat.resolvedAt >= :startDate', { startDate });
        }
        if (endDate) {
            query.andWhere('chat.resolvedAt <= :endDate', { endDate });
        }
        const results = await query.getRawMany();
        return {
            paid: parseInt(results.find(r => r.type === 'paid')?.count || '0'),
            promise: parseInt(results.find(r => r.type === 'promise')?.count || '0'),
            no_agreement: parseInt(results.find(r => r.type === 'no_agreement')?.count || '0'),
            callback: parseInt(results.find(r => r.type === 'callback')?.count || '0'),
        };
    }
    async getGlobalResolutionStats(startDate, endDate, campaignId) {
        const query = this.chatRepository
            .createQueryBuilder('chat')
            .select('chat.resolutionType', 'type')
            .addSelect('COUNT(*)', 'count')
            .where('chat.status = :status', { status: chat_entity_1.ChatStatus.RESOLVED });
        if (startDate) {
            query.andWhere('chat.resolvedAt >= :startDate', { startDate });
        }
        if (endDate) {
            query.andWhere('chat.resolvedAt <= :endDate', { endDate });
        }
        if (campaignId) {
            query.andWhere('chat.campaignId = :campaignId', { campaignId });
        }
        query.groupBy('chat.resolutionType');
        const results = await query.getRawMany();
        const totalResolved = results.reduce((sum, r) => sum + parseInt(r.count || '0'), 0);
        return {
            total: totalResolved,
            byType: {
                paid: parseInt(results.find(r => r.type === 'paid')?.count || '0'),
                promise: parseInt(results.find(r => r.type === 'promise')?.count || '0'),
                no_agreement: parseInt(results.find(r => r.type === 'no_agreement')?.count || '0'),
                callback: parseInt(results.find(r => r.type === 'callback')?.count || '0'),
            },
            rates: {
                paid: totalResolved > 0 ? (parseInt(results.find(r => r.type === 'paid')?.count || '0') / totalResolved * 100).toFixed(2) : 0,
                promise: totalResolved > 0 ? (parseInt(results.find(r => r.type === 'promise')?.count || '0') / totalResolved * 100).toFixed(2) : 0,
                no_agreement: totalResolved > 0 ? (parseInt(results.find(r => r.type === 'no_agreement')?.count || '0') / totalResolved * 100).toFixed(2) : 0,
                callback: totalResolved > 0 ? (parseInt(results.find(r => r.type === 'callback')?.count || '0') / totalResolved * 100).toFixed(2) : 0,
            },
        };
    }
    getPaymentMethodLabel(method) {
        const labels = {
            'transfer': 'Transferencia Bancaria',
            'pse': 'PSE',
            'card': 'Tarjeta Crédito/Débito',
            'cash': 'Efectivo',
            'other': 'Otro',
        };
        return labels[method] || method || 'No especificado';
    }
};
exports.ChatResolutionService = ChatResolutionService;
__decorate([
    (0, schedule_1.Cron)('0 9 * * *'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ChatResolutionService.prototype, "sendPaymentReminders", null);
exports.ChatResolutionService = ChatResolutionService = ChatResolutionService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __param(1, (0, typeorm_1.InjectRepository)(client_entity_1.Client)),
    __param(2, (0, typeorm_1.InjectRepository)(payment_record_entity_1.PaymentRecord)),
    __param(4, (0, common_1.Inject)((0, common_1.forwardRef)(() => whatsapp_service_1.WhatsappService))),
    __param(5, (0, common_1.Inject)((0, common_1.forwardRef)(() => chats_export_service_1.ChatsExportService))),
    __param(6, (0, common_1.Inject)((0, common_1.forwardRef)(() => messages_service_1.MessagesService))),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        event_emitter_1.EventEmitter2,
        whatsapp_service_1.WhatsappService,
        chats_export_service_1.ChatsExportService,
        messages_service_1.MessagesService])
], ChatResolutionService);
//# sourceMappingURL=chat-resolution.service.js.map