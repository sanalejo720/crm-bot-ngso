import { User } from '../../users/entities/user.entity';
import { Permission } from './permission.entity';
export declare class Role {
    id: string;
    name: string;
    description: string;
    isActive: boolean;
    isSystem: boolean;
    users: User[];
    permissions: Permission[];
    createdAt: Date;
    updatedAt: Date;
}
