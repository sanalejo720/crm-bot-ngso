import { Repository } from 'typeorm';
import { Chat } from '../chats/entities/chat.entity';
import { ChatStateService } from '../chats/services/chat-state.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
export declare class TimeoutMonitorWorker {
    private chatRepository;
    private chatStateService;
    private eventEmitter;
    private readonly logger;
    private readonly AGENT_WARNING_TIME;
    private readonly AGENT_TIMEOUT_TIME;
    private readonly CLIENT_WARNING_TIME;
    private readonly CLIENT_TIMEOUT_TIME;
    private readonly CLIENT_TIMEOUT_ENABLED;
    constructor(chatRepository: Repository<Chat>, chatStateService: ChatStateService, eventEmitter: EventEmitter2);
    checkTimeouts(): Promise<void>;
    private checkAgentTimeouts;
    private checkClientTimeouts;
    private sendAgentWarning;
    private sendClientWarning;
    private closeByAgentTimeout;
    private closeByClientTimeout;
    getTimeoutStats(startDate: Date, endDate: Date): Promise<{
        agentTimeouts: number;
        clientTimeouts: number;
        total: number;
    }>;
}
