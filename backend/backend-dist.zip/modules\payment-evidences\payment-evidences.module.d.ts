export declare class PaymentEvidencesModule {
}
