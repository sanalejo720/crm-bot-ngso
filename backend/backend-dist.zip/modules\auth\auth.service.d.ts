import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { Repository } from 'typeorm';
import { User } from '../users/entities/user.entity';
import { AgentSessionsService } from '../users/services/agent-sessions.service';
import { LoginDto, LoginResponseDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';
export declare class AuthService {
    private userRepository;
    private jwtService;
    private configService;
    private agentSessionsService;
    private readonly logger;
    constructor(userRepository: Repository<User>, jwtService: JwtService, configService: ConfigService, agentSessionsService: AgentSessionsService);
    validateUser(email: string, password: string): Promise<any>;
    login(loginDto: LoginDto): Promise<LoginResponseDto>;
    register(registerDto: RegisterDto): Promise<User>;
    private generateTokens;
    refreshToken(userId: string, refreshToken: string): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    logout(userId: string): Promise<void>;
    generate2FASecret(email: string): {
        secret: string;
        qrCode: string;
    };
    enable2FA(userId: string, secret: string, token: string): Promise<void>;
    disable2FA(userId: string): Promise<void>;
}
