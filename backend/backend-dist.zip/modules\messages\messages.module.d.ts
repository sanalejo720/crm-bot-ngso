export declare class MessagesModule {
}
