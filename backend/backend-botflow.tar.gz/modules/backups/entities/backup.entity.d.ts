import { User } from '../../users/entities/user.entity';
export declare enum BackupStatus {
    PROCESSING = "processing",
    COMPLETED = "completed",
    FAILED = "failed"
}
export declare enum BackupType {
    MANUAL = "manual",
    SCHEDULED = "scheduled"
}
export declare class Backup {
    id: string;
    fileName: string;
    filePath: string;
    fileSize: number;
    status: BackupStatus;
    type: BackupType;
    passwordHash: string;
    isEncrypted: boolean;
    errorMessage: string;
    metadata: {
        databaseSize?: number;
        filesSize?: number;
        totalRecords?: number;
        tablesIncluded?: string[];
        compressionRatio?: number;
    };
    createdBy: User;
    createdById: string;
    createdAt: Date;
    completedAt: Date;
}
