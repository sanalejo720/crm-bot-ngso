export declare class UploadCsvDto {
    file: any;
}
export interface CsvDebtorRow {
    fullName: string;
    documentType: string;
    documentNumber: string;
    phone?: string;
    email?: string;
    address?: string;
    debtAmount: number;
    initialDebtAmount: number;
    daysOverdue: number;
    lastPaymentDate?: string;
    promiseDate?: string;
    status?: string;
    notes?: string;
    producto?: string;
    numeroCredito?: string;
    fechaVencimiento?: string;
}
