"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var BotExecutorService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotExecutorService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const event_emitter_1 = require("@nestjs/event-emitter");
const bot_flow_entity_1 = require("./entities/bot-flow.entity");
const bot_node_entity_1 = require("./entities/bot-node.entity");
const chat_entity_1 = require("../chats/entities/chat.entity");
const campaign_entity_1 = require("../campaigns/entities/campaign.entity");
const whatsapp_service_1 = require("../whatsapp/whatsapp.service");
const message_entity_1 = require("../messages/entities/message.entity");
const messages_service_1 = require("../messages/messages.service");
let BotExecutorService = BotExecutorService_1 = class BotExecutorService {
    constructor(botFlowRepository, botNodeRepository, chatRepository, campaignRepository, whatsappService, messagesService, eventEmitter) {
        this.botFlowRepository = botFlowRepository;
        this.botNodeRepository = botNodeRepository;
        this.chatRepository = chatRepository;
        this.campaignRepository = campaignRepository;
        this.whatsappService = whatsappService;
        this.messagesService = messagesService;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(BotExecutorService_1.name);
        this.botSessions = new Map();
    }
    async handleMessageCreated(payload) {
        try {
            const { message, chat } = payload;
            if (message.direction !== 'inbound') {
                return;
            }
            this.logger.log(`🤖 Mensaje entrante recibido de ${chat.contactPhone} - Chat: ${chat.id} - Estado: ${chat.status}`);
            if (chat.status === 'closed') {
                this.logger.log(`🔄 Chat ${chat.id} estaba cerrado, reactivando para bot...`);
                await this.chatRepository.update(chat.id, {
                    status: () => "'bot'",
                    closedAt: null,
                });
                chat.status = 'bot';
            }
            if (chat.assignedAgentId) {
                this.logger.log(`Chat ${chat.id} tiene agente asignado, bot no responde`);
                return;
            }
            if (!chat.campaign) {
                const chatWithCampaign = await this.chatRepository.findOne({
                    where: { id: chat.id },
                    relations: ['campaign', 'whatsappNumber'],
                });
                if (!chatWithCampaign) {
                    this.logger.log(`Chat no encontrado: ${chat.id}`);
                    return;
                }
                chat.campaign = chatWithCampaign.campaign;
                chat.whatsappNumber = chatWithCampaign.whatsappNumber;
            }
            const result = await this.processIncomingMessage(chat.id, message.content);
            if (result.shouldRespond && result.response) {
                await this.sendBotMessage(chat, result.response);
            }
            if (result.shouldTransferToAgent) {
                this.logger.log(`📋 Cambiando estado del chat ${chat.id} a 'waiting' (en cola para asignación)`);
                await this.chatRepository.update(chat.id, {
                    status: () => "'waiting'",
                });
            }
        }
        catch (error) {
            this.logger.error(`Error manejando mensaje: ${error.message}`, error.stack);
        }
    }
    async handleChatClosed(chat) {
        const chatId = chat.id || chat.chatId;
        this.logger.log(`🔔 Evento chat.closed recibido para chat ${chatId}`);
        try {
            const chatWithRelations = await this.chatRepository.findOne({
                where: { id: chatId },
                relations: ['campaign', 'whatsappNumber'],
            });
            if (!chatWithRelations) {
                this.logger.error(`Chat ${chatId} no encontrado en handleChatClosed`);
                return;
            }
            const farewellMessage = `✅ *Gracias por contactarnos*

Su conversación ha sido cerrada. Si necesita asistencia adicional, puede escribirnos nuevamente y el sistema le atenderá automáticamente.

*Equipo de Soporte NGSO*`;
            await this.sendBotMessage(chatWithRelations, farewellMessage);
            this.logger.log(`💬 Mensaje de despedida enviado al chat ${chatId}`);
            await this.resetBotSession(chatId);
            this.logger.log(`🔄 Sesión del bot reseteada para chat ${chatId}`);
        }
        catch (error) {
            this.logger.error(`Error en handleChatClosed para chat ${chatId}: ${error.message}`, error.stack);
        }
    }
    async processIncomingMessage(chatId, message) {
        try {
            const chat = await this.chatRepository.findOne({
                where: { id: chatId },
                relations: ['campaign'],
            });
            if (!chat || !chat.campaign) {
                return { shouldRespond: false };
            }
            const campaign = chat.campaign;
            if (!campaign.settings?.botEnabled || !campaign.settings?.botFlowId) {
                return { shouldRespond: false };
            }
            let session = this.botSessions.get(chatId);
            if (!session) {
                const flow = await this.botFlowRepository.findOne({
                    where: { id: campaign.settings.botFlowId },
                    relations: ['nodes'],
                });
                if (!flow || flow.status !== 'active') {
                    this.logger.warn(`Flujo ${campaign.settings.botFlowId} no encontrado o inactivo`);
                    return { shouldRespond: false };
                }
                const startNode = flow.nodes.find(node => node.id === flow.startNodeId);
                if (!startNode) {
                    this.logger.error(`Nodo inicial no encontrado en flujo ${flow.id}`);
                    return { shouldRespond: false };
                }
                session = {
                    chatId,
                    flowId: flow.id,
                    currentNodeId: startNode.id,
                    variables: {},
                    startedAt: new Date(),
                };
                this.botSessions.set(chatId, session);
                this.logger.log(`🤖 Bot iniciado para chat ${chatId}`);
            }
            return await this.executeCurrentNode(session, message);
        }
        catch (error) {
            this.logger.error(`Error procesando mensaje para bot: ${error.message}`, error.stack);
            return { shouldRespond: false };
        }
    }
    async executeCurrentNode(session, userMessage) {
        const node = await this.botNodeRepository.findOne({
            where: { id: session.currentNodeId },
        });
        if (!node) {
            this.logger.error(`Nodo ${session.currentNodeId} no encontrado`);
            return { shouldRespond: false };
        }
        this.logger.log(`📍 Ejecutando nodo: ${node.name} (${node.type})`);
        switch (node.type) {
            case bot_node_entity_1.BotNodeType.MESSAGE:
                return this.handleMessageNode(session, node);
            case bot_node_entity_1.BotNodeType.MENU:
                return this.handleMenuNode(session, node, userMessage);
            case bot_node_entity_1.BotNodeType.INPUT:
                return this.handleInputNode(session, node, userMessage);
            case bot_node_entity_1.BotNodeType.TRANSFER_AGENT:
                return this.handleTransferNode(session);
            case bot_node_entity_1.BotNodeType.END:
                this.botSessions.delete(session.chatId);
                return { shouldRespond: false };
            default:
                if (node.nextNodeId) {
                    session.currentNodeId = node.nextNodeId;
                    return this.executeCurrentNode(session, userMessage);
                }
                return { shouldRespond: false };
        }
    }
    async handleMessageNode(session, node) {
        const message = this.replaceVariables(node.config.message || '', session.variables);
        if (node.nextNodeId) {
            session.currentNodeId = node.nextNodeId;
            this.botSessions.set(session.chatId, session);
            return {
                shouldRespond: true,
                response: message,
            };
        }
        return {
            shouldRespond: true,
            response: message,
        };
    }
    async handleMenuNode(session, node, userMessage) {
        if (!session.waitingForInput) {
            session.waitingForInput = true;
            this.botSessions.set(session.chatId, session);
            let menuText = node.config.message || 'Selecciona una opción:';
            if (node.config.options) {
                menuText += '\n\n';
                node.config.options.forEach((opt, idx) => {
                    menuText += `${idx + 1}. ${opt.label}\n`;
                });
            }
            return {
                shouldRespond: true,
                response: menuText,
            };
        }
        session.waitingForInput = false;
        if (node.config.options) {
            const selectedOption = node.config.options.find((opt, idx) => userMessage === String(idx + 1) ||
                userMessage.toLowerCase() === opt.value.toLowerCase() ||
                userMessage.toLowerCase() === opt.label.toLowerCase());
            if (selectedOption && selectedOption.nextNodeId) {
                session.currentNodeId = selectedOption.nextNodeId;
            }
            else if (node.nextNodeId) {
                session.currentNodeId = node.nextNodeId;
            }
        }
        this.botSessions.set(session.chatId, session);
        return this.executeCurrentNode(session, userMessage);
    }
    async handleInputNode(session, node, userMessage) {
        if (!session.waitingForInput) {
            session.waitingForInput = true;
            this.botSessions.set(session.chatId, session);
            return {
                shouldRespond: true,
                response: node.config.message || 'Por favor ingresa tu respuesta:',
            };
        }
        session.waitingForInput = false;
        const variableName = node.config.variableName || 'input';
        session.variables[variableName] = userMessage;
        if (node.nextNodeId) {
            session.currentNodeId = node.nextNodeId;
        }
        this.botSessions.set(session.chatId, session);
        return this.executeCurrentNode(session, userMessage);
    }
    async handleTransferNode(session) {
        this.logger.log(`👤 Transfiriendo chat ${session.chatId} a agente`);
        this.botSessions.delete(session.chatId);
        return {
            shouldRespond: true,
            response: 'Te estoy conectando con un asesor. En un momento te atenderá.',
            shouldTransferToAgent: true,
        };
    }
    replaceVariables(text, variables) {
        let result = text;
        for (const [key, value] of Object.entries(variables)) {
            const regex = new RegExp(`{{${key}}}`, 'g');
            result = result.replace(regex, String(value));
        }
        return result;
    }
    async resetBotSession(chatId) {
        this.botSessions.delete(chatId);
        this.logger.log(`🔄 Sesión de bot reiniciada para chat ${chatId}`);
    }
    getBotSession(chatId) {
        return this.botSessions.get(chatId);
    }
    async sendBotMessage(chat, messageText) {
        try {
            if (chat.whatsappNumber) {
                await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, messageText, message_entity_1.MessageType.TEXT);
            }
            const savedMessage = await this.messagesService.create({
                chatId: chat.id,
                content: messageText,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
            });
            this.logger.log(`✅ Mensaje del bot enviado y guardado: ${savedMessage.id}`);
            this.eventEmitter.emit('message.created', {
                message: savedMessage,
                chat: chat,
            });
        }
        catch (error) {
            this.logger.error(`Error enviando mensaje del bot: ${error.message}`, error.stack);
        }
    }
};
exports.BotExecutorService = BotExecutorService;
__decorate([
    (0, event_emitter_1.OnEvent)('message.created'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], BotExecutorService.prototype, "handleMessageCreated", null);
__decorate([
    (0, event_emitter_1.OnEvent)('chat.closed'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], BotExecutorService.prototype, "handleChatClosed", null);
exports.BotExecutorService = BotExecutorService = BotExecutorService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(bot_flow_entity_1.BotFlow)),
    __param(1, (0, typeorm_1.InjectRepository)(bot_node_entity_1.BotNode)),
    __param(2, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __param(3, (0, typeorm_1.InjectRepository)(campaign_entity_1.Campaign)),
    __param(4, (0, common_1.Inject)((0, common_1.forwardRef)(() => whatsapp_service_1.WhatsappService))),
    __param(5, (0, common_1.Inject)((0, common_1.forwardRef)(() => messages_service_1.MessagesService))),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        whatsapp_service_1.WhatsappService,
        messages_service_1.MessagesService,
        event_emitter_1.EventEmitter2])
], BotExecutorService);
//# sourceMappingURL=bot-executor.service.js.map