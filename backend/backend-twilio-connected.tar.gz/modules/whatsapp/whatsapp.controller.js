"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WhatsappController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const whatsapp_service_1 = require("./whatsapp.service");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
let WhatsappController = class WhatsappController {
    constructor(whatsappService) {
        this.whatsappService = whatsappService;
    }
    async getGeneralStatus() {
        const activeNumbers = await this.whatsappService.findAllActive();
        return {
            success: true,
            data: {
                connected: activeNumbers.length > 0,
                totalNumbers: activeNumbers.length || 0,
                numbers: activeNumbers,
            },
        };
    }
    async getQR() {
        return {
            success: true,
            data: {
                message: 'Use el endpoint POST /whatsapp/:id/wppconnect/start para iniciar una sesión y obtener el QR',
                instruction: 'Primero necesita crear un número WhatsApp en el sistema',
            },
        };
    }
    async checkConnection() {
        const activeNumbers = await this.whatsappService.findAllActive();
        const isConnected = activeNumbers && activeNumbers.length > 0;
        return {
            success: true,
            data: {
                connected: isConnected,
                message: isConnected ? 'WhatsApp conectado' : 'WhatsApp no conectado',
            },
        };
    }
    findAllActive() {
        return this.whatsappService.findAllActive();
    }
    findOne(id) {
        return this.whatsappService.findOne(id);
    }
    findByCampaign(campaignId) {
        return this.whatsappService.findByCampaign(campaignId);
    }
    startWppConnectSession(id) {
        return this.whatsappService.startWppConnectSession(id);
    }
    getWppConnectStatus(id) {
        return this.whatsappService.getWppConnectStatus(id);
    }
    async sendMessage(body) {
        const { whatsappNumberId, to, content, type = 'text' } = body;
        const result = await this.whatsappService.sendMessage(whatsappNumberId, to, content, type);
        return {
            success: true,
            data: result,
            message: 'Mensaje enviado correctamente',
        };
    }
    getDebugSessions() {
        return this.whatsappService.getDebugSessions();
    }
};
exports.WhatsappController = WhatsappController;
__decorate([
    (0, common_1.Get)('status'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estado general de WhatsApp' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'whatsapp', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], WhatsappController.prototype, "getGeneralStatus", null);
__decorate([
    (0, common_1.Get)('qr'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener código QR para conexión' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'whatsapp', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], WhatsappController.prototype, "getQR", null);
__decorate([
    (0, common_1.Get)('check'),
    (0, swagger_1.ApiOperation)({ summary: 'Verificar conexión de WhatsApp' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'whatsapp', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], WhatsappController.prototype, "checkConnection", null);
__decorate([
    (0, common_1.Get)('numbers'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener todos los números WhatsApp activos' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'whatsapp', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], WhatsappController.prototype, "findAllActive", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener número WhatsApp por ID' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'whatsapp', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], WhatsappController.prototype, "findOne", null);
__decorate([
    (0, common_1.Get)('campaign/:campaignId'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener números WhatsApp por campaña' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'whatsapp', action: 'read' }),
    __param(0, (0, common_1.Param)('campaignId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], WhatsappController.prototype, "findByCampaign", null);
__decorate([
    (0, common_1.Post)(':id/wppconnect/start'),
    (0, swagger_1.ApiOperation)({ summary: 'Iniciar sesión WPPConnect' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'whatsapp', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], WhatsappController.prototype, "startWppConnectSession", null);
__decorate([
    (0, common_1.Get)(':id/wppconnect/status'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estado de sesión WPPConnect' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'whatsapp', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], WhatsappController.prototype, "getWppConnectStatus", null);
__decorate([
    (0, common_1.Post)('send-message'),
    (0, swagger_1.ApiOperation)({ summary: 'Enviar mensaje de WhatsApp' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'whatsapp', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], WhatsappController.prototype, "sendMessage", null);
__decorate([
    (0, common_1.Get)('debug/sessions'),
    (0, swagger_1.ApiOperation)({ summary: 'Ver sesiones activas en WPPConnect (DEBUG)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'whatsapp', action: 'read' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], WhatsappController.prototype, "getDebugSessions", null);
exports.WhatsappController = WhatsappController = __decorate([
    (0, swagger_1.ApiTags)('whatsapp'),
    (0, common_1.Controller)('whatsapp'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [whatsapp_service_1.WhatsappService])
], WhatsappController);
//# sourceMappingURL=whatsapp.controller.js.map