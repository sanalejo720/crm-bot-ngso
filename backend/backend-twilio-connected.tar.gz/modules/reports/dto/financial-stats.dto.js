"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FinancialTrendDto = exports.DailyFinancialsDto = exports.FinancialSummaryDto = exports.AgentRecaudoDto = exports.CampaignFinancialsDto = void 0;
class CampaignFinancialsDto {
}
exports.CampaignFinancialsDto = CampaignFinancialsDto;
class AgentRecaudoDto {
}
exports.AgentRecaudoDto = AgentRecaudoDto;
class FinancialSummaryDto {
}
exports.FinancialSummaryDto = FinancialSummaryDto;
class DailyFinancialsDto {
}
exports.DailyFinancialsDto = DailyFinancialsDto;
class FinancialTrendDto {
}
exports.FinancialTrendDto = FinancialTrendDto;
//# sourceMappingURL=financial-stats.dto.js.map