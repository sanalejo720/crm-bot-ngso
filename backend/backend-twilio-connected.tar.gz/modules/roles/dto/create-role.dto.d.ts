export declare class CreateRoleDto {
    name: string;
    description?: string;
    permissionIds?: string[];
}
