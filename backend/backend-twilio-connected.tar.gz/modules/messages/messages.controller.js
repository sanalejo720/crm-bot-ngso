"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessagesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const messages_service_1 = require("./messages.service");
const create_message_dto_1 = require("./dto/create-message.dto");
const send_message_dto_1 = require("./dto/send-message.dto");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const permissions_guard_1 = require("../auth/guards/permissions.guard");
const permissions_decorator_1 = require("../auth/decorators/permissions.decorator");
const current_user_decorator_1 = require("../auth/decorators/current-user.decorator");
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
let MessagesController = class MessagesController {
    constructor(messagesService) {
        this.messagesService = messagesService;
    }
    create(createMessageDto) {
        return this.messagesService.create(createMessageDto);
    }
    sendMessage(sendMessageDto, senderId) {
        return this.messagesService.sendTextMessage(sendMessageDto.chatId, senderId, sendMessageDto.content);
    }
    sendMediaMessage(sendMediaDto, senderId) {
        return this.messagesService.sendMediaMessage(sendMediaDto.chatId, senderId, sendMediaDto.mediaUrl, sendMediaDto.mediaType, sendMediaDto.caption);
    }
    findMessages(chatId, limit, offset) {
        if (!chatId) {
            return { success: false, message: 'chatId is required' };
        }
        return this.messagesService.findByChatId(chatId, { limit, offset });
    }
    findByChatId(chatId, limit, offset) {
        return this.messagesService.findByChatId(chatId, { limit, offset });
    }
    findOne(id) {
        return this.messagesService.findOne(id);
    }
    markMessageAsRead(id) {
        return this.messagesService.markAsRead(id);
    }
    markAsRead(chatId) {
        return this.messagesService.markAsRead(chatId);
    }
    getStats(chatId) {
        return this.messagesService.getStats(chatId);
    }
    async downloadMedia(id, res) {
        const message = await this.messagesService.findOne(id);
        if (!message || !message.mediaUrl) {
            throw new common_1.NotFoundException('Mensaje o archivo multimedia no encontrado');
        }
        const filePath = path.join(process.cwd(), message.mediaUrl.replace(/^\//, ''));
        if (!fs.existsSync(filePath)) {
            throw new common_1.NotFoundException('Archivo no encontrado en el servidor');
        }
        const fileName = message.mediaFileName || path.basename(filePath);
        res.download(filePath, fileName);
    }
};
exports.MessagesController = MessagesController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Crear mensaje (uso interno)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'messages', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_message_dto_1.CreateMessageDto]),
    __metadata("design:returntype", void 0)
], MessagesController.prototype, "create", null);
__decorate([
    (0, common_1.Post)('send'),
    (0, swagger_1.ApiOperation)({ summary: 'Enviar mensaje de texto' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'messages', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [send_message_dto_1.SendMessageDto, String]),
    __metadata("design:returntype", void 0)
], MessagesController.prototype, "sendMessage", null);
__decorate([
    (0, common_1.Post)('send-media'),
    (0, swagger_1.ApiOperation)({ summary: 'Enviar mensaje con media' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'messages', action: 'create' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [send_message_dto_1.SendMediaMessageDto, String]),
    __metadata("design:returntype", void 0)
], MessagesController.prototype, "sendMediaMessage", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener mensajes por chatId (query param)' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'messages', action: 'read' }),
    __param(0, (0, common_1.Query)('chatId')),
    __param(1, (0, common_1.Query)('limit')),
    __param(2, (0, common_1.Query)('offset')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, Number]),
    __metadata("design:returntype", void 0)
], MessagesController.prototype, "findMessages", null);
__decorate([
    (0, common_1.Get)('chat/:chatId'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener mensajes de un chat' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'messages', action: 'read' }),
    __param(0, (0, common_1.Param)('chatId')),
    __param(1, (0, common_1.Query)('limit')),
    __param(2, (0, common_1.Query)('offset')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, Number]),
    __metadata("design:returntype", void 0)
], MessagesController.prototype, "findByChatId", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener mensaje por ID' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'messages', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], MessagesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id/read'),
    (0, swagger_1.ApiOperation)({ summary: 'Marcar mensaje como leído' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'messages', action: 'update' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], MessagesController.prototype, "markMessageAsRead", null);
__decorate([
    (0, common_1.Post)('chat/:chatId/mark-read'),
    (0, swagger_1.ApiOperation)({ summary: 'Marcar mensajes como leídos' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'messages', action: 'update' }),
    __param(0, (0, common_1.Param)('chatId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], MessagesController.prototype, "markAsRead", null);
__decorate([
    (0, common_1.Get)('chat/:chatId/stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas de mensajes' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'messages', action: 'read' }),
    __param(0, (0, common_1.Param)('chatId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], MessagesController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)(':id/download-media'),
    (0, swagger_1.ApiOperation)({ summary: 'Descargar archivo multimedia de un mensaje' }),
    (0, permissions_decorator_1.RequirePermissions)({ module: 'messages', action: 'read' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], MessagesController.prototype, "downloadMedia", null);
exports.MessagesController = MessagesController = __decorate([
    (0, swagger_1.ApiTags)('messages'),
    (0, common_1.Controller)('messages'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, permissions_guard_1.PermissionsGuard),
    (0, swagger_1.ApiBearerAuth)(),
    __metadata("design:paramtypes", [messages_service_1.MessagesService])
], MessagesController);
//# sourceMappingURL=messages.controller.js.map