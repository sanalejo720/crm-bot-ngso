import { Repository } from 'typeorm';
import { Evidence } from './entities/evidence.entity';
export declare class EvidencesService {
    private evidenceRepository;
    private readonly logger;
    constructor(evidenceRepository: Repository<Evidence>);
    create(data: {
        ticketNumber: string;
        closureType: 'paid' | 'promise' | 'transfer';
        filePath: string;
        fileName: string;
        chatId: string;
        clientId?: string;
        clientName: string;
        agentId: string;
        agentName: string;
        amount?: number;
        promiseDate?: Date;
    }): Promise<Evidence>;
    findAll(filters?: {
        closureType?: 'paid' | 'promise' | 'transfer';
        agentId?: string;
        startDate?: Date;
        endDate?: Date;
    }): Promise<Evidence[]>;
    findByTicket(ticketNumber: string): Promise<Evidence>;
    getAgentStats(agentId?: string): Promise<any[]>;
}
