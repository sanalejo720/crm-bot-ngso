import { DocumentType } from '../entities/debtor.entity';
export declare class CreateDebtorDto {
    fullName: string;
    documentType: DocumentType;
    documentNumber: string;
    phone?: string;
    email?: string;
    address?: string;
    debtAmount: number;
    initialDebtAmount: number;
    daysOverdue: number;
    lastPaymentDate?: string;
    promiseDate?: string;
    status?: string;
    notes?: string;
    metadata?: Record<string, any>;
}
