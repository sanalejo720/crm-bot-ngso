"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuickRepliesModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const quick_replies_controller_1 = require("./quick-replies.controller");
const quick_replies_service_1 = require("./quick-replies.service");
const quick_reply_entity_1 = require("./entities/quick-reply.entity");
const chats_module_1 = require("../chats/chats.module");
const seed_quick_replies_service_1 = require("../../scripts/seed-quick-replies.service");
let QuickRepliesModule = class QuickRepliesModule {
};
exports.QuickRepliesModule = QuickRepliesModule;
exports.QuickRepliesModule = QuickRepliesModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([quick_reply_entity_1.QuickReply]),
            chats_module_1.ChatsModule,
        ],
        controllers: [quick_replies_controller_1.QuickRepliesController],
        providers: [quick_replies_service_1.QuickRepliesService, seed_quick_replies_service_1.QuickRepliesSeedService],
        exports: [quick_replies_service_1.QuickRepliesService],
    })
], QuickRepliesModule);
//# sourceMappingURL=quick-replies.module.js.map