import { ClientsService } from './clients.service';
import { CreateClientDto } from './dto/create-client.dto';
import { UpdateClientDto } from './dto/update-client.dto';
import { LeadStatus } from './entities/client.entity';
export declare class ClientsController {
    private readonly clientsService;
    constructor(clientsService: ClientsService);
    create(createClientDto: CreateClientDto, user: any): Promise<import("./entities/client.entity").Client>;
    findAll(search?: string, leadStatus?: LeadStatus, campaignId?: string, tags?: string, assignedTo?: string): Promise<import("./entities/client.entity").Client[]>;
    getStats(campaignId?: string): Promise<{
        total: number;
        byStatus: any;
    }>;
    findDuplicates(): Promise<any[]>;
    findOne(id: string): Promise<import("./entities/client.entity").Client>;
    update(id: string, updateClientDto: UpdateClientDto): Promise<import("./entities/client.entity").Client>;
    updateLeadStatus(id: string, body: {
        leadStatus: LeadStatus;
    }): Promise<import("./entities/client.entity").Client>;
    addNote(id: string, body: {
        note: string;
    }, user: any): Promise<import("./entities/client.entity").Client>;
    addTags(id: string, body: {
        tags: string[];
    }): Promise<import("./entities/client.entity").Client>;
    removeTags(id: string, body: {
        tags: string[];
    }): Promise<import("./entities/client.entity").Client>;
    assignTo(id: string, body: {
        userId: string;
    }): Promise<import("./entities/client.entity").Client>;
    bulkImport(body: {
        clients: CreateClientDto[];
    }, user: any): Promise<{
        success: number;
        failed: number;
    }>;
    remove(id: string): Promise<void>;
}
