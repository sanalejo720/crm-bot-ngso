"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var MonitoringService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MonitoringService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const message_entity_1 = require("../messages/entities/message.entity");
const event_emitter_1 = require("@nestjs/event-emitter");
let MonitoringService = MonitoringService_1 = class MonitoringService {
    constructor(messageRepository, eventEmitter) {
        this.messageRepository = messageRepository;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(MonitoringService_1.name);
        this.agentOffensiveWords = {
            abuse: {
                high: ['idiota', 'estúpido', 'tonto', 'burro', 'imbécil', 'inútil'],
                medium: ['molesto', 'fastidioso', 'pesado', 'insoportable'],
                low: ['no entiende', 'difícil', 'complicado'],
            },
            threat: {
                critical: ['amenaza', 'voy a', 'te voy', 'cuidado'],
                high: ['problema', 'consecuencias'],
            },
            discrimination: {
                critical: ['negro', 'indio', 'pobre', 'ignorante'],
                high: ['analfabeto', 'sin educación'],
            },
            profanity: {
                high: ['mierda', 'carajo', 'puta', 'joder', 'coño', 'verga', 'hijueputa'],
                medium: ['diablos', 'demonio'],
            },
        };
        this.clientOffensiveWords = {
            abuse: {
                high: ['idiota', 'estúpido', 'tonto', 'burro', 'imbécil', 'inútil', 'malparido', 'gonorrea'],
                medium: ['incompetente', 'inservible', 'malo', 'pésimo'],
                low: ['lento', 'ineficiente'],
            },
            threat: {
                critical: ['matar', 'denunciar', 'demandar', 'acusar', 'quemar'],
                high: ['reportar', 'quejar', 'problema grave'],
            },
            profanity: {
                high: ['mierda', 'carajo', 'puta', 'joder', 'coño', 'verga', 'hijueputa', 'hp'],
                medium: ['maldito', 'maldita', 'diablos'],
            },
        };
    }
    analyzeMessage(messageId, chatId, content, direction, senderType, agentId, agentName) {
        const matches = [];
        const contentLower = content.toLowerCase();
        const dictionary = senderType === 'agent' ? this.agentOffensiveWords : this.clientOffensiveWords;
        Object.keys(dictionary).forEach((category) => {
            Object.keys(dictionary[category]).forEach((severity) => {
                dictionary[category][severity].forEach((word) => {
                    if (contentLower.includes(word.toLowerCase())) {
                        matches.push({
                            word,
                            category: category,
                            severity: severity,
                        });
                    }
                });
            });
        });
        if (matches.length > 0) {
            const alert = {
                messageId,
                chatId,
                direction,
                sender: senderType,
                content,
                matches,
                timestamp: new Date(),
                agentId,
                agentName,
            };
            this.logger.warn(`⚠️ Palabras ofensivas detectadas en mensaje ${messageId} (${senderType}): ${matches.length} coincidencias`);
            this.eventEmitter.emit('monitoring.offensive-words-detected', alert);
            return alert;
        }
        return null;
    }
    async getNumberStats(numberId, days = 7) {
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);
        const messages = await this.messageRepository
            .createQueryBuilder('message')
            .leftJoin('message.chat', 'chat')
            .leftJoin('chat.whatsappNumber', 'whatsappNumber')
            .where('whatsappNumber.id = :numberId', { numberId })
            .andWhere('message.createdAt >= :startDate', { startDate })
            .select([
            'COUNT(*) as total_messages',
            'COUNT(CASE WHEN message.direction = :outbound THEN 1 END) as sent',
            'COUNT(CASE WHEN message.direction = :inbound THEN 1 END) as received',
            'MAX(message.createdAt) as last_message_at',
        ])
            .setParameters({ outbound: 'outbound', inbound: 'inbound' })
            .getRawOne();
        return {
            numberId,
            totalMessages: parseInt(messages.total_messages) || 0,
            messagesSent: parseInt(messages.sent) || 0,
            messagesReceived: parseInt(messages.received) || 0,
            lastMessageAt: messages.last_message_at,
            periodDays: days,
        };
    }
    async getNumbersRanking(limit = 10, days = 7) {
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - days);
        const ranking = await this.messageRepository
            .createQueryBuilder('message')
            .leftJoin('message.chat', 'chat')
            .leftJoin('chat.whatsappNumber', 'whatsappNumber')
            .where('message.createdAt >= :startDate', { startDate })
            .groupBy('whatsappNumber.id')
            .addGroupBy('whatsappNumber.phoneNumber')
            .addGroupBy('whatsappNumber.displayName')
            .select([
            'whatsappNumber.id as number_id',
            'whatsappNumber.phoneNumber as phone_number',
            'whatsappNumber.displayName as display_name',
            'COUNT(*) as total_messages',
            'COUNT(CASE WHEN message.direction = :outbound THEN 1 END) as sent',
            'COUNT(CASE WHEN message.direction = :inbound THEN 1 END) as received',
            'MAX(message.createdAt) as last_message_at',
        ])
            .setParameters({ outbound: 'outbound', inbound: 'inbound' })
            .orderBy('total_messages', 'DESC')
            .limit(limit)
            .getRawMany();
        return ranking.map((item) => ({
            numberId: item.number_id,
            phoneNumber: item.phone_number,
            displayName: item.display_name,
            totalMessages: parseInt(item.total_messages),
            messagesSent: parseInt(item.sent),
            messagesReceived: parseInt(item.received),
            lastMessageAt: item.last_message_at,
        }));
    }
    async getRecentAlerts(limit = 50) {
        return [];
    }
    addCustomOffensiveWord(word, category, severity, target) {
        if (target === 'agent' || target === 'both') {
            if (!this.agentOffensiveWords[category][severity]) {
                this.agentOffensiveWords[category][severity] = [];
            }
            this.agentOffensiveWords[category][severity].push(word);
        }
        if (target === 'client' || target === 'both') {
            if (!this.clientOffensiveWords[category][severity]) {
                this.clientOffensiveWords[category][severity] = [];
            }
            this.clientOffensiveWords[category][severity].push(word);
        }
        this.logger.log(`✅ Palabra ofensiva agregada: "${word}" (${category}/${severity}/${target})`);
    }
    getOffensiveWords() {
        return {
            agent: this.agentOffensiveWords,
            client: this.clientOffensiveWords,
        };
    }
};
exports.MonitoringService = MonitoringService;
exports.MonitoringService = MonitoringService = MonitoringService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(message_entity_1.Message)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        event_emitter_1.EventEmitter2])
], MonitoringService);
//# sourceMappingURL=monitoring.service.js.map