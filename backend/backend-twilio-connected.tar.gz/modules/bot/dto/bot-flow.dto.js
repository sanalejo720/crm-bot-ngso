"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BulkCreateNodesDto = exports.UpdateBotNodeDto = exports.CreateBotNodeDto = exports.UpdateBotFlowDto = exports.CreateBotFlowDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const bot_flow_entity_1 = require("../entities/bot-flow.entity");
class CreateBotFlowDto {
}
exports.CreateBotFlowDto = CreateBotFlowDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Flujo de Cobranza' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateBotFlowDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'Flujo para gestión de cobranza automatizada' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateBotFlowDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: bot_flow_entity_1.BotFlowStatus.DRAFT, enum: bot_flow_entity_1.BotFlowStatus }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(bot_flow_entity_1.BotFlowStatus),
    __metadata("design:type", String)
], CreateBotFlowDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'node-welcome' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateBotFlowDto.prototype, "startNodeId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: {
            clientName: { name: 'Nombre del cliente', type: 'string', defaultValue: 'Cliente' },
            debtAmount: { name: 'Monto de deuda', type: 'number', defaultValue: 0 },
        },
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsObject)(),
    __metadata("design:type", Object)
], CreateBotFlowDto.prototype, "variables", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: {
            maxInactivityTime: 300,
            transferToAgentOnError: true,
            fallbackMessage: 'Disculpa, no entendí. ¿Puedes intentar de nuevo?',
        },
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsObject)(),
    __metadata("design:type", Object)
], CreateBotFlowDto.prototype, "settings", void 0);
class UpdateBotFlowDto {
}
exports.UpdateBotFlowDto = UpdateBotFlowDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'Flujo de Cobranza v2' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateBotFlowDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'Flujo actualizado' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateBotFlowDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: bot_flow_entity_1.BotFlowStatus.ACTIVE, enum: bot_flow_entity_1.BotFlowStatus }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(bot_flow_entity_1.BotFlowStatus),
    __metadata("design:type", String)
], UpdateBotFlowDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'node-welcome' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateBotFlowDto.prototype, "startNodeId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsObject)(),
    __metadata("design:type", Object)
], UpdateBotFlowDto.prototype, "variables", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsObject)(),
    __metadata("design:type", Object)
], UpdateBotFlowDto.prototype, "settings", void 0);
class CreateBotNodeDto {
}
exports.CreateBotNodeDto = CreateBotNodeDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Mensaje de Bienvenida' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateBotNodeDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'message', enum: ['message', 'menu', 'input', 'condition', 'api_call', 'transfer_agent', 'end'] }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateBotNodeDto.prototype, "type", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: {
            message: '¡Hola {{clientName}}! Tienes una deuda de ${{debtAmount}}',
            nextNodeId: 'node-menu',
        },
    }),
    (0, class_validator_1.IsObject)(),
    __metadata("design:type", Object)
], CreateBotNodeDto.prototype, "config", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'node-menu' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateBotNodeDto.prototype, "nextNodeId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 100 }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateBotNodeDto.prototype, "positionX", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 200 }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateBotNodeDto.prototype, "positionY", void 0);
class UpdateBotNodeDto {
}
exports.UpdateBotNodeDto = UpdateBotNodeDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'Mensaje Actualizado' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateBotNodeDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateBotNodeDto.prototype, "type", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsObject)(),
    __metadata("design:type", Object)
], UpdateBotNodeDto.prototype, "config", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateBotNodeDto.prototype, "nextNodeId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], UpdateBotNodeDto.prototype, "positionX", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], UpdateBotNodeDto.prototype, "positionY", void 0);
class BulkCreateNodesDto {
}
exports.BulkCreateNodesDto = BulkCreateNodesDto;
__decorate([
    (0, swagger_1.ApiProperty)({ type: [CreateBotNodeDto] }),
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], BulkCreateNodesDto.prototype, "nodes", void 0);
//# sourceMappingURL=bot-flow.dto.js.map