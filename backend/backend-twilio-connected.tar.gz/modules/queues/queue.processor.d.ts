import { Job } from 'bull';
import { QueueService, ChatAssignmentJob } from './queue.service';
export declare class QueueProcessor {
    private queueService;
    private readonly logger;
    constructor(queueService: QueueService);
    handleAssignChat(job: Job<ChatAssignmentJob>): Promise<void>;
}
