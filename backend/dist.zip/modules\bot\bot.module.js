"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const bot_engine_service_1 = require("./bot-engine.service");
const bot_listener_service_1 = require("./bot-listener.service");
const bot_flows_service_1 = require("./bot-flows.service");
const bot_executor_service_1 = require("./bot-executor.service");
const bot_controller_1 = require("./bot.controller");
const bot_flows_controller_1 = require("./bot-flows.controller");
const bot_flow_entity_1 = require("./entities/bot-flow.entity");
const bot_node_entity_1 = require("./entities/bot-node.entity");
const campaign_entity_1 = require("../campaigns/entities/campaign.entity");
const chat_entity_1 = require("../chats/entities/chat.entity");
const messages_module_1 = require("../messages/messages.module");
const chats_module_1 = require("../chats/chats.module");
const debtors_module_1 = require("../debtors/debtors.module");
const whatsapp_module_1 = require("../whatsapp/whatsapp.module");
let BotModule = class BotModule {
};
exports.BotModule = BotModule;
exports.BotModule = BotModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([bot_flow_entity_1.BotFlow, bot_node_entity_1.BotNode, campaign_entity_1.Campaign, chat_entity_1.Chat]),
            messages_module_1.MessagesModule,
            chats_module_1.ChatsModule,
            debtors_module_1.DebtorsModule,
            whatsapp_module_1.WhatsappModule,
        ],
        controllers: [bot_controller_1.BotController, bot_flows_controller_1.BotFlowsController],
        providers: [bot_engine_service_1.BotEngineService, bot_listener_service_1.BotListenerService, bot_flows_service_1.BotFlowsService, bot_executor_service_1.BotExecutorService],
        exports: [bot_engine_service_1.BotEngineService, bot_listener_service_1.BotListenerService, bot_flows_service_1.BotFlowsService, bot_executor_service_1.BotExecutorService],
    })
], BotModule);
//# sourceMappingURL=bot.module.js.map