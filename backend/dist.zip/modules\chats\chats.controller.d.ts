import { ChatsService } from './chats.service';
import { ChatsExportService } from './chats-export.service';
import { CreateChatDto } from './dto/create-chat.dto';
import { UpdateChatDto } from './dto/update-chat.dto';
import { AssignChatDto, TransferChatDto } from './dto/assign-chat.dto';
import { ChatStatus } from './entities/chat.entity';
export declare class ChatsController {
    private readonly chatsService;
    private readonly chatsExportService;
    constructor(chatsService: ChatsService, chatsExportService: ChatsExportService);
    create(createChatDto: CreateChatDto): Promise<import("./entities/chat.entity").Chat>;
    findAll(status?: ChatStatus, campaignId?: string, assignedAgentId?: string, whatsappNumberId?: string): Promise<import("./entities/chat.entity").Chat[]>;
    getMyChats(userId: string, userRole: {
        name: string;
    }): Promise<import("./entities/chat.entity").Chat[]>;
    getWaitingChats(campaignId: string): Promise<import("./entities/chat.entity").Chat[]>;
    findOne(id: string): Promise<import("./entities/chat.entity").Chat>;
    update(id: string, updateChatDto: UpdateChatDto): Promise<import("./entities/chat.entity").Chat>;
    assign(id: string, assignDto: AssignChatDto): Promise<import("./entities/chat.entity").Chat>;
    reassign(id: string, assignDto: AssignChatDto): Promise<import("./entities/chat.entity").Chat>;
    updateStatus(id: string, body: {
        status: ChatStatus;
    }, userId: string): Promise<import("./entities/chat.entity").Chat>;
    transfer(id: string, currentUserId: string, transferDto: TransferChatDto): Promise<import("./entities/chat.entity").Chat>;
    close(id: string, userId: string): Promise<import("./entities/chat.entity").Chat>;
    resolve(id: string, userId: string): Promise<import("./entities/chat.entity").Chat>;
    getAgentStats(agentId: string): Promise<{
        active: number;
        resolved: number;
        total: number;
    }>;
    exportChatToPDF(id: string, body: {
        closureType: 'paid' | 'promise';
    }, agentId: string): Promise<{
        success: boolean;
        message: string;
        data: {
            fileName: string;
            ticketNumber: string;
        };
    }>;
}
