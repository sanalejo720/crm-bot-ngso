"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorkdayController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const workday_service_1 = require("./workday.service");
const workday_dto_1 = require("./dto/workday.dto");
let WorkdayController = class WorkdayController {
    constructor(workdayService) {
        this.workdayService = workdayService;
    }
    async clockIn(req, dto) {
        return await this.workdayService.clockIn(req.user.id, dto.notes);
    }
    async clockOut(req, dto) {
        return await this.workdayService.clockOut(req.user.id, dto.notes);
    }
    async startPause(req, dto) {
        return await this.workdayService.startPause(req.user.id, dto.pauseType, dto.reason);
    }
    async endPause(req, dto) {
        return await this.workdayService.endPause(req.user.id, dto.pauseId);
    }
    async getCurrentWorkday(req) {
        return await this.workdayService.getCurrentWorkday(req.user.id);
    }
    async getHistory(req, startDate, endDate) {
        const start = startDate ? new Date(startDate) : undefined;
        const end = endDate ? new Date(endDate) : undefined;
        return await this.workdayService.getWorkdayHistory(req.user.id, start, end);
    }
    async getStats(req, query) {
        const startDate = query.startDate ? new Date(query.startDate) : undefined;
        const endDate = query.endDate ? new Date(query.endDate) : undefined;
        const agentId = query.agentId || req.user.id;
        return await this.workdayService.getWorkdayStats(agentId, startDate, endDate);
    }
    async getAgentWorkday(agentId) {
        return await this.workdayService.getCurrentWorkday(agentId);
    }
};
exports.WorkdayController = WorkdayController;
__decorate([
    (0, common_1.Post)('clock-in'),
    (0, swagger_1.ApiOperation)({ summary: 'Registrar entrada del agente' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Entrada registrada' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Ya registró entrada hoy' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, workday_dto_1.ClockInDto]),
    __metadata("design:returntype", Promise)
], WorkdayController.prototype, "clockIn", null);
__decorate([
    (0, common_1.Post)('clock-out'),
    (0, swagger_1.ApiOperation)({ summary: 'Registrar salida del agente' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Salida registrada' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'No ha registrado entrada' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, workday_dto_1.ClockOutDto]),
    __metadata("design:returntype", Promise)
], WorkdayController.prototype, "clockOut", null);
__decorate([
    (0, common_1.Post)('pause/start'),
    (0, swagger_1.ApiOperation)({ summary: 'Iniciar pausa (almuerzo, break, etc.)' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Pausa iniciada' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Ya tiene una pausa activa' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, workday_dto_1.StartPauseDto]),
    __metadata("design:returntype", Promise)
], WorkdayController.prototype, "startPause", null);
__decorate([
    (0, common_1.Post)('pause/end'),
    (0, swagger_1.ApiOperation)({ summary: 'Finalizar pausa activa' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Pausa finalizada' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Pausa no encontrada' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, workday_dto_1.EndPauseDto]),
    __metadata("design:returntype", Promise)
], WorkdayController.prototype, "endPause", null);
__decorate([
    (0, common_1.Get)('current'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener jornada actual del agente' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Jornada actual obtenida' }),
    __param(0, (0, common_1.Request)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], WorkdayController.prototype, "getCurrentWorkday", null);
__decorate([
    (0, common_1.Get)('history'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener historial de jornadas' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Historial obtenido' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], WorkdayController.prototype, "getHistory", null);
__decorate([
    (0, common_1.Get)('stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener estadísticas de jornadas' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Estadísticas obtenidas' }),
    __param(0, (0, common_1.Request)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, workday_dto_1.GetWorkdayStatsDto]),
    __metadata("design:returntype", Promise)
], WorkdayController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)('agent/:agentId'),
    (0, swagger_1.ApiOperation)({ summary: 'Obtener jornada actual de un agente específico (Admin)' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Jornada obtenida' }),
    __param(0, (0, common_1.Param)('agentId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], WorkdayController.prototype, "getAgentWorkday", null);
exports.WorkdayController = WorkdayController = __decorate([
    (0, swagger_1.ApiTags)('workday'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Controller)('workday'),
    __metadata("design:paramtypes", [workday_service_1.WorkdayService])
], WorkdayController);
//# sourceMappingURL=workday.controller.js.map