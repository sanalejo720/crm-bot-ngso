import { Campaign } from '../../campaigns/entities/campaign.entity';
import { WhatsappNumber } from '../../whatsapp/entities/whatsapp-number.entity';
import { User } from '../../users/entities/user.entity';
import { Client } from '../../clients/entities/client.entity';
import { Message } from '../../messages/entities/message.entity';
export declare enum ChatStatus {
    WAITING = "waiting",
    BOT = "bot",
    ACTIVE = "active",
    PENDING = "pending",
    RESOLVED = "resolved",
    CLOSED = "closed"
}
export declare enum ChatChannel {
    WHATSAPP = "whatsapp"
}
export declare class Chat {
    id: string;
    externalId: string;
    contactPhone: string;
    contactName: string;
    channel: ChatChannel;
    status: ChatStatus;
    lastMessageText: string;
    lastMessage: string;
    lastMessageAt: Date;
    unreadCount: number;
    tags: string[];
    priority: number;
    assignedAt: Date;
    firstResponseAt: Date;
    resolvedAt: Date;
    closedAt: Date;
    metadata: Record<string, any>;
    botContext: {
        sessionId?: string;
        flowId?: string;
        currentNodeId?: string;
        variables?: Record<string, any>;
        transferredToAgent?: boolean;
    };
    campaign: Campaign;
    campaignId: string;
    whatsappNumber: WhatsappNumber;
    whatsappNumberId: string;
    assignedAgent: User;
    assignedAgentId: string;
    client: Client;
    clientId: string;
    debtorId: string;
    messages: Message[];
    subStatus?: string;
    isBotActive: boolean;
    lastAgentMessageAt?: Date;
    lastClientMessageAt?: Date;
    firstResponseTimeSeconds?: number;
    agentWarningSent: boolean;
    clientWarningSent: boolean;
    autoCloseScheduledAt?: Date;
    transferCount: number;
    botRestartCount: number;
    createdAt: Date;
    updatedAt: Date;
}
