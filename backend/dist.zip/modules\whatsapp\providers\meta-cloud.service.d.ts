import { ConfigService } from '@nestjs/config';
import { EventEmitter2 } from '@nestjs/event-emitter';
export declare class MetaCloudService {
    private readonly configService;
    private readonly eventEmitter;
    private readonly logger;
    private readonly apiUrl;
    private readonly accessToken;
    private readonly phoneNumberId;
    private readonly version;
    constructor(configService: ConfigService, eventEmitter: EventEmitter2);
    sendTextMessage(to: string, text: string): Promise<any>;
    sendImageMessage(to: string, imageUrl: string, caption?: string): Promise<any>;
    sendDocumentMessage(to: string, documentUrl: string, filename?: string): Promise<any>;
    sendTextMessageWithCredentials(phoneNumberId: string, accessToken: string, to: string, text: string): Promise<any>;
    sendImageMessageWithCredentials(phoneNumberId: string, accessToken: string, to: string, imageUrl: string, caption?: string): Promise<any>;
    processWebhook(payload: any): Promise<void>;
    private processIncomingMessage;
    private processMessageStatus;
    markAsRead(messageId: string): Promise<void>;
    healthCheck(): Promise<boolean>;
}
