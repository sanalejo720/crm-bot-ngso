import { Response } from 'express';
import { PazYSalvoService } from './paz-y-salvo.service';
export declare class PazYSalvoController {
    private readonly pazYSalvoService;
    private readonly logger;
    constructor(pazYSalvoService: PazYSalvoService);
    checkAvailability(clientId: string): Promise<{
        success: boolean;
        data: {
            isAvailable: boolean;
            pazYSalvo?: import("./entities/paz-y-salvo.entity").PazYSalvo;
            message: string;
            daysRemaining?: number;
        };
    }>;
    getByClientId(clientId: string): Promise<{
        success: boolean;
        data: import("./entities/paz-y-salvo.entity").PazYSalvo;
    }>;
    downloadPazYSalvo(clientId: string, req: any, res: Response): Promise<Response<any, Record<string, any>>>;
    createPazYSalvo(clientId: string, req: any): Promise<{
        success: boolean;
        message: string;
        data: import("./entities/paz-y-salvo.entity").PazYSalvo;
    }>;
}
