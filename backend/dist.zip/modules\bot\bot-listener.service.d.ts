import { Repository } from 'typeorm';
import { BotEngineService } from './bot-engine.service';
import { ChatsService } from '../chats/chats.service';
import { DebtorsService } from '../debtors/debtors.service';
import { Chat } from '../chats/entities/chat.entity';
import { Message } from '../messages/entities/message.entity';
import { MessagesService } from '../messages/messages.service';
import { WhatsappService } from '../whatsapp/whatsapp.service';
import { Campaign } from '../campaigns/entities/campaign.entity';
interface MessageCreatedEvent {
    message: Message;
    chat: Chat;
}
interface ChatAssignedEvent {
    chat: Chat;
    agentId: string;
    agentName: string;
}
export declare class BotListenerService {
    private botEngineService;
    private chatsService;
    private debtorsService;
    private messagesService;
    private whatsappService;
    private campaignRepository;
    private readonly logger;
    constructor(botEngineService: BotEngineService, chatsService: ChatsService, debtorsService: DebtorsService, messagesService: MessagesService, whatsappService: WhatsappService, campaignRepository: Repository<Campaign>);
    private isBusinessHours;
    handleMessageCreated(event: MessageCreatedEvent): Promise<void>;
    searchDebtorByDocument(documentType: string, documentNumber: string): Promise<any>;
    private sendOutOfHoursMessage;
    handleChatAssigned(event: ChatAssignedEvent): Promise<void>;
}
export {};
