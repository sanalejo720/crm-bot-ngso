"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FinancialStatsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const campaign_entity_1 = require("../campaigns/entities/campaign.entity");
const client_entity_1 = require("../clients/entities/client.entity");
const chat_entity_1 = require("../chats/entities/chat.entity");
const user_entity_1 = require("../users/entities/user.entity");
let FinancialStatsService = class FinancialStatsService {
    constructor(campaignRepo, clientRepo, chatRepo, userRepo) {
        this.campaignRepo = campaignRepo;
        this.clientRepo = clientRepo;
        this.chatRepo = chatRepo;
        this.userRepo = userRepo;
    }
    async getCampaignFinancials(campaignId, startDate, endDate) {
        const campaign = await this.campaignRepo.findOne({
            where: { id: campaignId },
        });
        if (!campaign) {
            throw new Error('Campaña no encontrada');
        }
        const totalToRecoverResult = await this.clientRepo
            .createQueryBuilder('client')
            .select('SUM(client.debtAmount)', 'total')
            .innerJoin('client.chats', 'chat')
            .where('chat.campaignId = :campaignId', { campaignId })
            .andWhere('chat.createdAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .getRawOne();
        const totalToRecover = parseFloat(totalToRecoverResult?.total || '0');
        const totalRecoveredResult = await this.clientRepo
            .createQueryBuilder('client')
            .select('SUM(COALESCE(client.lastPaymentAmount, client.debtAmount))', 'total')
            .addSelect('COUNT(DISTINCT client.id)', 'count')
            .innerJoin('client.chats', 'chat')
            .where('chat.campaignId = :campaignId', { campaignId })
            .andWhere("client.collectionStatus = 'paid'")
            .andWhere('chat.createdAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .getRawOne();
        const totalRecovered = parseFloat(totalRecoveredResult?.total || '0');
        const clientsPaid = parseInt(totalRecoveredResult?.count || '0', 10);
        const totalInPromisesResult = await this.clientRepo
            .createQueryBuilder('client')
            .select('SUM(COALESCE(client.promisePaymentAmount, client.debtAmount))', 'total')
            .addSelect('COUNT(DISTINCT client.id)', 'count')
            .innerJoin('client.chats', 'chat')
            .where('chat.campaignId = :campaignId', { campaignId })
            .andWhere("client.collectionStatus = 'promise'")
            .andWhere('chat.createdAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .getRawOne();
        const totalInPromises = parseFloat(totalInPromisesResult?.total || '0');
        const promisesCount = parseInt(totalInPromisesResult?.count || '0', 10);
        const clientsWithDebtResult = await this.clientRepo
            .createQueryBuilder('client')
            .select('COUNT(DISTINCT client.id)', 'count')
            .innerJoin('client.chats', 'chat')
            .where('chat.campaignId = :campaignId', { campaignId })
            .andWhere('client.debtAmount > 0')
            .getRawOne();
        const clientsWithDebt = parseInt(clientsWithDebtResult?.count || '0', 10);
        const paymentsCountResult = await this.clientRepo
            .createQueryBuilder('client')
            .select('COUNT(DISTINCT client.id)', 'count')
            .innerJoin('client.chats', 'chat')
            .where('chat.campaignId = :campaignId', { campaignId })
            .andWhere('client.lastPaymentDate BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .getRawOne();
        const paymentsCount = parseInt(paymentsCountResult?.count || '0', 10);
        const recoveryPercentage = totalToRecover > 0 ? (totalRecovered / totalToRecover) * 100 : 0;
        return {
            campaignId,
            campaignName: campaign.name,
            totalToRecover,
            totalRecovered,
            totalInPromises,
            recoveryPercentage,
            paymentsCount,
            promisesCount,
            clientsWithDebt,
            clientsPaid,
        };
    }
    async getAgentRecaudo(agentId, startDate, endDate) {
        const agent = await this.userRepo.findOne({
            where: { id: agentId },
            relations: ['role'],
        });
        if (!agent) {
            throw new Error('Agente no encontrado');
        }
        const totalRecoveredResult = await this.clientRepo
            .createQueryBuilder('client')
            .select('SUM(client.lastPaymentAmount)', 'total')
            .addSelect('COUNT(DISTINCT client.id)', 'count')
            .innerJoin('client.chats', 'chat')
            .where('chat.assignedAgentId = :agentId', { agentId })
            .andWhere('client.lastPaymentDate BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .getRawOne();
        const totalRecovered = parseFloat(totalRecoveredResult?.total || '0');
        const paymentsCount = parseInt(totalRecoveredResult?.count || '0', 10);
        const promisesResult = await this.clientRepo
            .createQueryBuilder('client')
            .select('SUM(client.promisePaymentAmount)', 'total')
            .addSelect('COUNT(DISTINCT client.id)', 'count')
            .innerJoin('client.chats', 'chat')
            .where('chat.assignedAgentId = :agentId', { agentId })
            .andWhere('client.promisePaymentDate IS NOT NULL')
            .andWhere('client.promisePaymentDate BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .getRawOne();
        const totalInPromises = parseFloat(promisesResult?.total || '0');
        const promisesCount = parseInt(promisesResult?.count || '0', 10);
        const clientsAttendedResult = await this.chatRepo
            .createQueryBuilder('chat')
            .select('COUNT(DISTINCT chat.clientId)', 'count')
            .where('chat.assignedAgentId = :agentId', { agentId })
            .andWhere('chat.createdAt BETWEEN :startDate AND :endDate', {
            startDate,
            endDate,
        })
            .getRawOne();
        const clientsAttended = parseInt(clientsAttendedResult?.count || '0', 10);
        const effectivenessRate = promisesCount > 0 ? (paymentsCount / promisesCount) * 100 : 0;
        const averageTicket = paymentsCount > 0 ? totalRecovered / paymentsCount : 0;
        return {
            agentId,
            agentName: agent.fullName || 'Sin nombre',
            totalRecovered,
            paymentsCount,
            promisesCount,
            totalInPromises,
            effectivenessRate,
            averageTicket,
            clientsAttended,
        };
    }
    async getFinancialSummary(period, startDate, endDate) {
        const { start, end } = this.calculateDateRange(period, startDate, endDate);
        const campaigns = await this.campaignRepo.find();
        const campaignsStats = await Promise.all(campaigns.map((campaign) => this.getCampaignFinancials(campaign.id, start, end)));
        const totalToRecover = campaignsStats.reduce((sum, c) => sum + c.totalToRecover, 0);
        const totalRecovered = campaignsStats.reduce((sum, c) => sum + c.totalRecovered, 0);
        const totalInPromises = campaignsStats.reduce((sum, c) => sum + c.totalInPromises, 0);
        const globalRecoveryRate = totalToRecover > 0 ? (totalRecovered / totalToRecover) * 100 : 0;
        const agents = await this.userRepo.find({
            where: { isAgent: true },
            relations: ['role'],
        });
        let topAgents = await Promise.all(agents.map((agent) => this.getAgentRecaudo(agent.id, start, end)));
        topAgents = topAgents.sort((a, b) => b.totalRecovered - a.totalRecovered);
        topAgents = topAgents.map((agent, index) => ({
            ...agent,
            ranking: index + 1,
        }));
        topAgents = topAgents.slice(0, 10);
        return {
            period: this.formatPeriod(period, start, end),
            totalToRecover,
            totalRecovered,
            totalInPromises,
            globalRecoveryRate,
            campaignsStats,
            topAgents,
        };
    }
    async getDailyFinancials(date) {
        const startOfDay = new Date(date);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(date);
        endOfDay.setHours(23, 59, 59, 999);
        const recoveredResult = await this.clientRepo
            .createQueryBuilder('client')
            .select('SUM(client.amountRecovered)', 'total')
            .select('COUNT(DISTINCT client.id)', 'count')
            .where('client.lastPaymentDate BETWEEN :start AND :end', {
            start: startOfDay,
            end: endOfDay,
        })
            .getRawOne();
        const promisesResult = await this.clientRepo
            .createQueryBuilder('client')
            .select('COUNT(DISTINCT client.id)', 'count')
            .where('client.promiseDate BETWEEN :start AND :end', {
            start: startOfDay,
            end: endOfDay,
        })
            .getRawOne();
        return {
            date: date.toISOString().split('T')[0],
            totalRecovered: parseFloat(recoveredResult?.total || '0'),
            paymentsCount: parseInt(recoveredResult?.count || '0', 10),
            promisesCount: parseInt(promisesResult?.count || '0', 10),
        };
    }
    async getFinancialTrend(startDate, endDate) {
        const dates = [];
        const recovered = [];
        const promises = [];
        const currentDate = new Date(startDate);
        while (currentDate <= endDate) {
            const dayData = await this.getDailyFinancials(new Date(currentDate));
            dates.push(dayData.date);
            recovered.push(dayData.totalRecovered);
            promises.push(dayData.promisesCount);
            currentDate.setDate(currentDate.getDate() + 1);
        }
        return { dates, recovered, promises };
    }
    calculateDateRange(period, startDate, endDate) {
        const now = new Date();
        switch (period) {
            case 'daily':
                const startOfDay = new Date(now);
                startOfDay.setHours(0, 0, 0, 0);
                const endOfDay = new Date(now);
                endOfDay.setHours(23, 59, 59, 999);
                return { start: startOfDay, end: endOfDay };
            case 'weekly':
                const startOfWeek = new Date(now);
                startOfWeek.setDate(now.getDate() - 7);
                startOfWeek.setHours(0, 0, 0, 0);
                return { start: startOfWeek, end: now };
            case 'monthly':
                const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
                return { start: startOfMonth, end: now };
            case 'custom':
                if (!startDate || !endDate) {
                    throw new Error('Se requieren startDate y endDate para período custom');
                }
                return { start: startDate, end: endDate };
            default:
                return { start: now, end: now };
        }
    }
    formatPeriod(period, start, end) {
        const options = {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
        };
        switch (period) {
            case 'daily':
                return `Hoy - ${start.toLocaleDateString('es-CO', options)}`;
            case 'weekly':
                return `Última semana (${start.toLocaleDateString('es-CO', options)} - ${end.toLocaleDateString('es-CO', options)})`;
            case 'monthly':
                return `Mes actual - ${start.toLocaleDateString('es-CO', { year: 'numeric', month: 'long' })}`;
            case 'custom':
                return `${start.toLocaleDateString('es-CO', options)} - ${end.toLocaleDateString('es-CO', options)}`;
            default:
                return 'Período desconocido';
        }
    }
};
exports.FinancialStatsService = FinancialStatsService;
exports.FinancialStatsService = FinancialStatsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(campaign_entity_1.Campaign)),
    __param(1, (0, typeorm_1.InjectRepository)(client_entity_1.Client)),
    __param(2, (0, typeorm_1.InjectRepository)(chat_entity_1.Chat)),
    __param(3, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], FinancialStatsService);
//# sourceMappingURL=financial-stats.service.js.map