import { Response } from 'express';
import { MessagesService } from './messages.service';
import { CreateMessageDto } from './dto/create-message.dto';
import { SendMessageDto, SendMediaMessageDto } from './dto/send-message.dto';
export declare class MessagesController {
    private readonly messagesService;
    constructor(messagesService: MessagesService);
    create(createMessageDto: CreateMessageDto): Promise<import("./entities/message.entity").Message>;
    sendMessage(sendMessageDto: SendMessageDto, senderId: string): Promise<import("./entities/message.entity").Message>;
    sendMediaMessage(sendMediaDto: SendMediaMessageDto, senderId: string): Promise<import("./entities/message.entity").Message>;
    findMessages(chatId: string, limit?: number, offset?: number): Promise<import("./entities/message.entity").Message[]> | {
        success: boolean;
        message: string;
    };
    findByChatId(chatId: string, limit?: number, offset?: number): Promise<import("./entities/message.entity").Message[]>;
    findOne(id: string): Promise<import("./entities/message.entity").Message>;
    markMessageAsRead(id: string): Promise<void>;
    markAsRead(chatId: string): Promise<void>;
    getStats(chatId: string): Promise<{
        total: number;
        sent: number;
        delivered: number;
        read: number;
        failed: number;
    }>;
    downloadMedia(id: string, res: Response): Promise<void>;
}
