import { OnGatewayConnection, OnGatewayDisconnect } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
import { Chat } from '../chats/entities/chat.entity';
import { Message } from '../messages/entities/message.entity';
import { User, AgentState } from '../users/entities/user.entity';
interface AuthenticatedSocket extends Socket {
    userId?: string;
    user?: User;
}
export declare class EventsGateway implements OnGatewayConnection, OnGatewayDisconnect {
    private jwtService;
    server: Server;
    private readonly logger;
    private connectedUsers;
    constructor(jwtService: JwtService);
    handleConnection(client: AuthenticatedSocket): Promise<void>;
    handleDisconnect(client: AuthenticatedSocket): void;
    handleSubscribeChat(client: AuthenticatedSocket, data: {
        chatId: string;
    }): {
        success: boolean;
    };
    handleUnsubscribeChat(client: AuthenticatedSocket, data: {
        chatId: string;
    }): {
        success: boolean;
    };
    handleAgentJoin(client: AuthenticatedSocket, data: {
        agentId: string;
    }): {
        success: boolean;
        room: string;
    };
    handleTyping(client: AuthenticatedSocket, data: {
        chatId: string;
        isTyping: boolean;
    }): void;
    handleAgentStateChange(client: AuthenticatedSocket, data: {
        state: AgentState;
    }): {
        success: boolean;
    };
    handleChatCreated(chat: Chat): void;
    handleChatAssigned(data: {
        chat: Chat;
        agentId: string;
        agentName: string;
    }): void;
    handleChatTransferred(data: {
        chat: Chat;
        fromAgentId: string;
        toAgentId: string;
        fromAgentName: string;
        toAgentName: string;
    }): void;
    handleChatUnassigned(data: {
        chat: Chat;
        previousAgentId: string;
        reason: string;
    }): void;
    handleChatClosed(chat: Chat): void;
    handleMessageCreated(event: {
        message: Message;
        chat: any;
    }): void;
    handleMessageStatusUpdated(data: {
        messageId: string;
        chatId: string;
        status: string;
    }): void;
    handleAgentStateChanged(data: {
        userId: string;
        userName: string;
        state: AgentState;
    }): void;
    handleWhatsAppQRGenerated(data: {
        numberId: string;
        qrCode: string;
        sessionName?: string;
    }): void;
    handleWhatsAppSessionStatus(data: {
        sessionName: string;
        status: string;
    }): void;
    handleWhatsAppSessionDisconnected(data: {
        numberId: string;
    }): void;
    handleWhatsAppMessageReceived(data: any): void;
    emitToUser(userId: string, event: string, data: any): void;
    emitToChat(chatId: string, event: string, data: any): void;
    emitToAgents(event: string, data: any): void;
    emitToSupervisors(event: string, data: any): void;
    isUserConnected(userId: string): boolean;
    getConnectedUsers(): string[];
}
export {};
