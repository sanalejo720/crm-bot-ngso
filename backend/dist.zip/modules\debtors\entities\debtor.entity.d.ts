import { Campaign } from '../../campaigns/entities/campaign.entity';
export declare enum DocumentType {
    CC = "CC",
    CE = "CE",
    NIT = "NIT",
    TI = "TI",
    PASSPORT = "PASSPORT"
}
export declare class Debtor {
    id: string;
    fullName: string;
    documentType: DocumentType;
    documentNumber: string;
    phone: string;
    email: string;
    address: string;
    debtAmount: number;
    initialDebtAmount: number;
    daysOverdue: number;
    lastPaymentDate: Date;
    promiseDate: Date;
    status: string;
    notes: string;
    metadata: {
        producto?: string;
        numeroCredito?: string;
        fechaVencimiento?: string;
        [key: string]: any;
    };
    campaign: Campaign;
    campaignId: string;
    createdAt: Date;
    updatedAt: Date;
    lastContactedAt: Date;
}
