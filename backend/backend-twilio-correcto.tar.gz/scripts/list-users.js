"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const typeorm_1 = require("typeorm");
const ds = new typeorm_1.DataSource({
    type: 'postgres',
    host: 'localhost',
    port: 5432,
    username: 'postgres',
    password: 'postgres123',
    database: 'crm_whatsapp'
});
ds.initialize()
    .then(async () => {
    const users = await ds.query(`
      SELECT u.id, u."fullName", u.email, r.name as role 
      FROM users u 
      JOIN roles r ON u."roleId" = r.id 
      ORDER BY r.name
    `);
    console.log('\n=== USUARIOS EN LA BASE DE DATOS ===\n');
    users.forEach((u) => {
        console.log(`${u.role.padEnd(15)} | ${u.email.padEnd(30)} | ${u.fullName}`);
    });
    await ds.destroy();
})
    .catch(err => console.error('Error:', err.message));
//# sourceMappingURL=list-users.js.map