import { MessageType, MessageDirection, MessageSenderType } from '../entities/message.entity';
export declare class CreateMessageDto {
    chatId: string;
    type: MessageType;
    direction: MessageDirection;
    senderType: MessageSenderType;
    content?: string;
    mediaUrl?: string;
    mediaFileName?: string;
    mediaMimeType?: string;
    mediaSize?: number;
    externalId?: string;
    senderId?: string;
    isInternal?: boolean;
    metadata?: Record<string, any>;
}
