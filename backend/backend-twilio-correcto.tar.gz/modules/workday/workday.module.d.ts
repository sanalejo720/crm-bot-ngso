export declare class WorkdayModule {
}
