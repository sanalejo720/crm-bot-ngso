import { CampaignStatus } from '../entities/campaign.entity';
export declare class CreateCampaignDto {
    name: string;
    description?: string;
    startDate?: string;
    endDate?: string;
    status?: CampaignStatus;
    settings?: Record<string, any>;
}
