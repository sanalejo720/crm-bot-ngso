"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var BotEngineService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BotEngineService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const bot_flow_entity_1 = require("./entities/bot-flow.entity");
const bot_node_entity_1 = require("./entities/bot-node.entity");
const messages_service_1 = require("../messages/messages.service");
const chats_service_1 = require("../chats/chats.service");
const whatsapp_service_1 = require("../whatsapp/whatsapp.service");
const debtors_service_1 = require("../debtors/debtors.service");
const chat_entity_1 = require("../chats/entities/chat.entity");
const message_entity_1 = require("../messages/entities/message.entity");
let BotEngineService = BotEngineService_1 = class BotEngineService {
    constructor(botFlowRepository, botNodeRepository, messagesService, chatsService, whatsappService, debtorsService) {
        this.botFlowRepository = botFlowRepository;
        this.botNodeRepository = botNodeRepository;
        this.messagesService = messagesService;
        this.chatsService = chatsService;
        this.whatsappService = whatsappService;
        this.debtorsService = debtorsService;
        this.logger = new common_1.Logger(BotEngineService_1.name);
        this.sessions = new Map();
    }
    async startFlow(chatId, flowId) {
        this.logger.log(`Iniciando flujo ${flowId} para chat ${chatId}`);
        const flow = await this.botFlowRepository.findOne({
            where: { id: flowId, status: bot_flow_entity_1.BotFlowStatus.ACTIVE },
            relations: ['nodes'],
        });
        if (!flow) {
            throw new common_1.NotFoundException(`Flujo de bot ${flowId} no encontrado o inactivo`);
        }
        if (!flow.startNodeId) {
            throw new Error('El flujo no tiene nodo inicial configurado');
        }
        const chat = await this.chatsService.findOne(chatId);
        const variables = this.initializeVariables(flow);
        variables['clientName'] = chat.contactName || 'Cliente';
        variables['clientPhone'] = chat.contactPhone;
        variables['debtorFound'] = false;
        const session = {
            chatId,
            flowId,
            currentNodeId: flow.startNodeId,
            variables,
            createdAt: new Date(),
            lastActivityAt: new Date(),
        };
        this.sessions.set(chatId, session);
        await this.chatsService.update(chatId, {
            status: chat_entity_1.ChatStatus.BOT,
            botContext: {
                sessionId: chatId,
                flowId,
                currentNodeId: flow.startNodeId,
                variables: session.variables,
                transferredToAgent: false,
            },
        });
        await this.executeNode(chatId, flow.startNodeId);
    }
    async processUserInput(chatId, userInput) {
        const session = this.sessions.get(chatId);
        if (!session) {
            this.logger.warn(`No hay sesión activa para chat ${chatId}`);
            return;
        }
        session.lastActivityAt = new Date();
        const currentNode = await this.botNodeRepository.findOne({
            where: { id: session.currentNodeId },
        });
        if (!currentNode) {
            throw new common_1.NotFoundException(`Nodo ${session.currentNodeId} no encontrado`);
        }
        let nextNodeId = null;
        switch (currentNode.type) {
            case bot_node_entity_1.BotNodeType.MENU:
                nextNodeId = this.handleMenuInput(currentNode, userInput);
                break;
            case bot_node_entity_1.BotNodeType.INPUT:
                nextNodeId = await this.handleTextInput(currentNode, userInput, session);
                break;
            case bot_node_entity_1.BotNodeType.CONDITION:
                session.variables['user_response'] = userInput;
                nextNodeId = this.handleCondition(currentNode, session);
                break;
            default:
                nextNodeId = currentNode.nextNodeId;
        }
        if (!nextNodeId) {
            this.logger.warn(`No se encontró siguiente nodo para ${currentNode.id}`);
            return;
        }
        session.currentNodeId = nextNodeId;
        session.lastActivityAt = new Date();
        this.sessions.set(chatId, session);
        await this.chatsService.update(chatId, {
            botContext: {
                ...session,
                sessionId: chatId,
            },
        });
        this.logger.log(`➡️ Procesando respuesta, avanzando a nodo: ${nextNodeId}`);
        await this.executeNode(chatId, nextNodeId);
    }
    async executeNode(chatId, nodeId) {
        const node = await this.botNodeRepository.findOne({ where: { id: nodeId } });
        if (!node) {
            throw new common_1.NotFoundException(`Nodo ${nodeId} no encontrado`);
        }
        this.logger.log(`Ejecutando nodo ${node.name} (${node.type}) para chat ${chatId}`);
        switch (node.type) {
            case bot_node_entity_1.BotNodeType.MESSAGE:
                await this.executeMessageNode(chatId, node);
                break;
            case bot_node_entity_1.BotNodeType.MENU:
                await this.executeMenuNode(chatId, node);
                break;
            case bot_node_entity_1.BotNodeType.INPUT:
                await this.executeInputNode(chatId, node);
                break;
            case bot_node_entity_1.BotNodeType.CONDITION:
                this.logger.log(`⏸️ Nodo CONDITION alcanzado. Esperando respuesta del usuario...`);
                break;
            case bot_node_entity_1.BotNodeType.API_CALL:
                await this.executeApiCallNode(chatId, node);
                break;
            case bot_node_entity_1.BotNodeType.TRANSFER_AGENT:
                await this.executeTransferNode(chatId, node);
                break;
            case bot_node_entity_1.BotNodeType.END:
                await this.executeEndNode(chatId);
                break;
            default:
                this.logger.warn(`Tipo de nodo no soportado: ${node.type}`);
        }
    }
    async executeMessageNode(chatId, node) {
        const message = node.config.message;
        if (!message) {
            this.logger.warn('Nodo de mensaje sin contenido');
            return;
        }
        const chat = await this.chatsService.findOne(chatId);
        const processedMessage = this.replaceVariables(message, this.sessions.get(chatId)?.variables);
        try {
            const result = await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, processedMessage, message_entity_1.MessageType.TEXT);
            const savedMessage = await this.messagesService.create({
                chatId,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
                content: processedMessage,
                externalId: result.messageId,
            });
            await this.messagesService.updateStatus(savedMessage.id, message_entity_1.MessageStatus.SENT);
            this.logger.log(`Bot envió mensaje a ${chat.contactPhone}: "${processedMessage.substring(0, 50)}..."`);
        }
        catch (error) {
            this.logger.error(`Error enviando mensaje del bot: ${error.message}`);
            const savedMessage = await this.messagesService.create({
                chatId,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
                content: processedMessage,
            });
            await this.messagesService.updateStatus(savedMessage.id, message_entity_1.MessageStatus.FAILED, error.message);
        }
        if (node.nextNodeId) {
            const session = this.sessions.get(chatId);
            if (session) {
                session.currentNodeId = node.nextNodeId;
                session.lastActivityAt = new Date();
                this.sessions.set(chatId, session);
                await this.chatsService.update(chatId, {
                    botContext: {
                        ...session,
                        sessionId: chatId,
                    },
                });
                this.logger.log(`⏭️ Avanzando automáticamente al nodo: ${node.nextNodeId}`);
                await this.executeNode(chatId, node.nextNodeId);
            }
        }
    }
    async executeMenuNode(chatId, node) {
        const options = node.config.options || [];
        if (options.length === 0) {
            this.logger.warn('Nodo de menú sin opciones');
            return;
        }
        const menuText = options
            .map((opt, index) => `${index + 1}. ${opt.label}`)
            .join('\n');
        await this.messagesService.create({
            chatId,
            type: message_entity_1.MessageType.TEXT,
            direction: message_entity_1.MessageDirection.OUTBOUND,
            senderType: message_entity_1.MessageSenderType.BOT,
            content: menuText,
        });
    }
    async executeInputNode(chatId, node) {
        const message = node.config.message || '¿Cuál es tu respuesta?';
        const chat = await this.chatsService.findOne(chatId);
        const session = this.sessions.get(chatId);
        const processedMessage = this.replaceVariables(message, session?.variables);
        try {
            const result = await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, processedMessage, message_entity_1.MessageType.TEXT);
            const savedMessage = await this.messagesService.create({
                chatId,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
                content: processedMessage,
                externalId: result.messageId,
            });
            await this.messagesService.updateStatus(savedMessage.id, message_entity_1.MessageStatus.SENT);
            this.logger.log(`📝 Bot solicitó input: "${processedMessage.substring(0, 50)}..."`);
        }
        catch (error) {
            this.logger.error(`Error enviando solicitud de input: ${error.message}`);
        }
        this.logger.log(`⏸️ Nodo INPUT alcanzado. Esperando respuesta del usuario...`);
    }
    async executeConditionNode(chatId, node) {
        const session = this.sessions.get(chatId);
        if (!session)
            return;
        const nextNodeId = this.handleCondition(node, session);
        if (nextNodeId) {
            session.currentNodeId = nextNodeId;
            this.sessions.set(chatId, session);
            await this.executeNode(chatId, nextNodeId);
        }
    }
    async executeApiCallNode(chatId, node) {
        this.logger.log('Ejecutando llamada API (no implementado)');
        if (node.nextNodeId) {
            const session = this.sessions.get(chatId);
            if (session) {
                session.currentNodeId = node.nextNodeId;
                await this.executeNode(chatId, node.nextNodeId);
            }
        }
    }
    async executeTransferNode(chatId, node) {
        this.logger.log(`Transfiriendo chat ${chatId} a agente humano`);
        const message = node.config.message || 'Perfecto, en un momento uno de nuestros asesores será asignado a tu caso para ayudarte con tu solicitud. ⏳\n\nPor favor espera un momento mientras te conectamos con un especialista.';
        const chat = await this.chatsService.findOne(chatId);
        const session = this.sessions.get(chatId);
        const processedMessage = this.replaceVariables(message, session?.variables);
        try {
            const result = await this.whatsappService.sendMessage(chat.whatsappNumber.id, chat.contactPhone, processedMessage, message_entity_1.MessageType.TEXT);
            const savedMessage = await this.messagesService.create({
                chatId,
                type: message_entity_1.MessageType.TEXT,
                direction: message_entity_1.MessageDirection.OUTBOUND,
                senderType: message_entity_1.MessageSenderType.BOT,
                content: processedMessage,
                externalId: result.messageId,
            });
            await this.messagesService.updateStatus(savedMessage.id, message_entity_1.MessageStatus.SENT);
            this.logger.log(`📤 Mensaje de transferencia enviado a ${chat.contactPhone}`);
        }
        catch (error) {
            this.logger.error(`Error enviando mensaje de transferencia: ${error.message}`);
        }
        await this.chatsService.update(chatId, {
            status: chat_entity_1.ChatStatus.ACTIVE,
            botContext: {
                ...session,
                transferredToAgent: true,
            },
        });
        this.logger.log(`✅ Chat ${chatId} transferido a estado ACTIVE - Esperando asignación de asesor`);
        this.sessions.delete(chatId);
    }
    async executeEndNode(chatId) {
        this.logger.log(`Finalizando flujo para chat ${chatId}`);
        await this.messagesService.create({
            chatId,
            type: message_entity_1.MessageType.TEXT,
            direction: message_entity_1.MessageDirection.OUTBOUND,
            senderType: message_entity_1.MessageSenderType.BOT,
            content: '¡Gracias por tu tiempo! Si necesitas más ayuda, no dudes en escribirnos.',
        });
        await this.chatsService.update(chatId, {
            status: chat_entity_1.ChatStatus.RESOLVED,
        });
        this.sessions.delete(chatId);
    }
    handleMenuInput(node, userInput) {
        const options = node.config.options || [];
        const inputNum = parseInt(userInput.trim());
        if (isNaN(inputNum) || inputNum < 1 || inputNum > options.length) {
            return null;
        }
        return options[inputNum - 1].nextNodeId;
    }
    async handleTextInput(node, userInput, session) {
        const variableName = node.config.variableName;
        const validation = node.config.validation;
        if (validation) {
            if (validation.required && !userInput.trim()) {
                await this.messagesService.create({
                    chatId: session.chatId,
                    type: message_entity_1.MessageType.TEXT,
                    direction: message_entity_1.MessageDirection.OUTBOUND,
                    senderType: message_entity_1.MessageSenderType.BOT,
                    content: validation.errorMessage || 'Este campo es requerido',
                });
                return null;
            }
            if (validation.pattern) {
                const regex = new RegExp(validation.pattern);
                if (!regex.test(userInput)) {
                    await this.messagesService.create({
                        chatId: session.chatId,
                        type: message_entity_1.MessageType.TEXT,
                        direction: message_entity_1.MessageDirection.OUTBOUND,
                        senderType: message_entity_1.MessageSenderType.BOT,
                        content: validation.errorMessage || 'Formato inválido',
                    });
                    return null;
                }
            }
        }
        if (variableName) {
            session.variables[variableName] = userInput;
            if (variableName === 'documento_validado' || variableName === 'documentNumber') {
                this.logger.log(`🔍 Capturado documento: ${userInput}, buscando deudor...`);
                const cleanDocument = userInput.replace(/[.\-\s]/g, '');
                const debtor = await this.debtorsService.findByDocument('CC', cleanDocument);
                if (debtor) {
                    session.variables.debtor = {
                        fullName: debtor.fullName,
                        documentType: debtor.documentType,
                        documentNumber: debtor.documentNumber,
                        phone: debtor.phone,
                        email: debtor.email || '[No disponible]',
                        debtAmount: debtor.debtAmount,
                        initialDebtAmount: debtor.initialDebtAmount,
                        daysOverdue: debtor.daysOverdue,
                        status: debtor.status,
                        lastPaymentDate: '[No disponible]',
                        producto: '[No disponible]',
                        numeroCredito: '[No disponible]',
                        fechaVencimiento: '[No disponible]',
                    };
                    if (debtor.lastPaymentDate) {
                        const paymentDate = debtor.lastPaymentDate;
                        if (paymentDate instanceof Date) {
                            session.variables.debtor.lastPaymentDate = paymentDate.toISOString().split('T')[0];
                        }
                        else if (typeof paymentDate === 'string') {
                            session.variables.debtor.lastPaymentDate = paymentDate.split('T')[0];
                        }
                    }
                    if (debtor.metadata) {
                        session.variables.debtor.producto = debtor.metadata.producto || '[No disponible]';
                        session.variables.debtor.numeroCredito = debtor.metadata.numeroCredito || '[No disponible]';
                        session.variables.debtor.fechaVencimiento = debtor.metadata.fechaVencimiento || '[No disponible]';
                    }
                    session.variables.debtorFound = true;
                    this.logger.log(`✅ Deudor encontrado: ${debtor.fullName} - CC ${debtor.documentNumber} - Deuda: $${debtor.debtAmount}`);
                    try {
                        const updateData = { debtorId: debtor.id };
                        if (debtor.campaignId) {
                            updateData.campaignId = debtor.campaignId;
                            this.logger.log(`🔄 Actualizando chat con deudor ${debtor.fullName} y campaña ${debtor.campaignId}`);
                        }
                        else {
                            this.logger.log(`🔄 Actualizando chat con deudor ${debtor.fullName}`);
                        }
                        await this.chatsService.update(session.chatId, updateData);
                    }
                    catch (error) {
                        this.logger.error(`Error actualizando chat con información del deudor: ${error.message}`);
                    }
                    await this.debtorsService.updateLastContacted(debtor.id);
                }
                else {
                    this.logger.warn(`❌ No se encontró deudor con documento: ${cleanDocument}`);
                    session.variables['debtorFound'] = false;
                }
            }
        }
        return node.nextNodeId;
    }
    handleCondition(node, session) {
        const conditions = node.config.conditions || [];
        const variableName = node.config.variable;
        this.logger.log(`🔍 Evaluando condición en nodo: ${node.name}`);
        this.logger.log(`   Variable a evaluar: ${variableName}`);
        this.logger.log(`   Variables disponibles:`, session.variables);
        const variableValue = session.variables[variableName];
        this.logger.log(`   Valor actual de "${variableName}": "${variableValue}"`);
        for (const condition of conditions) {
            this.logger.log(`   Evaluando: ${variableValue} ${condition.operator} ${condition.value}`);
            let matches = false;
            switch (condition.operator) {
                case 'equals':
                    matches = String(variableValue) === String(condition.value);
                    break;
                case 'contains':
                    matches = String(variableValue).includes(String(condition.value));
                    break;
                case 'contains_ignore_case':
                    matches = String(variableValue).toLowerCase().includes(String(condition.value).toLowerCase());
                    break;
                case 'greater':
                    matches = Number(variableValue) > Number(condition.value);
                    break;
                case 'less':
                    matches = Number(variableValue) < Number(condition.value);
                    break;
            }
            if (matches) {
                this.logger.log(`   ✅ Match encontrado! Siguiente nodo: ${condition.nextNodeId}`);
                return condition.nextNodeId;
            }
        }
        const fallbackNodeId = node.config.elseNodeId || node.nextNodeId;
        this.logger.log(`   ❌ Ninguna condición match. Usando fallback: ${fallbackNodeId}`);
        return fallbackNodeId;
    }
    initializeVariables(flow) {
        const variables = {};
        if (flow.variables) {
            Object.entries(flow.variables).forEach(([key, config]) => {
                variables[key] = config.defaultValue || null;
            });
        }
        return variables;
    }
    replaceVariables(text, variables) {
        if (!variables) {
            return text.replace(/\{\{([^}]+)\}\}/g, '[No disponible]');
        }
        let result = text;
        const regex = /\{\{([^}]+)\}\}/g;
        result = result.replace(regex, (match, path) => {
            const keys = path.split('.');
            let value = variables;
            for (const key of keys) {
                if (value && typeof value === 'object' && key in value) {
                    value = value[key];
                }
                else {
                    return '[No disponible]';
                }
            }
            if (typeof value === 'number') {
                if (value >= 1000) {
                    return value.toLocaleString('es-CO');
                }
            }
            return value != null ? String(value) : '[No disponible]';
        });
        return result;
    }
    hasActiveSession(chatId) {
        return this.sessions.has(chatId);
    }
    cleanInactiveSessions(maxInactivityMinutes = 30) {
        const now = new Date();
        this.sessions.forEach((session, chatId) => {
            const inactiveMinutes = (now.getTime() - session.lastActivityAt.getTime()) / 1000 / 60;
            if (inactiveMinutes > maxInactivityMinutes) {
                this.logger.log(`Limpiando sesión inactiva: ${chatId}`);
                this.sessions.delete(chatId);
            }
        });
    }
};
exports.BotEngineService = BotEngineService;
exports.BotEngineService = BotEngineService = BotEngineService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(bot_flow_entity_1.BotFlow)),
    __param(1, (0, typeorm_1.InjectRepository)(bot_node_entity_1.BotNode)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        messages_service_1.MessagesService,
        chats_service_1.ChatsService,
        whatsapp_service_1.WhatsappService,
        debtors_service_1.DebtorsService])
], BotEngineService);
//# sourceMappingURL=bot-engine.service.js.map