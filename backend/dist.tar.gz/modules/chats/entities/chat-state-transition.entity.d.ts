import { Chat } from './chat.entity';
import { User } from '../../users/entities/user.entity';
export declare class ChatStateTransition {
    id: string;
    chatId: string;
    chat: Chat;
    fromStatus: string;
    toStatus: string;
    fromSubStatus?: string;
    toSubStatus?: string;
    reason?: string;
    triggeredBy: 'system' | 'agent' | 'supervisor' | 'bot' | 'client';
    agentId?: string;
    agent?: User;
    metadata: Record<string, any>;
    createdAt: Date;
}
