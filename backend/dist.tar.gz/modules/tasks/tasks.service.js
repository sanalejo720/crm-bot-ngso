"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var TasksService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TasksService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const task_entity_1 = require("./entities/task.entity");
const event_emitter_1 = require("@nestjs/event-emitter");
const schedule_1 = require("@nestjs/schedule");
let TasksService = TasksService_1 = class TasksService {
    constructor(taskRepository, eventEmitter) {
        this.taskRepository = taskRepository;
        this.eventEmitter = eventEmitter;
        this.logger = new common_1.Logger(TasksService_1.name);
    }
    async create(createTaskDto, createdBy) {
        this.logger.log(`Creando tarea: ${createTaskDto.title}`);
        const task = this.taskRepository.create(createTaskDto);
        task.createdBy = { id: createdBy };
        const saved = await this.taskRepository.save(task);
        const savedTask = Array.isArray(saved) ? saved[0] : saved;
        this.eventEmitter.emit('task.created', savedTask);
        if (savedTask.assignedTo) {
            this.eventEmitter.emit('task.assigned', {
                task: savedTask,
                assignedTo: savedTask.assignedTo?.id || savedTask.assignedTo,
            });
        }
        return savedTask;
    }
    async findAll(filters) {
        const query = this.taskRepository.createQueryBuilder('task');
        if (filters?.assignedTo) {
            query.andWhere('task.assignedTo = :assignedTo', { assignedTo: filters.assignedTo });
        }
        if (filters?.createdBy) {
            query.andWhere('task.createdBy = :createdBy', { createdBy: filters.createdBy });
        }
        if (filters?.status) {
            query.andWhere('task.status = :status', { status: filters.status });
        }
        if (filters?.priority) {
            query.andWhere('task.priority = :priority', { priority: filters.priority });
        }
        if (filters?.clientId) {
            query.andWhere('task.clientId = :clientId', { clientId: filters.clientId });
        }
        if (filters?.campaignId) {
            query.andWhere('task.campaignId = :campaignId', { campaignId: filters.campaignId });
        }
        if (filters?.chatId) {
            query.andWhere('task.chatId = :chatId', { chatId: filters.chatId });
        }
        query
            .orderBy('task.priority', 'DESC')
            .addOrderBy('task.dueDate', 'ASC')
            .addOrderBy('task.createdAt', 'DESC');
        return query.getMany();
    }
    async findPendingByUser(userId) {
        return this.taskRepository.find({
            where: {
                assignedTo: { id: userId },
                status: task_entity_1.TaskStatus.PENDING,
            },
            order: {
                priority: 'DESC',
                dueDate: 'ASC',
            },
        });
    }
    async findOverdueByUser(userId) {
        return this.taskRepository
            .createQueryBuilder('task')
            .leftJoinAndSelect('task.assignedTo', 'user')
            .where('user.id = :userId', { userId })
            .andWhere('task.status = :status', { status: task_entity_1.TaskStatus.PENDING })
            .andWhere('task.dueDate < :now', { now: new Date() })
            .orderBy('task.priority', 'DESC')
            .addOrderBy('task.dueDate', 'ASC')
            .getMany();
    }
    async findOne(id) {
        const task = await this.taskRepository.findOne({
            where: { id },
            relations: ['client', 'campaign', 'chat'],
        });
        if (!task) {
            throw new common_1.NotFoundException(`Tarea ${id} no encontrada`);
        }
        return task;
    }
    async update(id, updateTaskDto) {
        const task = await this.findOne(id);
        Object.assign(task, updateTaskDto);
        const updatedTask = await this.taskRepository.save(task);
        this.eventEmitter.emit('task.updated', updatedTask);
        return updatedTask;
    }
    async updateStatus(id, status, completedBy) {
        const task = await this.findOne(id);
        const oldStatus = task.status;
        task.status = status;
        if (status === task_entity_1.TaskStatus.COMPLETED) {
            task.completedAt = new Date();
            task.completedBy = completedBy;
        }
        const updatedTask = await this.taskRepository.save(task);
        this.eventEmitter.emit('task.status-changed', {
            task: updatedTask,
            oldStatus,
            newStatus: status,
        });
        return updatedTask;
    }
    async assignTo(id, userId) {
        const task = await this.findOne(id);
        const oldAssignee = task.assignedTo;
        task.assignedTo = { id: userId };
        const updatedTask = await this.taskRepository.save(task);
        this.eventEmitter.emit('task.reassigned', {
            task: updatedTask,
            oldAssignee,
            newAssignee: userId,
        });
        return updatedTask;
    }
    async complete(id, completedBy) {
        return this.updateStatus(id, task_entity_1.TaskStatus.COMPLETED, completedBy);
    }
    async remove(id) {
        const task = await this.findOne(id);
        await this.taskRepository.softRemove(task);
        this.eventEmitter.emit('task.deleted', { taskId: id });
        this.logger.log(`Tarea ${id} eliminada`);
    }
    async getStats(userId) {
        const query = this.taskRepository.createQueryBuilder('task');
        if (userId) {
            query.where('task.assignedTo = :userId', { userId });
        }
        const total = await query.getCount();
        const pending = await query
            .clone()
            .andWhere('task.status = :status', { status: task_entity_1.TaskStatus.PENDING })
            .getCount();
        const completed = await query
            .clone()
            .andWhere('task.status = :status', { status: task_entity_1.TaskStatus.COMPLETED })
            .getCount();
        const overdue = await query
            .clone()
            .andWhere('task.status = :status', { status: task_entity_1.TaskStatus.PENDING })
            .andWhere('task.dueDate < :now', { now: new Date() })
            .getCount();
        const byPriority = await query
            .clone()
            .select('task.priority', 'priority')
            .addSelect('COUNT(*)', 'count')
            .groupBy('task.priority')
            .getRawMany();
        return {
            total,
            pending,
            completed,
            overdue,
            completionRate: total > 0 ? ((completed / total) * 100).toFixed(2) : 0,
            byPriority: byPriority.reduce((acc, item) => {
                acc[item.priority] = parseInt(item.count);
                return acc;
            }, {}),
        };
    }
    async notifyOverdueTasks() {
        this.logger.log('Verificando tareas vencidas...');
        const overdueTasks = await this.taskRepository.find({
            where: {
                status: task_entity_1.TaskStatus.PENDING,
                dueDate: (0, typeorm_2.LessThan)(new Date()),
            },
        });
        for (const task of overdueTasks) {
            this.eventEmitter.emit('task.overdue', task);
        }
        this.logger.log(`${overdueTasks.length} tareas vencidas notificadas`);
    }
    async notifyUpcomingTasks() {
        this.logger.log('Verificando tareas próximas...');
        const tomorrow = new Date();
        tomorrow.setHours(tomorrow.getHours() + 24);
        const upcomingTasks = await this.taskRepository
            .createQueryBuilder('task')
            .where('task.status = :status', { status: task_entity_1.TaskStatus.PENDING })
            .andWhere('task.dueDate > :now', { now: new Date() })
            .andWhere('task.dueDate <= :tomorrow', { tomorrow })
            .getMany();
        for (const task of upcomingTasks) {
            this.eventEmitter.emit('task.reminder', task);
        }
        this.logger.log(`${upcomingTasks.length} recordatorios de tareas enviados`);
    }
};
exports.TasksService = TasksService;
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_HOUR),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TasksService.prototype, "notifyOverdueTasks", null);
__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_6_HOURS),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TasksService.prototype, "notifyUpcomingTasks", null);
exports.TasksService = TasksService = TasksService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(task_entity_1.Task)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        event_emitter_1.EventEmitter2])
], TasksService);
//# sourceMappingURL=tasks.service.js.map