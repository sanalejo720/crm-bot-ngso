"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateWhatsappNumberDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const create_whatsapp_number_dto_1 = require("./create-whatsapp-number.dto");
class UpdateWhatsappNumberDto extends (0, swagger_1.PartialType)(create_whatsapp_number_dto_1.CreateWhatsappNumberDto) {
}
exports.UpdateWhatsappNumberDto = UpdateWhatsappNumberDto;
//# sourceMappingURL=update-whatsapp-number.dto.js.map