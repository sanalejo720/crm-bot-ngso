import { CreateWhatsappNumberDto } from './create-whatsapp-number.dto';
declare const UpdateWhatsappNumberDto_base: import("@nestjs/common").Type<Partial<CreateWhatsappNumberDto>>;
export declare class UpdateWhatsappNumberDto extends UpdateWhatsappNumberDto_base {
}
export {};
