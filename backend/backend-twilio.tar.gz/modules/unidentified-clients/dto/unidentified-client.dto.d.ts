import { UnidentifiedClientStatus } from '../entities/unidentified-client.entity';
export declare class CreateUnidentifiedClientDto {
    phone: string;
    name?: string;
    documentType?: string;
    documentNumber?: string;
    notes?: string;
    chatId?: string;
    assignedToId?: string;
    metadata?: any;
}
declare const UpdateUnidentifiedClientDto_base: import("@nestjs/common").Type<Partial<CreateUnidentifiedClientDto>>;
export declare class UpdateUnidentifiedClientDto extends UpdateUnidentifiedClientDto_base {
}
export declare class UpdateStatusDto {
    status: UnidentifiedClientStatus;
    notes?: string;
}
export {};
