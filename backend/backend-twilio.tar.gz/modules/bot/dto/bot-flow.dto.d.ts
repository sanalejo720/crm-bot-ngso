import { BotFlowStatus } from '../entities/bot-flow.entity';
export declare class CreateBotFlowDto {
    name: string;
    description?: string;
    status?: BotFlowStatus;
    startNodeId?: string;
    variables?: Record<string, any>;
    settings?: {
        maxInactivityTime?: number;
        transferToAgentOnError?: boolean;
        fallbackMessage?: string;
    };
}
export declare class UpdateBotFlowDto {
    name?: string;
    description?: string;
    status?: BotFlowStatus;
    startNodeId?: string;
    variables?: Record<string, any>;
    settings?: Record<string, any>;
}
export declare class CreateBotNodeDto {
    name: string;
    type: string;
    config: Record<string, any>;
    nextNodeId?: string;
    positionX?: number;
    positionY?: number;
}
export declare class UpdateBotNodeDto {
    name?: string;
    type?: string;
    config?: Record<string, any>;
    nextNodeId?: string;
    positionX?: number;
    positionY?: number;
}
export declare class BulkCreateNodesDto {
    nodes: CreateBotNodeDto[];
}
