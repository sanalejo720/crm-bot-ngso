import { BotFlowsService } from './bot-flows.service';
import { CreateBotFlowDto, UpdateBotFlowDto, CreateBotNodeDto, UpdateBotNodeDto, BulkCreateNodesDto } from './dto/bot-flow.dto';
export declare class BotFlowsController {
    private readonly botFlowsService;
    constructor(botFlowsService: BotFlowsService);
    findAll(status?: string, page?: number, limit?: number): Promise<{
        message: string;
        data: import("./entities/bot-flow.entity").BotFlow[];
        meta: {
            page: number;
            limit: number;
            total: number;
            totalPages: number;
        };
    }>;
    findOne(id: string): Promise<{
        message: string;
        data: import("./entities/bot-flow.entity").BotFlow;
    }>;
    create(createDto: CreateBotFlowDto): Promise<{
        message: string;
        data: import("./entities/bot-flow.entity").BotFlow;
    }>;
    update(id: string, updateDto: UpdateBotFlowDto): Promise<{
        message: string;
        data: import("./entities/bot-flow.entity").BotFlow;
    }>;
    remove(id: string): Promise<void>;
    duplicate(id: string): Promise<{
        message: string;
        data: import("./entities/bot-flow.entity").BotFlow;
    }>;
    publish(id: string): Promise<{
        message: string;
        data: import("./entities/bot-flow.entity").BotFlow;
    }>;
    createNode(flowId: string, createDto: CreateBotNodeDto): Promise<{
        message: string;
        data: import("./entities/bot-node.entity").BotNode;
    }>;
    createNodesBulk(flowId: string, bulkDto: BulkCreateNodesDto): Promise<{
        message: string;
        data: import("./entities/bot-node.entity").BotNode[];
    }>;
    updateNode(flowId: string, nodeId: string, updateDto: UpdateBotNodeDto): Promise<{
        message: string;
        data: import("./entities/bot-node.entity").BotNode;
    }>;
    removeNode(flowId: string, nodeId: string): Promise<void>;
    getStats(id: string): Promise<{
        message: string;
        data: any;
    }>;
}
