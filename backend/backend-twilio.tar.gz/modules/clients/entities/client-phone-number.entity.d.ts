import { Client } from '../../clients/entities/client.entity';
export declare class ClientPhoneNumber {
    id: string;
    clientId: string;
    client: Client;
    phoneNumber: string;
    isPrimary: boolean;
    isActive: boolean;
    notes: string;
    createdAt: Date;
    updatedAt: Date;
    lastContactAt: Date;
}
